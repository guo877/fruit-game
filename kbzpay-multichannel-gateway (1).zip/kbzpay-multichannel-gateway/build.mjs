/**
 * 单文件打包器
 * ------------------------------------------------------------
 * Cloudflare 后台的「粘贴代码」方式只接受单个文件，而源码拆成多个模块更易维护。
 * 本脚本把 src/i18n.js + src/core.js + src/engine.js + src/plug.js + src/api.js + src/pages.js + worker.js 按依赖顺序
 * 合并成 dist/index.js（单文件，可直接粘贴部署）。
 *
 * 用法：node build.mjs   （或 npm run build）
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.dirname(fileURLToPath(import.meta.url))
const ORDER = ['src/i18n.js', 'src/core.js', 'src/engine.js', 'src/plug.js', 'src/api.js', 'src/pages.js', 'worker.js']

function stripModuleSyntax(code, keepDefaultExport) {
  // 去掉相对路径 import
  code = code.replace(/^[ \t]*import\s+[^;\n]*?from\s*['"]\.[^'"]*['"];?[ \t]*$/gm, '')
  // 去掉 import './x.js' 这种副作用导入
  code = code.replace(/^[ \t]*import\s*['"]\.[^'"]*['"];?[ \t]*$/gm, '')
  // 去掉 re-export { ... }
  code = code.replace(/^[ \t]*export\s*\{[^}]*\}[ \t]*;?[ \t]*$/gm, '')
  if (!keepDefaultExport) {
    // export default -> 保留在最后一个文件里
    code = code.replace(/^([ \t]*)export\s+default\s+/gm, '$1var __default_export = ')
  }
  // export const/let/var/function/async/class -> 去掉 export 关键字
  code = code.replace(/^([ \t]*)export\s+(?=(const|let|var|function|async|class)\b)/gm, '$1')
  return code
}

let out = ''
out += '/* eslint-disable */\n'
out += '/* ==========================================================================\n'
out += ' * 缅甸多平台收付款多级分管通道系统 —— 单文件部署版（自动生成，请勿直接修改）\n'
out += ' * 源码：src/i18n.js + src/core.js + src/engine.js + src/plug.js + src/api.js + src/pages.js + worker.js\n'
out += ' * 重新生成：node build.mjs\n'
out += ' * ========================================================================== */\n'

for (const rel of ORDER) {
  const abs = path.join(root, rel)
  if (!fs.existsSync(abs)) {
    console.error('[build] 缺少源文件：' + rel)
    process.exit(1)
  }
  const isLast = rel === ORDER[ORDER.length - 1]
  const code = stripModuleSyntax(fs.readFileSync(abs, 'utf8'), isLast)
  out += '\n/* ===== ' + rel + ' ===== */\n' + code.trim() + '\n'
}

if (ORDER[ORDER.length - 1] !== 'worker.js' || !/export\s+default\s/.test(fs.readFileSync(path.join(root, 'worker.js'), 'utf8'))) {
  console.error('[build] worker.js 必须保留 export default { fetch }')
  process.exit(1)
}

const distDir = path.join(root, 'dist')
fs.mkdirSync(distDir, { recursive: true })
const target = path.join(distDir, 'index.js')
fs.writeFileSync(target, out)
console.log('[build] 已生成单文件：dist/index.js  (' + out.length + ' 字节)')
console.log('[build] 部署方式：')
console.log('        A. wrangler deploy           （使用 main = worker.js，多模块自动打包）')
console.log('        B. 复制 dist/index.js 内容粘贴到 Cloudflare Workers 在线编辑器')