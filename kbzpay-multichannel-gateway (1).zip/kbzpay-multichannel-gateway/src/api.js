/* =============================================================================
 * HTTP 接口层（api.js）
 * -----------------------------------------------------------------------------
 * 职责：路由分发 / 地区锁定 / 登录鉴权 / 数据域校验 / 页面与 SDK 下发
 * 说明：所有需要登录的接口都会先做「归属可见性」校验，越权一律返回 404。
 * ========================================================================== */

import { jsonResponse, htmlResponse, toInt, safeStr, nowIso, randomToken, hashPassword, sha256hex, timingSafeEqual, kvGet, kvPut, kvDel, ensureSeed, getConfig, setConfig, publicConfig, getUser, listUsers, publicUser, createUser, updateUser, disableUser, visibleOwnerIds, canAccessOwner, isDescendantOf, login, logout, authenticate, ledgerList, ledgerVerify, getStats, addAudit, listAudit, listChannels, createChannel, updateChannel, replaceChannel, deleteChannel, httpError, regionGate, getPool, poolLedgerList, getDeposit, listDeposits, applyDepositDefault, setupStatus, setupSuperAdmin, superAdminInitialized, verifyApiSignature, rateLimitCheck, idempotentLookup, idempotentRemember, guardReplay, publicChannel, maskAccount, verifyAuditChain, listSessions, revokeSession, hashIp } from './core.js'
import { createOrder, listOrders, findOrderById, getOrderByToken, cancelOrder, refundOrder, submitProof, settleOrder, matchIncoming, ingestReconcile, requestPayout, listPayouts, approvePayout, rejectPayout, executorPull, executorReceipt, listDevices, createDevice, deleteDevice, resolveDevice, listAdapters, createAdapter, deleteAdapter, handleAdapterCallback, handleGameCallback, listWebhooks, retryWebhook, runWebhooks, setPoolAccounts, depositTopup, applyPenalty, resolvePenalty, appealPenalty, refundDeposit, chargeRental, listRentals, listPenalties, buildTree, overview, deliverOrder, confirmReceive, confirmReceiveByToken, deliveryOfToken, publicOrder, autoReceiveSweep, STAGE_TEXT, platformAccount, PLATFORM_ID, rentalBoard, registerGameId, listGameIds, createGamePointOrder, listGamePointOrders, getGamePointOrder, cancelGamePointOrder, rollbackGamePointOrder, gameExecutorPull, gameExecutorReceipt, GAME_DIRECTION_TEXT, GAME_STATUS_TEXT, runMaintenance, maintenanceStatus, listUnmatched, matchUnmatched } from './engine.js'
import { PLUG_MANIFEST, PLUG_VERSION, PLUG_TEMPLATES, PLUG_CONNECTOR_CODE, plugPair, plugAuth, plugInfo, plugCreateOrderViaPlug, plugNotifyViaPlug, plugPullViaPlug, plugCreatePairingCode, plugListPairingCodes, plugRevokePairingCode, plugRotateKey, plugCreateAdapterProfile, plugGetProfile, plugListPoints, plugConnectionTest, plugParseCaptured, plugQuickStart, plugTemplateById, plugMaskKey, plugKeyOf, plugNormCode } from './plug.js'

import { LANDING_PAGE, CONSOLE_PAGE, SETUP_PAGE, PAY_PAGE, REGION_BLOCK_PAGE, SDK_CODE, PLUG_PAGE } from './pages.js'

/**
 * 响应头（统一安全基线 + CORS 策略）
 * - 未登录的公开接入面（收银台 / 回调 / 插件 / 清单）保持 `*`，方便任意平台直接调用；
 * - 已登录的 /api/ 面仅回显同源 Origin（浏览器跨站脚本无法携带他人登录态读取数据），
 *   无 Origin 的非浏览器客户端（curl / 服务端）不下发该头，不影响直连。
 */
export function corsHeaders(origin, authed) {
  const o = (origin && origin !== 'null') ? String(origin) : ''
  const h = {
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Merchant-Key, X-Device-Key, X-Signature, X-Timestamp, X-Nonce, X-Idempotency-Key',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
    // —— 通用安全响应头（对所有响应生效）——
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'; form-action 'self'",
  }
  if (!authed) h['Access-Control-Allow-Origin'] = '*'
  else if (o) h['Access-Control-Allow-Origin'] = o
  return h
}

/** /api/pay/ 下的保留字：这些是固定功能路由，不是订单 token */
const RESERVED_PAY_SEGMENTS = { confirm: 1, init: 1, delivery: 1, receive: 1, status: 1 }

/** 站点基址：用于生成回调地址、连接器链接与清单里的绝对地址 */
function baseOrigin(url) {
  return (url && url.origin && url.origin !== 'null') ? url.origin : (String(url.protocol || 'https:') + '//' + String(url.host || ''))
}

function tokenOf(request, url) {
  const h = request.headers.get('Authorization') || ''
  if (h.toLowerCase().indexOf('bearer ') === 0) return capToken(h.slice(7).trim())
  const cookie = request.headers.get('Cookie') || ''
  const m = /(?:^|;\s*)kbz_token=([^;]+)/.exec(cookie)
  if (m) return capToken(decodeURIComponent(m[1]))
  return capToken(url.searchParams.get('token') || '')
}

/** 登录态 / 订单 token 长度上限：异常超长串直接截断，避免被当作超长 KV 键使用 */
function capToken(t) {
  return String(t || '').slice(0, 200)
}

async function requireUser(env, request, url) {
  const u = await authenticate(env, tokenOf(request, url))
  if (!u) throw httpError(401, '未登录或登录已过期')
  return u
}

async function requireSuper(env, request, url) {
  const u = await requireUser(env, request, url)
  if (u.role !== 'super') throw httpError(403, '仅超级管理员可操作')
  return u
}

/* 公开接入面加固参数 */
const MAX_BODY_BYTES = 2 * 1024 * 1024 // 请求体上限（2 MB）：够装收银台截图 data URL，又能挡住超大报文体拖垮边缘节点
const MAX_BATCH_ROWS = 200             // 单次批量上报条数上限：防止单个请求塞入海量流水打满边缘算力与 KV 写入

/** 读取请求体并施加体积上限：超限直接 413，不做任何解析 */
async function readBody(request, maxBytes) {
  const raw = await request.text()
  const max = toInt(maxBytes, MAX_BODY_BYTES) || MAX_BODY_BYTES
  if (raw && raw.length > max) throw httpError(413, '请求体过大（上限 ' + Math.round(max / 1024) + ' KB）')
  return raw
}

/** 列表查询条数上限：把调用方传入的 limit 夹到安全区间，防止超大 limit 触发海量 KV 读取（读放大 / 算力耗尽） */
const MAX_LIST_LIMIT = 2000
function qLimit(sp, def, max) {
  const d = toInt(def, 200)
  const m = toInt(max, MAX_LIST_LIMIT) || MAX_LIST_LIMIT
  const v = toInt(sp.get('limit'), d)
  if (!v || v <= 0) return d > m ? m : d
  return v > m ? m : v
}

/**
 * 公开接入面（免登录）入口限流：按「入口 + 来源 IP」计数。
 * 目的：密钥/配对码枚举、PBKDF2 类计算接口被刷、公开收银台被恶意刷单，
 * 均在这一层被挡住；正常客户端远达不到上限，不影响业务。
 */
async function publicGuard(env, request, scope, cfg) {
  const c = cfg || await getConfig(env)
  const limit = (c && c.publicRateLimitPerMin !== undefined) ? c.publicRateLimitPerMin : 240
  const ip = safeStr(request.headers.get('CF-Connecting-IP') || request.headers.get('X-Forwarded-For') || '', 60) || 'anon'
  return await rateLimitCheck(env, 'pub:' + scope + ':' + ip, limit)
}

async function jsonBody(request) {
  const t = await readBody(request)
  try { return t ? JSON.parse(t) : {} } catch (e) { return {} }
}

export async function handleRequest(request, env, ctx) {
  const url = new URL(request.url)
  const path = url.pathname
  const method = request.method
  // CORS 收紧：凡是「携带登录态」的请求（Bearer / Cookie / ?token=）一律按已登录面处理，
  //   仅当 Origin 与本服务同源时回显；跨站页面即使能触发请求，浏览器也读不到响应体（无 ACAO）。
  //   未携带登录态的公开接入面（收银台 / 回调 / 插件 / 清单）保持 `*`，方便任意平台直接调用。
  const origin = request.headers.get('Origin') || ''
  const carriesToken = !!(request.headers.get('Authorization') ||
    /(?:^|;\s*)kbz_token=/.test(request.headers.get('Cookie') || '') ||
    url.searchParams.get('token'))
  const cors = corsHeaders(carriesToken && origin && origin === url.origin ? origin : '', carriesToken)

  if (method === 'OPTIONS') return new Response(null, { status: 204, headers: cors })

  try {
    await ensureSeed(env)
    const cfg = await getConfig(env)

    // ---- 请求体体积上限（先于一切解析，避免超大报文被反复读取） ----
    if (toInt(request.headers.get('Content-Length'), 0) > MAX_BODY_BYTES) {
      return jsonResponse({ success: false, error: '请求体过大（上限 ' + Math.round(MAX_BODY_BYTES / 1024) + ' KB）' }, 413, cors)
    }

    // ---- 地区锁定（仅缅甸） ----
    const interactive = path === '/' || path === '/console' || path === '/login' || path === '/admin' || path === '/setup' || path === '/pay' || path === '/plug' || path === '/kbz-plug.js' || path === '/kbz-plug.min.js' || path.indexOf('/.well-known/') === 0 || path.indexOf('/api/') === 0
    if (interactive) {
      const gate = regionGate(request, cfg)
      if (!gate.allowed) {
        if (path.indexOf('/api/') === 0) {
          return jsonResponse({ success: false, error: '本系统仅限缅甸地区使用', code: 'REGION_BLOCKED', country: gate.country }, 403, cors)
        }
        return htmlResponse(REGION_BLOCK_PAGE(gate.country), 403, cors)
      }
    }

    /* ======================= 静态页面 / SDK ======================= */
    if (method === 'GET' && (path === '/' || path === '/index.html')) return htmlResponse(LANDING_PAGE(cfg, url), 200, cors)
    if (method === 'GET' && (path === '/console' || path === '/login' || path === '/console.html')) return htmlResponse(CONSOLE_PAGE(cfg), 200, cors)
    // 超管唯一入口：未完成首次设密 → 展示设密表单；已完成 → 展示超管登录台
    if (method === 'GET' && (path === '/admin' || path === '/setup')) {
      const st = await setupStatus(env)
      if (!st.initialized) return htmlResponse(SETUP_PAGE(cfg, st), 200, cors)
      return htmlResponse(CONSOLE_PAGE(cfg, { adminEntry: true }), 200, cors)
    }
    if (method === 'GET' && path === '/pay') return htmlResponse(PAY_PAGE(cfg), 200, cors)
    if (method === 'GET' && (path === '/sdk.js' || path === '/kbz-sdk.js')) {
      return new Response(SDK_CODE, { headers: Object.assign({ 'Content-Type': 'application/javascript; charset=utf-8' }, cors) })
    }
    if (method === 'GET' && path === '/health') return jsonResponse({ ok: true, name: cfg.gatewayName, version: cfg.version, ts: nowIso() }, 200, cors)

    /* ======================= 公开接口 ======================= */
    if (path === '/api/config' && method === 'GET') {
      return jsonResponse({ success: true, config: await publicConfig(env) }, 200, cors)
    }
    if (path === '/api/region/check' && method === 'GET') {
      const g = regionGate(request, cfg)
      return jsonResponse({ success: true, allowed: g.allowed, country: g.country, mode: g.mode }, 200, cors)
    }
    /* ---- 超管唯一入口：首次设密（第一个输入的密码即唯一超管密码） ---- */
    if (path === '/api/setup/status' && method === 'GET') {
      const st = await setupStatus(env)
      return jsonResponse({ success: true, ...st }, 200, cors)
    }
    if (path === '/api/setup/admin' && method === 'POST') {
      await publicGuard(env, request, 'setup', cfg)   // 设密为一次性入口，仍按来源 IP 限流（防被刷 CPU 密集的 PBKDF2）
      const b = await jsonBody(request)
      const r = await setupSuperAdmin(env, b)
      // 设密成功即签发登录态，直接进入后台，免二次输入
      const lr = await login(env, r.profile.username, b.password, { ip: request.headers.get('CF-Connecting-IP'), ua: request.headers.get('User-Agent') })
      return jsonResponse({ success: true, profile: r.profile, token: lr.token, expiresInSec: lr.expiresInSec }, 200, cors)
    }
    if (path === '/api/auth/login' && method === 'POST') {
      await publicGuard(env, request, 'login', cfg)   // 按来源 IP 限流：挡住「换账号喷洒」绕过账号级锁定的猜解
      const b = await jsonBody(request)
      const r = await login(env, b.username, b.password, { ip: request.headers.get('CF-Connecting-IP'), ua: request.headers.get('User-Agent') })
      return jsonResponse({ success: true, ...r }, 200, cors)
    }
    if (path === '/api/auth/logout' && method === 'POST') {
      await logout(env, tokenOf(request, url))
      return jsonResponse({ success: true }, 200, cors)
    }
    if (path === '/api/auth/me' && method === 'GET') {
      const u = await requireUser(env, request, url)
      return jsonResponse({ success: true, profile: publicUser(u, { full: true }), isSuper: u.role === 'super' }, 200, cors)
    }

    // 商户系统查询订单状态（X-Merchant-Key，无需登录态）
    let m = /^\/api\/pay\/status\/([A-Za-z0-9_]+)$/.exec(path)
    if (m && method === 'GET') {
      await publicGuard(env, request, 'pstatus', cfg)   // 商户密钥查询：按来源 IP 限流，挡住密钥枚举
      const mu = await userByMerchantKey(env, request)
      if (!mu) return jsonResponse({ success: false, error: '无效的商户密钥' }, 401, cors)
      const o = await findOrderById(env, mu, m[1])
      if (!o) return jsonResponse({ success: false, error: '订单不存在' }, 404, cors)
      return jsonResponse({ success: true, order: publicOrderPayload(o, cfg, mu.id) }, 200, cors)
    }
    // 托管收银台：按 token 取付款信息（公开）
    m = /^\/api\/pay\/([a-z0-9]+)$/.exec(path)
    if (m && method === 'GET' && !RESERVED_PAY_SEGMENTS[m[1]]) {
      await publicGuard(env, request, 'payview', cfg)   // 收银台按 token 公开取单：按来源 IP 限流，挡住 token 枚举
      const o = await getOrderByToken(env, m[1])
      if (!o) return jsonResponse({ success: false, error: '订单不存在或已过期' }, 404, cors)
      return jsonResponse({ success: true, order: publicOrderPayload(o, cfg) }, 200, cors)
    }
    if (path === '/api/pay/confirm' && method === 'POST') {
      await publicGuard(env, request, 'confirm', cfg)   // 公开提交付款凭证：按来源 IP 限流，挡住恶意刷单刷存储
      const b = await jsonBody(request)
      const r = await submitProof(env, safeStr(b.token, 40), b)
      // 公开收银台：调用方持订单 token（即买家本人），按买家视角返回（可见应付金额与收款账号）
      return jsonResponse({ success: true, order: publicOrderPayload(r.order, cfg) }, 200, cors)
    }
    // 买家查询发货凭据（卡密 / 物流单号 / 游戏发货状态，持 token 公开可取）
    if (path === '/api/pay/delivery' && method === 'GET') {
      await publicGuard(env, request, 'delivery', cfg)
      const t = url.searchParams.get('t') || url.searchParams.get('token') || ''
      const r = await deliveryOfToken(env, t)
      return jsonResponse({ success: true, ...r }, 200, cors)
    }
    // 买家确认收货 → 自动转款到户（持订单 token，无需登录）
    if (path === '/api/pay/receive' && method === 'POST') {
      await publicGuard(env, request, 'receive', cfg)
      const b = await jsonBody(request)
      const o = await confirmReceiveByToken(env, b.token, b)
      return jsonResponse({ success: true, order: o }, 200, cors)
    }
    // 商户服务端下单（服务端 API 接入）：签名 + 防重放 + 限流 + 幂等（重复提交不重复建单）
    if (path === '/api/pay/init' && method === 'POST') {
      await publicGuard(env, request, 'payinit', cfg)
      const raw = await readBody(request)
      const b = parseJsonSafe(raw)
      const key = request.headers.get('X-Merchant-Key') || ''
      const user = await userByMerchantKey(env, request)
      if (!user) return jsonResponse({ success: false, error: '无效的商户密钥' }, 401, cors)
      const gate = await gateInbound(env, request, user, path, raw, { scope: 'payinit', secret: key })
      if (!gate.ok) return jsonResponse(gate.body, gate.status, cors)
      const o = await createOrder(env, user, b)
      const payload = { order: publicOrderPayload(o, cfg, user.id) }
      await rememberIdempotent(env, 'payinit', user.id, gate.idemKey, payload)
      return jsonResponse({ success: true, order: payload.order }, 200, cors)
    }

    /* ======================= 设备接口（通知转发端 / 出款执行端） ======================= */
    if (path === '/api/notify/forward' && method === 'POST') {
      const raw = await readBody(request)
      const b = parseJsonSafe(raw)
      const dev = await requireDevice(env, request)
      const gate = await gateInbound(env, request, dev, path, raw, { scope: 'notify', secret: request.headers.get('X-Device-Key') || '' })
      if (!gate.ok) return jsonResponse(gate.body, gate.status, cors)
      const rows = Array.isArray(b.rows) ? b.rows : [b]
      if (rows.length > MAX_BATCH_ROWS) throw httpError(413, '单次上报条数超限（上限 ' + MAX_BATCH_ROWS + ' 条），请分批上报')
      const results = []
      for (const row of rows) results.push(await matchIncoming(env, row))
      return jsonResponse({ success: true, device: dev.id, results: results }, 200, cors)
    }
    if (path === '/api/reconcile/ingest' && method === 'POST') {
      const raw = await readBody(request)
      const dev = await requireDevice(env, request)
      const gate = await gateInbound(env, request, dev, path, raw, { scope: 'reconcile', secret: request.headers.get('X-Device-Key') || '' })
      if (!gate.ok) return jsonResponse(gate.body, gate.status, cors)
      const b = parseJsonSafe(raw)
      const rows = Array.isArray(b.rows) ? b.rows : []
      if (rows.length > MAX_BATCH_ROWS) throw httpError(413, '单次上报条数超限（上限 ' + MAX_BATCH_ROWS + ' 条），请分批上报')
      const r = await ingestReconcile(env, rows)
      return jsonResponse({ success: true, ...r }, 200, cors)
    }
    if (path === '/api/payout/executor/pull' && method === 'GET') {
      const dev = await requireDevice(env, request)
      const r = await executorPull(env, dev)
      return jsonResponse({ success: true, ...r }, 200, cors)
    }
    if (path === '/api/payout/executor/receipt' && method === 'POST') {
      const raw = await readBody(request)
      const dev = await requireDevice(env, request)
      const gate = await gateInbound(env, request, dev, path, raw, { scope: 'exereceipt', secret: request.headers.get('X-Device-Key') || '' })
      if (!gate.ok) return jsonResponse(gate.body, gate.status, cors)
      const b = parseJsonSafe(raw)
      const r = await executorReceipt(env, dev, b)
      return jsonResponse({ success: true, ...r }, 200, cors)
    }

    /* ======================= 适配器回调（持牌通道 / 第三方平台） ======================= */
    m = /^\/api\/adapter\/callback\/([A-Za-z0-9_]+)$/.exec(path)
    if (m && method === 'POST') {
      const raw = await readBody(request)
      await rateLimitCheck(env, 'adpcb:' + m[1])
      try {
        const r = await handleAdapterCallback(env, m[1], raw, request.headers)
        return jsonResponse({ success: true, ...r }, 200, cors)
      } catch (e) {
        if (e && e.status === 401) await addAudit(env, 'system', 'callback.reject', { kind: 'adapter', adapterId: m[1], reason: e.message })
        throw e
      }
    }
    /* ======================= 游戏发货回执（平台发币完成后回调） ======================= */
    m = /^\/api\/game\/callback\/([A-Za-z0-9_]+)$/.exec(path)
    if (m && method === 'POST') {
      const raw = await readBody(request)
      await rateLimitCheck(env, 'gamecb:' + m[1])
      try {
        const r = await handleGameCallback(env, m[1], raw, request.headers)
        return jsonResponse({ success: true, ...r }, 200, cors)
      } catch (e) {
        if (e && e.status === 401) await addAudit(env, 'system', 'callback.reject', { kind: 'game', adapterId: m[1], reason: e.message })
        throw e
      }
    }

    /* ======================= 零文档即插即用接入层（plug，公开免登录） ======================= */
    // 自描述清单：机器可读，脚本 / AI 可据此自动完成对接（接入方无需阅读任何文档）
    if (path === '/api/plug/manifest' && method === 'GET') {
      return jsonResponse(PLUG_MANIFEST(baseOrigin(url), cfg), 200, cors)
    }
    // 同一清单的标准发现入口（便于脚本自动探测）
    if (path === '/.well-known/kbz-connect.json' && method === 'GET') {
      return jsonResponse(PLUG_MANIFEST(baseOrigin(url), cfg), 200, cors)
    }
    // 单文件连接器：端点自发现 / 字段自动映射 / 失败重试
    if (method === 'GET' && (path === '/kbz-plug.js' || path === '/kbz-plug.min.js')) {
      return new Response(PLUG_CONNECTOR_CODE, {
        status: 200,
        headers: Object.assign({ 'Content-Type': 'application/javascript; charset=utf-8', 'Cache-Control': 'public, max-age=300' }, cors),
      })
    }
    // 三语接入向导页（?lang=zh|my|en）
    if (method === 'GET' && path === '/plug') return htmlResponse(PLUG_PAGE(cfg, url), 200, cors)
    // 一键配对：用后台生成的配对码换取接入凭据（适配器 + 接入密钥 + 开箱即用代码）
    if (path === '/api/plug/pair' && method === 'POST') {
      await publicGuard(env, request, 'pair', cfg)   // 配对码换取凭据：按来源 IP 限流，挡住配对码枚举
      const raw = await readBody(request)
      const r = await plugPair(env, parseJsonSafe(raw), baseOrigin(url))
      return jsonResponse({ success: true, ...r }, 200, cors)
    }
    // 通用入口：/api/plug/:adapterId/{order,notify,pull,info}（接入密钥 / HMAC 签名双通道鉴权）
    m = /^\/api\/plug\/([A-Za-z0-9_]+)\/(order|notify|pull|info)$/.exec(path)
    if (m && (method === 'POST' || method === 'GET')) {
      const raw = method === 'POST' ? await readBody(request) : ''
      const authz = await plugAuth(env, request, url, m[1], raw)
      const adp = authz.adapter
      const base = baseOrigin(url)
      if (m[2] === 'info') return jsonResponse({ success: true, info: plugInfo(adp, base) }, 200, cors)
      if (m[2] === 'pull') {
        const ref = url.searchParams.get('ref') || url.searchParams.get('orderNo') || url.searchParams.get('orderId') || ''
        const r = await plugPullViaPlug(env, adp, ref, url.searchParams.get('token') || '', base)
        return jsonResponse({ success: true, ...r }, 200, cors)
      }
      if (m[2] === 'order') {
        const idemKey = safeStr(request.headers.get('X-Idempotency-Key'), 80)
        if (idemKey) {
          const hit = await idempotentLookup(env, 'plugorder', adp.id + ':' + idemKey)
          if (hit.hit) return jsonResponse({ success: true, idempotent: true, ...hit.hit }, 200, cors)
        }
        const r = await plugCreateOrderViaPlug(env, adp, parseJsonSafe(raw), base)
        await idempotentRemember(env, 'plugorder', adp.id + ':' + idemKey, r)
        return jsonResponse({ success: true, ...r }, 200, cors)
      }
      const r = await plugNotifyViaPlug(env, adp, parseJsonSafe(raw), base)
      return jsonResponse({ success: true, ...r }, 200, cors)
    }

    /* ======================= 游戏上分 / 下分执行端（设备密钥） ======================= */
    if (path === '/api/game/executor/pull' && method === 'GET') {
      const dev = await requireDevice(env, request)
      const r = await gameExecutorPull(env, dev)
      return jsonResponse({ success: true, ...r }, 200, cors)
    }
    if (path === '/api/game/executor/receipt' && method === 'POST') {
      const raw = await readBody(request)
      const dev = await requireDevice(env, request)
      const gate = await gateInbound(env, request, dev, path, raw, { scope: 'gameexec', secret: request.headers.get('X-Device-Key') || '' })
      if (!gate.ok) return jsonResponse(gate.body, gate.status, cors)
      const r = await gameExecutorReceipt(env, dev, parseJsonSafe(raw))
      await rememberIdempotent(env, 'gameexec', dev.id, gate.idemKey, r)
      return jsonResponse({ success: true, ...r }, 200, cors)
    }

    /* ======================= 需要登录的接口 ======================= */
    if (path.indexOf('/api/') === 0) {
      const user = await requireUser(env, request, url)
      return await handleAuthed(request, env, user, path, method, url, cors, cfg, ctx)
    }

    return jsonResponse({ success: false, error: '接口不存在' }, 404, cors)
  } catch (e) {
    const status = e && e.status ? e.status : 500
    // 5xx 错误脱敏：内部异常（含 KV / 加解密 / 未捕获异常）默认不外泄 message，
    //   只返回统一文案 + 关联号，真实原因写入审计，超管排查时可用「错误详情」开关临时打开。
    let expose = false
    try { expose = (await getConfig(env)).exposeErrorDetail === true } catch (x) { expose = false }
    let msg = (e && e.message) || '服务器错误'
    let detail = e && e.extra ? e.extra : undefined
    let errorId
    if (status >= 500 && !expose) {
      errorId = await randomToken(6)   // 必须 await：否则关联号是 Promise，调用方看到 [object Promise]、审计也存不进真实号
      msg = '服务器内部错误（关联号 ' + errorId + '）'
      detail = undefined
      try { await addAudit(env, 'system', 'error.5xx', { errorId: errorId, status: status, path: path, real: String((e && e.message) || '').slice(0, 300) }) } catch (x) { /* 审计失败不影响响应 */ }
    }
    const payload = { success: false, error: msg }
    if (errorId) payload.errorId = errorId
    if (detail !== undefined) payload.detail = detail
    return jsonResponse(payload, status, cors)
  }
}

async function requireDevice(env, request) {
  await publicGuard(env, request, 'device')   // 按来源 IP 限流：挡住设备密钥 / 执行端密钥枚举
  const key = request.headers.get('X-Device-Key') || ''
  if (!key) throw httpError(401, '缺少设备密钥 X-Device-Key')
  const dev = await resolveDevice(env, key)
  if (!dev) throw httpError(401, '设备密钥无效或已停用')
  return dev
}

async function userByMerchantKey(env, request) {
  const key = request.headers.get('X-Merchant-Key') || ''
  if (!key) return null
  // 优先按哈希索引查（明文密钥不落库），兼容历史明文索引
  const hash = await sha256hex('mkey:' + key)
  let idx = await kvGet(env, 'mkeyhash:' + hash, null)
  if (!idx) idx = await kvGet(env, 'mkey:' + key, null)
  if (!idx) return null
  const u = await getUser(env, idx.userId)
  if (!u || u.status === 'disabled') return null
  return u
}

function parseJsonSafe(text) {
  try { return text ? JSON.parse(text) : {} } catch (e) { return {} }
}

/**
 * 接入方入站请求统一闸门：限流 → 幂等键 → 签名与防重放。
 * 签名密钥默认复用接入方密钥本身（商户密钥 / 设备密钥），无需额外派发，傻瓜接入。
 */
async function gateInbound(env, request, actor, path, rawBody, opts) {
  const o = opts || {}
  const scope = o.scope || path
  try {
    await rateLimitCheck(env, scope + ':' + actor.id, o.rateLimit)
    const idemKey = safeStr(request.headers.get('X-Idempotency-Key'), 80)
    if (idemKey) {
      const hit = await idempotentLookup(env, scope, actor.id + ':' + idemKey)
      if (hit.hit) return { ok: false, status: 200, body: Object.assign({ success: true, idempotent: true }, hit.hit), idemKey: idemKey }
    }
    await verifyApiSignature(env, {
      headers: request.headers, method: request.method, path: path,
      rawBody: rawBody || '', secret: o.secret || '', scope: scope + ':' + actor.id,
    })
    return { ok: true, idemKey: idemKey }
  } catch (e) {
    const status = e && e.status ? e.status : 500
    await addAudit(env, (actor && actor.id) || 'system', 'inbound.reject', { scope: scope, status: status, reason: (e && e.message) || '请求校验失败' })
    return { ok: false, status: status, body: { success: false, error: (e && e.message) || '请求校验失败' } }
  }
}

async function rememberIdempotent(env, scope, actorId, idemKey, payload) {
  if (!idemKey) return null
  return await idempotentRemember(env, scope, actorId + ':' + idemKey, payload)
}

function publicOrderPayload(o, cfg, viewerId) {
  const expired = o.status === 'pending' && Date.parse(o.expiresAt) <= Date.now()
  const d = o.delivery || {}
  const stage = o.stage || 'pending'
  // 收款账号默认脱敏：仅订单归属者本人 / 通道归属者本人可取明文（上级查看下级订单一律脱敏）
  const acct = o.channelAccount || ''
  const ownerView = !viewerId || viewerId === o.ownerId || viewerId === o.channelOwnerId
  return {
    orderId: o.id, token: o.token, scene: o.scene, status: expired ? 'expired' : o.status,
    amount: o.amount, payable: o.payable, tailorCode: o.tailCode, tailCode: o.tailCode, currency: cfg.currency,
    channelAccount: ownerView ? acct : maskAccount(acct),
    channelAccountMasked: maskAccount(acct), channelHolder: o.channelHolder,
    subject: o.subject, customer: o.customer, merchantOrderId: o.merchantOrderId,
    expiresAt: o.expiresAt, paidAt: o.paidAt, payUrl: '/pay?t=' + o.token,
    amountText: (o.amount || 0).toLocaleString('en-US'), payableText: (o.payable || 0).toLocaleString('en-US'),
    // —— 履约链（下单→到账→发货→收货→转款到户）——
    stage: stage,
    stageText: STAGE_TEXT[stage] || stage,
    escrow: o.escrow === true,
    escrowText: o.escrow ? '托管中（收货后转款到户）' : '直接入账',
    deliveryType: o.deliveryType || '',
    deliveryStatus: o.deliveryStatus || 'pending',
    hasCard: !!o.cardSecretCipher,
    delivery: {
      type: d.type || '', itemName: d.itemName || '', carrier: d.carrier || '',
      trackingNo: d.type === 'logistics' ? d.trackingNo : '', deliveryUrl: d.deliveryUrl || '', note: d.note || '',
    },
    deliveredAt: o.deliveredAt || null,
    autoReceiveAt: o.autoReceiveAt || null,
    receivedAt: o.receivedAt || null,
    settledAt: o.settledAt || null,
    settleAmount: o.settleAmount || 0,
    settleFee: o.settleFee || 0,
    settleNet: o.settleNet || 0,
    beneficiaryId: o.beneficiaryId || o.ownerId,
    // —— 平台使用费（对代理分级账户计提，随订单可核）——
    platformFee: toInt(o.platformFee, 0),
    platformFeeDue: toInt(o.platformFeeDue, 0),
    // —— 游戏闭环 ——
    gameAccount: o.gameAccount || '', gameRole: o.gameRole || '', gameZone: o.gameZone || '',
    itemCode: o.itemCode || '', quantity: o.quantity || 1,
    grantStatus: o.grantStatus || '', grantTxid: o.grantTxid || '',
  }
}

/* ======================= 已登录路由 ======================= */
async function handleAuthed(request, env, user, path, method, url, cors, cfg, ctx) {
  const body = (method === 'POST' || method === 'PUT' || method === 'DELETE') ? await jsonBody(request) : {}
  const q = url.searchParams

  /* ---- 强制改密闸门（默认关闭；开启后新建账号未改密前仅可改密/查看总览） ---- */
  if (cfg.enforcePasswordChange === true && user.mustChangePassword === true
    && path !== '/api/me/password' && path !== '/api/auth/me' && path !== '/api/overview') {
    throw httpError(428, '为保障账号安全，请先修改初始密码后再使用其他功能', {
      code: 'PASSWORD_CHANGE_REQUIRED', hint: '调用 POST /api/me/password 提交 oldPassword / password 即可解除',
    })
  }

  /* ---- 个人 ---- */
  if (path === '/api/me/password' && method === 'POST') {
    if (!body.password || String(body.password).length < 6) throw httpError(400, '新密码至少 6 位')
    const u = await getUser(env, user.id)
    const cur = await hashPassword(String(body.oldPassword || ''), u.salt)
    if (!(await timingSafeEqual(cur, u.passHash))) throw httpError(401, '原密码不正确')
    u.salt = await randomToken(8)
    u.passHash = await hashPassword(String(body.password), u.salt)
    u.mustChangePassword = false
    u.updatedAt = nowIso()
    await kvPut(env, 'user:' + u.id, u)
    await addAudit(env, user.id, 'auth.password', {})
    return jsonResponse({ success: true }, 200, cors)
  }
  if (path === '/api/me/merchantkey' && method === 'POST') {
    const key = 'mk_' + await randomToken(20)
    // 只存哈希索引：明文密钥仅在本次响应中回显一次，库内不留明文
    const hash = await sha256hex('mkey:' + key)
    await kvPut(env, 'mkeyhash:' + hash, { userId: user.id, masked: maskAccount(key), createdAt: nowIso() })
    await addAudit(env, user.id, 'merchant.key.rotate', {})
    return jsonResponse({ success: true, merchantKey: key, merchantKeyMasked: maskAccount(key) }, 200, cors)
  }
  if (path === '/api/overview' && method === 'GET') {
    return jsonResponse({ success: true, overview: await overview(env, user) }, 200, cors)
  }
  if (path === '/api/tree' && method === 'GET') {
    return jsonResponse({ success: true, ...(await buildTree(env, user)) }, 200, cors)
  }
  if (path === '/api/stats' && method === 'GET') {
    const ownerId = q.get('ownerId') || user.id
    if (!(await canAccessOwner(env, user, ownerId))) throw httpError(404, '资源不存在')
    return jsonResponse({ success: true, stats: await getStats(env, ownerId) }, 200, cors)
  }

  /* ---- 账号管理 ---- */
  if (path === '/api/accounts' && method === 'GET') {
    const tree = await buildTree(env, user)
    return jsonResponse({ success: true, accounts: tree.nodes }, 200, cors)
  }
  if (path === '/api/accounts' && method === 'POST') {
    const created = await createUser(env, user, body)
    return jsonResponse({ success: true, account: created }, 200, cors)
  }
  let m = /^\/api\/accounts\/([A-Za-z0-9_]+)$/.exec(path)
  if (m && method === 'PUT') return jsonResponse({ success: true, account: await updateUser(env, user, m[1], body) }, 200, cors)
  if (m && method === 'DELETE') return jsonResponse({ success: true, account: await disableUser(env, user, m[1]) }, 200, cors)

  /* ---- 通道（自有 KBZ 收款账号） ---- */
  if (path === '/api/channels' && method === 'GET') {
    const flow = q.get('flow') === 'pay' ? 'pay' : (q.get('flow') === 'receive' ? 'receive' : '')
    const own = await listChannels(env, user.id, flow)
    const ownerId = q.get('ownerId')
    if (ownerId && ownerId !== user.id) {
      if (!(await canAccessOwner(env, user, ownerId))) throw httpError(404, '资源不存在')
      // 上级查看下级通道：一律脱敏（明文仅限通道归属者本人）
      const sub = await listChannels(env, ownerId, flow)
      return jsonResponse({ success: true, flow: flow || 'all', channels: sub.map(function (c) { return publicChannel(c, false) }) }, 200, cors)
    }
    if (q.get('reveal') === '1') {
      if (cfg.allowReveal === false) throw httpError(403, '系统已关闭受限明文读取')
      await addAudit(env, user.id, 'channel.reveal', { count: own.length, flow: flow || 'all' })
      return jsonResponse({ success: true, flow: flow || 'all', channels: own.map(function (c) { return publicChannel(c, true) }) }, 200, cors)
    }
    return jsonResponse({ success: true, flow: flow || 'all', channels: own.map(function (c) { return publicChannel(c, false) }) }, 200, cors)
  }
  if (path === '/api/channels' && method === 'POST') {
    const c = await createChannel(env, user, body)
    return jsonResponse({ success: true, channel: publicChannel(c, true) }, 200, cors)
  }

  /* ---- 收付款设置：收款账户 / 付款账户（两个资金账户窗口，均支持一键替换） ---- */
  if (path === '/api/fundaccounts' && method === 'GET') {
    const flow = q.get('flow') === 'pay' ? 'pay' : 'receive'
    const ownerId = q.get('ownerId')
    if (ownerId && ownerId !== user.id) {
      // 上级查看下级资金账户：一律脱敏（明文仅限账户归属者本人）
      if (!(await canAccessOwner(env, user, ownerId))) throw httpError(404, '资源不存在')
      const sub = await listChannels(env, ownerId, flow)
      return jsonResponse({ success: true, flow: flow, ownerId: ownerId, accounts: sub.map(function (c) { return publicChannel(c, false) }) }, 200, cors)
    }
    const own = await listChannels(env, user.id, flow)
    // 归属方本人可取明文（受限明文读取需开启并留痕）；否则默认脱敏
    if (q.get('reveal') === '1') {
      if (cfg.allowReveal === false) throw httpError(403, '系统已关闭受限明文读取')
      await addAudit(env, user.id, 'fundaccount.reveal', { flow: flow, count: own.length })
      return jsonResponse({ success: true, flow: flow, ownerId: user.id, accounts: own.map(function (c) { return publicChannel(c, true) }) }, 200, cors)
    }
    return jsonResponse({ success: true, flow: flow, ownerId: user.id, accounts: own.map(function (c) { return publicChannel(c, false) }) }, 200, cors)
  }
  if (path === '/api/fundaccounts' && method === 'POST') {
    const flow = body.flow === 'pay' ? 'pay' : 'receive'
    const c = await createChannel(env, user, Object.assign({}, body, { flow: flow }))
    return jsonResponse({ success: true, flow: flow, account: publicChannel(c, true) }, 200, cors)
  }
  m = /^\/api\/fundaccounts\/([A-Za-z0-9_]+)\/replace$/.exec(path)
  if (m && method === 'POST') {
    const r = await replaceChannel(env, user, m[1], body)
    return jsonResponse({
      success: true,
      replaced: publicChannel(r.replaced, true),
      current: publicChannel(r.current, true),
      cooldownUntil: r.cooldownUntil,
    }, 200, cors)
  }
  m = /^\/api\/fundaccounts\/([A-Za-z0-9_]+)$/.exec(path)
  if (m && method === 'PUT') return jsonResponse({ success: true, account: publicChannel(await updateChannel(env, user, m[1], body), true) }, 200, cors)
  if (m && method === 'DELETE') return jsonResponse({ success: true, account: await deleteChannel(env, user, m[1]) }, 200, cors)
  m = /^\/api\/channels\/([A-Za-z0-9_]+)\/replace$/.exec(path)
  if (m && method === 'POST') {
    const r = await replaceChannel(env, user, m[1], body)
    return jsonResponse({
      success: true,
      replaced: publicChannel(r.replaced, true),
      current: publicChannel(r.current, true),
      cooldownUntil: r.cooldownUntil,
    }, 200, cors)
  }
  m = /^\/api\/channels\/([A-Za-z0-9_]+)$/.exec(path)
  if (m && method === 'PUT') return jsonResponse({ success: true, channel: publicChannel(await updateChannel(env, user, m[1], body), true) }, 200, cors)
  if (m && method === 'DELETE') return jsonResponse({ success: true, channel: await deleteChannel(env, user, m[1]) }, 200, cors)

  /* ---- 收款订单 ---- */
  if (path === '/api/orders' && method === 'GET') {
    if (q.get('ownerId') && !(await canAccessOwner(env, user, q.get('ownerId')))) throw httpError(404, '资源不存在')
    const list = await listOrders(env, user, {
      status: q.get('status') || '', scene: q.get('scene') || '', stage: q.get('stage') || '',
      escrow: q.get('escrow') === null ? undefined : q.get('escrow'),
      ownerId: q.get('ownerId') || '', kw: q.get('kw') || '', limit: qLimit(q, 200),
    })
    const withDelivery = q.get('delivery') === '1'
    const out = []
    for (const o of list) out.push(withDelivery ? await publicOrder(env, o, { reveal: true, viewerId: user.id }) : publicOrderPayload(o, cfg, user.id))
    return jsonResponse({ success: true, orders: out }, 200, cors)
  }
  if (path === '/api/orders' && method === 'POST') {
    const o = await createOrder(env, user, body)
    return jsonResponse({ success: true, order: publicOrderPayload(o, cfg, user.id) }, 200, cors)
  }
  m = /^\/api\/orders\/([A-Za-z0-9_]+)$/.exec(path)
  if (m && method === 'GET') {
    const o = await findOrderById(env, user, m[1])
    if (!o) throw httpError(404, '资源不存在')
    return jsonResponse({ success: true, order: publicOrderPayload(o, cfg, user.id) }, 200, cors)
  }
  m = /^\/api\/orders\/([A-Za-z0-9_]+)\/close$/.exec(path)
  if (m && method === 'POST') {
    const o = await cancelOrder(env, user, m[1])
    return jsonResponse({ success: true, order: publicOrderPayload(o, cfg, user.id) }, 200, cors)
  }
  m = /^\/api\/orders\/([A-Za-z0-9_]+)\/refund$/.exec(path)
  if (m && method === 'POST') {
    const o = await refundOrder(env, user, m[1], body.reason)
    return jsonResponse({ success: true, order: publicOrderPayload(o, cfg, user.id) }, 200, cors)
  }
  // 手工补单核销（代理/超管在后台核对后确认到账）
  m = /^\/api\/orders\/([A-Za-z0-9_]+)\/markpaid$/.exec(path)
  if (m && method === 'POST') {
    const o = await findOrderById(env, user, m[1])
    if (!o) throw httpError(404, '资源不存在')
    const r = await settleOrder(env, o, { amount: toInt(body.amount, o.payable), txid: safeStr(body.txid, 64) || ('MANUAL' + Date.now()), source: 'manual' })
    return jsonResponse({ success: true, order: publicOrderPayload(r.order, cfg) }, 200, cors)
  }
  // 手动发货（可在此补录卡密 / 物流单号 / 游戏发货要素）
  m = /^\/api\/orders\/([A-Za-z0-9_]+)\/deliver$/.exec(path)
  if (m && method === 'POST') {
    const o = await deliverOrder(env, user, m[1], body)
    return jsonResponse({ success: true, order: o }, 200, cors)
  }
  // 确认收货 → 自动转款到户
  m = /^\/api\/orders\/([A-Za-z0-9_]+)\/receive$/.exec(path)
  if (m && method === 'POST') {
    const o = await confirmReceive(env, user, m[1], body)
    return jsonResponse({ success: true, order: o }, 200, cors)
  }

  /* ---- 出款 ---- */
  if (path === '/api/payouts' && method === 'GET') {
    if (q.get('ownerId') && !(await canAccessOwner(env, user, q.get('ownerId')))) throw httpError(404, '资源不存在')
    const list = await listPayouts(env, user, { status: q.get('status') || '', ownerId: q.get('ownerId') || '', limit: qLimit(q, 200) })
    return jsonResponse({ success: true, payouts: list }, 200, cors)
  }
  if (path === '/api/payouts' && method === 'POST') {
    return jsonResponse({ success: true, payout: await requestPayout(env, user, body) }, 200, cors)
  }
  m = /^\/api\/payouts\/([A-Za-z0-9_]+)\/approve$/.exec(path)
  if (m && method === 'POST') return jsonResponse({ success: true, payout: await approvePayout(env, user, m[1]) }, 200, cors)
  m = /^\/api\/payouts\/([A-Za-z0-9_]+)\/reject$/.exec(path)
  if (m && method === 'POST') return jsonResponse({ success: true, payout: await rejectPayout(env, user, m[1], body.reason) }, 200, cors)

  /* ---- 设备 ---- */
  if (path === '/api/devices' && method === 'GET') return jsonResponse({ success: true, devices: await listDevices(env, user) }, 200, cors)
  if (path === '/api/devices' && method === 'POST') return jsonResponse({ success: true, device: await createDevice(env, user, body) }, 200, cors)
  m = /^\/api\/devices\/([A-Za-z0-9_]+)$/.exec(path)
  if (m && method === 'DELETE') return jsonResponse({ success: true, device: await deleteDevice(env, user, m[1]) }, 200, cors)

  /* ---- 适配器 ---- */
  if (path === '/api/adapters' && method === 'GET') return jsonResponse({ success: true, adapters: await listAdapters(env, user) }, 200, cors)
  if (path === '/api/adapters' && method === 'POST') return jsonResponse({ success: true, adapter: await createAdapter(env, user, body) }, 200, cors)
  m = /^\/api\/adapters\/([A-Za-z0-9_]+)$/.exec(path)
  if (m && method === 'DELETE') return jsonResponse({ success: true, adapter: await deleteAdapter(env, user, m[1]) }, 200, cors)

  /* ---- 回调 ---- */
  if (path === '/api/webhooks' && method === 'GET') return jsonResponse({ success: true, webhooks: await listWebhooks(env, user) }, 200, cors)
  m = /^\/api\/webhooks\/([A-Za-z0-9_]+)\/retry$/.exec(path)
  if (m && method === 'POST') return jsonResponse({ success: true, ...(await retryWebhook(env, user, m[1])) }, 200, cors)
  if (path === '/api/webhooks/run' && method === 'POST') {
    await requireSuper(env, request, url)
    return jsonResponse({ success: true, ...(await runWebhooks(env, toInt(body.limit, 50))) }, 200, cors)
  }
  // 手动触发一次「自动收货 + 转款到户」扫描（定时任务也会自动执行）
  if (path === '/api/orders/auto-receive' && method === 'POST') {
    await requireSuper(env, request, url)
    return jsonResponse({ success: true, ...(await autoReceiveSweep(env, toInt(body.limit, 200))) }, 200, cors)
  }

  /* ---- 超管专属：代理租用与保证金总表（逐行 / 可按状态与关键词筛选） ---- */
  if (path === '/api/rental-board' && method === 'GET') {
    await requireSuper(env, request, url)
    return jsonResponse({ success: true, ...(await rentalBoard(env, user, { status: q.get('status') || '', kw: q.get('kw') || '', limit: qLimit(q, 500) })) }, 200, cors)
  }

  /* ---- 游戏上分 / 下分：游戏ID 台账 + 指令单（幂等创建 / 回执 / 取消 / 回滚） ---- */
  if (path === '/api/game/ids' && method === 'GET') {
    return jsonResponse({ success: true, gameIds: await listGameIds(env, user) }, 200, cors)
  }
  if (path === '/api/game/ids' && method === 'POST') {
    return jsonResponse({ success: true, gameId: await registerGameId(env, user, body) }, 200, cors)
  }
  if (path === '/api/game/orders' && method === 'GET') {
    const ownerId = q.get('ownerId') || ''
    if (ownerId && !(await canAccessOwner(env, user, ownerId))) throw httpError(404, '资源不存在')
    return jsonResponse({
      success: true,
      directions: GAME_DIRECTION_TEXT,
      statusText: GAME_STATUS_TEXT,
      orders: await listGamePointOrders(env, user, {
        status: q.get('status') || '', direction: q.get('direction') || '',
        ownerId: ownerId, kw: q.get('kw') || '', limit: qLimit(q, 200),
      }),
    }, 200, cors)
  }
  if (path === '/api/game/orders' && method === 'POST') {
    // 幂等：同一操作者 + 同一 X-Idempotency-Key 只受理一次（重复提交原样回首次结果）
    const idemKey = safeStr(request.headers.get('X-Idempotency-Key'), 80)
    if (idemKey) {
      const hit = await idempotentLookup(env, 'gamepoint', user.id + ':' + idemKey)
      if (hit.hit) return jsonResponse({ success: true, idempotent: true, ...hit.hit }, 200, cors)
    }
    const order = await createGamePointOrder(env, user, body)
    const payload = { order: order }
    await rememberIdempotent(env, 'gamepoint', user.id, idemKey, payload)
    return jsonResponse({ success: true, order: order }, 200, cors)
  }
  m = /^\/api\/game\/orders\/([A-Za-z0-9_]+)$/.exec(path)
  if (m && method === 'GET') {
    const o = await getGamePointOrder(env, user, m[1])
    if (!o) throw httpError(404, '资源不存在')
    return jsonResponse({ success: true, order: o }, 200, cors)
  }
  m = /^\/api\/game\/orders\/([A-Za-z0-9_]+)\/cancel$/.exec(path)
  if (m && method === 'POST') {
    return jsonResponse({ success: true, order: await cancelGamePointOrder(env, user, m[1], body.reason || body.note) }, 200, cors)
  }
  m = /^\/api\/game\/orders\/([A-Za-z0-9_]+)\/rollback$/.exec(path)
  if (m && method === 'POST') {
    return jsonResponse({ success: true, order: await rollbackGamePointOrder(env, user, m[1], body.reason || body.note) }, 200, cors)
  }

  /* ---- 零文档即插即用：模板库 / 配对码 / 接入点 / 抓包自适配 / 一键连通测试 ---- */
  if (path === '/api/plug/templates' && method === 'GET') {
    return jsonResponse({ success: true, version: PLUG_VERSION, templates: PLUG_TEMPLATES }, 200, cors)
  }
  if (path === '/api/plug/codes' && method === 'GET') {
    return jsonResponse({ success: true, codes: await plugListPairingCodes(env, user) }, 200, cors)
  }
  if (path === '/api/plug/codes' && method === 'POST') {
    return jsonResponse({ success: true, code: await plugCreatePairingCode(env, user, body) }, 200, cors)
  }
  m = /^\/api\/plug\/codes\/([A-Za-z0-9\-_]+)\/revoke$/.exec(path)
  if (m && method === 'POST') {
    return jsonResponse({ success: true, ...(await plugRevokePairingCode(env, user, m[1])) }, 200, cors)
  }
  if (path === '/api/plug/points' && method === 'GET') {
    return jsonResponse({ success: true, version: PLUG_VERSION, points: await plugListPoints(env, user, baseOrigin(url)), guideUrl: baseOrigin(url) + '/plug' }, 200, cors)
  }
  if (path === '/api/plug/parse' && method === 'POST') {
    return jsonResponse({ success: true, ...(plugParseCaptured(body)) }, 200, cors)
  }
  if (path === '/api/plug/adapters' && method === 'POST') {
    const r = await plugCreateAdapterProfile(env, user, body, baseOrigin(url))
    await addAudit(env, user.id, 'plug.wizard.create', { adapterId: r.adapter.id, templateId: (r.profile || {}).templateId || '' })
    return jsonResponse({ success: true, ...r }, 200, cors)
  }
  m = /^\/api\/plug\/adapters\/([A-Za-z0-9_]+)\/profile$/.exec(path)
  if (m && method === 'GET') {
    return jsonResponse({ success: true, ...(await plugGetProfile(env, user, m[1])) }, 200, cors)
  }
  m = /^\/api\/plug\/adapters\/([A-Za-z0-9_]+)\/test$/.exec(path)
  if (m && method === 'POST') {
    return jsonResponse({ success: true, ...(await plugConnectionTest(env, user, m[1], body, baseOrigin(url))) }, 200, cors)
  }
  m = /^\/api\/plug\/adapters\/([A-Za-z0-9_]+)\/rotate$/.exec(path)
  if (m && method === 'POST') {
    const r = await plugRotateKey(env, user, m[1])
    return jsonResponse({ success: true, ...r }, 200, cors)
  }

  /* ---- 账本 ---- */
  if (path === '/api/ledger' && method === 'GET') {
    const ownerId = q.get('ownerId') || user.id
    if (!(await canAccessOwner(env, user, ownerId))) throw httpError(404, '资源不存在')
    return jsonResponse({ success: true, entries: await ledgerList(env, ownerId, qLimit(q, 200)) }, 200, cors)
  }
  if (path === '/api/ledger/verify' && method === 'GET') {
    const ownerId = q.get('ownerId') || user.id
    if (!(await canAccessOwner(env, user, ownerId))) throw httpError(404, '资源不存在')
    return jsonResponse({ success: true, ...(await ledgerVerify(env, ownerId)) }, 200, cors)
  }

  /* ---- 保证金 / 租用金 / 扣罚 ---- */
  if (path === '/api/deposit' && method === 'GET') {
    if (user.role === 'super') return jsonResponse({ success: true, deposits: await listDeposits(env, user) }, 200, cors)
    return jsonResponse({ success: true, deposit: await getDeposit(env, user.id === user.rootId ? user.id : (user.role === 'agent' ? user.id : user.parentId)) }, 200, cors)
  }
  if (path === '/api/deposit/order' && method === 'POST') {
    const o = await createOrder(env, user, Object.assign({}, body, { scene: 'deposit', subject: '保证金缴纳' }))
    return jsonResponse({ success: true, order: publicOrderPayload(o, cfg, user.id) }, 200, cors)
  }
  if (path === '/api/rental/order' && method === 'POST') {
    const o = await createOrder(env, user, Object.assign({}, body, { scene: 'rental', subject: '系统租用金' }))
    return jsonResponse({ success: true, order: publicOrderPayload(o, cfg, user.id) }, 200, cors)
  }
  if (path === '/api/rentals' && method === 'GET') {
    const agentId = q.get('agentId') || ''
    return jsonResponse({ success: true, rentals: await listRentals(env, user, { agentId: agentId }) }, 200, cors)
  }
  if (path === '/api/penalties' && method === 'GET') {
    const agentId = q.get('agentId') || ''
    return jsonResponse({ success: true, penalties: await listPenalties(env, user, { agentId: agentId }) }, 200, cors)
  }
  m = /^\/api\/penalties\/([A-Za-z0-9_]+)\/appeal$/.exec(path)
  if (m && method === 'POST') return jsonResponse({ success: true, penalty: await appealPenalty(env, user, m[1], body.note) }, 200, cors)

  /* ---- 审计 ---- */
  if (path === '/api/audit' && method === 'GET') {
    return jsonResponse({ success: true, logs: await listAudit(env, user, qLimit(q, 200)) }, 200, cors)
  }
  /* ---- 审计链验真（超管专属）：逐条重算哈希，发现被删除 / 被改动的记录 ---- */
  if (path === '/api/audit/verify' && method === 'GET') {
    await requireSuper(env, request, url)
    return jsonResponse({ success: true, ...(await verifyAuditChain(env)) }, 200, cors)
  }

  /* ---- 安全会话管理：本人可查 / 可撤自己的会话；超管可查 / 可撤任意账号的会话 ---- */
  if (path === '/api/security/sessions' && method === 'GET') {
    const rows = await listSessions(env, user, safeStr(q.get('userId'), 40))
    const cur = tokenOf(request, url)
    rows.forEach(function (s) { s.isCurrent = !!cur && s.token === cur })
    return jsonResponse({ success: true, sessions: rows, me: user.id }, 200, cors)
  }
  if (path === '/api/security/sessions/revoke' && method === 'POST') {
    const r = await revokeSession(env, user, safeStr(body.token, 120))
    return jsonResponse({ success: true, ...r }, 200, cors)
  }
  if (path === '/api/security/ip' && method === 'GET') {
    // 只回哈希，不回原始 IP（避免后台泄露真实来源地址）
    const ip = request.headers.get('CF-Connecting-IP') || request.headers.get('X-Forwarded-For') || ''
    return jsonResponse({ success: true, ipHash: await hashIp(ip) }, 200, cors)
  }

  /* ---- 超管专属：维护与对账（定时任务同源，可手动立即执行一次） ---- */
  if (path === '/api/maintenance/status' && method === 'GET') {
    await requireSuper(env, request, url)
    return jsonResponse({ success: true, ...(await maintenanceStatus(env, user)) }, 200, cors)
  }
  if (path === '/api/maintenance/run' && method === 'POST') {
    await requireSuper(env, request, url)
    const r = await runMaintenance(env, { by: user.id, limit: toInt(body.limit, 200), expire: body.expire !== false, autoReceive: body.autoReceive !== false, webhooks: body.webhooks !== false })
    return jsonResponse({ success: true, ...r }, 200, cors)
  }
  // 对账未匹配流水（人工核销闭环）：列表 + 指定订单核销
  if (path === '/api/reconcile/unmatched' && method === 'GET') {
    await requireSuper(env, request, url)
    const rows = await listUnmatched(env, user, { status: q.get('status') || '', limit: qLimit(q, 200) })
    return jsonResponse({ success: true, rows: rows, count: rows.length }, 200, cors)
  }
  m = /^\/api\/reconcile\/([A-Za-z0-9_]+)\/match$/.exec(path)
  if (m && method === 'POST') {
    await requireSuper(env, request, url)
    const r = await matchUnmatched(env, user, m[1], body)
    return jsonResponse({ success: true, ...r }, 200, cors)
  }

  /* ---- 超管专属：资金池 ---- */
  if (path.indexOf('/api/pool') === 0) {
    await requireSuper(env, request, url)
    if (path === '/api/pool' && method === 'GET') {
      return jsonResponse({
        success: true,
        pool: await getPool(env),
        ledger: await poolLedgerList(env, qLimit(q, 100)),
        deposits: await listDeposits(env, user),
        penalties: await listPenalties(env, user, {}),
        rentals: await listRentals(env, user, {}),
      }, 200, cors)
    }
    if (path === '/api/pool/accounts' && method === 'POST') {
      return jsonResponse({ success: true, pool: await setPoolAccounts(env, user, body) }, 200, cors)
    }
    if (path === '/api/pool/deposit' && method === 'POST') {
      return jsonResponse({ success: true, deposit: await depositTopup(env, user, body) }, 200, cors)
    }
    if (path === '/api/pool/penalty' && method === 'POST') {
      return jsonResponse({ success: true, ...(await applyPenalty(env, user, body)) }, 200, cors)
    }
    if (path === '/api/pool/penalty/resolve' && method === 'POST') {
      return jsonResponse({ success: true, penalty: await resolvePenalty(env, user, safeStr(body.penaltyId, 40), body) }, 200, cors)
    }
    if (path === '/api/pool/deposit/refund' && method === 'POST') {
      return jsonResponse({ success: true, deposit: await refundDeposit(env, user, body) }, 200, cors)
    }
    if (path === '/api/pool/rental' && method === 'POST') {
      return jsonResponse({ success: true, rental: await chargeRental(env, user, body) }, 200, cors)
    }
    if (path === '/api/pool/ledger' && method === 'GET') {
      return jsonResponse({ success: true, entries: await poolLedgerList(env, qLimit(q, 200)) }, 200, cors)
    }
  }

  /* ---- 超管专属：平台账户（使用费与保证金收款归集） ---- */
  if (path === '/api/platform' && method === 'GET') {
    await requireSuper(env, request, url)
    return jsonResponse({ success: true, platform: await platformAccount(env) }, 200, cors)
  }

  /* ---- 超管专属：系统设置 ---- */
  if (path === '/api/settings' && method === 'GET') {
    await requireSuper(env, request, url)
    const raw = Object.assign({}, await getConfig(env))
    delete raw.adminPassword // 不向前端回显任何口令字段
    return jsonResponse({ success: true, config: await publicConfig(env), raw: raw, adminInitialized: await superAdminInitialized(env) }, 200, cors)
  }
  if (path === '/api/settings' && method === 'PUT') {
    await requireSuper(env, request, url)
    const allow = ['gatewayName', 'currency', 'regionMode', 'allowCountries', 'minWithdraw', 'withdrawFeeRate',
      'autoPayoutLimit', 'tailDigits', 'tailTtlSec', 'orderTtlSec', 'webhookRetries', 'webhookBackoffSec',
      'depositDefaultRequired', 'commissionDefault', 'rentalFeeMonthly', 'channelCooldownSec', 'allowSubAgents',
      'rentalBillingCycle', 'rentalDueDay', 'rentalGraceDays', 'rentalOverdueAction',
      'autoDeliver', 'autoReceiveHours', 'autoSettle', 'settleFeeRate', 'platformFeeRate', 'platformFeeOnCollect',
      'requireApiSignature', 'signatureSkewSec', 'nonceTtlSec', 'rateLimitPerMin', 'publicRateLimitPerMin', 'allowReveal', 'enforcePasswordChange',
      'sessionTtlSec', 'loginMaxAttempts', 'loginLockSec', 'exposeErrorDetail']
    const patch = {}
    allow.forEach(function (k) { if (body[k] !== undefined) patch[k] = body[k] })
    const next = await setConfig(env, patch)
    // 改「默认应缴保证金」→ 联动同步未逐户钉定的代理（user.depositRequired 与保证金台账 required 同步）
    if (patch.depositDefaultRequired !== undefined) {
      await applyDepositDefault(env, patch.depositDefaultRequired)
    }
    await addAudit(env, user.id, 'settings.update', { patch: Object.keys(patch) })
    const nextRaw = Object.assign({}, next)
    delete nextRaw.adminPassword   // 不向前端回显任何口令字段
    return jsonResponse({ success: true, config: await publicConfig(env), raw: nextRaw }, 200, cors)
  }

  throw httpError(404, '接口不存在')
}