/* =============================================================================
 * 零文档即插即用接入层（plug.js）——「U 盘模式」
 * -----------------------------------------------------------------------------
 * 目标：任何平台（电商 / 游戏 / 自有系统）即使没有对接文档，也能 3 步接入：
 *   ① 后台一键生成「配对码」→ ② 用配对码换取接入凭据 → ③ 粘贴一行代码即可用。
 * 机制：
 *   - 自描述清单 /api/plug/manifest（以及 /.well-known/kbz-connect.json）：机器可读，
 *     脚本或 AI 可据此自动完成对接，无需人工阅读任何文档；
 *   - 单文件连接器 /kbz-plug.js：内置端点自发现、字段自动映射、失败重试；
 *   - 通用入口 /api/plug/:adapterId/{order,notify,pull,info}：接受 JSON / 表单 /
 *     查询串 / 纯文本等异构报文，按别名表自动识别字段（英文 / 中文 / 缅文均可）。
 * 设计原则：字段名不强制、报文格式不强制、有无签名都能跑；识别不出来就回报
 *          「我看懂了什么」（mapped），让接入方零文档即可自纠。
 * ========================================================================== */
/*
 * ✅ 状态：已正式接入运行链路（本版本起）。
 *    本文件已加入 build.mjs 的 ORDER（core → engine → plug → api → pages），随 dist/index.js 一起构建发布；
 *    路由在 src/api.js 内按以下约定注册：
 *      公开（免登录）：
 *        GET  /api/plug/manifest                    自描述清单（机器可读）
 *        GET  /.well-known/kbz-connect.json         同一清单的标准发现入口
 *        GET  /kbz-plug.js                          单文件连接器（端点自发现 / 字段自动映射 / 失败重试）
 *        POST /api/plug/pair                        用配对码换取接入凭据（适配器 + plugKey）
 *        GET  /plug                                 三语接入向导页（?lang=zh|my|en）
 *        POST|GET /api/plug/:adapterId/{order,notify,pull,info}   通用入口（密钥 / 签名双通道鉴权）
 *      登录（后台）：
 *        GET  /api/plug/templates                   预置平台模板库
 *        GET|POST /api/plug/codes                   配对码列表 / 生成
 *        POST /api/plug/codes/:code/revoke          撤销配对码
 *        GET  /api/plug/points                      已接入的接入点列表（含向导画像）
 *        POST /api/plug/adapters                    一键接入（模板或纯手工 → 生成适配器配置）
 *        POST /api/plug/adapters/:id/test           一键连通测试
 *        GET  /api/plug/adapters/:id/profile        读取向导生成的接入画像
 *        POST /api/plug/parse                       抓包报文免文档自适配（字段映射识别）
 *    新增能力：预置平台模板库（PLUG_TEMPLATES）+ 一键接入向导 + 抓包免文档自适配 + 连通测试。
 * ========================================================================== */

import { kvGet, kvPut, kvDel, kvList, sha256hex, randomToken, safeStr, toInt, nowIso, maskAccount, encryptField, decryptField, addAudit, getConfig, httpError, rateLimitCheck, getUser, headerOf, timingSafeEqual, hmacHex, hmacHex as _hmac, visibleOwnerIds, canAccessOwner } from './core.js'
import { createOrder, settleOrder, deliverOrder, confirmReceive, cancelOrder, refundOrder, grantGameOrder, STAGE_TEXT, createAdapter, listAdapters } from './engine.js'

/* ============================== 一、字段别名表（免文档识别的核心） ============================== */
/**
 * 规范字段 → 可接受的外部字段名（大小写、下划线、连字符、空格、中文、缅文全部自动归一）。
 * 命中顺序：先规范名，再按数组顺序取第一个出现者；未命中则留空，不影响其它字段。
 */
export const PLUG_FIELDS = {
  orderNo: ['orderNo', 'order_no', 'outTradeNo', 'out_trade_no', 'tradeNo', 'trade_no', 'merchantOrderId', 'merchant_order_no', 'orderId', 'order_id', 'orderNumber', 'bizOrderNo', 'tid', 'billNo', '订单号', '商户订单号', '订单编号', '订单', 'အော်ဒါနံပါတ်'],
  amount: ['amount', 'amt', 'money', 'total', 'totalAmount', 'total_amount', 'totalFee', 'price', 'payable', 'payAmount', 'sum', 'value', 'cost', '金额', '支付金额', '应付金额', '收款金额', '价格', 'ငွေပမာဏ', 'ပမာဏ'],
  subject: ['subject', 'title', 'desc', 'description', 'body', 'goodsName', 'goods_name', 'productName', 'itemName', 'item', 'product', 'remark', '标题', '名称', '商品名称', '商品', '说明', '备注'],
  customer: ['customer', 'customerId', 'user', 'userId', 'user_id', 'uid', 'buyer', 'buyerId', 'buyer_id', 'memberId', 'player', 'playerId', 'account', '用户', '买家', '玩家', '账号'],
  scene: ['scene', 'biz', 'bizType', 'biz_type', 'tradeType', 'trade_type', 'category', 'kind', 'type', '业务类型', '场景', '类型', 'အမျိုးအစား'],
  platform: ['platform', 'app', 'appName', 'app_name', 'channel', 'source', 'from', '平台', '渠道', '来源'],
  cardSecret: ['cardSecret', 'card_secret', 'cardKey', 'cardCode', 'card_code', 'cardNo', 'card_no', 'secret', '券码', '卡密', '卡号', '兑换码'],
  trackingNo: ['trackingNo', 'tracking_no', 'logistics', 'expressNo', 'express_no', 'waybillNo', 'waybill_no', 'shipNo', '物流单号', '快递单号', '运单号'],
  notifyUrl: ['notifyUrl', 'notify_url', 'callbackUrl', 'callback_url', 'callback', 'webhook', 'webhookUrl', 'pushUrl', '回调地址', '通知地址'],
  gameAccount: ['gameAccount', 'game_account', 'playerAccount', 'player_account', 'gameUser', 'role', 'roleAccount', '游戏账号', '游戏帐号', '角色账号', 'ဂိမ်းအကောင့်'],
  gameRole: ['gameRole', 'game_role', 'roleName', 'role_name', 'character', 'charName', '角色', '角色名', '昵称'],
  gameZone: ['gameZone', 'game_zone', 'zone', 'zoneId', 'server', 'serverId', 'server_id', '区服', '大区', '服务器'],
  itemCode: ['itemCode', 'item_code', 'sku', 'skuId', 'productCode', 'product_code', 'goodsCode', 'goods_code', '道具编码', '商品编码', '商品ID'],
  quantity: ['quantity', 'qty', 'count', 'num', 'nums', 'buyCount', '数量', '个数'],
  txid: ['txid', 'txId', 'transactionId', 'transaction_id', 'transId', 'trans_id', 'refNo', 'ref_no', 'tradeId', '流水号', '交易号', '转账号'],
  token: ['token', 'orderToken', 'payToken', 't', '支付令牌'],
}

/** 全量别名（含动作/状态类），供清单自描述与动作判定使用 */
export const PLUG_ACTION_KEYS = ['action', 'event', 'eventType', 'op', 'status', 'state', 'bizType', 'type', 'kind', '动作', '事件', '状态', '操作']
export const PLUG_PAID_KEYS = ['paid', 'ok', 'success', 'isPaid', 'isSuccess', 'is_paid', 'payStatus', '是否成功', '是否支付']

const PLUG_WRAPPERS = ['data', 'payload', 'order', 'body', 'params', 'bizContent', 'biz_content', 'result', 'info', 'content', 'detail']
const MY_DIGITS = { '\u1040': '0', '\u1041': '1', '\u1042': '2', '\u1043': '3', '\u1044': '4', '\u1045': '5', '\u1046': '6', '\u1047': '7', '\u1048': '8', '\u1049': '9' }
const PLUG_SCENES = ['ecommerce', 'game', 'deposit', 'rental', 'manual']
const PLUG_CODE_TTL = 86400   // 配对码默认有效期：24 小时

/** 字段名归一：去掉大小写、下划线、连字符、空格、点号差异 */
export function plugNormKey(k) {
  return String(k === undefined || k === null ? '' : k).replace(/[\s_\-.]+/g, '').toLowerCase()
}

/** 展开常见包装层（data / payload / order / params ...），顶层字段优先 */
export function plugFlatten(raw) {
  const out = {}
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out
  Object.keys(raw).forEach(function (k) { out[k] = raw[k] })
  PLUG_WRAPPERS.forEach(function (w) {
    let v = raw[w]
    if (typeof v === 'string' && v.charAt(0) === '{') { try { v = JSON.parse(v) } catch (e) { v = null } }
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      Object.keys(v).forEach(function (k) { if (!(k in out)) out[k] = v[k] })
    }
  })
  return out
}

/** 按归一化键取值（兼容大小写/下划线/中文别名） */
export function plugGet(raw, key) {
  const flat = plugFlatten(raw)
  const want = plugNormKey(key)
  const keys = Object.keys(flat)
  for (let i = 0; i < keys.length; i++) {
    if (plugNormKey(keys[i]) === want) {
      const v = flat[keys[i]]
      if (v === undefined || v === null) continue
      if (typeof v === 'object') continue
      if (String(v) === '') continue
      return v
    }
  }
  return undefined
}

function plugFirstStr(raw, keys) {
  for (let i = 0; i < keys.length; i++) {
    const v = plugGet(raw, keys[i])
    if (v !== undefined) return String(v)
  }
  return ''
}

/** 宽松解析金额：支持 1,000 / MMK 1000 / "1000元" / 缅文数字 / 全角数字 / 千分位点 */
export function plugParseAmount(v) {
  if (typeof v === 'number') return Math.trunc(v)
  let s = String(v === undefined || v === null ? '' : v)
  if (!s) return 0
  s = s.replace(/[\u1040-\u1049]/g, function (ch) { return MY_DIGITS[ch] || '' })
  s = s.replace(/[\uFF10-\uFF19]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 65248) })
  s = s.replace(/[^0-9.\-]/g, '')
  if (!s) return 0
  const neg = s.charAt(0) === '-'
  s = s.replace(/-/g, '')
  if (!s) return 0
  const parts = s.split('.')
  let n
  if (parts.length > 1) {
    const frac = parts[parts.length - 1]
    n = (frac.length === 3) ? parseInt(parts.join(''), 10) : Math.trunc(parseFloat(s))
  } else {
    n = parseInt(parts[0], 10)
  }
  if (!n || isNaN(n) || !isFinite(n)) return 0
  return neg ? -n : n
}

/** 免文档字段映射：返回规范字段 + 每个字段实际命中的外部字段名（mapped） */
export function plugMapFields(raw) {
  const flat = plugFlatten(raw)
  const norm = {}
  Object.keys(flat).forEach(function (k) {
    const nk = plugNormKey(k)
    if (!(nk in norm)) norm[nk] = { k: k, v: flat[k] }
  })
  const fields = {}, mapped = {}
  Object.keys(PLUG_FIELDS).forEach(function (canon) {
    const direct = norm[plugNormKey(canon)]
    if (direct) { fields[canon] = direct.v; mapped[canon] = direct.k; return }
    const list = PLUG_FIELDS[canon]
    for (let i = 0; i < list.length; i++) {
      const hit = norm[plugNormKey(list[i])]
      if (hit) { fields[canon] = hit.v; mapped[canon] = hit.k; return }
    }
  })
  return { fields: fields, mapped: mapped, flat: flat }
}

/** 场景自动判定：显式声明优先，否则按游戏特征字段推断 */
export function plugDetectScene(raw, explicit) {
  const s = String(explicit === undefined || explicit === null ? '' : explicit).toLowerCase()
  if (/deposit|保证金|押金/.test(s)) return 'deposit'
  if (/rental|租用|租金/.test(s)) return 'rental'
  if (/manual|手工|线下/.test(s)) return 'manual'
  if (/game|游戏|发币|道具|点券/.test(s)) return 'game'
  if (/ecom|shop|goods|商品|购物/.test(s)) return 'ecommerce'
  const f = plugMapFields(raw).fields
  if (f.gameAccount || f.gameRole || f.gameZone) return 'game'
  return 'ecommerce'
}

/** 动作判定（核销 / 发货 / 收货 / 发币 / 关闭 / 退款 / 仅查询） */
export function plugDetectAction(raw) {
  const explicit = plugFirstStr(raw, PLUG_ACTION_KEYS)
  const s = explicit.toLowerCase()
  if (/grant|发币|发放/.test(s)) return { action: 'grant', explicit: explicit }
  if (/ship|deliver|发货|配送|signed/.test(s)) return { action: 'deliver', explicit: explicit }
  if (/receive|confirm|收货|确认收货/.test(s)) return { action: 'receive', explicit: explicit }
  if (/close|cancel|取消|关闭/.test(s)) return { action: 'close', explicit: explicit }
  if (/refund|退款/.test(s)) return { action: 'refund', explicit: explicit }
  if (/paid|pay|payment|settle|到账|收款|已付/.test(s)) return { action: 'paid', explicit: explicit }
  const flag = plugFirstStr(raw, PLUG_PAID_KEYS).toLowerCase()
  if (/^(1|true|yes|y|ok|paid|success|successful|已完成)$/.test(flag)) {
    // 明确的支付标志位：交给调用方按订单场景再定夺（游戏场景会被归一为发币回执）
    return { action: 'paid', explicit: '' }
  }
  const f = plugMapFields(raw).fields
  if (f.cardSecret || f.trackingNo) return { action: 'deliver', explicit: '' }
  if (f.txid) return { action: 'paid', explicit: '' }
  if (explicit) return { action: 'status', explicit: explicit }
  return { action: 'status', explicit: '' }
}

/** 通用报文解析：JSON / 表单 / 查询串 / 纯文本，任一格式都能吃 */
export function plugParseUniversal(raw, ctype, url) {
  const ct = String(ctype || '').toLowerCase()
  const text = String(raw === undefined || raw === null ? '' : raw)
  if (text) {
    const looksJson = ct.indexOf('json') >= 0 || /^\s*[\[{]/.test(text)
    if (looksJson) {
      try {
        const j = JSON.parse(text)
        if (j && typeof j === 'object' && !Array.isArray(j)) return j
      } catch (e) { /* 继续尝试其它格式 */ }
    }
    if (ct.indexOf('form') >= 0 || ct.indexOf('urlencoded') >= 0 || text.indexOf('=') >= 0) {
      const o = plugFormToObj(text)
      if (Object.keys(o).length) return o
    }
    // 类对象文本：从浏览器 DevTools / 服务端日志里直接复制的报文，键不带引号、分隔符混杂
    const loose = plugLoosePairs(text)
    if (Object.keys(loose).length) {
      const known = Object.keys(plugMapFields(loose).fields).length > 0
      if (Object.keys(loose).length >= 2 || known) return plugMergeQuery(loose, url)
    }
    // 完全无法结构化：把整段文本当作备注，仍可凭 URL 上的字段完成接入
    const o = { raw: text }
    plugMergeQuery(o, url)
    return o
  }
  const o = {}
  plugMergeQuery(o, url)
  return o
}

function plugFormToObj(text) {
  const out = {}
  try {
    const sp = new URLSearchParams(String(text))
    sp.forEach(function (v, k) { if (k !== 'k') out[k] = v })
  } catch (e) { /* 非法表单串：忽略 */ }
  return out
}

/** 宽松键值解析：兼容从浏览器 DevTools / 服务端日志里直接复制的「类对象文本」，
 *  例如 {out_trade_no: T20261023001, money: "10,000 MMK", playerAccount: gamer001, serverId: s1}
 *  键名可带可不带引号，分隔符支持逗号 / 分号 / 换行 / 制表符，值两侧引号会被剥离。 */
export function plugLoosePairs(text) {
  let t = String(text === undefined || text === null ? '' : text).trim()
  if (!t) return {}
  for (let i = 0; i < 3; i++) {
    const w = t.match(/^([\[({]+)[\s\S]*([\])}]+)$/)
    if (!w) break
    t = t.slice(w[1].length, t.length - w[2].length).trim()
  }
  if (!t) return {}
  const segs = []
  let cur = '', quote = '', depth = 0
  for (let i = 0; i < t.length; i++) {
    const ch = t[i]
    if (quote) {
      cur += ch
      if (ch === quote) quote = ''
      continue
    }
    if (ch === '"' || ch === "'") { quote = ch; cur += ch; continue }
    if (ch === '{' || ch === '[' || ch === '(') { depth++; cur += ch; continue }
    if (ch === '}' || ch === ']' || ch === ')') { depth = depth > 0 ? depth - 1 : 0; cur += ch; continue }
    if (depth === 0 && (ch === ',' || ch === ';' || ch === '\n' || ch === '\r' || ch === '\t')) {
      if (cur.trim()) segs.push(cur.trim())
      cur = ''
      continue
    }
    cur += ch
  }
  if (cur.trim()) segs.push(cur.trim())
  const out = {}
  let lastKey = ''
  segs.forEach(function (seg) {
    const m = seg.match(/^\s*["']?([A-Za-z0-9_.\-]+)["']?\s*[:=]\s*([\s\S]*?)\s*$/)
    if (!m) {
      // 续段：上一个值被逗号切断（如 amount: 25,000 MMK 中的 "000 MMK"）
      if (lastKey && /^[\d,]+$/.test(String(out[lastKey]))) out[lastKey] = String(out[lastKey]) + ', ' + seg
      return
    }
    let v = m[2]
    const qm = v.match(/^(["'])([\s\S]*)\1$/)
    if (qm) v = qm[2]
    if (v === 'true' || v === 'false') v = v === 'true'
    else if (/^-?\d+(\.\d+)?$/.test(v)) v = Number(v)
    out[m[1]] = v
    lastKey = m[1]
  })
  return out
}

function plugMergeQuery(o, url) {
  if (!url || !url.searchParams) return o
  url.searchParams.forEach(function (v, k) { if (k !== 'k' && !(k in o)) o[k] = v })
  return o
}

/* ============================== 二、自描述清单（免文档的核心） ============================== */
export const PLUG_VERSION = '1.0.0'

export function PLUG_MANIFEST(baseUrl, cfg) {
  const b = String(baseUrl || '').replace(/\/+$/, '')
  const C = cfg || {}
  return {
    spec: 'kbz-connect',
    version: PLUG_VERSION,
    name: (C.gatewayName || 'KBZPay 多平台收付款通道') + ' · 零文档即插即用接入',
    summary: '无需对接文档：用配对码换取凭据后，把任意格式的报文直接发到通用入口即可收发单、收通知、查状态。字段名不必统一，系统按别名表自动识别（英文/中文/缅文均可）。',
    currency: C.currency || 'MMK',
    baseUrl: b,
    generatedAt: nowIso(),
    quickStart: [
      '1) 在网关后台点「即插即用接入 → 生成配对码」，得到一个配对码（24 小时内有效、只能使用一次）。',
      '2) 调 POST ' + b + '/api/plug/pair，body 传 {"code":"配对码","name":"你的平台名","targetUrl":"可选：你方接收通知的地址"}，返回 adapterId 与 plugKey。',
      '3) 之后所有请求带上请求头 X-Plug-Key: <plugKey> 即可；或直接把 ' + b + '/kbz-plug.js 引入页面后用 KBZPlug.init(...) 调用。'
    ],
    endpoints: [
      { id: 'manifest', method: 'GET', path: '/api/plug/manifest', auth: 'none', purpose: '本自描述清单（机器可读）' },
      { id: 'wellKnown', method: 'GET', path: '/.well-known/kbz-connect.json', auth: 'none', purpose: '同上，标准发现路径' },
      { id: 'pair', method: 'POST', path: '/api/plug/pair', auth: 'code', purpose: '用配对码换取接入凭据（只需一次）', body: { code: '配对码', name: '平台名称', platform: '可选', targetUrl: '可选：你方接收通知的地址' } },
      { id: 'order', method: 'POST', path: '/api/plug/{adapterId}/order', auth: 'plugKey|signature', purpose: '通用下单（任意字段名/任意报文格式）' },
      { id: 'notify', method: 'POST', path: '/api/plug/{adapterId}/notify', auth: 'plugKey|signature', purpose: '通用回执（到账/发货/收货/发币/关闭/退款）' },
      { id: 'pull', method: 'GET', path: '/api/plug/{adapterId}/pull', auth: 'plugKey', purpose: '反向查询订单状态', query: { orderNo: '你方订单号或本系统订单号' } },
      { id: 'info', method: 'GET', path: '/api/plug/{adapterId}/info', auth: 'plugKey', purpose: '本接入点的实测信息（端点、字段别名、密钥掩码）' },
    ],
    auth: {
      primary: { type: 'header', name: 'X-Plug-Key', value: '<plugKey>', note: '也支持 ?k=<plugKey> 查询参数，方便表单/浏览器直连' },
      alternative: { type: 'header', name: 'X-Signature', value: 'HMAC-SHA256(plugKey, 原始请求体)', note: '不带密钥时可按此签名鉴权' },
      pushVerify: { note: '本系统主动推送给你方（发货/收货/结算）时，请求头 X-Signature = HMAC-SHA256(plugKey, 原始请求体)，用同一个 plugKey 校验即可。' },
    },
    fieldAliases: PLUG_FIELDS,
    amountRule: '金额可带分隔符、单位与缅文/全角数字，例如 "1,000"、"MMK 1000"、"၁၀၀၀" 均识别为 1000。必填字段只有 amount。',
    scenes: PLUG_SCENES,
    sceneRule: '不传 scene 时按特征自动判定：含游戏账号/角色/区服 → game；含 scene 关键字（deposit/rental/manual）→ 对应场景；其余 → ecommerce。',
    actions: ['paid（到账核销）', 'deliver（发货）', 'receive（收货转款到户）', 'grant（游戏发币回执）', 'close（关单）', 'refund（退款）', 'status（仅查询）'],
    actionRule: '不传 action 时自动判定：带 txid → paid；带卡密/物流单号 → deliver；游戏订单的通用成功回执 → grant。',
    responseShape: { success: 'boolean', order: '{ orderNo, orderId, payUrl, amount, payable, tailorCode, tailCode, stage, status, ... }（tailorCode 与 tailCode 同值，均指订单应付金额尾部的识别码）', mapped: '本次实际命中的外部字段名（便于零文档自纠）' },
    errorCodes: {
      400: '字段无法识别（例如金额缺失）——按 fieldAliases 换一个字段名重试',
      401: '缺少或错误的接入凭据（X-Plug-Key / 签名）',
      403: '接入点已停用 / 账号已停用 / 非缅甸地区',
      404: '配对码或订单不存在',
      409: '订单状态不允许该操作（例如已到账不可取消）',
      429: '请求过于频繁（限流）',
    },
    examples: {
      curl: [
        'curl -X POST ' + b + '/api/plug/pair -H "Content-Type: application/json" -d \'{"code":"XXXX-XXXX","name":"我的商城"}\'',
        'curl -X POST ' + b + '/api/plug/{adapterId}/order -H "X-Plug-Key: {plugKey}" -H "Content-Type: application/json" -d \'{"out_trade_no":"A1001","money":"1,000 MMK","商品":"点卡"}\'',
        'curl "' + b + '/api/plug/{adapterId}/pull?k={plugKey}&orderNo=A1001"',
      ],
      form: 'POST ' + b + '/api/plug/{adapterId}/order （Content-Type: application/x-www-form-urlencoded）body: order_no=A1001&total_amount=1000',
      connector: '<script src="' + b + '/kbz-plug.js"></script>\n<script>KBZPlug.init({ base:"' + b + '", adapterId:"{adapterId}", plugKey:"{plugKey}" });\nKBZPlug.pay(1000, { orderNo:"A1001", subject:"点卡" });</script>',
    },
    connectorUrl: b + '/kbz-plug.js',
    guideUrl: b + '/plug',
  }
}

/* ============================== 三、配对码（一键生成 / 一次使用） ============================== */
function plugNewCode() {
  const A = 'ACDEFGHJKLMNPQRTUVWXY34679'
  const b = new Uint8Array(8)
  crypto.getRandomValues(b)
  let s = ''
  for (let i = 0; i < 8; i++) s += A.charAt(b[i] % A.length)
  return s.slice(0, 4) + '-' + s.slice(4)
}

export function plugNormCode(code) {
  return String(code === undefined || code === null ? '' : code).toUpperCase().replace(/[^A-Z0-9]/g, '')
}

export async function plugCreatePairingCode(env, actor, opts) {
  const o = opts || {}
  const ttl = toInt(o.ttlSec, PLUG_CODE_TTL)
  let code = plugNewCode()
  for (let i = 0; i < 5; i++) {
    const exists = await kvGet(env, 'plugcode:' + plugNormCode(code), null)
    if (!exists) break
    code = plugNewCode()
  }
  const rec = {
    code: code, ownerId: actor.id, rootId: actor.rootId || actor.id,
    label: safeStr(o.label, 40) || '平台接入',
    status: 'active', usedAt: null, usedBy: '', adapterId: '',
    createdAt: nowIso(), expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
  }
  await kvPut(env, 'plugcode:' + plugNormCode(code), rec)
  await addAudit(env, actor.id, 'plug.code.create', { code: code, ttlSec: ttl })
  return rec
}

export async function plugListPairingCodes(env, actor) {
  const keys = await kvList(env, 'plugcode:')
  const out = []
  for (const k of keys) {
    const r = await kvGet(env, k, null)
    if (!r || r.ownerId !== actor.id) continue
    const active = r.status === 'active' && Date.parse(r.expiresAt) > Date.now()
    out.push({
      code: r.code, label: r.label, status: active ? 'active' : (r.status === 'active' ? 'expired' : r.status),
      adapterId: r.adapterId || '', usedBy: r.usedBy || '', createdAt: r.createdAt, expiresAt: r.expiresAt, usedAt: r.usedAt,
    })
  }
  out.sort(function (a, b) { return String(b.createdAt) < String(a.createdAt) ? -1 : 1 })
  return out
}

export async function plugRevokePairingCode(env, actor, code) {
  const key = 'plugcode:' + plugNormCode(code)
  const r = await kvGet(env, key, null)
  if (!r || r.ownerId !== actor.id) throw httpError(404, '配对码不存在')
  r.status = 'revoked'
  await kvPut(env, key, r)
  await addAudit(env, actor.id, 'plug.code.revoke', { code: r.code })
  return { code: r.code, status: r.status }
}

/* ============================== 四、一键配对：凭据自动发放 ============================== */
/** 用配对码换取接入点（适配器），自动生成密钥、回调地址与开箱即用代码片段 */
export async function plugPair(env, payload, baseUrl) {
  const p = payload || {}
  const code = plugNormCode(p.code)
  if (!code) throw httpError(400, '缺少配对码 code')
  const key = 'plugcode:' + code
  const rec = await kvGet(env, key, null)
  if (!rec) throw httpError(404, '配对码不存在或已失效')
  if (rec.status === 'used') throw httpError(403, '该配对码已被使用（配对码只能使用一次）')
  if (rec.status !== 'active') throw httpError(403, '该配对码已作废')
  if (Date.parse(rec.expiresAt) <= Date.now()) {
    rec.status = 'expired'
    await kvPut(env, key, rec)
    throw httpError(403, '该配对码已过期，请让对接人重新生成')
  }
  const owner = await getUser(env, rec.ownerId)
  if (!owner || owner.status === 'disabled') throw httpError(403, '接入方账号已停用')

  const forward = safeStr(p.targetUrl, 300)
  const plugKey = 'pk_' + await randomToken(20)
  const b = String(baseUrl || '').replace(/\/+$/, '')
  const adapter = {
    id: 'adp_' + code.toLowerCase() + '_' + Math.random().toString(36).slice(2, 6),
    ownerId: owner.id, rootId: owner.rootId || owner.id,
    name: safeStr(p.name, 40) || safeStr(rec.label, 40) || '平台接入',
    platform: safeStr(p.platform, 40) || 'plug',
    mode: 'plug',
    plug: true,
    plugKeyCipher: await encryptField(env, plugKey),   // 明文不落库，仅创建响应回显一次
    signSecretCipher: await encryptField(env, plugKey), // 与推送验签共用同一把 plugKey
    signSecretMasked: plugMaskKey(plugKey),
    targetUrl: forward,
    amountField: 'amount', orderIdField: 'orderNo',
    status: 'active', pairedAt: nowIso(), createdAt: nowIso(), updatedAt: nowIso(),
  }
  await kvPut(env, 'adp:' + owner.id + ':' + adapter.id, adapter)
  await kvPut(env, 'adpcb:' + adapter.id, { ownerId: owner.id, adapterId: adapter.id })
  await kvPut(env, 'plugadp:' + adapter.id, { ownerId: owner.id, name: adapter.name, pairedAt: adapter.pairedAt })
  await kvPut(env, 'plugkeyhash:' + await sha256hex('plug:' + plugKey), { adapterId: adapter.id, ownerId: owner.id })
  rec.status = 'used'
  rec.usedAt = nowIso()
  rec.adapterId = adapter.id
  rec.usedBy = adapter.name
  await kvPut(env, key, rec)
  await addAudit(env, owner.id, 'plug.pair', { adapterId: adapter.id, name: adapter.name, platform: adapter.platform, forward: forward ? 'yes' : 'no' })

  const info = plugInfo(adapter, baseUrl)
  return {
    adapterId: adapter.id,
    name: adapter.name,
    plugKey: plugKey,
    keyMasked: plugMaskKey(plugKey),
    ...info.endpoints,
    pushUrl: forward || '',
    oneLine: '<script src="' + b + '/kbz-plug.js"></script>\n<script>KBZPlug.init({ base: "' + b + '", adapterId: "' + adapter.id + '", plugKey: "' + plugKey + '" })</script>',
    curl: 'curl -X POST ' + b + '/api/plug/' + adapter.id + '/order -H "X-Plug-Key: ' + plugKey + '" -H "Content-Type: application/json" -d \'{"out_trade_no":"A1001","money":"1,000 MMK"}\'',
    manifestUrl: b + '/api/plug/manifest',
    guideUrl: b + '/plug',
    tip: '把 adapterId 与 plugKey 填进你方代码即可，字段名不必对齐：系统会按别名表自动识别（金额字段名不同也能收到）。',
  }
}

export function plugMaskKey(k) {
  const s = String(k || '')
  if (!s) return ''
  return '\u2022\u2022\u2022\u2022' + s.slice(-4)
}

/* ============================== 五、接入鉴权（密钥 / 签名，任选其一） ============================== */
async function plugLoadAdapter(env, adapterId) {
  const idx = await kvGet(env, 'adpcb:' + adapterId, null)
  if (!idx) return null
  const a = await kvGet(env, 'adp:' + idx.ownerId + ':' + idx.adapterId, null)
  if (!a) return null
  return a
}

/** 双通道鉴权：X-Plug-Key（或 ?k=）优先，其次 HMAC 签名；两者都没有 → 401 并给出用法提示 */
export async function plugAuth(env, request, url, adapterId, rawBody) {
  const cfg = await getConfig(env)
  const a = await plugLoadAdapter(env, adapterId)
  if (!a) throw httpError(404, '接入点不存在')
  if (a.status !== 'active') throw httpError(403, '接入点已停用，请联系对接人重新配对')
  await rateLimitCheck(env, 'plug:' + adapterId, cfg.rateLimitPerMin)

  const key = safeStr(headerOf(request.headers, 'X-Plug-Key'), 80) || safeStr(url.searchParams.get('k'), 80)
  if (key) {
    const idx = await kvGet(env, 'plugkeyhash:' + await sha256hex('plug:' + key), null)
    if (!idx || idx.adapterId !== adapterId) throw httpError(401, '接入密钥无效（请用配对时返回的 plugKey）')
    return { adapter: a, mode: 'key' }
  }
  const sig = headerOf(request.headers, 'X-Signature') || headerOf(request.headers, 'X-Sign')
  if (sig) {
    const expect = await hmacHex(await plugKeyOf(env, a), String(rawBody || ''))
    if (await timingSafeEqual(String(sig).toLowerCase(), String(expect).toLowerCase())) return { adapter: a, mode: 'sign' }
    throw httpError(401, '签名校验失败（签名串 = HMAC-SHA256(plugKey, 原始请求体)）')
  }
  throw httpError(401, '缺少接入密钥：请带请求头 X-Plug-Key: <plugKey>（或 ?k=<plugKey>），详见 ' + '/api/plug/manifest')
}

/** 取回该接入点的 plugKey 明文（仅用于内部推送验签） */
export async function plugKeyOf(env, a) {
  if (!a) return ''
  // 配对路径写 plugKeyCipher；普通适配器创建只写 signSecretCipher，两者都要认
  const cipher = a.plugKeyCipher || a.signSecretCipher
  if (cipher) { try { return await decryptField(env, cipher) } catch (e) { return '' } }
  return ''
}

export function plugInfo(adapter, baseUrl) {
  const b = String(baseUrl || '').replace(/\/+$/, '')
  const id = adapter.id
  return {
    adapterId: id,
    name: adapter.name,
    platform: adapter.platform,
    status: adapter.status,
    pairedAt: adapter.pairedAt || adapter.createdAt || '',
    keyMasked: adapter.signSecretMasked || '',
    pushUrl: adapter.targetUrl || '',
    endpoints: {
      orderUrl: b + '/api/plug/' + id + '/order',
      notifyUrl: b + '/api/plug/' + id + '/notify',
      pullUrl: b + '/api/plug/' + id + '/pull',
      infoUrl: b + '/api/plug/' + id + '/info',
      manifestUrl: b + '/api/plug/manifest',
      connectorUrl: b + '/kbz-plug.js',
      guideUrl: b + '/plug',
    },
    auth: { keyHeader: 'X-Plug-Key', keyQuery: 'k', signature: 'HMAC-SHA256(plugKey, 原始请求体)' },
    fields: PLUG_FIELDS,
    amountRule: '金额字段名不限（amount/money/total/金额…），可带分隔符、单位与缅文数字，唯一必填。',
    scenes: PLUG_SCENES,
    actions: ['paid', 'deliver', 'receive', 'grant', 'close', 'refund', 'status'],
  }
}

/* ============================== 六、通用下单 / 回执 / 查询 ============================== */
/** 只在本接入点范围内按「你方订单号 / 本系统订单号 / 支付 token」定位订单 */
async function plugFindOrder(env, a, ref, token) {
  if (token) {
    const idx = await kvGet(env, 'ordtok:' + safeStr(token, 80), null)
    if (idx) {
      const o = await kvGet(env, 'ord:' + idx.ownerId + ':' + idx.orderId, null)
      if (o) return o
    }
  }
  if (!ref) return null
  const hit = await kvGet(env, 'plugord:' + a.id + ':' + safeStr(ref, 60), null)
  if (hit) {
    const o = await kvGet(env, 'ord:' + hit.ownerId + ':' + hit.orderId, null)
    if (o) return o
  }
  const direct = await kvGet(env, 'ord:' + a.ownerId + ':' + safeStr(ref, 60), null)
  if (direct) return direct
  const keys = await kvList(env, 'ord:' + a.ownerId + ':')
  for (const k of keys) {
    const o = await kvGet(env, k, null)
    if (o && o.merchantOrderId && o.merchantOrderId === String(ref)) return o
  }
  return null
}

/** 面向平台的订单视图（只回必要字段，收款账号一律脱敏） */
export function plugOrderView(o, a, baseUrl) {
  const b = String(baseUrl || '').replace(/\/+$/, '')
  return {
    orderNo: o.merchantOrderId || o.id,
    orderId: o.id,
    scene: o.scene,
    status: o.status,
    stage: o.stage,
    stageText: STAGE_TEXT[o.stage] || o.stage,
    amount: o.amount,
    payable: o.payable,
    tailorCode: o.tailCode,
    tailCode: o.tailCode,   // 别名：与 tailorCode 同值，取用哪个都可以
    payUrl: b + '/pay?t=' + o.token,
    token: o.token,
    subject: o.subject,
    customer: o.customer,
    channelAccountMasked: maskAccount(o.channelAccount || ''),
    expiresAt: o.expiresAt,
    paidAt: o.paidAt || null,
    deliveredAt: o.deliveredAt || null,
    receivedAt: o.receivedAt || null,
    settledAt: o.settledAt || null,
    settleAmount: o.settleAmount || 0,
    settleNet: o.settleNet || 0,
    deliveryType: o.deliveryType || '',
    gameAccount: o.gameAccount || '',
    gameRole: o.gameRole || '',
    gameZone: o.gameZone || '',
    grantStatus: o.grantStatus || '',
    pushUrl: (a && a.targetUrl) || '',
    createdAt: o.createdAt,
  }
}

export async function plugCreateOrderViaPlug(env, a, raw, baseUrl) {
  const owner = await getUser(env, a.ownerId)
  if (!owner || owner.status === 'disabled') throw httpError(403, '接入方账号已停用')
  const m = plugMapFields(raw)
  const f = m.fields
  const extRef = safeStr(f.orderNo, 60)

  // 幂等：同一接入点 + 同一你方订单号 → 直接回原单，不会重复建单
  if (extRef) {
    const o = await plugFindOrder(env, a, extRef)
    if (o) return { duplicate: true, mapped: m.mapped, order: plugOrderView(o, a, baseUrl) }
  }

  const amount = plugParseAmount(f.amount)
  if (!amount) throw httpError(400, '未识别到金额：请传 amount / money / total / 金额 等字段（可参考 /api/plug/manifest 的 fieldAliases）')
  if (amount < 0) throw httpError(400, '金额不能为负')
  const scene = plugDetectScene(raw, f.scene)
  const pushUrl = safeStr(f.notifyUrl, 300) || a.targetUrl || ''
  const plugKey = await plugKeyOf(env, a)

  const order = await createOrder(env, owner, {
    amount: amount,
    scene: scene,
    subject: safeStr(f.subject, 80),
    customer: safeStr(f.customer, 60),
    platform: safeStr(f.platform, 40) || a.platform || 'plug',
    merchantOrderId: extRef,
    cardSecret: safeStr(f.cardSecret, 400),
    trackingNo: safeStr(f.trackingNo, 60),
    notifyUrl: pushUrl,
    notifySecret: plugKey || '',
    gameAccount: safeStr(f.gameAccount, 60),
    gameRole: safeStr(f.gameRole, 60),
    gameZone: safeStr(f.gameZone, 40),
    itemCode: safeStr(f.itemCode, 60),
    quantity: toInt(f.quantity, 1),
  })
  if (extRef) await kvPut(env, 'plugord:' + a.id + ':' + extRef, { ownerId: order.ownerId, orderId: order.id })
  await addAudit(env, a.ownerId, 'plug.order', { adapterId: a.id, orderId: order.id, scene: scene, amount: amount, mapped: m.mapped })
  return { duplicate: false, mapped: m.mapped, order: plugOrderView(order, a, baseUrl) }
}

/** 通用回执：到账 / 发货 / 收货 / 发币 / 关闭 / 退款 / 仅查询 */
export async function plugNotifyViaPlug(env, a, raw, baseUrl) {
  const owner = await getUser(env, a.ownerId)
  if (!owner || owner.status === 'disabled') throw httpError(403, '接入方账号已停用')
  const m = plugMapFields(raw)
  const f = m.fields
  const det = plugDetectAction(raw)
  let action = det.action
  const ref = safeStr(f.orderNo, 60) || safeStr(f.orderId, 60)
  const order = await plugFindOrder(env, a, ref, f.token)
  if (!order) throw httpError(404, '未找到对应订单（请检查 orderNo 是否为本系统订单号或你方商户订单号）')

  // 场景归一：游戏订单的「通用成功回执」视为发币回执；非游戏订单不发币
  if (order.scene === 'game' && !/paid|pay|payment|到账|收款|已付/.test(String(det.explicit || '').toLowerCase())) {
    if (action === 'paid' || action === 'status' || action === 'deliver') action = 'grant'
  }
  if (order.scene !== 'game' && action === 'grant') action = 'deliver'

  let order2 = order
  let extra = {}
  if (action === 'paid') {
    const r = await settleOrder(env, order, {
      amount: plugParseAmount(f.amount) || order.payable,
      txid: safeStr(f.txid, 64) || ('PLUG' + Date.now()),
      source: 'plug',
    })
    order2 = r.order
    extra = { duplicate: !!r.duplicate, underpaid: !!r.underpaid, expired: !!r.expired }
    if (r.underpaid) extra.note = '到账金额小于应付金额，订单进入部分到账（partial）'
  } else if (action === 'grant') {
    order2 = await grantGameOrder(env, order, {
      ok: true, txid: safeStr(f.txid, 64), auto: true,
      quantity: toInt(f.quantity, order.quantity), itemCode: safeStr(f.itemCode, 60) || order.itemCode,
    })
    extra = { grantStatus: order2.grantStatus || '' }
  } else if (action === 'deliver') {
    order2 = await deliverOrder(env, owner, order.id, {
      cardSecret: safeStr(f.cardSecret, 400) || undefined,
      trackingNo: safeStr(f.trackingNo, 60) || undefined,
      subject: order.subject,
      delivery: { itemName: safeStr(f.subject, 80) || undefined },
    })
    extra = { deliveryType: (order2.delivery && order2.delivery.type) || '' }
  } else if (action === 'receive') {
    order2 = await confirmReceive(env, owner, order.id, {})
  } else if (action === 'close') {
    order2 = await cancelOrder(env, owner, order.id)
  } else if (action === 'refund') {
    order2 = await refundOrder(env, owner, order.id, safeStr(f.subject, 120) || '平台发起退款')
  } else {
    // status：只读，不改状态
    order2 = await kvGet(env, 'ord:' + order.ownerId + ':' + order.id, null) || order
  }
  await addAudit(env, a.ownerId, 'plug.notify', { adapterId: a.id, orderId: order.id, action: action, mapped: m.mapped })
  return { action: action, mapped: m.mapped, ...extra, order: plugOrderView(order2, a, baseUrl) }
}

export async function plugPullViaPlug(env, a, ref, token, baseUrl) {
  const order = await plugFindOrder(env, a, ref, token)
  if (!order) throw httpError(404, '未找到对应订单')
  return { order: plugOrderView(order, a, baseUrl) }
}

/* ============================== 七、接入点自身信息 / 轮换密钥 ============================== */
export async function plugRotateKey(env, actor, adapterId) {
  // 与 plugLoadScopedAdapter 对称：自己的接入点，或自己可见范围内（超管对全部、代理对下属）的接入点
  const a = await plugLoadScopedAdapter(env, actor, adapterId)
  if (!a) throw httpError(404, '接入点不存在')
  const ownerId = a.ownerId
  const oldKey = await plugKeyOf(env, a)
  if (oldKey) await kvDel(env, 'plugkeyhash:' + await sha256hex('plug:' + oldKey))
  const plugKey = 'pk_' + await randomToken(20)
  const next = Object.assign({}, a, {
    plugKeyCipher: await encryptField(env, plugKey),
    signSecretCipher: await encryptField(env, plugKey),
    signSecretMasked: plugMaskKey(plugKey),
    updatedAt: nowIso(),
  })
  await kvPut(env, 'adp:' + ownerId + ':' + a.id, next)
  await kvPut(env, 'plugkeyhash:' + await sha256hex('plug:' + plugKey), { adapterId: a.id, ownerId: ownerId })
  await addAudit(env, actor.id, 'plug.rotate', { adapterId: a.id, ownerId: ownerId })
  return { adapterId: a.id, plugKey: plugKey, keyMasked: plugMaskKey(plugKey), rotatedAt: next.updatedAt }
}

/* ============================== 八、预置平台模板库（一键接入） ============================== */
/**
 * 模板 = 一套「开箱即用」的接入画像：场景 / 端点 / 方法 / 字段映射 / 签名规则 / 回调解析。
 * 管理员在后台选一个模板（或选「纯手工模式 manual_free」）→ 只填最少信息 → 一键生成适配器与接入凭据。
 * fields：本系统规范字段 → 该平台常见的外部字段名（规范字段清单见 PLUG_FIELDS）；
 *         未列出的平台按「纯手工模式」自行填写或直接粘贴抓包报文由 plugParseCaptured 自适配。
 */
export const PLUG_TEMPLATES = [
  {
    id: 'kbzpay_hosted',
    name: { zh: 'KBZPay 托管收银台', en: 'KBZPay hosted checkout', my: 'KBZPay ငွေလက်ခံ စာမျက်နှာ' },
    scene: 'ecommerce', mode: 'hosted', method: 'POST', endpoint: '{base}/api/pay/init',
    signRule: 'hmac-sha256(原始请求体, plugKey) 置于 X-Signature', callbackParse: 'json',
    fields: { orderNo: 'merchantOrderId', amount: 'amount', subject: 'subject', customer: 'customer', cardSecret: 'cardSecret', trackingNo: 'trackingNo', notifyUrl: 'notifyUrl' },
    notes: { zh: '最省事的托管方式：跳到本系统收银台完成付款，回调按 JSON 推送。', en: 'Hosted checkout: redirect to the built-in cashier, JSON callback.', my: 'ငွေရှင်းစာမျက်နှာသုံး အလွယ်ဆုံးနည်း၊ JSON ဖြင့် အကြောင်းပြန်ပို့သည်။' },
  },
  {
    id: 'ecom_shop',
    name: { zh: '自建商城 / 电商订单', en: 'Custom shop / e-commerce order', my: 'ကိုယ်ပိုင် ဆိုင်တိုင် / ကုန်သွယ် အော်ဒါ' },
    scene: 'ecommerce', mode: 'api', method: 'POST', endpoint: '{base}/api/plug/{adapterId}/order',
    signRule: 'hmac-sha256(原始请求体, plugKey) 置于 X-Signature', callbackParse: 'json',
    fields: { orderNo: 'order_sn', amount: 'total_fee', subject: 'goods_name', customer: 'buyer_id', trackingNo: 'express_no', itemCode: 'sku', quantity: 'qty', notifyUrl: 'notify_url' },
    notes: { zh: '字段名不必对齐：order_sn / total_fee 这类命名会被别名表自动识别。', en: 'Field names need no alignment — aliases are auto-detected.', my: 'ကွက်လပ်အမည်များ ကိုက်ညီရန် မလိုပါ၊ အလိုအလျောက် ဖော်ထုတ်သည်။' },
  },
  {
    id: 'game_platform',
    name: { zh: '游戏平台 / 发币订单', en: 'Game platform / coin order', my: 'ဂိမ်းပလက်ဖောင်း / ငွေကြေးအော်ဒါ' },
    scene: 'game', mode: 'api', method: 'POST', endpoint: '{base}/api/plug/{adapterId}/order',
    signRule: 'hmac-sha256(原始请求体, plugKey) 置于 X-Signature', callbackParse: 'json',
    fields: { orderNo: 'out_trade_no', amount: 'money', gameAccount: 'playerAccount', gameZone: 'serverId', gameRole: 'roleName', itemCode: 'sku', quantity: 'qty', customer: 'playerId', notifyUrl: 'notify_url' },
    notes: { zh: '游戏类进托管：收货（发币）后才转款到户；回执可用 grant 动作。', en: 'Game orders are escrowed until coin grant is confirmed.', my: 'ဂိမ်းအော်ဒါသည် ငွေထုတ်ပေးပြီးမှ လွှဲပြောင်းသည်။' },
  },
  {
    id: 'wallet_topup',
    name: { zh: '钱包 / 账户充值', en: 'Wallet / account top-up', my: 'ပိုက်ဆံအိတ် / အကောင့် ဖြည့်ငွေ' },
    scene: 'deposit', mode: 'api', method: 'POST', endpoint: '{base}/api/plug/{adapterId}/order',
    signRule: 'hmac-sha256(原始请求体, plugKey) 置于 X-Signature', callbackParse: 'json',
    fields: { orderNo: 'orderId', amount: 'payAmount', customer: 'userId', subject: 'title', platform: 'source', notifyUrl: 'notifyUrl' },
    notes: { zh: '充值场景：金额识别码 + 自动匹配核销，回调只需带 txid 即可。', en: 'Top-up: amount tail code + auto reconciliation.', my: 'ဖြည့်ငွေ − ပမာဏကုဒ်ဖြင့် အလိုအလျောက် ကိုက်ညီစစ်ဆေးသည်။' },
  },
  {
    id: 'manual_free',
    name: { zh: '纯手工模式（无模板）', en: 'Manual mode (no template)', my: 'လက်ဖြင့် စနစ်（ပုံစံမပါ）' },
    scene: 'manual', mode: 'api', method: 'POST', endpoint: '{base}/api/plug/{adapterId}/order',
    signRule: 'hmac-sha256(原始请求体, plugKey) 置于 X-Signature', callbackParse: 'json',
    fields: {},
    notes: { zh: '没有任何文档时的兜底：把抓包报文贴进来，由系统自适配字段映射。', en: 'Fallback with no docs: paste a captured request and let the system map fields.', my: 'စာရွက်စာတမ်းမရှိလျှင် ဖမ်းယူထားသည့် တောင်းဆိုချက်ကို ကူးထည့်ပါ။' },
  },
]

export function plugTemplateById(id) {
  const key = safeStr(id, 40)
  if (!key) return null
  for (const t of PLUG_TEMPLATES) { if (t.id === key) return t }
  return null
}

/** 模板 + 手工填写 → 归一化接入画像（端点 / 方法 / 字段映射 / 签名规则 / 回调解析） */
export function plugNormalizeProfile(payload, tpl) {
  const p = payload || {}
  const base = tpl || {}
  const scene = PLUG_SCENES.indexOf(p.scene) >= 0 ? p.scene : (PLUG_SCENES.indexOf(base.scene) >= 0 ? base.scene : 'manual')
  const mode = ['hosted', 'sdk', 'api'].indexOf(p.mode) >= 0 ? p.mode : (base.mode === 'hosted' ? 'hosted' : 'api')
  const method = ['POST', 'GET', 'PUT', 'PATCH'].indexOf(String(p.method || '').toUpperCase()) >= 0
    ? String(p.method).toUpperCase() : (base.method || 'POST')
  const fields = Object.assign({}, base.fields || {})
  const patch = (p.fields && typeof p.fields === 'object') ? p.fields : {}
  Object.keys(patch).forEach(function (k) { if (patch[k]) fields[k] = safeStr(patch[k], 40) })
  return {
    templateId: base.id || '',
    scene: scene,
    mode: mode,
    method: method,
    endpoint: safeStr(p.endpoint, 300) || base.endpoint || '{base}/api/plug/{adapterId}/order',
    signRule: safeStr(p.signRule, 160) || base.signRule || 'hmac-sha256(原始请求体, plugKey) 置于 X-Signature',
    callbackParse: safeStr(p.callbackParse, 40) || base.callbackParse || 'json',
    fields: fields,
    captured: p.captured || null,
    notes: base.notes || null,
  }
}

/** 端点占位符替换：{base} / {adapterId} */
export function plugProfileEndpoint(prof, baseUrl, adapterId) {
  const b = String(baseUrl || '').replace(/\/+$/, '')
  return String((prof && prof.endpoint) || '').split('{base}').join(b).split('{adapterId}').join(String(adapterId || ''))
}

/* ============================== 九、抓包免文档自适配 ============================== */
/**
 * 无 API 文档时的核心能力：把抓包得到的请求（JSON / 表单 / 查询串 / 纯文本 + URL 查询参数）
 * 丢进来，系统回报「我看懂了什么」：识别到的标准字段、命中的外部字段名、缺失字段、场景与动作。
 * 管理员据此一键生成字段映射，不必向对方索要任何文档。
 */
export function plugParseCaptured(payload) {
  const p = payload || {}
  const urlStr = safeStr(p.url, 500)
  const ctype = safeStr(p.contentType || p.ctype, 80)
  let raw = (p.captured !== undefined && p.captured !== null) ? p.captured : p.raw
  if (raw && typeof raw === 'object') raw = JSON.stringify(raw)
  raw = String(raw === undefined || raw === null ? '' : raw)
  let urlObj = null
  if (urlStr) { try { urlObj = new URL(urlStr) } catch (e) { urlObj = null } }
  if (!raw.trim() && !(urlObj && Array.from(urlObj.searchParams.keys()).length)) {
    throw httpError(400, '请粘贴抓包得到的请求内容（JSON / 表单 / 查询串均可），或提供带查询参数的 URL')
  }
  const parsed = plugParseUniversal(raw, ctype, urlObj)
  const m = plugMapFields(parsed)
  const det = plugDetectAction(parsed)
  const scene = plugDetectScene(parsed, m.fields.scene)
  const amountRaw = m.fields.amount
  const amount = plugParseAmount(amountRaw)
  const used = {}
  Object.keys(m.fields).forEach(function (k) { if (m.fields[k] !== undefined && m.fields[k] !== null && m.fields[k] !== '') used[k] = m.fields[k] })
  const mapped = {}
  Object.keys(m.mapped || {}).forEach(function (k) { mapped[k] = m.mapped[k] })
  const missing = []
  if (!amount) missing.push('amount（金额）')
  if (!safeStr(m.fields.orderNo, 60)) missing.push('orderNo（你方订单号，可选但建议提供）')
  const known = Object.keys(used)
  const confidence = Math.min(100, Math.round(known.length * 100 / 6))
  return {
    url: urlStr,
    contentType: ctype,
    scene: scene,
    action: det.action,
    actionField: det.explicit || '',
    fields: used,
    mapped: mapped,
    missing: missing,
    amount: amount,
    amountRaw: amountRaw === undefined || amountRaw === null ? '' : String(amountRaw),
    confidence: confidence,
    flatCount: Object.keys(m.flat || {}).length,
    suggestion: missing.length
      ? '还缺关键字段，请补一条含「金额」的抓包样例，或在向导里手工指定金额字段名。'
      : '字段齐全，可直接在向导里一键生成适配器（字段映射已自动填入）。',
  }
}

/* ============================== 十、一键接入向导（配置落库 / 连通测试 / 接入点列表） ============================== */
/** 取回归属可见的接入点（自己的，或自己子孙的） */
async function plugLoadScopedAdapter(env, actor, adapterId) {
  const id = safeStr(adapterId, 60)
  if (!id) return null
  const own = await kvGet(env, 'adp:' + actor.id + ':' + id, null)
  if (own) return own
  const idx = await kvGet(env, 'adpcb:' + id, null)
  if (!idx || !idx.ownerId) return null
  if (!(await canAccessOwner(env, actor, idx.ownerId))) return null
  return await kvGet(env, 'adp:' + idx.ownerId + ':' + id, null)
}

/** 一键接入：模板 / 纯手工画像 → 生成适配器（复用 engine.createAdapter），并落库接入画像 */
export async function plugCreateAdapterProfile(env, actor, payload, baseUrl) {
  const p = payload || {}
  const tpl = plugTemplateById(safeStr(p.templateId, 40))
  const prof = plugNormalizeProfile(p, tpl)
  // 抓包自适配：直接粘贴报文时，用识别结果回填字段映射
  if (p.captured) {
    const parsed = plugParseCaptured(p)
    Object.keys(parsed.fields).forEach(function (k) {
      const v = safeStr(parsed.mapped[k], 40)
      if (v) prof.fields[k] = v
    })
    if (!p.scene) prof.scene = parsed.scene
  }
  // 与「配对码自助接入」（plugPair）保持等价：密钥同时写入 plugKeyCipher（X-Plug-Key 鉴权）
  // 与 signSecretCipher（推送验签），并补写 plugkeyhash 索引；否则向导生成的接入点既无法鉴权，
  // 连通测试的「密钥可用性」也会必然失败。
  const secret = safeStr(p.signSecret, 80) || ('pk_' + await randomToken(20))
  const created = await createAdapter(env, actor, {
    name: safeStr(p.name, 40) || (tpl ? (tpl.name.zh || tpl.id) : '手工接入点'),
    platform: safeStr(p.platform, 40) || prof.scene,
    mode: prof.mode,
    targetUrl: safeStr(p.targetUrl, 300),
    signSecret: secret,
    amountField: prof.fields.amount || 'amount',
    orderIdField: prof.fields.orderNo || 'orderNo',
  })
  const stored = await kvGet(env, 'adp:' + actor.id + ':' + created.id, null)
  const keyCipher = await encryptField(env, secret)
  const adapterRec = Object.assign({}, stored || {}, {
    plug: true,
    plugKeyCipher: keyCipher,
    signSecretCipher: keyCipher,
    signSecretMasked: plugMaskKey(secret),
    pairedAt: (stored && stored.pairedAt) || nowIso(),
    updatedAt: nowIso(),
  })
  await kvPut(env, 'adp:' + actor.id + ':' + created.id, adapterRec)
  await kvPut(env, 'plugkeyhash:' + await sha256hex('plug:' + secret), { adapterId: created.id, ownerId: actor.id })
  const adapter = Object.assign({}, created, { plug: true, signSecretMasked: adapterRec.signSecretMasked })
  const rec = {
    adapterId: created.id,
    ownerId: actor.id,
    templateId: prof.templateId,
    templateName: tpl ? tpl.name : null,
    scene: prof.scene,
    mode: prof.mode,
    method: prof.method,
    endpoint: prof.endpoint,
    endpointResolved: plugProfileEndpoint(prof, baseUrl, created.id),
    signRule: prof.signRule,
    callbackParse: prof.callbackParse,
    fields: prof.fields,
    capturedSample: prof.captured ? String(prof.captured).slice(0, 2000) : '',
    notes: prof.notes,
    targetUrl: created.targetUrl || '',
    wizard: true,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
  await kvPut(env, 'plugprof:' + created.id, rec)
  await addAudit(env, actor.id, 'plug.profile.create', { adapterId: created.id, templateId: rec.templateId, scene: rec.scene })
  const quick = plugInfo(adapter, baseUrl)
  return {
    adapter: adapter,
    profile: rec,
    plugKey: secret,
    keyMasked: adapterRec.signSecretMasked,
    endpoints: quick.endpoints,
    oneLine: '<script src="' + String(baseUrl || '').replace(/\/+$/, '') + '/kbz-plug.js"></script>\n<script>KBZPlug.init({ base: "' + String(baseUrl || '').replace(/\/+$/, '') + '", adapterId: "' + created.id + '", plugKey: "' + secret + '" })</script>',
    tip: '把 adapterId 与接入密钥填进你方代码即可；字段名不必对齐，系统按别名表自动识别。',
  }
}

export async function plugGetProfile(env, actor, adapterId) {
  const a = await plugLoadScopedAdapter(env, actor, adapterId)
  if (!a) throw httpError(404, '资源不存在')
  const prof = await kvGet(env, 'plugprof:' + a.id, null)
  return { adapterId: a.id, name: a.name, info: plugInfo(a, ''), profile: prof }
}

/** 接入点列表（含向导画像与端点速览）：后台接入向导页用 */
export async function plugListPoints(env, actor, baseUrl) {
  const list = await listAdapters(env, actor)
  const out = []
  for (const a of list) {
    const prof = await kvGet(env, 'plugprof:' + a.id, null)
    const info = plugInfo(a, baseUrl)
    out.push({
      adapterId: a.id,
      name: a.name,
      platform: a.platform,
      mode: a.mode,
      plug: !!a.plug,
      status: a.status,
      ownerId: a.ownerId,
      keyMasked: a.signSecretMasked || '',
      hasSecret: !!a.hasSecret,
      targetUrl: a.targetUrl || '',
      callbackUrl: a.callbackUrl,
      createdAt: a.createdAt || '',
      endpoints: info.endpoints,
      templateId: prof ? prof.templateId : '',
      endpoint: prof ? prof.endpointResolved || prof.endpoint : '',
      method: prof ? prof.method : 'POST',
      signRule: prof ? prof.signRule : '',
      callbackParse: prof ? prof.callbackParse : '',
      fields: prof ? prof.fields : null,
      wizard: !!(prof && prof.wizard),
    })
  }
  out.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)) })
  return out
}

/** 单次 HTTP 探测（带超时，用于一键连通测试） */
async function plugHttpProbe(url, method, headers, body, timeoutMs) {
  const started = Date.now()
  const ctl = new AbortController()
  const timer = setTimeout(function () { ctl.abort() }, toInt(timeoutMs, 8000))
  try {
    const res = await fetch(url, { method: method, headers: headers, body: body, signal: ctl.signal })
    clearTimeout(timer)
    let text = ''
    try { text = await res.text() } catch (e) { text = '' }
    return { ok: !!res.ok, status: res.status, latencyMs: Date.now() - started, body: String(text).slice(0, 300) }
  } catch (e) {
    clearTimeout(timer)
    return { ok: false, status: 0, latencyMs: Date.now() - started, error: String((e && e.message) || e) }
  }
}

/**
 * 一键连通测试：① 接入点凭据与端点自检 ② 字段映射完整性 ③ 向目标回调地址做真实探测（若已配置）
 * ④ 密钥可用性。返回逐项结果与总结论，便于后台直接展示。
 */
export async function plugConnectionTest(env, actor, adapterId, payload, baseUrl) {
  const a = await plugLoadScopedAdapter(env, actor, adapterId)
  if (!a) throw httpError(404, '资源不存在')
  const p = payload || {}
  const info = plugInfo(a, baseUrl)
  const prof = await kvGet(env, 'plugprof:' + a.id, null)
  const keyPlain = await plugKeyOf(env, a)
  const b = String(baseUrl || '').replace(/\/+$/, '')
  const tests = []
  tests.push({
    name: '接入点状态与端点',
    ok: a.status === 'active' && !!info.endpoints.orderUrl,
    detail: a.status === 'active' ? ('端点就绪：' + info.endpoints.orderUrl) : ('接入点状态为 ' + a.status + '，请先启用'),
  })
  const fields = prof ? prof.fields : null
  const missing = []
  if (!fields || !fields.amount) missing.push('amount')
  tests.push({
    name: '字段映射完整性',
    ok: missing.length === 0,
    detail: missing.length ? ('缺少必填映射：' + missing.join('、') + '（可在向导里补，或粘贴抓包报文自适配）') : '金额等关键字段已映射',
  })
  tests.push({
    name: '密钥可用性',
    ok: !!keyPlain,
    detail: keyPlain ? ('接入密钥可用（' + plugMaskKey(keyPlain) + '）') : '未取到接入密钥，请重新配对或轮换密钥',
  })
  const forward = safeStr(p.targetUrl, 300) || a.targetUrl || ''
  if (forward) {
    const sample = prof && prof.capturedSample
      ? prof.capturedSample
      : JSON.stringify({ action: 'status', orderNo: 'PLUGTEST' + Date.now(), amount: 1, note: '一键连通测试（可忽略）' })
    const sig = keyPlain ? await hmacHex(keyPlain, sample) : ''
    const headers = { 'Content-Type': 'application/json', 'X-Connector': 'kbz-plug/' + PLUG_VERSION }
    if (sig) headers['X-Signature'] = sig
    const probe = await plugHttpProbe(forward, 'POST', headers, sample, p.timeoutMs)
    tests.push({
      name: '推送回调地址连通',
      ok: probe.ok,
      detail: probe.ok
        ? ('目标地址响应 ' + probe.status + '（' + probe.latencyMs + 'ms）')
        : ('目标地址不可达或被拒：' + (probe.error || ('HTTP ' + probe.status)) + '（' + probe.latencyMs + 'ms）'),
      probe: probe,
    })
  } else {
    tests.push({ name: '推送回调地址连通', ok: true, detail: '未配置目标回调地址，跳过（本系统通用入口无需回调也能接入）' })
  }
  const failed = tests.filter(function (t) { return !t.ok })
  const result = {
    adapterId: a.id,
    name: a.name,
    forward: forward,
    selfBase: b,
    tests: tests,
    ok: failed.length === 0,
    failedCount: failed.length,
    conclusion: failed.length ? ('未通过：' + failed.map(function (t) { return t.name }).join('、')) : '全部通过，可直接接入',
  }
  await addAudit(env, actor.id, 'plug.test', { adapterId: a.id, ok: result.ok, failed: result.failedCount })
  return result
}

/* ============================== 十一、单文件连接器（/kbz-plug.js） ============================== */
/**
 * 连接器代码（零依赖、可 <script> 直引）：
 *   - 端点自发现：只需 base + adapterId + plugKey，无需记任何路径；
 *   - 字段自动映射：本地别名表把 orderNo/money/totalFee/金额… 归一为标准字段；
 *   - 失败重试：网络抖动自动重试，支付轮询自动收敛。
 * （注意：本常量内的正则一律不使用转义序列，避免字符串拼接时的转义歧义。）
 */
export const PLUG_CONNECTOR_CODE = [
  '/*! KBZPlug 零文档即插即用连接器 v' + PLUG_VERSION + ' | 单文件 · 零依赖 · 端点自发现 · 字段自动映射 · 失败重试 */',
  '(function (root, factory) {',
  '  if (typeof module === "object" && module.exports) { module.exports = factory() } else { root.KBZPlug = factory() }',
  '}(typeof self !== "undefined" ? self : this, function () {',
  '  var CFG = { base: "", adapterId: "", plugKey: "", timeout: 15000, retry: 2, pollMs: 2000, pollTries: 15 }',
  '  var ALIAS = {',
  '    orderNo: ["orderNo", "order_no", "outTradeNo", "out_trade_no", "tradeNo", "merchantOrderId", "orderId", "订单号"],',
  '    amount: ["amount", "amt", "money", "total", "totalFee", "total_fee", "price", "payable", "payAmount", "金额"],',
  '    subject: ["subject", "title", "desc", "goodsName", "itemName", "商品名称"],',
  '    customer: ["customer", "userId", "buyerId", "memberId", "playerId", "account", "用户", "玩家"],',
  '    gameAccount: ["gameAccount", "playerAccount", "gameUser", "游戏账号", "ဂိမ်းအကောင့်"],',
  '    gameZone: ["gameZone", "serverId", "zoneId", "区服"],',
  '    gameRole: ["gameRole", "roleName", "角色名"],',
  '    itemCode: ["itemCode", "sku", "goodsCode", "商品编码"],',
  '    quantity: ["quantity", "qty", "num", "数量"],',
  '    cardSecret: ["cardSecret", "cardCode", "cardNo", "卡密"],',
  '    trackingNo: ["trackingNo", "expressNo", "waybillNo", "物流单号"],',
  '    notifyUrl: ["notifyUrl", "callbackUrl", "webhook", "回调地址"],',
  '    txid: ["txid", "transactionId", "refNo", "流水号"]',
  '  }',
  '  function trimSlash(s) { s = String(s === undefined || s === null ? "" : s); while (s.length > 1 && s.charAt(s.length - 1) === "/") { s = s.slice(0, -1) } return s }',
  '  function norm(k) { return String(k === undefined || k === null ? "" : k).replace(/[^a-zA-Z0-9]/g, "").toLowerCase() }',
  '  function pick(o, canon) {',
  '    var n = {}, k, keys = ALIAS[canon] || [], i',
  '    for (k in (o || {})) { n[norm(k)] = o[k] }',
  '    for (i = 0; i < keys.length; i++) { var v = n[norm(keys[i])]; if (v !== undefined && v !== null && v !== "") { return v } }',
  '    return ""',
  '  }',
  '  function build(o) {',
  '    var b = {}, k, v',
  '    for (k in ALIAS) { v = pick(o, k); if (v !== "") { b[k] = v } }',
  '    for (k in (o || {})) { if (typeof o[k] === "object" && k !== "fields") { b[k] = o[k] } }',
  '    if (b.amount) { b.amount = String(b.amount) }',
  '    return b',
  '  }',
  '  function url(op, isGet, extra) {',
  '    var u = trimSlash(CFG.base) + "/api/plug/" + encodeURIComponent(CFG.adapterId) + "/" + op',
  '    var q = []',
  '    if (isGet && CFG.plugKey) { q.push("k=" + encodeURIComponent(CFG.plugKey)) }',
  '    if (extra) { q.push(extra) }',
  '    return q.length ? (u + "?" + q.join("&")) : u',
  '  }',
  '  function send(u, m, body, tries) {',
  '    var opt = { method: m, headers: { "Content-Type": "application/json" } }',
  '    if (CFG.plugKey) { opt.headers["X-Plug-Key"] = CFG.plugKey }',
  '    if (m !== "GET" && body) { opt.body = JSON.stringify(body) }',
  '    var ctl = null, timer = null',
  '    try { ctl = new AbortController(); opt.signal = ctl.signal } catch (e) { ctl = null }',
  '    if (ctl) { timer = setTimeout(function () { try { ctl.abort() } catch (e2) {} }, CFG.timeout) }',
  '    return fetch(u, opt).then(function (r) {',
  '      if (timer) { clearTimeout(timer) }',
  '      return r.text().then(function (t) { try { return JSON.parse(t) } catch (e3) { return { success: r.ok, raw: t } } })',
  '    }).catch(function (e) {',
  '      if (timer) { clearTimeout(timer) }',
  '      if (tries > 0) { return send(u, m, body, tries - 1) }',
  '      throw e',
  '    })',
  '  }',
  '  var api = {',
  '    version: "' + PLUG_VERSION + '",',
  '    aliases: ALIAS,',
  '    init: function (o) { for (var k in (o || {})) { CFG[k] = o[k] } CFG.base = trimSlash(CFG.base); return { base: CFG.base, adapterId: CFG.adapterId } },',
  '    config: function () { return { base: CFG.base, adapterId: CFG.adapterId, keyMasked: CFG.plugKey ? ("****" + String(CFG.plugKey).slice(-4)) : "" } },',
  '    info: function () { return send(url("info", true), "GET", null, CFG.retry) },',
  '    order: function (p) { return send(url("order", false), "POST", build(p || {}), CFG.retry) },',
  '    notify: function (p) { return send(url("notify", false), "POST", build(p || {}), CFG.retry) },',
  '    status: function (ref) { return send(url("pull", true, "ref=" + encodeURIComponent(ref || "")), "GET", null, CFG.retry) },',
  '    pay: function (amount, p) {',
  '      var body = {}, k',
  '      for (k in (p || {})) { body[k] = p[k] }',
  '      body.amount = amount',
  '      return api.order(body).then(function (r) {',
  '        var tries = 0',
  '        var ref = (r && r.order && (r.order.orderNo || r.order.orderId)) || ""',
  '        return new Promise(function (resolve, reject) {',
  '          function loop() {',
  '            if (tries++ >= CFG.pollTries) { return resolve(r) }',
  '            setTimeout(function () {',
  '              api.status(ref).then(function (s) {',
  '                var st = s && s.order && s.order.status',
  '                if (st === "paid" || st === "closed" || st === "canceled" || st === "refunded") { resolve(s) } else { loop() }',
  '              }).catch(function () { loop() })',
  '            }, CFG.pollMs)',
  '          }',
  '          loop()',
  '        })',
  '      })',
  '    }',
  '  }',
  '  return api',
  '}))',
].join('\n')

/** 开箱即用代码片段（配对 / 向导生成后回显一次） */
export function plugQuickStart(adapter, plugKeyPlain, baseUrl) {
  const b = String(baseUrl || '').replace(/\/+$/, '')
  const id = adapter && adapter.id ? adapter.id : ''
  const key = plugKeyPlain || ''
  return {
    oneLine: '<script src="' + b + '/kbz-plug.js"></script>\n<script>KBZPlug.init({ base: "' + b + '", adapterId: "' + id + '", plugKey: "' + key + '" })</script>',
    curl: 'curl -X POST ' + b + '/api/plug/' + id + '/order -H "X-Plug-Key: ' + key + '" -H "Content-Type: application/json" -d \'{"out_trade_no":"A1001","money":"1,000 MMK"}\'',
    manifestUrl: b + '/api/plug/manifest',
    connectorUrl: b + '/kbz-plug.js',
    guideUrl: b + '/plug',
    infoUrl: b + '/api/plug/' + id + '/info',
  }
}