/* =============================================================================
 * 页面层（pages.js）
 * -----------------------------------------------------------------------------
 * 说明：全部页面为「单文件内联」HTML（无外部依赖、无 CDN），可直接部署使用。
 *       页面内的脚本一律使用字符串拼接，避免与外层模板字符串冲突。
 * ========================================================================== */

import { translate } from './i18n.js'

/* 语言判定：?lang=my|en|zh，默认中文 */
function pickLang(url) {
  let code = ''
  try { code = (url && url.searchParams && url.searchParams.get('lang')) || '' } catch (e) { code = '' }
  code = String(code || '').toLowerCase()
  if (code === 'my' || code === 'mm' || code === 'burmese') return 'my'
  if (code === 'en') return 'en'
  return 'zh'
}

function esc(s) {
  return String(s === undefined || s === null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;')
}

function pageHead(title, cfg) {
  return '<!DOCTYPE html><html lang="zh"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">' +
    '<meta name="theme-color" content="#0a0e27">' +
    '<title>' + esc(title) + '</title>' +
    '<style>' + BASE_CSS + '</style></head>'
}

const BASE_CSS = [
  '*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}',
  'body{background:#0a0e27;color:#ccd6f6;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans Myanmar",sans-serif;line-height:1.6;font-size:15px}',
  'a{color:#64ffda;text-decoration:none}',
  '.wrap{max-width:1080px;margin:0 auto;padding:16px}',
  'h1{font-size:22px;color:#FFD700;margin-bottom:4px}',
  'h2{font-size:17px;color:#64ffda;margin:18px 0 10px}',
  'h3{font-size:15px;color:#e6f1ff;margin:12px 0 8px}',
  'p{color:#8892b0;font-size:14px}',
  '.card{background:#131a3a;border:1px solid #1e3a5f;border-radius:14px;padding:16px;margin-bottom:14px}',
  '.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}',
  '.between{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}',
  'button,.btn{background:#FFD700;color:#0a0e27;border:0;border-radius:10px;padding:10px 16px;font-size:14px;font-weight:700;cursor:pointer}',
  'button.ghost,.btn.ghost{background:transparent;color:#64ffda;border:1px solid #1e3a5f}',
  'button.danger{background:#ff6b6b;color:#fff}',
  'button.small{padding:6px 10px;font-size:12px;border-radius:8px}',
  'input,select,textarea{background:#0d1b3a;border:1px solid #1e3a5f;color:#ccd6f6;border-radius:10px;padding:10px 12px;font-size:15px;width:100%;font-family:inherit}',
  'label{display:block;font-size:12px;color:#8892b0;margin:8px 0 4px}',
  'table{width:100%;border-collapse:collapse;font-size:13px}',
  'th,td{padding:8px 6px;text-align:left;border-bottom:1px solid #1e3a5f;vertical-align:middle}',
  'th{color:#8892b0;font-weight:600;font-size:12px;white-space:nowrap}',
  '.tblbox{overflow-x:auto}',
  '.tag{display:inline-block;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700}',
  '.tag.ok{background:#64ffda22;color:#64ffda}.tag.wait{background:#FFD70022;color:#FFD700}',
  '.tag.bad{background:#ff6b6b22;color:#ff6b6b}.tag.mute{background:#8892b022;color:#8892b0}',
  '.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}',
  '.kpi{background:#0d1b3a;border-radius:12px;padding:12px}',
  '.kpi .v{font-size:20px;font-weight:800;color:#fff;word-break:break-all}',
  '.kpi .k{font-size:11px;color:#8892b0}',
  '.nav{display:flex;gap:6px;overflow-x:auto;padding:8px 0}',
  '.nav button{background:#0d1b3a;color:#8892b0;font-weight:600;white-space:nowrap}',
  '.nav button.on{background:#FFD700;color:#0a0e27}',
  '.muted{color:#8892b0;font-size:12px}',
  '.money{font-size:30px;font-weight:900;color:#FFD700;letter-spacing:1px}',
  '.mono{font-family:ui-monospace,Menlo,Consolas,monospace}',
  '.alert{background:#ff6b6b18;border:1px solid #ff6b6b55;border-radius:10px;padding:12px;color:#ff9b9b;font-size:13px;margin:10px 0}',
  '.ok{background:#64ffda18;border:1px solid #64ffda55;border-radius:10px;padding:12px;color:#64ffda;font-size:13px;margin:10px 0}',
  '.hide{display:none}',
  '.foot{text-align:center;color:#495670;font-size:11px;padding:20px 0}',
  '.copybox{display:flex;gap:8px;align-items:center;background:#0d1b3a;border:1px dashed #1e3a5f;border-radius:10px;padding:10px 12px;margin:6px 0}',
  '.copybox .txt{flex:1;font-family:ui-monospace,monospace;font-size:15px;color:#fff;word-break:break-all}',
].join('\n')

/* ============================== 地区限制页 ============================== */
export function REGION_BLOCK_PAGE(country) {
  return pageHead('地区限制', {}) +
    '<body><div class="wrap" style="max-width:520px;margin-top:12vh;text-align:center">' +
    '<div class="card"><h1>本系统仅限缅甸地区使用</h1>' +
    '<p style="margin-top:10px">This system is available in Myanmar only.</p>' +
    '<p style="margin-top:6px">ဤစနစ်ကို မြန်မာနိုင်ငံအတွင်း၌သာ အသုံးပြုနိုင်ပါသည်။</p>' +
    '<p class="muted" style="margin-top:12px">检测到的地区：' + esc(country || '未知') + '</p>' +
    '</div></div></body></html>'
}

/* ============================== 超管入口 · 首次设密 ============================== */
export function SETUP_PAGE(cfg, st) {
  const adminName = esc((st && st.adminUsername) || 'superadmin')
  return pageHead('超管入口 · 首次设密', cfg) +
    '<body><div class="wrap" style="max-width:460px;margin-top:7vh">' +
    '<div class="card">' +
    '<h1>超管入口</h1>' +
    '<p class="muted">本系统只有<b>一个</b>超级管理员。你在这里第一次输入的密码，就是<b>唯一的超管密码</b>；系统只保存其哈希，不保存明文，也无法找回（只能清空数据重新设置），请务必牢记。</p>' +
    '<label>超管账号</label><input id="u" value="' + adminName + '" autocomplete="username">' +
    '<label>设置密码（至少 6 位，唯一）</label><input id="p" type="password" autocomplete="new-password">' +
    '<label>确认密码</label><input id="p2" type="password" autocomplete="new-password">' +
    '<div style="margin-top:14px"><button id="btnSetup" style="width:100%">设定并进入后台</button></div>' +
    '<div id="msg"></div>' +
    '<p class="muted" style="margin-top:10px">设置成功后，本入口只保留登录功能，任何人都无法再次设定超管密码。</p>' +
    '</div></div>' +
    '<script>' + SETUP_JS + '</script>' +
    '</body></html>'
}

const SETUP_JS = [
  'var q=function(id){return document.getElementById(id)};',
  'function E(s){return String(s===undefined||s===null?"":s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;"}[c]})}',
  'function msg(h){q("msg").innerHTML=h}',
  'async function submit(){',
  '  var u=q("u").value.trim(),p=q("p").value,p2=q("p2").value;',
  '  if(p!==p2){msg("<div class=\\"alert\\">两次输入的密码不一致</div>");return}',
  '  var btn=q("btnSetup");btn.disabled=true;',
  '  try{',
  '    var r=await fetch("/api/setup/admin",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:u,password:p,confirm:p2})});',
  '    var d={};try{d=await r.json()}catch(e){d={success:false,error:"HTTP "+r.status}}',
  '    if(!d.success){msg("<div class=\\"alert\\">"+E(d.error)+"</div>");btn.disabled=false;return}',
  '    if(d.token){try{localStorage.setItem("kbz_token",d.token)}catch(e){}}',
  '    location.href="/console";',
  '  }catch(e){msg("<div class=\\"alert\\">网络错误，请重试</div>");btn.disabled=false}',
  '}',
  'q("btnSetup").onclick=submit;',
  'q("p2").addEventListener("keydown",function(e){if(e.key==="Enter")submit()});',
].join('\n')

/* ============================== 落地 / 使用说明页 ============================== */
export function LANDING_PAGE(cfg, url) {
  const origin = url ? url.origin : ''
  return pageHead(cfg.gatewayName, cfg) +
    '<body><div class="wrap">' +
    '<div class="between" style="margin-bottom:6px">' +
    '<h1>' + esc(cfg.gatewayName) + '</h1>' +
    '<div class="row"><a class="btn" href="/admin">超管入口</a><a class="ghost" href="/console">登录后台</a></div>' +
    '</div>' +
    '<p>KBZPay 主通道 · 自动收款 · 自动发货 · 收货转款到户 · 电商与游戏闭环 · 多级代理数据隔离 · 超管资金池（保证金 / 系统租用金 / 违规扣罚）· 签名防重放 · 敏感数据加密脱敏</p>' +

    '<div class="card"><h2>一、5 分钟上线（超管视角）</h2>' +
    '<div class="nav"><span class="tag ok">单文件</span><span class="tag ok">零依赖</span><span class="tag ok">免服务器</span><span class="tag ok">缅甸地区锁定</span></div>' +
    step('1', '创建 Worker', '登录 dash.cloudflare.com → Workers &amp; Pages → 创建 Worker，命名后点「Deploy」。') +
    step('2', '绑定 KV', '该 Worker → 设置 → 变量 → KV 命名空间绑定 → 变量名填 <code>KBZ_GATEWAY</code>，新建或选择一个 KV 空间。') +
    step('3', '粘贴代码', '编辑代码 → 用包内 <code>dist/index.js</code> 全文覆盖 → Save and Deploy。') +
    step('4', '设定超管密码', '打开 <code>' + esc(origin) + '/admin</code>（超管唯一入口），<b>第一次输入的密码即唯一超管密码</b>，设定后自动进入后台。') +
    step('5', '配置通道与资金池', '后台「通道」新增你的 KBZ 商业账号；「资金池」配置资金池收款账户。') +
    '</div>' +

    '<div class="card"><h2>二、三种接入方式（任意平台，无需对接文档）</h2>' +
    '<h3>① 托管收银台（最省事，任何平台都能用）</h3>' +
    '<p>超管/代理在后台创建订单，把返回的 <code>payUrl</code> 丢给用户打开即可完成付款（自动展示金额尾码与收款账号）。</p>' +
    '<h3>② 一行 SDK（网页 / H5 / 小程序 webview）</h3>' +
    '<div class="copybox"><span class="txt">&lt;script src="' + esc(origin) + '/sdk.js"&gt;&lt;/script&gt;</span></div>' +
    '<p class="muted">然后：KBZPay.init({apiBase:"' + esc(origin) + '", merchantKey:"你的商户密钥", userId:"用户ID", platform:"你的平台"}) → await KBZPay.pay(10000)</p>' +
    '<h3>③ 服务端 API（自建收银 / 游戏内购）</h3>' +
    '<p>服务端带 <code>X-Merchant-Key</code> 调 <code>POST /api/pay/init</code> 下单；到账后系统自动回调你配置的回调地址（带 HMAC 签名，失败自动重试）。</p>' +
    '</div>' +

    '<div class="card"><h2>三、自动收款是怎么跑通的</h2>' +
    '<p>下单 → 系统分配一个<b>唯一金额尾码</b>（0~999）→ 用户按显示的整数金额付款 → 通知转发端/对账文件把到账推送进系统 → 系统按尾码精确匹配订单 → 自动入账、写不可变账本、回调你的平台。截图+交易号人工核销作为兜底通道。</p>' +
    '</div>' +

    '<div class="card"><h2>四、出款（自动 + 审批闸门）</h2>' +
    '<p>单笔 ≤ 自动出款额度：直接进入出款队列；超过额度：进入人工审批。出款执行端（手机设备）拉取任务并在完成后回执，系统校验回执流水号后才会把订单置为「已出款」，失败自动退回额度。</p>' +
    '</div>' +

    '<div class="card"><h2>五、权限与数据隔离</h2>' +
    '<p>超管拥有全部数据所有权；代理只能看到自己及下级的账号、订单、账本；商户只能看到自己的数据。任何跨域访问都会被当成「资源不存在」（404），不会泄露数据是否存在。</p>' +
    '</div>' +

    '<div class="card"><h2>六、资金池（超管账户）</h2>' +
    '<p>资金池集中存放：各代理<b>保证金</b>、代理缴纳的<b>系统租用金</b>、以及<b>违规违法扣罚</b>金额。保证金不足的代理及其下级会自动受限，补齐后自动解除。<b>保证金的应缴额、扣罚、没收与退还，仅后台超管有权设定</b>，代理与商户均无此权限。</p>' +
    '</div>' +

    '<div class="card"><h2>七、电商闭环：下单 → 自动发货 → 收货转款到户</h2>' +
    '<p>下单时填写发货要素（卡密 / 物流单号），系统在<b>到账那一刻自动发货</b>并把凭据推给买家；买家在收银台点<b>「确认收货」</b>后，托管款项自动从平台托管余额转给商户可用余额（可再发起出款到银行卡/钱包）。</p>' +
    '<p class="muted">状态链：<code>待付款 → 已到账·待发货 → 已发货·待收货 → 已收货·待转款 → 已转款到户</code>。发货后超过 <code>autoReceiveHours</code> 小时买家未确认，定时任务会<b>自动收货并转款到户</b>（0 = 关闭自动收货）。</p>' +
    '</div>' +

    '<div class="card"><h2>八、游戏闭环：无文档接入 → 到账发币 → 自动转款到户</h2>' +
    '<p>游戏平台无需对接文档：下单时带上<b>游戏账号 / 角色 / 区服 / 道具编码</b>，到账后系统自动下发（或按你的规则人工发币），平台发币完成后回执 <code>POST /api/game/callback/&lt;适配器ID&gt;</code>，系统收到回执即视为已发货并<b>自动收货、转款到游戏商户户</b>。</p>' +
    '<p class="muted">回执必须带适配器密钥的 HMAC-SHA256 签名（缺失/错误一律 401），签名 = <code>HMAC-SHA256(适配器密钥, 原始请求体)</code>。</p>' +
    '</div>' +

    '<div class="card"><h2>九、安全与敏感数据存储</h2>' +
    '<p><b>密钥一律不落明文</b>：商户密钥、设备密钥只存<b>哈希</b>（较验用）；适配器签名密钥、订单级回调密钥、卡密内容、回调投递密钥均以 <b>AES-GCM 密文</b>落库（<code>enc1:…</code>），卡密在转款到户后<b>立即销毁</b>。</p>' +
    '<p><b>展示默认脱敏</b>：收款账号、手机号在列表与订单中默认打码（<code>0951****23</code>）；只有<b>订单归属者本人 / 通道归属者本人</b>可读明文，受限明文读取（<code>?reveal=1</code>）会<b>写入审计</b>，上级查看下级订单一律脱敏。</p>' +
    '<p><b>接入风控</b>：服务端 API 支持 HMAC 签名 + 时间戳 + Nonce 防重放 + 幂等键防重复下单 + 基础限流；回调一律强制验签；所有资金流水走<b>哈希链不可变账本</b>，关键动作全量审计。可把 <code>requireApiSignature</code> 打开为<b>强制签名模式</b>。</p>' +
    '<p class="muted">主密钥优先读环境变量 <code>DATA_KEY</code>；未配置时随机生成并存于 <code>sys:datakey</code>（仅本地兜底）。上线务必配置 <code>DATA_KEY</code> 作为 Secret。</p>' +
    '</div>' +

    '<p class="muted">提示：KBZPay 无公开 API，到账识别依赖「通知转发端 / 对账文件 / 截图核销」三条路径；如需官方回调，可接入持牌聚合通道（MMPay、2C2P 等）并通过「适配器」配置。系统不含任何默认超管口令——首次密码只在超管入口 <code>/admin</code> 由本人设定；上线前请替换设备密钥。</p>' +
    '<div class="foot">' + esc(cfg.gatewayName) + ' · v' + esc('1.0') + '</div>' +
    '</div></body></html>'
}

function step(n, title, desc) {
  return '<div class="row" style="align-items:flex-start;margin:10px 0">' +
    '<div class="tag ok" style="min-width:22px;text-align:center">' + n + '</div>' +
    '<div><div style="font-weight:700;color:#fff">' + title + '</div><div class="muted">' + desc + '</div></div>' +
    '</div>'
}

/* ---------- 小工具（仅页面侧使用，非注入脚本） ---------- */
function btnJS(label, fn) {
  return '<button class="small" onclick="' + esc(fn) + '">' + esc(label) + '</button>'
}
function epRow(use, method, path) {
  return '<tr><td>' + esc(use) + '</td><td class="mono">' + esc(method + ' ' + path) + '</td></tr>'
}

/* ============================== 无文档即插即用接入向导（公开页 · 三语） ============================== */
/**
 * 公开的三语接入向导：机器可读清单 + 一键配对 + 一行连接器 + 通用入口速查。
 * 语言切换：?lang=zh|en|my（默认中文）；文案复用 i18n 字典（translate）与本地三语表。
 */
export function PLUG_PAGE(cfg, url) {
  const origin = url ? url.origin : ''
  const lang = pickLang(url)
  const T = function (zh, en, my) { return lang === 'my' ? my : (lang === 'en' ? en : zh) }
  const L = {
    copy: translate(lang, 'common.copy'),
    pairDone: T('配对成功：请立即保存 adapterId 与接入密钥（密钥只显示一次）。', 'Paired. Save the adapterId and key now (the key is shown once).', 'တွဲပြီးပါပြီ — adapterId နှင့် သော့ကို ယခုပင် သိမ်းပါ။'),
    fail: translate(lang, 'error.scope'),
  }
  const base = origin + '/api/plug/{id}'
  return pageHead(cfg.gatewayName + ' · ' + T('无文档接入向导', 'Zero-doc integration', 'စာရွက်စာတမ်းမလိုချိတ်ဆက်ခြင်း'), cfg) +
    '<body><div class="wrap" style="max-width:860px">' +
    '<div class="between" style="margin-bottom:6px"><h1>' + esc(cfg.gatewayName) + '</h1>' +
    '<div class="row"><a class="btn ghost small" href="?lang=zh">中文</a><a class="btn ghost small" href="?lang=en">English</a><a class="btn ghost small" href="?lang=my">မြန်မာ</a></div></div>' +
    '<p>' + esc(T('零文档即插即用：选平台模板或纯手工模式，填最少信息即可完成对接；字段名不必对齐，系统按别名表自动识别金额与订单号。',
      'Zero-doc plug & play: pick a template or manual mode and integrate with the minimum of information. Field names need no alignment — amounts and order ids are auto-detected.',
      'စာရွက်စာတမ်းမလိုဘဲ ချိတ်ဆက်ပါ။ ကွက်လပ်အမည်များ ကိုက်ညီရန် မလိုပါ။')) + '</p>' +

    '<div class="card"><h2>' + esc(T('三步接入', 'Three steps', 'သုံးဆင့်')) + '</h2>' +
    step('1', T('取配对码', 'Get a pairing code', 'တွဲကုဒ် ရယူပါ'),
      esc(T('向后端管理员索取一个配对码（后台「接入向导 → 配对码」生成，一次性、有有效期）。', 'Ask the admin for a pairing code (Integration wizard → pairing codes; one-time, expiring).', 'အက်ဒမင်ထံမှ တွဲကုဒ် တစ်ခု တောင်းပါ။'))) +
    step('2', T('换取凭据', 'Exchange credentials', 'အထောက်အထား လဲလှယ်ပါ'),
      esc(T('把配对码提交到下方「一键配对」，立刻拿到 adapterId 与接入密钥 plugKey。', 'Submit the code below to receive your adapterId and plugKey instantly.', 'တွဲကုဒ်ကို အောက်တွင် တင်လိုက်ပါ။'))) +
    step('3', T('贴一行连接器', 'Drop the connector', 'ကွန်နက်တာ တစ်လိုင်း ထည့်ပါ'),
      esc(T('把一行连接器加进你的页面或服务端，或直接调用通用入口。', 'Add the one-line connector to your page/server, or call the generic endpoints directly.', 'ကွန်နက်တာ တစ်လိုင်း ထည့်ပါ၊ သို့မဟုတ် အထွေထွေဝင်ပေါက်ကို တိုက်ရိုက်ခေါ်ပါ။'))) +
    '</div>' +

    '<div class="card"><div class="between"><h3>' + esc(T('自描述清单（机器可读）', 'Self-describing manifest', 'ကိုယ်တိုင်ဖော်ပြ စာရင်း')) + '</h3>' +
    '<span class="row"><a class="btn ghost small" href="/api/plug/manifest" target="_blank">manifest</a><a class="btn ghost small" href="/.well-known/kbz-connect.json" target="_blank">.well-known</a>' + btnJS(T('加载清单', 'Load manifest', 'စာရင်း တင်ပါ'), 'loadManifest()') + '</span></div>' +
    '<p class="muted">' + esc(T('脚本或 AI 可据此自动完成对接，无需阅读任何文档。', 'Scripts or AI can auto-integrate with zero docs.', 'ဇာတ်ညွှန်း/AI များ အလိုအလျောက် ချိတ်နိုင်သည်။')) + '</p>' +
    '<pre id="mf" class="mono muted" style="white-space:pre-wrap;font-size:12px;max-height:320px;overflow:auto"></pre></div>' +

    '<div class="card"><h2>' + esc(T('一键配对', 'One-click pairing', 'တစ်ချက်တွဲခြင်း')) + '</h2>' +
    '<label>' + esc(T('配对码', 'Pairing code', 'တွဲကုဒ်')) + '</label><input id="code" placeholder="XXXX-XXXX">' +
    '<div class="row"><div style="flex:1;min-width:160px"><label>' + esc(T('接入点名称', 'Integration name', 'ချိတ်ဆက်အမည်')) + '</label><input id="pname"></div>' +
    '<div style="flex:1;min-width:200px"><label>' + esc(T('你方回调地址（可选）', 'Your callback URL (optional)', 'သင့် callback URL (မလိုအပ်ပါ)')) + '</label><input id="ptarget" placeholder="https://your.app/kbz/callback"></div></div>' +
    '<div style="margin-top:12px">' + btnJS(T('换取接入凭据', 'Exchange credentials', 'အထောက်အထား လဲလှယ်ပါ'), 'doPair()') + '</div>' +
    '<div id="pairres"></div></div>' +

    '<div class="card"><h2>' + esc(T('一行连接器', 'One-line connector', 'ကွန်နက်တာ တစ်လိုင်း')) + '</h2>' +
    '<div class="copybox"><span class="txt" id="c1">&lt;script src="' + esc(origin) + '/kbz-plug.js"&gt;&lt;/script&gt;</span>' + btnJS(T('复制', 'Copy', 'ကူးယူ'), 'copyEl(\'c1\')') + '</div>' +
    '<p class="muted">' + esc(T('随后即可用 KBZPlug.init({ base, adapterId, plugKey })。连接器内置端点自发现、字段自动映射与失败重试。', 'Then KBZPlug.init({ base, adapterId, plugKey }). The connector self-discovers endpoints, auto-maps fields and retries.', 'ထို့နောက် KBZPlug.init({ base, adapterId, plugKey }) အသုံးပြုပါ။')) + '</p>' +
    '<p class="muted mono">KBZPlug.init({ base: "' + esc(origin) + '", adapterId: "你的 adapterId", plugKey: "你的 plugKey" })</p></div>' +

    '<div class="card"><h2>' + esc(T('通用入口', 'Generic endpoints', 'အထွေထွေ ဝင်ပေါက်')) + '</h2>' +
    '<p class="muted">' + esc(T('把 {id} 换成你的 adapterId；鉴权任选其一：请求头 X-Plug-Key: plugKey，或 HMAC-SHA256(plugKey, 原始请求体) 置于 X-Signature。', 'Replace {id} with your adapterId. Auth: header X-Plug-Key: plugKey, or HMAC-SHA256(plugKey, raw body) in X-Signature.', '{id} နေရာတွင် သင့် adapterId ထည့်ပါ။')) + '</p>' +
    '<div class="tblbox"><table>' +
    '<tr><th>' + esc(T('用途', 'Purpose', 'ရည်ရွယ်ချက်')) + '</th><th>' + esc(T('方法与路径', 'Method & path', 'နည်းလမ်းနှင့် လမ်း')) + '</th></tr>' +
    epRow(T('创建订单（字段名不限）', 'Create order (any field names)', 'အော်ဒါ ဖန်တီး'), 'POST', base + '/order') +
    epRow(T('到账回执 / 状态推送', 'Paid / status notify', 'ငွေရောက် အကြောင်းပြန်'), 'POST', base + '/notify') +
    epRow(T('订单查询 / 拉取', 'Query / pull order', 'အော်ဒါ ရှာဖွေ'), 'GET', base + '/pull') +
    epRow(T('接入点信息', 'Integration info', 'ချိတ်ဆက်အချက်အလက်'), 'GET', base + '/info') +
    epRow(T('自描述清单', 'Manifest', 'စာရင်း'), 'GET', origin + '/api/plug/manifest') +
    epRow(T('一键配对', 'Pairing', 'တွဲခြင်း'), 'POST', origin + '/api/plug/pair') +
    '</table></div></div>' +

    '<div class="foot">' + esc(cfg.gatewayName) + '</div>' +
    '</div>' +
    '<script>var PGT=' + JSON.stringify(L).replace(/</g, '\\u003c') + ';</script>' +
    '<script>' + PLUG_PAGE_JS + '</script>' +
    '</body></html>'
}

const PLUG_PAGE_JS = [
  'function q(id){return document.getElementById(id)}',
  'function E(s){return String(s===undefined||s===null?"":s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;"}[c]})}',
  'function tip(m){var d=document.createElement("div");d.className="ok";d.style.position="fixed";d.style.left="50%";d.style.top="20px";d.style.transform="translateX(-50%)";d.style.zIndex=99;d.textContent=m;document.body.appendChild(d);setTimeout(function(){d.remove()},3200)}',
  'function copyEl(id){var el=q(id);if(el&&navigator.clipboard)navigator.clipboard.writeText(el.textContent||el.innerText||"");tip(PGT.copy||"OK")}',
  'async function loadManifest(){',
  '  q("mf").textContent="...";',
  '  try{var r=await fetch("/api/plug/manifest");var d=await r.json();q("mf").textContent=JSON.stringify(d,null,2)}catch(e){q("mf").textContent=String(e)}',
  '}',
  'async function doPair(){',
  '  var code=q("code").value.trim();if(!code)return tip("请输入配对码 / Pairing code required");',
  '  var body={code:code,name:q("pname").value,targetUrl:q("ptarget").value};',
  '  var d={success:false,error:"network"};',
  '  try{var r=await fetch("/api/plug/pair",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});d=await r.json()}catch(e){d={success:false,error:"network"}}',
  '  if(!d.success){q("pairres").innerHTML="<div class=\\"alert\\">"+E(d.error||PGT.fail)+"</div>";return}',
  '  var h="<div class=\\"ok\\">"+E(PGT.pairDone)+"</div>";',
  '  h+="<label>adapterId</label><div class=\\"copybox\\"><span class=\\"txt\\" id=\\"cid\\">"+E(d.adapterId)+"</span><button class=\\"small\\" onclick=\\"copyEl(\\x27cid\\x27)\\">"+E(PGT.copy)+"</button></div>";',
  '  h+="<label>plugKey</label><div class=\\"copybox\\"><span class=\\"txt\\" id=\\"ckey\\">"+E(d.plugKey)+"</span><button class=\\"small\\" onclick=\\"copyEl(\\x27ckey\\x27)\\">"+E(PGT.copy)+"</button></div>";',
  '  h+="<label>一行连接器</label><div class=\\"copybox\\"><span class=\\"txt\\" id=\\"cone\\">"+E(d.oneLine)+"</span><button class=\\"small\\" onclick=\\"copyEl(\\x27cone\\x27)\\">"+E(PGT.copy)+"</button></div>";',
  '  h+="<p class=\\"muted mono\\">"+E(d.curl)+"</p>";',
  '  q("pairres").innerHTML=h;',
  '}',
].join('\n')

/* ============================== 托管收银台 ============================== */
export function PAY_PAGE(cfg) {
  return pageHead('KBZPay 收款', cfg) +
    '<body><div class="wrap" style="max-width:520px">' +
    '<div class="card" id="top"><h1>KBZPay 收款</h1><p id="subject">正在加载订单…</p></div>' +
    '<div class="card hide" id="paycard">' +
    '<p class="muted">请转账以下金额（含识别尾码，必须完全一致）</p>' +
    '<div class="money" id="payable">—</div>' +
    '<label>收款账号</label><div class="copybox"><span class="txt" id="acct">—</span><button class="small" onclick="cp(\'acct\')">复制</button></div>' +
    '<label>收款人</label><div class="copybox"><span class="txt" id="holder">—</span><button class="small" onclick="cp(\'holder\')">复制</button></div>' +
    '<div class="alert">请使用 KBZPay 向上述账号转账，金额必须与上方完全一致（包括末尾识别码），否则系统无法自动识别到账。</div>' +
    '<label>转账交易号（KBZPay 交易单号，至少 5 位数字）</label><input id="txid" placeholder="例如 1234567890">' +
    '<label>转账金额</label><input id="amount" type="number" inputmode="numeric">' +
    '<label>转账截图（可选，用于人工兜底核销）</label><input id="shot" type="file" accept="image/*">' +
    '<div style="margin-top:12px"><button id="submit" style="width:100%">我已转账，提交核销</button></div>' +
    '<div id="msg"></div>' +
    '</div>' +
    '<div class="card"><p class="muted">若已到账但未自动核销，可稍等 1 分钟；系统会定期对账。也可把交易号发给客服人工处理。</p>' +
    '<p class="muted">到账后本页会显示<b>发货凭据</b>（卡密 / 物流单号 / 游戏道具发放状态）；收到商品后请点<b>「确认收货」</b>，款项将转给商户。若长时间未操作，系统会在约定期限后自动确认收货。</p></div>' +
    '<div class="foot">' + esc(cfg.gatewayName) + '</div>' +
    '</div>' +
    '<script>' + PAY_JS + '</script>' +
    '</body></html>'
}

const PAY_JS = [
  'var TOKEN = new URLSearchParams(location.search).get("t") || "";',
  'var CFG = {};',
  'function q(id){return document.getElementById(id)}',
  'function cp(id){var t=q(id).textContent;navigator.clipboard&&navigator.clipboard.writeText(t);toast("已复制")}',
  'function toast(m){var d=document.createElement("div");d.className="ok";d.textContent=m;q("msg").appendChild(d);setTimeout(function(){d.remove()},3000)}',
  'function money(n){return Number(n||0).toLocaleString("en-US")}',
  'function E(s){return String(s===undefined||s===null?"":s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;"}[c]})}',
  'async function load(){',
  '  if(!TOKEN){q("subject").textContent="缺少订单参数";return}',
  '  var r=await fetch("/api/pay/"+TOKEN);var d=await r.json();',
  '  if(!d.success){q("subject").textContent=d.error||"订单不存在";return}',
  '  var o=d.order;window.__o=o;',
  '  q("subject").textContent="订单 "+o.orderId+" · "+o.subject;',
  '  if(o.status==="paid"){q("paycard").className="card";loadDelivery();return}',
  '  if(o.status==="expired"||o.status==="closed"){q("paycard").innerHTML="<div class=\\"alert\\">订单已过期/关闭，请重新下单。</div>";return}',
  '  q("paycard").className="card";',
  '  q("payable").textContent=money(o.payable)+" "+o.currency;',
  '  q("acct").textContent=o.channelAccount;q("holder").textContent=o.channelHolder;',
  '  q("amount").value=o.payable;',
  '  q("txid").addEventListener("input",function(){window.__txid=this.value});',
  '  q("submit").onclick=submit;',
  '}',
  'async function submit(){',
  '  var txid=(q("txid").value||"").trim();',
  '  if(!/^\\d{5,}$/.test(txid)){toast("交易号至少 5 位数字");return}',
  '  var amount=parseInt(q("amount").value||"0",10);',
  '  var shot="";',
  '  var f=q("shot").files[0];',
  '  q("submit").disabled=true;q("submit").textContent="提交中…";',
  '  try{',
  '    if(f){shot=await fileToDataUrl(f)}',
  '    var r=await fetch("/api/pay/confirm",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:TOKEN,txid:txid,amount:amount,screenshot:shot})});',
  '    var d=await r.json();',
  '    if(d.success){toast("核销成功，订单已到账");loadDelivery()}',
  '    else{toast(d.error||"核销失败");q("submit").disabled=false;q("submit").textContent="我已转账，提交核销"}',
  '  }catch(e){toast("网络错误，请重试");q("submit").disabled=false;q("submit").textContent="我已转账，提交核销"}',
  '}',
  'function fileToDataUrl(f){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(r.result)};r.onerror=rej;r.readAsDataURL(f)})}',
  '/* 到账后展示发货凭据 + 确认收货（收货即把托管款项转给商户） */',
  'async function loadDelivery(){',
  '  var r=await fetch("/api/pay/delivery?t="+encodeURIComponent(TOKEN));var d=await r.json();',
  '  if(!d.success){toast(d.error||"读取发货信息失败");return}',
  '  var o=d.order||{};window.__o=o;var v=o.deliveryView||{};',
  '  var h="<div class=\\"ok\\">已到账 · 金额 "+money(o.amount)+" "+E(o.currency||"")+"</div>";',
  '  h+="<p class=\\"muted\\">订单阶段："+E(o.stageText||o.stage||"")+"</p>";',
  '  if(v.type==="card"&&v.cardSecret){h+="<label>卡密 / 兑换码（请及时保存）</label><div class=\\"copybox\\"><span class=\\"txt\\" id=\\"cardsec\\">"+E(v.cardSecret)+"</span><button class=\\"small\\" onclick=\\"cp(\\x27cardsec\\x27)\\">复制</button></div>"}',
  '  if(v.type==="logistics"){h+="<label>物流单号</label><div class=\\"copybox\\"><span class=\\"txt\\">"+E((v.carrier||"")+" "+(v.trackingNo||""))+"</span></div>"}',
  '  if(v.type==="game"){h+="<p class=\\"muted\\">游戏道具发放至："+E(o.gameAccount||"")+" "+E(o.gameZone||"")+" "+E(o.gameRole||"")+"（发币状态 "+E(o.grantStatus||"waiting")+"）</p>"}',
  '  if(o.stage==="delivered"){h+="<div style=\\"margin-top:12px\\"><button id=\\"btnRecv\\" style=\\"width:100%\\">确认收货（款项转给商户）</button></div>"}',
  '  if(o.stage==="settled"){h+="<div class=\\"ok\\">已确认收货，交易完成 ✔</div>"}',
  '  if(o.stage==="paid"&&v.type==="manual"){h+="<p class=\\"muted\\">商户正在处理发货，请稍候刷新。</p>"}',
  '  q("paycard").className="card";q("paycard").innerHTML=h;',
  '  if(q("btnRecv"))q("btnRecv").onclick=confirmReceive;',
  '}',
  'async function confirmReceive(){',
  '  if(!confirm("确认已收到商品/道具？确认后款项将转给商户。"))return;',
  '  var btn=q("btnRecv");if(btn){btn.disabled=true;btn.textContent="提交中…"}',
  '  try{',
  '    var r=await fetch("/api/pay/receive",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:TOKEN})});',
  '    var d=await r.json();',
  '    if(d.success){toast("已确认收货，交易完成");loadDelivery()}else{toast(d.error||"确认失败");if(btn){btn.disabled=false;btn.textContent="确认收货（款项转给商户）"}}',
  '  }catch(e){toast("网络错误，请重试");if(btn){btn.disabled=false;btn.textContent="确认收货（款项转给商户）"}}',
  '}',
  'load();',
].join('\n')

/* ============================== 一行 SDK ============================== */
export const SDK_CODE = [
  '/* KBZPay 多平台收付款 SDK v1.1 —— 一行接入，无文档可用（自动附带签名 / 防重放 / 幂等头） */',
  'window.KBZPay = {',
  '  config: { apiBase: "", merchantKey: "", userId: "", platform: "" },',
  '  init: function (opts) {',
  '    for (var k in (opts || {})) this.config[k] = opts[k];',
  '    if (!this.config.apiBase) {',
  '      var s = document.querySelector(\'script[src*="sdk.js"]\');',
  '      if (s) this.config.apiBase = new URL(s.src).origin;',
  '      else this.config.apiBase = location.origin;',
  '    }',
  '    return this;',
  '  },',
  '  _h: function () { return { "Content-Type": "application/json", "X-Merchant-Key": this.config.merchantKey || "" }; },',
  '  _hex: function (buf) { var b = new Uint8Array(buf), s = ""; for (var i = 0; i < b.length; i++) s += ("0" + b[i].toString(16)).slice(-2); return s; },',
  '  _sha256hex: async function (str) {',
  '    if (!window.crypto || !crypto.subtle) return "";',
  '    return this._hex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(str || ""))));',
  '  },',
  '  _hmacHex: async function (secret, msg) {',
  '    if (!window.crypto || !crypto.subtle) return "";',
  '    var k = await crypto.subtle.importKey("raw", new TextEncoder().encode(String(secret || "")), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);',
  '    return this._hex(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(String(msg || ""))));',
  '  },',
  '  _nonce: function () { return Date.now().toString(36) + Math.random().toString(36).slice(2, 10); },',
  '  _idem: function () { return "idem_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10); },',
  '  // 生成签名头：Signature = HMAC-SHA256(商户密钥, METHOD\\nPATH\\nX-Timestamp\\nX-Nonce\\nsha256hex(原始请求体))',
  '  _signed: async function (method, path, rawBody, idemKey) {',
  '    var h = this._h();',
  '    if (!this.config.merchantKey || !window.crypto || !crypto.subtle) return h;',
  '    var ts = String(Date.now()), nonce = this._nonce();',
  '    var bodyHash = await this._sha256hex(rawBody || "");',
  '    var payload = method + "\\n" + path + "\\n" + ts + "\\n" + nonce + "\\n" + bodyHash;',
  '    h["X-Timestamp"] = ts; h["X-Nonce"] = nonce;',
  '    h["X-Signature"] = await this._hmacHex(this.config.merchantKey, payload);',
  '    if (idemKey) h["X-Idempotency-Key"] = idemKey;',
  '    return h;',
  '  },',
  '  createOrder: async function (opts) {',
  '    opts = opts || {};',
  '    var path = "/api/pay/init";',
  '    var body = JSON.stringify({',
  '      amount: opts.amount, customer: opts.userId || this.config.userId, platform: this.config.platform,',
  '      subject: opts.subject, merchantOrderId: opts.merchantOrderId, scene: opts.scene || "ecommerce",',
  '      gameAccount: opts.gameAccount, gameRole: opts.gameRole, gameZone: opts.gameZone,',
  '      itemCode: opts.itemCode, quantity: opts.quantity, cardSecret: opts.cardSecret,',
  '      trackingNo: opts.trackingNo, notifyUrl: opts.notifyUrl, beneficiaryId: opts.beneficiaryId',
  '    });',
  '    var headers = await this._signed("POST", path, body, opts.idempotencyKey || this._idem());',
  '    var r = await fetch(this.config.apiBase + path, { method: "POST", headers: headers, body: body });',
  '    return r.json();',
  '  },',
  '  pay: function (amount, opts) {',
  '    var self = this;',
  '    return this.createOrder(Object.assign({ amount: amount }, opts || {})).then(function (d) {',
  '      if (!d.success) { throw new Error(d.error || "下单失败"); }',
  '      var url = self.config.apiBase + d.order.payUrl;',
  '      if (/Mobile|Android|iPhone|iPad/.test(navigator.userAgent)) { location.href = url; return d; }',
  '      var w = window.open(url, "kbzpay", "width=480,height=760");',
  '      return new Promise(function (resolve) {',
  '        var timer = setInterval(function () {',
  '          if (!w || w.closed) { clearInterval(timer); resolve(d); return; }',
  '          try { if (w.location.href.indexOf(self.config.apiBase) === 0) return; } catch (e) {}',
  '        }, 800);',
  '        setTimeout(function () { clearInterval(timer); resolve(d); }, 10 * 60 * 1000);',
  '      });',
  '    });',
  '  },',
  '  query: async function (orderId) {',
  '    var path = "/api/pay/status/" + orderId;',
  '    var headers = await this._signed("GET", path, "");',
  '    var r = await fetch(this.config.apiBase + path, { headers: headers });',
  '    return r.json();',
  '  },',
  '  status: function (orderId) { return this.query(orderId); }',
  '};',
].join('\n')

/* ============================== 后台控制台（超管 / 代理 / 商户） ============================== */
export function CONSOLE_PAGE(cfg, opts) {
  return pageHead(cfg.gatewayName + ' · 后台', cfg) +
    '<body>' +
    '<div id="login" class="wrap" style="max-width:420px;margin-top:10vh">' +
    '<div class="card"><h1>' + esc(cfg.gatewayName) + '</h1>' +
    '<p style="margin-bottom:8px">请使用账号密码登录</p>' +
    '<label>账号</label><input id="u" autocomplete="username">' +
    '<label>密码</label><input id="p" type="password" autocomplete="current-password">' +
    '<div style="margin-top:12px"><button id="btnLogin" style="width:100%">登录</button></div>' +
    '<div id="loginmsg"></div>' +
    '<p class="muted" style="margin-top:10px">超管请从 <a href="/admin">超管入口</a> 进入（首次使用需在该入口设定唯一超管密码）；代理 / 商户请使用上级分配的账号登录。</p>' +
    '</div></div>' +

    '<div id="app" class="hide"><div class="wrap">' +
    '<div class="between"><div><h1 id="title">后台</h1><p class="muted" id="who"></p></div>' +
    '<div class="row"><button class="ghost small" id="btnPwd">改密码</button>' +
    '<button class="ghost small" id="btnLogout">退出</button></div></div>' +
    '<div class="nav" id="nav"></div>' +
    '<div id="view"></div>' +
    '<div class="foot" id="foot"></div>' +
    '</div></div>' +

    '<script>' + CONSOLE_JS + '\n' + CONSOLE_EXTRA_JS + '</script>' +
    '</body></html>'
}

const CONSOLE_JS = [
  'var T = localStorage.getItem("kbz_token") || "";',
  'var ME = null;',
  'var PC_CFG = {};',
  'function q(id){return document.getElementById(id)}',
  'function E(s){return String(s===undefined||s===null?"":s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;"}[c]})}',
  'function money(n){return Number(n||0).toLocaleString("en-US")}',
  'function cls(s){if(s==="paid"||s==="active"||s==="delivered"||s==="resolved"||s==="queued")return "ok";if(s==="pending"||s==="cooldown"||s==="processing"||s==="appealed")return "wait";if(s==="closed"||s==="rejected"||s==="failed"||s==="disabled"||s==="frozen"||s==="retired"||s==="refunded")return "bad";return "mute"}',
  'function tag(s){return "<span class=\\"tag "+cls(s)+"\\">"+E(s)+"</span>"}',
  'function tip(m,ok){var d=document.createElement("div");d.className=ok?"ok":"alert";d.style.position="fixed";d.style.left="50%";d.style.top="20px";d.style.transform="translateX(-50%)";d.style.zIndex=99;d.style.maxWidth="90vw";d.textContent=m;document.body.appendChild(d);setTimeout(function(){d.remove()},3200)}',
  'async function api(path,method,body){',
  '  var opt={method:method||"GET",headers:{}};',
  '  if(T)opt.headers["Authorization"]="Bearer "+T;',
  '  if(body){opt.headers["Content-Type"]="application/json";opt.body=JSON.stringify(body)}',
  '  var r=await fetch(path,opt);',
  '  var d={};try{d=await r.json()}catch(e){d={success:false,error:"HTTP "+r.status}}',
  '  if(r.status===401){logout(true)}',
  '  if(r.status===428&&d.code==="PASSWORD_CHANGE_REQUIRED"){if(!window.__pwdPrompted){window.__pwdPrompted=true;tip("为保障账号安全，请先修改初始密码")}if(typeof changePwd==="function")changePwd()}',
  '  return d',
  '}',
  'function logout(silent){localStorage.removeItem("kbz_token");T="";if(!silent)location.reload();else location.reload()}',
  '/* ---------- 登录 ---------- */',
  'async function doLogin(){',
  '  var u=q("u").value.trim(),p=q("p").value;',
  '  var d=await api("/api/auth/login","POST",{username:u,password:p});',
  '  if(!d.success){var m="<div class=\\"alert\\">"+E(d.error)+"</div>";if(String(d.error).indexOf("/admin")>=0)m+="<p style=\\"margin-top:8px\\"><a class=\\"btn\\" href=\\"/admin\\">前往超管入口设密</a></p>";q("loginmsg").innerHTML=m;return}',
  '  T=d.token;localStorage.setItem("kbz_token",T);ME=d.profile;boot()',
  '}',

  'var TABS={',
  '  super:[["overview","总览"],["accounts","组织树与账号"],["pool","资金池"],["platform","平台账户"],["deposits","保证金/扣罚/租用金"],["agentrentals","代理租用与保证金"],["gamepoints","游戏上下分"],["pluguide","接入向导"],["orders","全部订单"],["payouts","出款审批"],["channels","通道"],["fund","收付款设置"],["devices","设备"],["adapters","适配器"],["webhooks","回调"],["audit","审计日志"],["security","安全会话"],["maintenance","维护与对账"],["settings","系统设置"]],',
  '  agent:[["overview","总览"],["channels","我的 KBZ 通道"],["fund","收付款设置"],["accounts","下级账号"],["orders","我的订单"],["gamepoints","游戏上下分"],["pluguide","接入向导"],["payouts","出款"],["deposits","保证金"],["devices","设备"],["adapters","适配器"],["webhooks","回调"],["audit","审计日志"],["security","安全会话"]],',
  '  merchant:[["overview","总览"],["access","接入信息"],["orders","订单"],["balance","余额与提现"],["gamepoints","游戏上下分"],["pluguide","接入向导"],["fund","收付款设置"],["adapters","适配器"],["webhooks","回调"],["security","安全会话"]]',
  '};',
  'var CUR="overview";',
  'function renderNav(){',
  '  var tabs=TABS[ME.role]||TABS.merchant;var h="";',
  '  tabs.forEach(function(t){h+="<button class=\\""+(t[0]===CUR?"on":"")+"\\" onclick=\\"go(\\x27"+t[0]+"\\x27)\\">"+t[1]+"</button>"});',
  '  q("nav").innerHTML=h;',
  '}',
  'function go(t){CUR=t;renderNav();var f=VIEWS[t];if(f)f()}',
  'function boot(){',
  '  q("login").className="hide";q("app").className="";',
  '  q("who").textContent=(ME.name||ME.username)+" · "+(ME.role==="super"?"超级管理员":(ME.role==="agent"?"代理":"商户"));',
  '  q("foot").textContent=document.domain;',
  '  renderNav();go("overview");',
  '}',
  '/* ---------- 通用渲染 ---------- */',
  'function kpi(k,v){return "<div class=\\"kpi\\"><div class=\\"k\\">"+E(k)+"</div><div class=\\"v\\">"+E(v)+"</div></div>"}',
  'function table(cols,rows,fmt){',
  '  var h="<div class=\\"tblbox\\"><table><tr>";',
  '  cols.forEach(function(c){h+="<th>"+E(c)+"</th>"});h+="</tr>";',
  '  if(!rows||!rows.length){h+="<tr><td colspan=\\""+cols.length+"\\" class=\\"muted\\">暂无数据</td></tr>"}',
  '  (rows||[]).forEach(function(r){h+="<tr>";cols.forEach(function(c){h+="<td>"+(fmt?fmt(c,r):E(r[c]))+"</td>"});h+="</tr>"});',
  '  return h+"</table></div>"',
  '}',
  'function btn(label,fn){return "<button class=\\"small\\" onclick=\\""+fn+"\\">"+label+"</button>"}',
  'function inputRow(id,label,ph,type){return "<label>"+label+"</label><input id=\\""+id+"\\" placeholder=\\""+E(ph||"")+"\\" "+(type?"type=\\""+type+"\\"":"")+">"}',
  'function inputVal(id,label,val,type){return "<label>"+label+"</label><input id=\\""+id+"\\" value=\\""+E(val===undefined||val===null?"":val)+"\\" "+(type?"type=\\""+type+"\\"":"")+">"}',

  '/* ---------- 各视图 ---------- */',
  'var VIEWS={};',
  'VIEWS.overview=async function(){',
  '  var d=await api("/api/overview");if(!d.success)return tip(d.error);',
  '  var o=d.overview;var h="<div class=\\"grid\\">";',
  '  if(ME.role==="super"){',
  '    h+=kpi("代理数",o.agents)+kpi("商户数",o.merchants)+kpi("订单数",o.orders)+kpi("累计收款",money(o.collectTotal)+" MMK");',
  '    h+=kpi("资金池余额",money(o.pool.balance)+" MMK")+kpi("保证金总额",money(o.pool.depositTotal))+kpi("租用金总额",money(o.pool.rentalTotal))+kpi("已扣罚总额",money(o.pool.penaltyTotal));',
  '    h+=kpi("待审批出款",o.payoutPending)+kpi("待出款",o.payoutQueued)+kpi("在途订单",o.pendingOrders);',
  '  }else{',
  '    h+=kpi("可用余额",money(o.balance)+" MMK")+kpi("累计收款",money(o.collectTotal))+kpi("订单数",o.orders)+kpi("在途订单",o.pendingOrders);',
  '    h+=kpi("待审批出款",o.payoutPending)+kpi("待出款",o.payoutQueued)+kpi("自动出款额度",money(o.limits.autoPayoutLimit));',
  '    if(o.deposit){h+=kpi("保证金已缴",money(o.deposit.paid))+kpi("应缴保证金",money(o.deposit.required))+kpi("保证金状态",o.deposit.sufficient?"合规":"不足·受限")+kpi("已扣罚",money(o.deposit.penalty))}',
  '  }',
  '  h+="</div>";',
  '  if(ME.role!=="merchant"){',
  '    h+="<div class=\\"card\\"><div class=\\"between\\"><h3>快捷操作</h3></div><div class=\\"row\\">"',
  '      +btn("新建收款订单","quickOrder()")+btn("发起出款","quickPayout()")+btn("新增 KBZ 通道","quickChannel()")+ (ME.role==="super"?btn("记一笔保证金","quickDeposit()"):"")+"</div></div>";',
  '  }',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.accounts=async function(){',
  '  var d=await api("/api/accounts");if(!d.success)return tip(d.error);',
  '  var rows=d.accounts.map(function(a){return Object.assign({},a,{depositTxt:a.deposit?(money(a.deposit.paid)+"/"+money(a.deposit.required)):"-",statsTxt:a.stats?money(a.stats.balance):"-",ops:opButtons(a)})});',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>组织树与账号（共 "+d.count+" 个）</h3>"+ (ME.role!=="merchant"?btn("新建下级账号","quickAccount()"):"") +"</div>"+',
  '    table(["账号","名称","角色","状态","保证金(已缴/应缴)","余额","操作"],rows,function(c,r){if(c==="ops")return r.ops;return c==="状态"?tag(r.status):E(r[c])})+"</div>";',
  '  h+="<div class=\\"card\\"><h3>层级结构</h3><pre class=\\"mono muted\\" style=\\"white-space:pre-wrap\\">"+E(treeText(d.accounts))+"</pre></div>";',
  '  q("view").innerHTML=h;',
  '}',
  'function opButtons(a){',
  '  var h="";',
  '  if(ME.role==="super"||(ME.role==="agent"&&a.role==="merchant")){',
  '    h+=btn("改名","editName(\\x27"+a.id+"\\x27)");',
  '    if(a.status==="active")h+=btn("停用","disableUser(\\x27"+a.id+"\\x27)");',
  '    if(ME.role==="super")h+=btn("设保证金","setDepositReq(\\x27"+a.id+"\\x27)");',
  '  }',
  '  return h||"<span class=\\"muted\\">—</span>"',
  '}',
  'function treeText(nodes){',
  '  var byParent={};nodes.forEach(function(n){byParent[n.parentId||"root"]=(byParent[n.parentId||"root"]||[]).concat([n])});',
  '  var out="";',
  '  function walk(pid,depth){',
  '    var arr=byParent[pid]||[];arr.forEach(function(n){',
  '      out+=new Array(depth*2+1).join(" ")+"["+(n.role==="super"?"超管":(n.role==="agent"?"代理":"商户"))+"] "+n.username+" · "+n.name+"\\n";walk(n.id,depth+1)});',
  '  }',
  '  walk("root",0);return out||"（无下级账号）"',
  '}',
  'VIEWS.channels=async function(){',
  '  var d=await api("/api/channels");if(!d.success)return tip(d.error);',
  '  var rows=(d.channels||[]).map(function(c){return Object.assign({},c,{ops:chanOps(c)})});',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>我的 KBZ 收款通道</h3>"+btn("新增通道","quickChannel()")+"</div>"',
  '    +"<p class=\\"muted\\">新增/替换后立即生效；替换旧通道会自动进入冷却期，在途订单仍可继续核销，不影响已有业务。</p>"',
  '    +table(["账号","名称","持有人","状态","主通道","累计收款","操作"],rows,function(c,r){',
  '      if(c==="状态")return tag(r.status);',
  '      if(c==="主通道")return r.primary?"是":"—";',
  '      if(c==="累计收款")return money(r.totalReceived);',
  '      if(c==="操作")return r.ops;',
  '      if(c==="账号")return "<span class=\\"mono\\">"+E(r.accountMasked||r.account||"")+"</span>";',
  '      return E(r[c])})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'function chanOps(c){',
  '  var h=btn("一键替换","replaceChannel(\\x27"+c.id+"\\x27)")+btn("设为主通道","setPrimary(\\x27"+c.id+"\\x27)");',
  '  if(c.status==="active")h+=btn("冻结","freezeChannel(\\x27"+c.id+"\\x27)");',
  '  h+=btn("删除","delChannel(\\x27"+c.id+"\\x27)");',
  '  return h',
  '}',
  '/* ---------- 收付款设置：收款账户 / 付款账户（两个资金账户窗口，均支持一键替换） ---------- */',
  'function fundPanel(title,flow,list){',
  '  var rows=(list||[]).map(function(c){return Object.assign({},c,{ops:fundOps(c,flow),primTxt:c.primary?"是":"—",recvTxt:money(c.totalReceived)})});',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>"+E(title)+"（"+(list||[]).length+"）</h3>"+btn(flow==="pay"?"新增付款账户":"新增收款账户","quickFund(\\x27"+flow+"\\x27)")+"</div>";',
  '  h+="<p class=\\"muted\\">"+(flow==="pay"?"付款账户用于对外出款：发起出款时若未指定收款账号，系统自动回落到本账户的主付款账户。":"收款账户用于承接收款单：新订单会分配给主收款账户（无主账号时按优先级）。")+"</p>";',
  '  h+=table(["账号","名称","持有人","状态","主账户","累计收款","操作"],rows,function(c,r){',
  '    if(c==="账号")return "<span class=\\"mono\\">"+E(r.accountMasked||r.account||"")+"</span>";',
  '    if(c==="状态")return tag(r.status);',
  '    if(c==="主账户")return r.primTxt;',
  '    if(c==="累计收款")return r.recvTxt;',
  '    if(c==="操作")return r.ops;',
  '    return E(r[c]||"—")});',
  '  return h+"</div>"',
  '}',
  'function fundOps(c,flow){',
  '  var h=btn("一键替换","replaceFund(\\x27"+c.id+"\\x27,\\x27"+flow+"\\x27)");',
  '  if(c.status!=="retired")h+=btn("设为主账户","setFundPrimary(\\x27"+c.id+"\\x27,\\x27"+flow+"\\x27)");',
  '  if(c.status==="active")h+=btn("冻结","freezeFund(\\x27"+c.id+"\\x27,\\x27"+flow+"\\x27)");',
  '  h+=btn("删除","delFund(\\x27"+c.id+"\\x27,\\x27"+flow+"\\x27)");',
  '  return h',
  '}',
  'VIEWS.fund=async function(){',
  '  var r=await api("/api/fundaccounts?flow=receive");if(!r.success)return tip(r.error);',
  '  var p=await api("/api/fundaccounts?flow=pay");if(!p.success)return tip(p.error);',
  '  var sel="";',
  '  if(ME.role==="super"){',
  '    var ag=await api("/api/accounts");',
  '    var alist=(ag.accounts||[]).filter(function(a){return a.role==="agent"});',
  '    sel="<div class=\\"card\\"><div class=\\"between\\"><h3>查看下级代理的资金账户</h3><span class=\\"row\\">"+btn("查看","viewAgentFund()")+"</span></div><p class=\\"muted\\">超管可查看任一代理的收款 / 付款账户，展示一律脱敏；账户明细与一键替换由该代理本人完成。</p><p class=\\"muted\\">可选代理："+E(alist.map(function(a){return a.username}).join("、")||"（暂无）")+"</p></div>";',
  '  }',
  '  var h="<div class=\\"card\\"><h3>收付款设置</h3><p class=\\"muted\\">你本账户的两个资金账户窗口：<b>收款账户</b>（承接收款单）与<b>付款账户</b>（对外出款）。两者均支持<b>一键替换</b>为你自己的 KBZ 商业账号——输入新账号即可顶替，旧账号自动进入冷却期，在途订单不受影响。</p></div>";',
  '  h+=fundPanel("收款账户","receive",r.accounts);',
  '  h+=fundPanel("付款账户","pay",p.accounts);',
  '  h+=sel;',
  '  q("view").innerHTML=h;',
  '}',
  'async function quickFund(flow){',
  '  var acct=prompt((flow==="pay"?"新增付款账户":"新增收款账户")+"：请输入 KBZ 商业账号（6-20 位数字）","");if(!acct)return;',
  '  var holder=prompt("账户持有人姓名（可留空）","")||"";',
  '  var label=prompt("备注名（可留空）","")||"";',
  '  var d=await api("/api/fundaccounts","POST",{account:acct,holder:holder,label:label,flow:flow,primary:true});',
  '  after(d.success?("已新增并设为主账户："+(flow==="pay"?"付款账户":"收款账户")):d.error)',
  '}',
  'async function replaceFund(id,flow){',
  '  var acct=prompt((flow==="pay"?"付款":"收款")+"账户 · 一键替换\\n\\n请输入新的 KBZ 商业账号（6-20 位数字），旧账号自动进入冷却期：","");if(!acct)return;',
  '  var holder=prompt("新账号持有人姓名（可留空）","")||"";',
  '  var d=await api("/api/fundaccounts/"+id+"/replace","POST",{account:acct,holder:holder,flow:flow});',
  '  if(!d.success)return tip(d.error);',
  '  var cd=d.cooldownUntil?String(d.cooldownUntil).slice(0,19).replace("T"," "):"";',
  '  tip("已一键替换："+(flow==="pay"?"付款":"收款")+"账户新号 "+((d.current&&d.current.account)||"")+" 已接管，旧账户冷却至 "+cd,true);',
  '  go(CUR);',
  '}',
  'async function setFundPrimary(id,flow){var d=await api("/api/fundaccounts/"+id,"PUT",{primary:true});after(d.success?"已设为主账户":d.error)}',
  'async function freezeFund(id,flow){var d=await api("/api/fundaccounts/"+id,"PUT",{status:"frozen"});after(d.success?"已冻结":d.error)}',
  'async function delFund(id,flow){if(!confirm("确认停用该资金账户？"))return;var d=await api("/api/fundaccounts/"+id,"DELETE",{});after(d.success?"已停用":d.error)}',
  'async function viewAgentFund(){',
  '  var id=prompt("请输入要查看的代理 ID（见「下级账号 / 组织树」）","");if(!id)return;',
  '  var r=await api("/api/fundaccounts?flow=receive&ownerId="+encodeURIComponent(id));',
  '  if(!r.success)return tip(r.error);',
  '  var p=await api("/api/fundaccounts?flow=pay&ownerId="+encodeURIComponent(id));',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>代理 "+E(id)+" 的资金账户（脱敏）</h3>"+btn("返回","go(\\x27fund\\x27)")+"</div><p class=\\"muted\\">上级查看下级一律脱敏，明文仅限账户归属者本人。</p></div>";',
  '  h+=fundPanel("收款账户","receive",r.accounts);',
  '  h+=fundPanel("付款账户","pay",(p.success&&p.accounts)||[]);',
  '  q("view").innerHTML=h;',
  '}',
  '/* ---------- 超管：平台账户（使用费与保证金 / 租用金归集） ---------- */',
  'VIEWS.platform=async function(){',
  '  var d=await api("/api/platform");if(!d.success)return tip(d.error);',
  '  var p=d.platform;',
  '  var h="<div class=\\"grid\\">"+kpi("平台使用费累计",money(p.platformFeeTotal)+" MMK")+kpi("平台账户余额",money(p.balance))+kpi("保证金归集",money(p.depositTotal))+kpi("租用金归集",money(p.rentalTotal))+kpi("资金池余额",money(p.poolBalance))+"</div>";',
  '  h+="<div class=\\"card\\"><h3>平台账户（超管层级）</h3><p class=\\"muted\\">"+E(p.rule)+"</p></div>";',
  '  h+="<div class=\\"card\\"><div class=\\"between\\"><h3>保证金 / 租用金收款账户（资金池）</h3>"+btn("配置收款账户","setPoolAccounts()")+"</div>"',
  '    +table(["账号","持有人","状态"],p.receiveAccounts||[],acctFmt)+"<p class=\\"muted\\">代理缴纳保证金 / 租用金时生成的缴纳单会指定到这里配置的资金池收款账户入账；超管账户不直接承接业务收款。</p></div>";',
  '  var c=await api("/api/settings");var cf=(c&&c.config)||{};PC_CFG=cf;',
  '  h+="<div class=\\"card\\"><h3>平台使用费率（仅超管可设）</h3>"',
  '    +inputVal("p_fee","平台使用费率（按代理账户收款结算额计提；0=暂不计提）",cf.platformFeeRate)',
  '    +inputVal("p_on","计提时机（true=收款结算时计提 / false=仅出款完成时计提）",cf.platformFeeOnCollect)',
  '    +"<p class=\\"muted\\">计提对象：订单归属向上最近的一级代理账户；代理可用余额不足时，差额记为欠缴（platformFeeDue），不硬扣、账目可核。</p>"',
  '    +"<div style=\\"margin-top:12px\\">"+btn("保存平台费率","savePlatform()")+"</div></div>";',
  '  q("view").innerHTML=h;',
  '}',
  'async function savePlatform(){',
  '  var gv=function(id){return q(id)?String(q(id).value):""};',
  '  var cur=PC_CFG||{};',
  '  var rate=gv("p_fee").trim()===""?cur.platformFeeRate:parseFloat(gv("p_fee"));',
  '  var on=gv("p_on").trim()===""?cur.platformFeeOnCollect:(gv("p_on").toLowerCase()==="true");',
  '  var d=await api("/api/settings","PUT",{platformFeeRate:rate,platformFeeOnCollect:on});after(d.success?"平台费率已保存":d.error)',
  '}',
  'VIEWS.orders=async function(){',
  '  var d=await api("/api/orders?limit=200");if(!d.success)return tip(d.error);',
  '  var rows=(d.orders||[]).map(function(o){return Object.assign({},o,{ops:orderOps(o),amountTxt:money(o.amount),payableTxt:money(o.payable)})});',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>收款订单</h3>"+btn("新建订单","quickOrder()")+"</div>"',
  '    +table(["订单号","场景","金额","应付(含尾码)","通道账号","状态","阶段","到账流水","操作"],rows,function(c,r){',
  '      if(c==="状态")return tag(r.status);',
  '      if(c==="阶段")return "<span class=\\"tag "+cls(r.stage==="settled"?"paid":(r.stage==="delivered"?"wait":"mute"))+"\\">"+E(r.stageText||r.stage||"—")+"</span>";',
  '      if(c==="金额")return r.amountTxt;',
  '      if(c==="应付(含尾码)")return "<b style=\\"color:#FFD700\\">"+r.payableTxt+"</b>";',
  '      if(c==="到账流水")return "<span class=\\"mono\\">"+E(r.paidTxid||"—")+"</span>";',
  '      if(c==="操作")return r.ops;',
  '      if(c==="订单号")return "<span class=\\"mono\\">"+E(r.orderId)+"</span>";',
  '      if(c==="通道账号")return "<span class=\\"mono\\">"+E(r.channelAccount)+"</span>";',
  '      return E(r[c])})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'function orderOps(o){',
  '  var h=btn("付款链接","payLink(\\x27"+o.payUrl+"\\x27)");',
  '  if(o.status==="pending")h+=btn("手工核销","markPaid(\\x27"+o.orderId+"\\x27)")+btn("关闭","closeOrder(\\x27"+o.orderId+"\\x27)");',
  '  if(o.status==="paid"){',
  '    if(o.stage==="paid")h+=btn("发货","deliverUI(\\x27"+o.orderId+"\\x27)");',
  '    if(o.stage==="delivered")h+=btn("确认收货","receiveOrder(\\x27"+o.orderId+"\\x27)");',
  '    if(o.stage==="received")h+=btn("转款到户","receiveOrder(\\x27"+o.orderId+"\\x27)");',
  '    h+=btn("退款","refundOrder(\\x27"+o.orderId+"\\x27)");',
  '  }',
  '  return h',
  '}',
  'VIEWS.payouts=async function(){',
  '  var d=await api("/api/payouts?limit=200");if(!d.success)return tip(d.error);',
  '  var rows=(d.payouts||[]).map(function(p){return Object.assign({},p,{amountTxt:money(p.amount),ops:payoutOps(p)})});',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>出款</h3>"+btn("发起出款","quickPayout()")+"</div>"',
  '    +"<p class=\\"muted\\">单笔不超过系统自动出款额度的直接进入出款队列；超过额度的需上级审批。执行端回执流水号校验通过后才算完成。</p>"',
  '    +table(["出款单","收款账号","金额","手续费","状态","审批人","流水号","操作"],rows,function(c,r){',
  '      if(c==="状态")return tag(r.status);',
  '      if(c==="金额")return r.amountTxt;',
  '      if(c==="手续费")return money(r.fee);',
  '      if(c==="操作")return r.ops;',
  '      if(c==="出款单")return "<span class=\\"mono\\">"+E(r.id)+"</span>";',
  '      return E(r[c]||"—")})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'function payoutOps(p){',
  '  if(p.status==="pending")return btn("通过","apv(\\x27"+p.id+"\\x27)")+btn("驳回","rej(\\x27"+p.id+"\\x27)");',
  '  if(p.status==="queued")return "<span class=\\"muted\\">等待执行端出款</span>";',
  '  return "<span class=\\"muted\\">—</span>"',
  '}',
  'VIEWS.pool=async function(){',
  '  var d=await api("/api/pool");if(!d.success)return tip(d.error);',
  '  var p=d.pool;',
  '  var h="<div class=\\"grid\\">"+kpi("资金池余额",money(p.balance)+" MMK")+kpi("保证金总额",money(p.depositTotal))+kpi("系统租用金",money(p.rentalTotal))+kpi("已扣罚",money(p.penaltyTotal))+kpi("已退还保证金",money(p.refundTotal))+"</div>";',
  '  h+="<div class=\\"card\\"><div class=\\"between\\"><h3>资金池收款账户</h3>"+btn("配置账户","setPoolAccounts()")+"</div>"',
  '    +table(["账号","持有人","状态"],p.accounts,acctFmt)+"</div>";',
  '  h+="<div class=\\"card\\"><div class=\\"between\\"><h3>资金池流水（不可篡改）</h3><span class=\\"row\\">"+btn("记一笔租用金","quickRental()")+btn("记一笔保证金","quickDeposit()")+btn("违规扣罚","quickPenalty()")+"</span></div>"',
  '    +poolTable(d.ledger)+"</div>";',
  '  h+="<div class=\\"card\\"><h3>各代理保证金台账</h3>"+depTable(d.deposits)+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'function acctFmt(c,r){if(c==="状态")return tag(r.status);if(c==="账号")return "<span class=\\"mono\\">"+E(r.accountMasked||r.account||"")+"</span>";return E(r[c]||"—")}',
  'function poolTable(list){return table(["时间","类型","金额","代理","说明"],(list||[]).map(function(e){return {t:e.ts?e.ts.slice(0,19).replace("T"," "):"",type:e.type,amt:money(e.amount),agent:e.agentId||"—",note:e.note||""}}),function(c,r){return c==="金额"?"<b>"+r.amt+"</b>":E(r[c])})}',
  'function depTable(list){return table(["代理","已缴","应缴","已扣罚","状态"],(list||[]).map(function(d){return {a:d.agentId,paid:money(d.paid),req:money(d.required),pen:money(d.penalty),st:d.sufficient?"合规":"不足"}}),function(c,r){if(c==="状态")return tag(r.st==="合规"?"paid":"pending")+E(r.st);return E(r[c])})}',
  'VIEWS.deposits=async function(){',
  '  var h="";',
  '  if(ME.role==="super"){',
  '    var d=await api("/api/pool");if(!d.success)return tip(d.error);',
  '    h+="<div class=\\"card\\"><div class=\\"between\\"><h3>保证金台账</h3><span class=\\"row\\">"+btn("记保证金","quickDeposit()")+btn("退还保证金","refundDepositUI()")+"</span></div>"+depTable(d.deposits)+"</div>";',
  '    h+="<div class=\\"card\\"><h3>违规扣罚记录</h3>"+table(["扣罚单","代理","金额","原因","状态","操作"],(d.penalties||[]).map(function(p){return Object.assign({},p,{amt:money(p.amount),ops:p.status==="appealed"?btn("复核","resolvePenalty(\\x27"+p.agentId+"\\x27,\\x27"+p.id+"\\x27)"):"<span class=\\"muted\\">—</span>"})}),function(c,r){if(c==="状态")return tag(r.status);if(c==="金额")return r.amt;if(c==="操作")return r.ops;return E(r[c]||"—")})+"</div>";',
  '    h+="<div class=\\"card\\"><div class=\\"between\\"><h3>系统租用金记录</h3>"+btn("记一笔租用金","quickRental()")+"</div>"+table(["租用单","代理","周期","金额","状态"],(d.rentals||[]).map(function(r){return Object.assign({},r,{amt:money(r.amount)})}),function(c,r){if(c==="状态")return tag(r.status);if(c==="金额")return r.amt;return E(r[c]||"—")})+"</div>";',
  '  }else{',
  '    var d=await api("/api/deposit");if(!d.success)return tip(d.error);',
  '    var dep=d.deposit;',
  '    h+="<div class=\\"grid\\">"+kpi("已缴保证金",money(dep.paid))+kpi("应缴保证金",money(dep.required))+kpi("已扣罚",money(dep.penalty))+kpi("状态",dep.sufficient?"合规":"不足·受限")+"</div>";',
  '    h+="<div class=\\"card\\"><div class=\\"between\\"><h3>缴纳保证金</h3>"+btn("生成缴纳单","quickDepositOrder()")+"</div><p class=\\"muted\\">系统会生成一个资金池收款订单，你按显示的金额转账到超管资金池账户即可自动入账。</p></div>";',
  '    var r1=await api("/api/rentals");',
  '    h+="<div class=\\"card\\"><h3>系统租用金记录</h3>"+table(["租用单","周期","金额","状态"],(r1.rentals||[]).map(function(r){return Object.assign({},r,{amt:money(r.amount)})}),function(c,r){if(c==="状态")return tag(r.status);if(c==="金额")return r.amt;return E(r[c]||"—")})+"</div>";',
  '    var r2=await api("/api/penalties");',
  '    h+="<div class=\\"card\\"><h3>扣罚记录</h3>"+table(["扣罚单","金额","原因","状态","操作"],(r2.penalties||[]).map(function(p){return Object.assign({},p,{amt:money(p.amount),ops:p.status==="applied"?btn("申诉","appealPenalty(\\x27"+p.id+"\\x27)"):"<span class=\\"muted\\">—</span>"})}),function(c,r){if(c==="状态")return tag(r.status);if(c==="金额")return r.amt;if(c==="操作")return r.ops;return E(r[c]||"—")})+"</div>";',
  '  }',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.devices=async function(){',
  '  var d=await api("/api/devices");if(!d.success)return tip(d.error);',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>设备（通知转发端 / 出款执行端）</h3>"+btn("新增设备","quickDevice()")+"</div>"',
  '    +"<p class=\\"muted\\">通知转发端：把手机上收到的 KBZPay 到账通知转发到 <code>POST /api/notify/forward</code>（请求头 X-Device-Key）。出款执行端：轮询 <code>GET /api/payout/executor/pull</code> 并回执。</p>"',
  '    +table(["设备","类型","标签","状态","密钥(掩码)","最后上线","操作"],d.devices,function(c,r){if(c==="状态")return tag(r.status);if(c==="操作")return btn("停用","delDevice(\\x27"+r.id+"\\x27)");return E(r[c]||"—")})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.adapters=async function(){',
  '  var d=await api("/api/adapters");if(!d.success)return tip(d.error);',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>平台适配器（无文档跨平台接入）</h3>"+btn("新增适配器","quickAdapter()")+"</div>"',
  '    +"<p class=\\"muted\\">适配器 = 一个平台的接入配置：托管收银台 / 一行 SDK / 服务端 API。填写回调地址与签名密钥后，订单到账会自动回推你的平台（失败自动重试）。</p>"',
  '    +table(["名称","平台","模式","回调地址","状态","回调入口","操作"],d.adapters,function(c,r){if(c==="状态")return tag(r.status);if(c==="回调入口")return "<span class=\\"mono\\">"+E(r.callbackUrl)+"</span>";if(c==="操作")return btn("停用","delAdapter(\\x27"+r.id+"\\x27)");return E(r[c]||"—")})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.webhooks=async function(){',
  '  var d=await api("/api/webhooks");if(!d.success)return tip(d.error);',
  '  var h="<div class=\\"card\\"><div class=\\"between\\"><h3>回调投递记录</h3>"+(ME.role==="super"?btn("立即重试全部","runHooks()"):"")+"</div>"',
  '    +table(["订单","地址","状态","尝试次数","最近错误","下次重试","操作"],d.webhooks,function(c,r){if(c==="状态")return tag(r.status);if(c==="操作")return btn("重试","retryHook(\\x27"+r.id+"\\x27)");return E(r[c]||"—")})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.audit=async function(){',
  '  var d=await api("/api/audit?limit=200");if(!d.success)return tip(d.error);',
  '  var h="<div class=\\"card\\"><h3>审计日志</h3>"+table(["时间","操作者","动作","详情"],d.logs.map(function(l){return {t:l.ts?l.ts.slice(0,19).replace("T"," "):"",a:l.actorId,act:l.action,d:JSON.stringify(l.detail||{})}}),function(c,r){return E(r[c])})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.settings=async function(){',
  '  var d=await api("/api/settings");if(!d.success)return tip(d.error);',
  '  var c=d.config,r=d.raw||{};',
  '  var h="<div class=\\"card\\"><h3>系统设置</h3>"',
  '   +inputRow("s_name","系统名称",c.gatewayName)+inputRow("s_reg","地区模式（geo/phone/both/off）",c.regionMode)',
  '   +inputRow("s_countries","允许国家（逗号分隔）",(c.allowCountries||[]).join(","))',
  '   +inputRow("s_min","最小出款金额",c.minWithdraw,"number")+inputRow("s_fee","出款手续费率（0.05=5%）",c.withdrawFeeRate,"number")',
  '   +inputRow("s_auto","自动出款额度",c.autoPayoutLimit,"number")+inputRow("s_tail","识别码位数",c.tailDigits,"number")',
  '   +inputRow("s_ttl","订单有效期（秒）",c.orderTtlSec,"number")+inputRow("s_dep","默认应缴保证金",c.depositDefaultRequired,"number")',
  '   +inputRow("s_rent","月度系统租用金",c.rentalFeeMonthly,"number")+inputRow("s_cd","通道冷却期（秒）",c.channelCooldownSec,"number")',
  '   +"<div style=\\"margin-top:12px\\">"+btn("保存设置","saveSettings()")+"</div></div>";',
  '  h+="<div class=\\"card\\"><h3>履约与闭环（电商 / 游戏）</h3>"',
  '   +inputRow("s_autoDeliver","到账自动发货（true/false）",c.autoDeliver)',
  '   +inputRow("s_recvHours","发货后自动收货小时数（0=关闭）",c.autoReceiveHours,"number")',
  '   +inputRow("s_autoSettle","收货后自动转款到户（true/false）",c.autoSettle)',
  '   +inputRow("s_settleFee","结算手续费率（0.01=1%）",c.settleFeeRate,"number")',
  '   +inputRow("s_sub","允许代理创建子代理（true/false）",c.allowSubAgents)',
  '   +"<div style=\\"margin-top:12px\\">"+btn("保存履约设置","saveSettings()")+"</div></div>";',
  '  h+="<div class=\\"card\\"><h3>接入安全（签名 / 防重放 / 限流）</h3>"',
  '   +inputRow("s_sig","服务端强制签名（true/false）",c.requireApiSignature)',
  '   +inputRow("s_skew","签名时间偏差容忍（秒）",c.signatureSkewSec,"number")',
  '   +inputRow("s_nonce","Nonce 有效期（秒）",c.nonceTtlSec,"number")',
  '   +inputRow("s_rl","每分钟限流（次）",c.rateLimitPerMin,"number")',
  '   +inputRow("s_reveal","允许归属方读取受限明文（true/false）",c.allowReveal)',
  '   +"<p class=\\"muted\\">开启强制签名后，所有服务端 API 调用都必须带 X-Timestamp / X-Nonce / X-Signature（SDK 已自动附带）。受限明文读取都会写审计。</p>"',
'   +"<div style=\\"margin-top:12px\\">"+btn("保存安全设置","saveSettings()")+"</div></div>";',
   '  h+="<div class=\\"card\\"><h3>会话与错误策略</h3>"',
   '   +inputVal("s_sess","会话有效期（秒，默认 43200=12 小时）",r.sessionTtlSec,"number")',
   '   +inputVal("s_lockmax","登录失败上限（次，达到即锁定）",r.loginMaxAttempts,"number")',
   '   +inputVal("s_locksec","登录锁定时长（秒）",r.loginLockSec,"number")',
   '   +inputVal("s_pubrl","公开接入面每分钟上限（次，按来源 IP 计；0=关闭）",r.publicRateLimitPerMin,"number")',
   '   +inputVal("s_expose","对外暴露错误详情（true/false）",r.exposeErrorDetail)',
   '   +"<p class=\\"muted\\">会话有效期越短越安全；登录失败达到上限后按「账号 + 来源 IP」锁定（不影响其他 IP 的正常登录）；公开接入面（免登录的收银台 / 回调 / 设备端 / 插件）另有按「入口 + 来源 IP」的每分钟上限，用于挡住密钥枚举与恶意刷单，正常客户端触及不到；错误详情仅排障时临时开启，开启后会把内部异常原文返回给调用方，排障完请立即关闭。</p>"',
   '   +"<div style=\\"margin-top:12px\\">"+btn("保存会话与错误策略","saveSettings()")+"</div></div>";',
   '  h+="<div class=\\"card\\"><h3>安全</h3><p class=\\"muted\\">超管密码与设备密钥务必在上线前更换；敏感数据（收款账号/手机号）默认脱敏展示。可在此修改超管密码。</p>"+btn("修改我的密码","changePwd()")+"</div>";',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.access=async function(){',
  '  var d=await api("/api/config");var c=d.config;',
  '  var h="<div class=\\"card\\"><h3>用户侧接入（一行 SDK）</h3>"',
  '   +"<div class=\\"copybox\\"><span class=\\"txt\\">&lt;script src=\\""+E(location.origin)+"/sdk.js\\"&gt;&lt;/script&gt;</span>"+btn("复制","copyStr(\\x27"+E(location.origin)+"/sdk.js\\x27)")+"</div>"',
  '   +"<p class=\\"muted\\">KBZPay.init({apiBase:\\""+E(location.origin)+"\\", merchantKey:\\"你的商户密钥\\", userId:\\"用户ID\\", platform:\\"你的平台\\"}); await KBZPay.pay(10000);</p></div>";',
  '  h+="<div class=\\"card\\"><div class=\\"between\\"><h3>商户密钥（服务端接入用）</h3>"+btn("生成 / 更换密钥","rotateKey()")+"</div><p class=\\"muted\\">服务端下单：POST /api/pay/init，请求头带 X-Merchant-Key；建议同时带 X-Timestamp / X-Nonce / X-Signature（签名=HMAC-SHA256(密钥, METHOD\\nPATH\\nX-Timestamp\\nX-Nonce\\nsha256hex(body))）与 X-Idempotency-Key 防重复下单。密钥只显示一次，请妥善保存。</p><div id=\\"mkey\\"></div></div>";',
  '  h+="<div class=\\"card\\"><h3>电商：自动发货 + 收货转款</h3>"',
  '   +"<p class=\\"muted\\">下单时带 <code>cardSecret</code>（卡密）或 <code>trackingNo</code>（物流单号），到账即自动发货；买家在收银台确认收货后款项自动转款到户。也可用 <code>POST /api/orders/:id/deliver</code> 手工补发货。</p>"',
  '   +"<div class=\\"copybox\\"><span class=\\"txt\\">curl -X POST .../api/pay/init -H \\"X-Merchant-Key: mk_xxx\\" -d \'{\\"amount\\":10000,\\"scene\\":\\"ecommerce\\",\\"cardSecret\\":\\"CARD-XXXX\\"}\'</span></div></div>";',
  '  h+="<div class=\\"card\\"><h3>游戏：无文档接入 + 发币回执</h3>"',
  '   +"<p class=\\"muted\\">下单带 <code>gameAccount / gameZone / gameRole / itemCode</code>（scene=game）；到账后系统自动下发，发币完成后回调 <code>POST /api/game/callback/&lt;适配器ID&gt;</code>（HMAC-SHA256 签名），收到回执即自动收货、转款到游戏商户户。</p>"',
  '   +"<div class=\\"copybox\\"><span class=\\"txt\\">{\\"orderId\\":\\"ord_xxx\\",\\"action\\":\\"grant\\",\\"ok\\":true,\\"txid\\":\\"GAME-123456\\"}</span></div></div>";',
  '  q("view").innerHTML=h;',
  '}',
  'VIEWS.balance=async function(){',
  '  var d=await api("/api/overview");var o=d.overview;',
  '  var s=await api("/api/stats");',
  '  var h="<div class=\\"grid\\">"+kpi("可用余额",money(o.balance)+" MMK")+kpi("提现手续费率",o.limits.withdrawFeeRate)+kpi("最小提现",money(o.limits.minWithdraw))+"</div>";',
  '  h+="<div class=\\"card\\"><h3>提现</h3>"+inputRow("w_acct","收款 KBZ 账号","","text")+inputRow("w_amt","提现金额","","number")+"<div style=\\"margin-top:10px\\">"+btn("提交提现","doWithdraw()")+"</div></div>";',
  '  var l=await api("/api/ledger");',
  '  h+="<div class=\\"card\\"><h3>我的账本（不可篡改）</h3>"+table(["时间","类型","方向","金额","说明"],(l.entries||[]).map(function(e){return {t:e.ts?e.ts.slice(0,19).replace("T"," "):"",type:e.type,dir:e.direction,amt:money(e.amount),note:e.note||""}}),function(c,r){return c==="金额"?"<b>"+r.amt+"</b>":E(r[c])})+"</div>";',
  '  q("view").innerHTML=h;',
  '}',

  '/* ---------- 动作 ---------- */',
  'async function after(msg,reload){tip(msg,true);if(reload!==false)go(CUR)}',
  'async function quickOrder(){',
  '  var amt=parseInt(prompt("请输入收款金额（MMK）","10000")||"0",10);if(!amt)return;',
  '  var scene=prompt("业务类型：ecommerce（电商）/ game（游戏）","game")||"game";',
  '  var cust=prompt("用户标识（可留空）","user001")||"";',
  '  var body={amount:amt,scene:scene,customer:cust,subject:"充值"};',
  '  if(scene==="game"){',
  '    body.gameAccount=prompt("游戏账号（到达后发币目标）","")||"";',
  '    body.gameZone=prompt("游戏区服（可留空）","")||"";',
  '    body.gameRole=prompt("游戏角色（可留空）","")||"";',
  '    body.itemCode=prompt("道具编码（可留空）","")||"";',
  '  }else if(scene==="ecommerce"){',
  '    var cs=prompt("卡密 / 兑换码（到账后自动发给买家，可留空由卖家手工发货）","")||"";',
  '    if(cs)body.cardSecret=cs;',
  '  }',
  '  var d=await api("/api/orders","POST",body);',
  '  if(!d.success)return tip(d.error);',
  '  var o=d.order;',
  '  alert("下单成功！\\n订单号："+o.orderId+"\\n应付金额（含尾码）："+money(o.payable)+" "+o.currency+"\\n收款账号："+o.channelAccount+"\\n付款链接："+location.origin+o.payUrl);',
  '  go("orders");',
  '}',
  'function payLink(u){prompt("付款链接（发给用户即可）",location.origin+u)}',
  'async function markPaid(id){var tx=prompt("到账交易号（至少 5 位数字）","");if(!tx)return;var d=await api("/api/orders/"+id+"/markpaid","POST",{txid:tx});after(d.success?"已核销":d.error)}',
  'async function closeOrder(id){if(!confirm("确认关闭该订单？"))return;var d=await api("/api/orders/"+id+"/close","POST",{});after(d.success?"已关闭":d.error)}',
  'async function refundOrder(id){var r=prompt("退款原因","用户申请退款")||"退款";if(!confirm("确认退款？余额将扣除该金额"))return;var d=await api("/api/orders/"+id+"/refund","POST",{reason:r});after(d.success?"已退款":d.error)}',
  'async function deliverUI(id){',
  '  var type=prompt("发货类型：card（卡密）/ logistics（物流）/ game（游戏）/ manual（人工/说明）","card")||"card";',
  '  var payload={delivery:{type:type}};',
  '  if(type==="card"){var cs=prompt("卡密内容（加密存储，收货转款后自动销毁）","");if(!cs)return tip("卡密不能为空");payload.cardSecret=cs;payload.delivery.note="卡密发货"}',
  '  else if(type==="logistics"){payload.trackingNo=prompt("物流单号","")||"";payload.delivery.carrier=prompt("承运商（可留空）","")||""}',
  '  else if(type==="game"){payload.delivery.note=prompt("发货说明（发币要素）","游戏道具发货")||""}',
  '  else {payload.delivery.note=prompt("发货说明","已发货")||"已发货"}',
  '  var d=await api("/api/orders/"+id+"/deliver","POST",payload);',
  '  after(d.success?"已发货（到账自动/手动发货成功）":d.error)',
  '}',
  'async function receiveOrder(id){if(!confirm("确认收货并把款项转款到户？"))return;var d=await api("/api/orders/"+id+"/receive","POST",{});after(d.success?"已确认收货，款项已转款到户":d.error)}',
  'async function quickChannel(){',
  '  var acct=prompt("KBZ 商业账号（6-20 位数字）","");if(!acct)return;',
  '  var holder=prompt("账户持有人姓名","")||"";',
  '  var label=prompt("通道备注名（可留空）","")||"";',
  '  var d=await api("/api/channels","POST",{account:acct,holder:holder,label:label,primary:true});',
  '  after(d.success?"通道已新增并设为主通道":d.error)',
  '}',
  'async function replaceChannel(id){',
  '  var acct=prompt("请输入新的 KBZ 商业账号（旧通道自动进入冷却期）","");if(!acct)return;',
  '  var holder=prompt("新账号持有人姓名（可留空）","")||"";',
  '  var d=await api("/api/channels/"+id+"/replace","POST",{account:acct,holder:holder});',
  '  after(d.success?"已一键替换，旧通道冷却中":d.error)',
  '}',
  'async function setPrimary(id){var d=await api("/api/channels/"+id,"PUT",{primary:true});after(d.success?"已设为主通道":d.error)}',
  'async function freezeChannel(id){var d=await api("/api/channels/"+id,"PUT",{status:"frozen"});after(d.success?"已冻结":d.error)}',
  'async function delChannel(id){if(!confirm("确认停用该通道？"))return;var d=await api("/api/channels/"+id,"DELETE",{});after(d.success?"已停用":d.error)}',
  'async function quickPayout(){',
  '  var acct=prompt("收款 KBZ 账号","");if(!acct)return;',
  '  var amt=parseInt(prompt("出款金额（MMK）","10000")||"0",10);if(!amt)return;',
  '  var d=await api("/api/payouts","POST",{account:acct,amount:amt});',
  '  if(!d.success)return tip(d.error);',
  '  after(d.payout.status==="queued"?"已自动进入出款队列":"已提交，等待审批")',
  '}',
  'async function apv(id){var d=await api("/api/payouts/"+id+"/approve","POST",{});after(d.success?"已通过":d.error)}',
  'async function rej(id){var r=prompt("驳回原因","")||"";var d=await api("/api/payouts/"+id+"/reject","POST",{reason:r});after(d.success?"已驳回":d.error)}',
  'async function quickAccount(){',
  '  var role=prompt("创建类型：agent（代理）或 merchant（商户）","merchant")||"merchant";',
  '  var username=prompt("登录账号（3-40 位字母/数字）","");if(!username)return;',
  '  var name=prompt("名称","")||username;',
  '  var password=prompt("初始密码（至少 6 位）","Kbz@123456")||"";',
  '  if(!password)return;',
  '  var d=await api("/api/accounts","POST",{role:role,username:username,name:name,password:password});',
  '  after(d.success?("账号已创建："+username):d.error)',
  '}',
  'async function editName(id){var n=prompt("新名称","");if(!n)return;var d=await api("/api/accounts/"+id,"PUT",{name:n});after(d.success?"已更新":d.error)}',
  'async function disableUser(id){if(!confirm("确认停用该账号？"))return;var d=await api("/api/accounts/"+id,"DELETE",{});after(d.success?"已停用":d.error)}',
  'async function setDepositReq(id){var v=parseInt(prompt("应缴保证金（MMK）","1000000")||"0",10);var d=await api("/api/accounts/"+id,"PUT",{depositRequired:v});after(d.success?"已更新":d.error)}',
  'async function quickDevice(){',
  '  var type=prompt("设备类型：notify（通知转发）/ payout（出款执行）/ both","both")||"both";',
  '  var label=prompt("设备标签","我的手机")||"我的手机";',
  '  var d=await api("/api/devices","POST",{type:type,label:label});',
  '  if(!d.success)return tip(d.error);',
  '  alert("设备已创建，请立即保存密钥（只显示一次）：\\n\\n"+d.device.keyPlain+"\\n\\n用法：请求头 X-Device-Key: 该密钥");',
  '  go("devices");',
  '}',
  'async function delDevice(id){if(!confirm("确认停用该设备？"))return;var d=await api("/api/devices/"+id,"DELETE",{});after(d.success?"已停用":d.error)}',
  'async function quickAdapter(){',
  '  var name=prompt("平台名称","我的游戏平台")||"我的游戏平台";',
  '  var mode=prompt("接入模式：hosted（托管收银台）/ sdk（一行 SDK）/ api（服务端 API）","api")||"api";',
  '  var url=prompt("到账回调地址（http/https，可留空）","")||"";',
  '  var d=await api("/api/adapters","POST",{name:name,mode:mode,targetUrl:url,platform:name});',
  '  if(!d.success)return tip(d.error);',
  '  alert("适配器已创建\\n回调地址：/api/adapter/callback/"+d.adapter.id+"\\n签名密钥（只显示一次）："+d.adapter.signSecret);',
  '  go("adapters");',
  '}',
  'async function delAdapter(id){if(!confirm("确认停用该适配器？"))return;var d=await api("/api/adapters/"+id,"DELETE",{});after(d.success?"已停用":d.error)}',
  'async function runHooks(){var d=await api("/api/webhooks/run","POST",{limit:50});after(d.success?("已投递 "+d.delivered+" 条"):d.error)}',
  'async function retryHook(id){var d=await api("/api/webhooks/"+id+"/retry","POST",{});after(d.success?"已重试":d.error)}',
  'async function setPoolAccounts(){',
  '  var raw=prompt("资金池收款账号（多个用英文逗号分隔）","")||"";',
  '  var arr=raw.split(",").map(function(s){return s.trim()}).filter(Boolean).map(function(a){return {account:a,holder:"资金池"}});',
  '  if(!arr.length)return;',
  '  var d=await api("/api/pool/accounts","POST",{accounts:arr});after(d.success?"已保存":d.error)',
  '}',
  'async function pickAgent(title){',
  '  var d=await api("/api/accounts");',
  '  var agents=(d.accounts||[]).filter(function(a){return a.role==="agent"});',
  '  if(!agents.length){tip("暂无代理账号，请先创建代理");return null}',
  '  var list=agents.map(function(a,i){return (i+1)+") "+a.username+" ("+a.id+")"}).join("\\n");',
  '  var sel=prompt(title+"\\n"+list+"\\n\\n请输入代理 ID","");',
  '  if(!sel)return null; return sel.trim()',
  '}',
  'async function quickDeposit(){var a=await pickAgent("记一笔保证金，选择代理：");if(!a)return;var v=parseInt(prompt("金额（MMK）","1000000")||"0",10);if(!v)return;var d=await api("/api/pool/deposit","POST",{agentId:a,amount:v});after(d.success?"保证金已入池":d.error)}',
  'async function quickPenalty(){var a=await pickAgent("违规扣罚，选择代理：");if(!a)return;var v=parseInt(prompt("扣罚金额（MMK）","100000")||"0",10);if(!v)return;var reason=prompt("扣罚原因","违反当地规定 / 违法行为")||"";var d=await api("/api/pool/penalty","POST",{agentId:a,amount:v,reason:reason});after(d.success?"已扣罚":d.error)}',
  'async function quickRental(){var a=await pickAgent("记录系统租用金，选择代理：");if(!a)return;var v=parseInt(prompt("金额（MMK）","200000")||"0",10);if(!v)return;var p=prompt("周期（如 2026-10）",new Date().toISOString().slice(0,7))||"";var d=await api("/api/pool/rental","POST",{agentId:a,amount:v,period:p});after(d.success?"租用金已入池":d.error)}',
  'async function refundDepositUI(){var a=await pickAgent("退还保证金，选择代理：");if(!a)return;var v=parseInt(prompt("退还金额（MMK）","")||"0",10);if(!v)return;if(!confirm("确认退还 "+money(v)+" MMK？"))return;var d=await api("/api/pool/deposit/refund","POST",{agentId:a,amount:v});after(d.success?"已退还":d.error)}',
  'async function resolvePenalty(agentId,id){var v=parseInt(prompt("复核退还金额（MMK，默认全额 "+"")||"0",10);var d=await api("/api/pool/penalty/resolve","POST",{agentId:agentId,penaltyId:id,refundAmount:v});after(d.success?"已复核":d.error)}',
  'async function appealPenalty(id){var n=prompt("申诉说明","申请复核")||"";var d=await api("/api/penalties/"+id+"/appeal","POST",{note:n});after(d.success?"已提交申诉":d.error)}',
  'async function quickDepositOrder(){var amt=parseInt(prompt("缴纳金额（MMK）","1000000")||"0",10);if(!amt)return;var d=await api("/api/deposit/order","POST",{amount:amt});if(!d.success)return tip(d.error);var o=d.order;alert("缴纳单已生成\\n应付金额："+o.payable+"\\n收款账号："+o.channelAccount+"\\n链接："+location.origin+o.payUrl);go("deposits")}',
  'async function doWithdraw(){var a=q("w_acct")?q("w_acct").value:"";var m=parseInt(q("w_amt")?q("w_amt").value:"0",10);if(!a||!m)return tip("请填写账号与金额");var d=await api("/api/payouts","POST",{account:a,amount:m});if(!d.success)return tip(d.error);after(d.payout.status==="queued"?"已进入出款队列":"已提交审批")}',
  'async function rotateKey(){if(!confirm("生成新密钥后旧密钥立即失效，确认？"))return;var d=await api("/api/me/merchantkey","POST",{});if(!d.success)return tip(d.error);q("mkey").innerHTML="<div class=\\"copybox\\"><span class=\\"txt\\">"+E(d.merchantKey)+"</span></div><p class=\\"muted\\">请立即复制保存，页面刷新后不再显示。</p>"}',
  'async function saveSettings(){',
  '  var gv=function(id){return q(id)?q(id).value:""};',
  '  var bv=function(id){return String(gv(id)).toLowerCase()==="true"};',
  '  var iv=function(id){var v=parseInt(gv(id),10);return isNaN(v)?0:v};',
  '  var p={gatewayName:gv("s_name"),regionMode:gv("s_reg"),allowCountries:String(gv("s_countries")).split(",").map(function(s){return s.trim().toUpperCase()}).filter(Boolean),minWithdraw:iv("s_min"),withdrawFeeRate:parseFloat(gv("s_fee")),autoPayoutLimit:iv("s_auto"),tailDigits:iv("s_tail"),orderTtlSec:iv("s_ttl"),depositDefaultRequired:iv("s_dep"),rentalFeeMonthly:iv("s_rent"),channelCooldownSec:iv("s_cd"),',
  '    autoDeliver:bv("s_autoDeliver"),autoReceiveHours:iv("s_recvHours"),autoSettle:bv("s_autoSettle"),settleFeeRate:parseFloat(gv("s_settleFee")||"0"),allowSubAgents:bv("s_sub"),',
  '    requireApiSignature:bv("s_sig"),signatureSkewSec:iv("s_skew"),nonceTtlSec:iv("s_nonce"),rateLimitPerMin:iv("s_rl"),allowReveal:bv("s_reveal"),',
  '    sessionTtlSec:iv("s_sess"),loginMaxAttempts:iv("s_lockmax"),loginLockSec:iv("s_locksec"),publicRateLimitPerMin:iv("s_pubrl"),exposeErrorDetail:bv("s_expose")};',
  '  var d=await api("/api/settings","PUT",p);after(d.success?"设置已保存":d.error)',
  '}',
  'async function changePwd(){',
  '  var oldp=prompt("当前密码","");if(oldp===null)return;',
  '  var np=prompt("新密码（至少 6 位）","");if(!np)return;',
  '  var d=await api("/api/me/password","POST",{oldPassword:oldp,password:np});',
  '  if(d.success)tip("密码已修改",true);else tip(d.error)',
  '}',
  'function copyStr(s){navigator.clipboard&&navigator.clipboard.writeText(s);tip("已复制",true)}',

  '/* ---------- 启动 ---------- */',
  'q("btnLogin").onclick=doLogin;',
  'q("p").addEventListener("keydown",function(e){if(e.key==="Enter")doLogin()});',
  'q("btnLogout").onclick=function(){logout()};',
  'q("btnPwd").onclick=changePwd;',
  '(async function(){',
  '  if(!T)return;',
  '  var d=await api("/api/auth/me");',
  '  if(d.success){ME=d.profile;boot()}else{localStorage.removeItem("kbz_token");T=""}',
  '})();',
].join('\n')

/* =============================================================================
 * 扩展控制台（CONSOLE_EXTRA_JS）
 * -----------------------------------------------------------------------------
 * 用模板字面量承载，避免上面单引号数组里 \x27 / \" 的双重转义负担。
 * 约束：本模板字面量内不得出现反引号、美元花括号插值，或字面量 </script>。
 * 新增视图：agentrentals（代理表 + 费用与时间管理）、gamepoints（游戏上下分）、
 *          pluguide（多平台无文档一键接入向导）。
 * ========================================================================== */
export const CONSOLE_EXTRA_JS = `
/* ==================== 扩展：代理表 / 费用与时间管理 / 游戏上下分 / 零文档接入向导 ==================== */
var AGF={status:'',kw:''};
var RB={};
var GPF={direction:'',status:''};
var PL_POINTS=[];

function countBy(arr,k,v){var n=0;(arr||[]).forEach(function(x){if(x&&x[k]===v)n++});return n}
function agentStatusTag(s){
  var m={normal:['ok','正常缴费'],grace:['wait','待缴费（未逾期）'],overdue:['bad','已逾期未缴'],restricted:['bad','受限（账号停用或保证金不足）']}[s];
  if(!m)m=['mute',s||'—'];
  return '<span class="tag '+m[0]+'">'+E(m[1])+'</span>';
}

/* ---------------- ① 超管：代理表 + 费用与时间管理 ---------------- */
VIEWS.agentrentals=async function(){
  if(ME.role!=='super')return tip('仅超级管理员可用');
  var st=await api('/api/settings');
  if(!st.success)return tip(st.error);
  PC_CFG=st.config||{};
  var d=await api('/api/rental-board?status='+encodeURIComponent(AGF.status||'')+'&kw='+encodeURIComponent(AGF.kw||''));
  if(!d.success)return tip(d.error);
  RB=d;
  var s=d.summary||{};
  var h='<div class="grid">'
    +kpi('代理总数',s.agents||0)+kpi('正常缴费',s.normal||0)+kpi('宽限期内',s.grace||0)+kpi('已逾期',s.overdue||0)+kpi('受限',s.restricted||0)
    +kpi('本期应收(未缴)',money(s.periodUnpaidTotal||0)+' MMK')+kpi('本期已收',money(s.periodPaidTotal||0)+' MMK')
    +kpi('应缴保证金合计',money(s.depositRequiredTotal||0))+kpi('保证金缺口',money(s.depositGapTotal||0))
    +'</div>';

  h+='<div class="card"><div class="between"><h3>费用与时间管理（超管）</h3>'
    +'<span class="muted">当前计费期：'+E(d.period||'')+'（'+E(d.billingCycleText||'')+'）</span></div>'
    +'<p class="muted">下面的月租、保证金、费率与时间规则保存后立即生效，并驱动下方「代理表」的缴费状态与到期判定。</p>'
    +inputVal('rb_rent','月租（每期应收，MMK）',PC_CFG.rentalFeeMonthly,'number')
    +inputVal('rb_dep','默认应缴保证金（MMK）',PC_CFG.depositDefaultRequired,'number')
    +inputVal('rb_fee','出款手续费率（0.05 表示 5%）',PC_CFG.withdrawFeeRate)
    +inputVal('rb_settle','收货转款费率（0 表示不加收）',PC_CFG.settleFeeRate)
    +inputVal('rb_pfee','平台使用费率（0 表示暂不计提）',PC_CFG.platformFeeRate)
    +'<label>计费周期</label><select id="rb_cycle">'
    +'<option value="monthly"'+(PC_CFG.rentalBillingCycle==='monthly'?' selected':'')+'>自然月（每月一期）</option>'
    +'<option value="quarterly"'+(PC_CFG.rentalBillingCycle==='quarterly'?' selected':'')+'>自然季度（每季一期）</option>'
    +'<option value="yearly"'+(PC_CFG.rentalBillingCycle==='yearly'?' selected':'')+'>自然年（每年一期）</option>'
    +'</select>'
    +inputVal('rb_due','到期日（每期第几号截止缴费，1-28）',PC_CFG.rentalDueDay,'number')
    +inputVal('rb_grace','宽限期（天，到期后仍不计逾期）',PC_CFG.rentalGraceDays,'number')
    +'<label>逾期处置</label><select id="rb_overdue">'
    +'<option value="restrict"'+(PC_CFG.rentalOverdueAction==='restrict'?' selected':'')+'>逾期即限制该代理全部业务（推荐）</option>'
    +'<option value="remind"'+(PC_CFG.rentalOverdueAction==='remind'?' selected':'')+'>仅提醒不限制</option>'
    +'</select>'
    +'<div style="margin-top:12px">'+btn('保存费用与时间设置','saveFeeConfig()')+'</div></div>';

  var rows=(d.rows||[]).map(function(r){
    return {
      '代理账号':(r.name||r.username)+'（'+r.username+'）',
      aid:r.agentId,
      '状态':r.status,
      '本期月租':money(r.monthlyFee),
      '本期缴费':r.periodPaid?('<b style="color:#64ffda">已缴 '+money(r.periodAmount)+'</b>'):'<span class="muted">未缴</span>',
      '到期日':r.currentDueDate||'—',
      '宽限期':(r.graceDays||0)+' 天'+(r.periodPaid?'':'（至 '+(r.graceUntil||'—')+'）'),
      '已逾期':(r.overdueDays>0?('<b style="color:#ff6b6b">'+r.overdueDays+' 天</b>'):'—'),
      '应缴保证金':money(r.depositRequired),
      '已缴保证金':money(r.depositPaid),
      '保证金缺口':money(Math.max(0,(r.depositRequired||0)-(r.depositPaid||0))),
      '累计租用金':money(r.rentTotal)+'（'+r.rentCount+' 笔）',
      '操作':agentRowOps(r)
    };
  });
  var cols=['代理账号','状态','本期月租','本期缴费','到期日','宽限期','已逾期','应缴保证金','已缴保证金','保证金缺口','累计租用金','操作'];
  h+='<div class="card"><div class="between"><h3>代理表（代理 '+(s.agents||0)+' 个 · 命中 '+(d.filtered||0)+'）</h3>'
    +'<div class="row">'+btn('生成代理级账号','quickCreateAgent()')+btn('刷新','go(\\x27agentrentals\\x27)')+'</div></div>'
    +'<label>状态筛选</label><select id="af_status">'
    +'<option value="">全部状态</option><option value="normal">正常缴费</option><option value="grace">宽限期内</option><option value="overdue">已逾期</option><option value="restricted">受限</option>'
    +'</select>'
    +inputVal('af_kw','关键词（账号 / 名称 / 代理ID）',AGF.kw)
    +'<div style="margin-top:8px">'+btn('筛选','applyAgentFilter()')+'</div>'
    +table(cols,rows,agentRowFmt)+'</div>';
  h+='<div class="card"><h3>代理明细</h3><div id="agentdetail"><p class="muted">点击表格里的「明细」，查看该代理的租用金、保证金与扣罚记录。</p></div></div>';
  q('view').innerHTML=h;
  var sel=q('af_status');if(sel)sel.value=AGF.status||'';
};
function agentRowFmt(c,r){
  if(c==='状态')return agentStatusTag(r['状态']);
  if(c==='代理账号')return '<b>'+E(r['代理账号'])+'</b><br><span class="mono muted">'+E(r.aid)+'</span>';
  if(c==='本期缴费')return r['本期缴费'];
  if(c==='已逾期')return r['已逾期'];
  if(c==='操作')return r['操作'];
  return E(r[c]||'—');
}
function agentRowOps(r){
  var id=r.agentId;
  var h=btn('明细','viewAgent(\\x27'+id+'\\x27)')
    +btn('记租用金','quickRentalFor(\\x27'+id+'\\x27)')
    +btn('记保证金','quickDepositFor(\\x27'+id+'\\x27)')
    +btn('设应缴保证金','setDepositReq(\\x27'+id+'\\x27)');
  if(r.userStatus==='active')h+=btn('停用','disableUser(\\x27'+id+'\\x27)');
  return h;
}
function applyAgentFilter(){
  AGF.status=q('af_status')?q('af_status').value:'';
  AGF.kw=q('af_kw')?String(q('af_kw').value).trim():'';
  go('agentrentals');
}
async function saveFeeConfig(){
  var gv=function(id){return q(id)?String(q(id).value).trim():''};
  var iv=function(id){var v=parseInt(gv(id),10);return isNaN(v)?0:v};
  var fv=function(id){var v=parseFloat(gv(id));return isNaN(v)?0:v};
  var cur=PC_CFG||{};
  var patch={
    rentalFeeMonthly:gv('rb_rent')===''?cur.rentalFeeMonthly:iv('rb_rent'),
    depositDefaultRequired:gv('rb_dep')===''?cur.depositDefaultRequired:iv('rb_dep'),
    withdrawFeeRate:gv('rb_fee')===''?cur.withdrawFeeRate:fv('rb_fee'),
    settleFeeRate:gv('rb_settle')===''?cur.settleFeeRate:fv('rb_settle'),
    platformFeeRate:gv('rb_pfee')===''?cur.platformFeeRate:fv('rb_pfee'),
    rentalBillingCycle:gv('rb_cycle')||'monthly',
    rentalDueDay:gv('rb_due')===''?cur.rentalDueDay:iv('rb_due'),
    rentalGraceDays:gv('rb_grace')===''?cur.rentalGraceDays:iv('rb_grace'),
    rentalOverdueAction:gv('rb_overdue')||'restrict'
  };
  var d=await api('/api/settings','PUT',patch);
  if(!d.success)return tip(d.error);
  tip('费用与时间设置已保存，代理表已按新规则重算',true);
  go('agentrentals');
}
async function quickCreateAgent(){
  var username=prompt('代理登录账号（3-40 位小写字母 / 数字 / . _ -）','agent'+String(Date.now()).slice(-5));
  if(!username)return;
  var name=prompt('代理名称',username)||username;
  var password=prompt('初始密码（至少 6 位）','Kbz@123456')||'';
  if(!password)return;
  var defDep=parseInt(String((PC_CFG&&PC_CFG.depositDefaultRequired)||0),10)||0;
  var depRaw=prompt('该代理应缴保证金（MMK；留空则采用默认 '+money(defDep)+'）','');
  var body={role:'agent',username:username,name:name,password:password};
  if(depRaw!==null&&String(depRaw).trim()!=='')body.depositRequired=parseInt(String(depRaw),10)||0;
  var d=await api('/api/accounts','POST',body);
  if(!d.success)return tip(d.error);
  var a=d.account||{};
  alert('代理级账号已生成\\n\\n登录账号：'+username+'\\n代理ID：'+a.id+'\\n应缴保证金：'+money(a.depositRequired||0)+' MMK\\n初始密码：'+password+'\\n\\n请把账号口令交给该代理。该代理登录后可在「收付款设置」一键替换自己的收款 / 付款账户，并按期向超管资金池缴纳月租与保证金。');
  go('agentrentals');
}
async function quickRentalFor(id){
  var v=parseInt(prompt('记录租用金到账（MMK）','200000')||'0',10);
  if(!v)return;
  var p=prompt('所属周期（如 '+(RB.period||'2026-10')+'）',RB.period||'')||'';
  var d=await api('/api/pool/rental','POST',{agentId:id,amount:v,period:p});
  after(d.success?'租用金已入池，该代理本期缴费状态已刷新':d.error);
}
async function quickDepositFor(id){
  var v=parseInt(prompt('记录保证金到账（MMK）','1000000')||'0',10);
  if(!v)return;
  var d=await api('/api/pool/deposit','POST',{agentId:id,amount:v});
  after(d.success?'保证金已入池':d.error);
}
async function quickRefundFor(id){
  var v=parseInt(prompt('退还保证金（MMK）','')||'0',10);
  if(!v)return;
  if(!confirm('确认退还 '+money(v)+' MMK 保证金？'))return;
  var d=await api('/api/pool/deposit/refund','POST',{agentId:id,amount:v});
  after(d.success?'已退还':d.error);
}
async function viewAgent(id){
  var box=q('agentdetail');
  if(box)box.innerHTML='<p class="muted">加载中…</p>';
  var acc=await api('/api/accounts');
  var u={};
  (acc&&acc.accounts||[]).forEach(function(a){if(a.id===id)u=a});
  var rt=await api('/api/rentals?agentId='+encodeURIComponent(id));
  var pn=await api('/api/penalties?agentId='+encodeURIComponent(id));
  var dep=u.deposit||{};
  var h='<div class="between"><h3>'+E(u.name||u.username||id)+'（'+E(u.username||'')+'）</h3>'+btn('关闭','closeAgentDetail()')+'</div>';
  h+='<div class="grid">'+kpi('账号状态',u.status==='active'?'正常':'已停用')
    +kpi('可用余额',money((u.stats&&u.stats.balance)||0)+' MMK')
    +kpi('已缴保证金',money(dep.paid||0))+kpi('应缴保证金',money(dep.required||0))+kpi('已扣罚',money(dep.penalty||0))+'</div>';
  h+='<h3>租用金缴纳记录</h3>'+table(['租用单','周期','金额','状态','记录时间'],(rt&&rt.rentals||[]).map(function(r){
    return {'租用单':r.id,'周期':r.period||'','金额':money(r.amount),'状态':r.status,'记录时间':r.createdAt?String(r.createdAt).slice(0,19).replace('T',' '):''};
  }),function(c,r){
    if(c==='状态')return tag(r['状态']);
    if(c==='金额')return '<b>'+r['金额']+'</b>';
    if(c==='租用单')return '<span class="mono">'+E(r['租用单'])+'</span>';
    return E(r[c]||'—');
  });
  h+='<h3>扣罚记录</h3>'+table(['扣罚单','金额','原因','状态'],(pn&&pn.penalties||[]).map(function(p){
    return {'扣罚单':p.id,'金额':money(p.amount),'原因':p.reason||'','状态':p.status};
  }),function(c,r){
    if(c==='状态')return tag(r['状态']);
    if(c==='金额')return '<b>'+r['金额']+'</b>';
    return E(r[c]||'—');
  });
  h+='<div class="row" style="margin-top:10px">'+btn('记租用金','quickRentalFor(\\x27'+id+'\\x27)')+btn('记保证金','quickDepositFor(\\x27'+id+'\\x27)')+btn('设应缴保证金','setDepositReq(\\x27'+id+'\\x27)')+btn('退还保证金','quickRefundFor(\\x27'+id+'\\x27)')+'</div>';
  if(box)box.innerHTML=h;
}
function closeAgentDetail(){var b=q('agentdetail');if(b)b.innerHTML='<p class="muted">已关闭。</p>'}

/* ---------------- ② 游戏上分 / 下分（游戏充值ID 闭环） ---------------- */
VIEWS.gamepoints=async function(){
  var qs='?status='+encodeURIComponent(GPF.status||'')+'&direction='+encodeURIComponent(GPF.direction||'')+'&limit=200';
  var d=await api('/api/game/orders'+qs);
  if(!d.success)return tip(d.error);
  var gg=await api('/api/game/ids');
  var orders=d.orders||[];
  var ids=(gg&&gg.gameIds)||[];
  var h='<div class="grid">'
    +kpi('游戏充值ID',ids.length)+kpi('待执行',countBy(orders,'status','queued'))+kpi('执行中',countBy(orders,'status','claimed'))
    +kpi('已成功',countBy(orders,'status','done'))+kpi('上分单',countBy(orders,'direction','in'))+kpi('下分单',countBy(orders,'direction','out'))
    +'</div>';
  h+='<div class="card"><div class="between"><h3>游戏上分 / 下分指令单（'+orders.length+'）</h3>'
    +'<div class="row">'+btn('登记游戏充值ID','quickGameId()')+btn('新建指令单','quickGameOrder()')+btn('刷新','go(\\x27gamepoints\\x27)')+'</div></div>'
    +'<p class="muted">上分（in）= 给游戏充值ID加币、资金入账；下分（out）= 从游戏充值ID扣币、资金出账。<b>下分在创建时即冻结等额余额</b>，执行端回执成功才实际出账；回执失败或取消会自动回补冻结。执行端用 <code>GET /api/game/executor/pull</code>（请求头 X-Device-Key）拉任务，完成后回执 <code>POST /api/game/executor/receipt</code>。</p>'
    +'<label>方向筛选</label><select id="gp_dir"><option value="">全部方向</option><option value="in">上分（加币）</option><option value="out">下分（扣币）</option></select>'
    +'<label>状态筛选</label><select id="gp_st"><option value="">全部状态</option><option value="queued">待执行</option><option value="claimed">执行中</option><option value="done">已成功</option><option value="failed">已失败</option><option value="canceled">已取消</option><option value="rolledback">已回滚</option></select>'
    +'<div style="margin-top:8px">'+btn('筛选','applyGameFilter()')+'</div>'
    +table(['指令单','游戏ID','方向','金额','状态','执行端','回执流水','创建时间','操作'],orders.map(function(o){
      return {
        '指令单':o.orderId,'游戏ID':o.gameId,'方向':o.directionText||o.direction,'金额':money(o.amount),
        '状态':o.status,'状态文本':o.statusText||o.status,'执行端':o.claimedBy||'','回执流水':o.executorTxid||'',
        '创建时间':o.createdAt?String(o.createdAt).slice(0,19).replace('T',' '):'','操作':gameRowOps(o)
      };
    }),gameRowFmt)+'</div>';
  h+='<div class="card"><h3>游戏充值ID台账（'+ids.length+'）</h3>'
    +table(['游戏ID','名称','区服','角色','平台','净发币额','累计上分','累计下分','最近更新'],ids.map(function(g){
      return {'游戏ID':g.gameId,'名称':g.label||'','区服':g.gameZone||'','角色':g.gameRole||'','平台':g.platform||'',
        '净发币额':money(g.credit),'累计上分':money(g.topupTotal),'累计下分':money(g.creditTotal),
        '最近更新':g.updatedAt?String(g.updatedAt).slice(0,19).replace('T',' '):''};
    }),function(c,r){
      if(c==='游戏ID')return '<b class="mono">'+E(r['游戏ID'])+'</b>';
      if(c==='净发币额')return '<b>'+r['净发币额']+'</b>';
      return E(r[c]||'—');
    })+'</div>';
  q('view').innerHTML=h;
  var s1=q('gp_dir');if(s1)s1.value=GPF.direction||'';
  var s2=q('gp_st');if(s2)s2.value=GPF.status||'';
};
function gameRowFmt(c,r){
  if(c==='状态')return gameStatusTag(r['状态'],r['状态文本']);
  if(c==='指令单')return '<span class="mono">'+E(r['指令单'])+'</span>';
  if(c==='金额')return '<b>'+r['金额']+'</b>';
  if(c==='执行端')return r['执行端']?'<span class="mono">'+E(r['执行端'])+'</span>':'<span class="muted">—</span>';
  if(c==='回执流水')return r['回执流水']?'<span class="mono">'+E(r['回执流水'])+'</span>':'<span class="muted">—</span>';
  if(c==='操作')return r['操作'];
  return E(r[c]||'—');
}
function gameStatusTag(s,t){
  var m={queued:'wait',claimed:'wait',done:'ok',failed:'bad',canceled:'mute',rolledback:'mute'}[s]||'mute';
  return '<span class="tag '+m+'">'+E(t||s||'—')+'</span>';
}
function gameRowOps(o){
  var id=o.orderId;
  var h='';
  if(o.status==='queued'||o.status==='claimed')h+=btn('取消','cancelGame(\\x27'+id+'\\x27)');
  if(o.status==='done'&&!o.rolledBack)h+=btn('回滚','rollbackGame(\\x27'+id+'\\x27)');
  return h||'<span class="muted">—</span>';
}
function applyGameFilter(){
  GPF.direction=q('gp_dir')?q('gp_dir').value:'';
  GPF.status=q('gp_st')?q('gp_st').value:'';
  go('gamepoints');
}
async function quickGameId(){
  var gameId=prompt('游戏充值ID（玩家账号）','');
  if(!gameId)return;
  var label=prompt('名称（可留空）',gameId)||gameId;
  var zone=prompt('区服（可留空）','')||'';
  var role=prompt('角色名（可留空）','')||'';
  var platform=prompt('游戏平台（可留空）','')||'';
  var d=await api('/api/game/ids','POST',{gameId:gameId,label:label,gameZone:zone,gameRole:role,platform:platform});
  after(d.success?('游戏充值ID已登记：'+((d.gameId&&d.gameId.gameId)||gameId)):d.error);
}
async function quickGameOrder(){
  var direction=prompt('方向：in = 上分（给玩家加币） / out = 下分（从玩家扣币）','in')||'in';
  direction=String(direction).trim().toLowerCase();
  if(direction!=='in'&&direction!=='out')return tip('方向只能是 in 或 out');
  var gameId=prompt('游戏充值ID（玩家账号）','');
  if(!gameId)return;
  var amount=parseInt(prompt('金额（MMK）','10000')||'0',10);
  if(!amount)return;
  var zone=prompt('区服（可留空）','')||'';
  var role=prompt('角色名（可留空）','')||'';
  var ext=prompt('外部订单号（可留空）','')||'';
  var note=prompt('备注（可留空）','')||'';
  var d=await api('/api/game/orders','POST',{direction:direction,gameId:gameId,amount:amount,gameZone:zone,gameRole:role,externalOrderNo:ext,note:note});
  if(!d.success){tip(d.error);return}
  var o=d.order||{};
  alert('指令单已创建\\n\\n指令单：'+o.orderId+'\\n方向：'+(o.directionText||'')+'\\n游戏充值ID：'+gameId+'\\n金额：'+money(o.amount)+' '+(o.currency||'MMK')+'\\n状态：'+(o.statusText||'')+'\\n\\n执行端拉取处理后回执，即完成记账。');
  go('gamepoints');
}
async function cancelGame(id){
  var r=prompt('取消原因','用户撤销')||'取消';
  if(!confirm('确认取消该指令单？（下分冻结额将自动释放）'))return;
  var d=await api('/api/game/orders/'+id+'/cancel','POST',{reason:r});
  after(d.success?'已取消并释放冻结':d.error);
}
async function rollbackGame(id){
  if(!confirm('确认回滚该指令单？回滚会撤销已完成的记账与发币变化，且不可再恢复。'))return;
  var r=prompt('回滚原因','纠错回滚')||'回滚';
  var d=await api('/api/game/orders/'+id+'/rollback','POST',{reason:r});
  after(d.success?'已回滚':d.error);
}

/* ---------------- ③ 多平台无文档一键接入向导（即插即用） ---------------- */
VIEWS.pluguide=async function(){
  var t=await api('/api/plug/templates');
  var pts=await api('/api/plug/points');
  var codes=await api('/api/plug/codes');
  var tpls=((t&&t.templates)||[]);
  var list=((pts&&pts.points)||[]);
  PL_POINTS=list;
  var cd=((codes&&codes.codes)||[]);
  var origin=location.origin;
  var h='<div class="card"><div class="between"><h3>多平台无文档一键接入向导</h3>'
    +'<span class="muted">即插即用 · 不需要对方提供任何 API 文档</span></div>'
    +'<p class="muted">三步完成接入：<b>① 选模板</b>（或用「纯手工模式」）→ <b>② 粘贴一段你抓到的下单 / 回调报文</b>（原样贴，字段名不用改，JSON、表单、查询串都行）→ <b>③ 点「一键智能解析」看识别结果，再点「一键生成接入点」</b>，即刻得到该平台专属的接入密钥与端点。把端点与密钥填进你的平台即可收单、发货、结算。</p>'
    +'<label>接入模板</label><select id="pl_tpl">'+tpls.map(function(x){return '<option value="'+E(x.id)+'">'+E((x.name&&x.name.zh)||x.id)+'</option>'}).join('')+'</select>'
    +inputVal('pl_name','平台名称（自定义，便于识别）','')
    +inputVal('pl_platform','平台标识（英文 / 数字，可留空）','')
    +inputVal('pl_target','对方到账回调地址（http/https，可留空，之后可在测试里补）','')
    +'<label>抓包报文（把一次真实下单请求的 body / query 原样粘贴进来）</label>'
    +'<textarea id="pl_cap" rows="5" placeholder="示例：{out_trade_no: T20261023001, money: 10000, playerAccount: gamer001, serverId: s1}"></textarea>'
    +'<div class="row" style="margin-top:10px">'+btn('一键智能解析','plugParse()')+btn('一键生成接入点','plugCreate()')+'</div>'
    +'<div id="pl_result"></div></div>';

  h+='<div class="card"><div class="between"><h3>我的接入点（'+list.length+'）</h3>'
    +'<div class="row">'+btn('刷新','go(\\x27pluguide\\x27)')+'</div></div>'
    +'<p class="muted">每个接入点都有独立的接入密钥（plugKey）与订单端点。密钥只在生成 / 轮换时明文显示一次，其余时间一律脱敏。</p>'
    +table(['接入点','名称','模式','订单端点','密钥','回调地址','接入画像','操作'],list.map(function(p){
      var ep=p.endpoints||{};
      return {'接入点':p.adapterId,'名称':p.name||'','模式':p.mode||'api','订单端点':ep.orderUrl||p.endpoint||'—',
        '密钥':p.keyMasked||'（未设置，请点轮换密钥）','回调地址':p.callbackUrl||'—',
        '接入画像':p.templateId?('向导生成 · '+p.templateId):'普通适配器','操作':plugOps(p)};
    }),function(c,r){
      if(c==='接入点')return '<span class="mono">'+E(r['接入点'])+'</span>';
      if(c==='订单端点')return '<span class="mono">'+E(r['订单端点'])+'</span>';
      if(c==='密钥')return '<span class="mono">'+E(r['密钥'])+'</span>';
      if(c==='回调地址')return '<span class="mono">'+E(r['回调地址'])+'</span>';
      if(c==='操作')return r['操作'];
      return E(r[c]||'—');
    })+'</div>';

  h+='<div class="card"><div class="between"><h3>一键配对码（'+cd.length+'）</h3>'
    +'<div class="row">'+btn('生成配对码','newPairCode()')+'</div></div>'
    +'<p class="muted">把「本系统地址 + 配对码」交给对方平台，对方在自助接入页 <a href="'+E(origin)+'/plug" target="_blank">/plug</a> 填入一次即完成绑定（无需注册）。配对码 30 分钟内有效，可随时作废。</p>'
    +table(['配对码','备注','状态','绑定接入点','创建时间','过期时间','操作'],cd.map(function(c0){
      return {'配对码':c0.code,'备注':c0.label||'','状态':c0.status,'绑定接入点':c0.adapterId||'—',
        '创建时间':c0.createdAt?String(c0.createdAt).slice(0,19).replace('T',' '):'',
        '过期时间':c0.expiresAt?String(c0.expiresAt).slice(0,19).replace('T',' '):'',
        '操作':c0.status==='active'?btn('作废','plugRevokeCode(\\x27'+c0.code+'\\x27)'):'<span class="muted">—</span>'};
    }),function(c,r){
      if(c==='状态')return tag(r['状态']);
      if(c==='配对码')return '<b class="mono">'+E(r['配对码'])+'</b>';
      if(c==='操作')return r['操作'];
      return E(r[c]||'—');
    })+'</div>';

  h+='<div class="card"><h3>开箱即用（像 U 盘一样插上就能用）</h3>'
    +'<p class="muted">对方平台只需下面任意一行，无需任何文档：</p>'
    +'<div class="copybox"><span class="txt">&lt;script src="'+E(origin)+'/kbz-plug.js"&gt;&lt;/script&gt;</span>'+btn('复制','copyStr(\\x27'+origin+'/kbz-plug.js\\x27)')+'</div>'
    +'<div class="copybox"><span class="txt">'+E(origin)+'/.well-known/kbz-connect.json</span>'+btn('复制','copyStr(\\x27'+origin+'/.well-known/kbz-connect.json\\x27)')+'</div>'
    +'<p class="muted">自助接入页：<a href="'+E(origin)+'/plug" target="_blank">/plug</a>　·　连接器清单：<a href="'+E(origin)+'/api/plug/manifest" target="_blank">/api/plug/manifest</a></p></div>';
  q('view').innerHTML=h;
};
function plugOps(p){
  var id=p.adapterId;
  return btn('测试连通','plugTest(\\x27'+id+'\\x27)')+btn('轮换密钥','plugRotate(\\x27'+id+'\\x27)')+btn('接入说明','plugExplain(\\x27'+id+'\\x27)');
}
function plugExplain(aid){
  var p=null;
  PL_POINTS.forEach(function(x){if(x&&x.adapterId===aid)p=x});
  if(!p)return tip('未找到该接入点，请先刷新页面');
  var ep=p.endpoints||{};
  var rows=[
    {'项目':'接入点ID','说明':p.adapterId},
    {'项目':'接入密钥','说明':p.keyMasked||'（未设置，请点「轮换密钥」生成）'},
    {'项目':'密钥请求头','说明':'X-Plug-Key: 你的接入密钥（也可用查询串 k=密钥）'},
    {'项目':'下单端点','说明':ep.orderUrl||p.endpoint||'—'},
    {'项目':'状态查询端点','说明':ep.infoUrl||'—'},
    {'项目':'任务拉取端点','说明':ep.pullUrl||'—'},
    {'项目':'回调推送端点','说明':ep.notifyUrl||'—'},
    {'项目':'签名规则','说明':p.signRule||'HMAC-SHA256(plugKey, 原始请求体) 放在请求头 X-Signature'},
    {'项目':'回调解析','说明':p.callbackParse||'json'},
    {'项目':'接入模式','说明':p.mode||'api'},
    {'项目':'平台标识','说明':p.platform||'—'}
  ];
  var box=q('pl_result');
  var h='<h3>接入说明 · '+E(p.name||aid)+'</h3>'
    +'<p class="muted">把下面的端点与密钥填进你的平台即可完成接入。字段名不必对齐：orderNo / money / total_fee / 金额… 会被自动识别；完全没有文档时，直接把抓包报文贴回上面重新解析一次即可。</p>'
    +table(['项目','说明'],rows);
  if(box)box.innerHTML=h;
}
async function plugParse(){
  var cap=q('pl_cap')?String(q('pl_cap').value):'';
  if(!cap.trim())return tip('请先粘贴一段抓包报文');
  var box=q('pl_result');
  if(box)box.innerHTML='<p class="muted">正在解析…</p>';
  var d=await api('/api/plug/parse','POST',{captured:cap,templateId:(q('pl_tpl')?q('pl_tpl').value:'')});
  if(!box)return;
  if(!d.success){box.innerHTML='<div class="alert">'+E(d.error)+'</div>';return}
  var rows=[];
  Object.keys(d.mapped||{}).forEach(function(k){rows.push({'系统字段':k,'取自报文':String(d.mapped[k])})});
  if(!rows.length)rows.push({'系统字段':'（未识别出字段）','取自报文':'—'});
  var h='<h3>解析结果（置信度 '+E(String(d.confidence||0))+'）</h3>'
    +'<p class="muted">场景判定：'+E(d.scene||'manual')+' · 建议动作：'+E(d.action||'order')+' · 识别金额：'+E(String(d.amount||0))+' MMK（原始：'+E(d.amountRaw||'—')+'）</p>'
    +table(['系统字段','取自报文'],rows);
  if(d.missing&&d.missing.length)h+='<div class="alert">仍需补齐：'+E(d.missing.join('、'))+'</div>';
  if(d.suggestion)h+='<p class="muted">'+E(d.suggestion)+'</p>';
  box.innerHTML=h;
}
async function plugCreate(){
  var tpl=q('pl_tpl')?q('pl_tpl').value:'';
  var name=(q('pl_name')?String(q('pl_name').value).trim():'')||'新接入平台';
  var platform=q('pl_platform')?String(q('pl_platform').value).trim():'';
  var target=q('pl_target')?String(q('pl_target').value).trim():'';
  var cap=q('pl_cap')?String(q('pl_cap').value).trim():'';
  var body={templateId:tpl,name:name,platform:platform};
  if(target)body.targetUrl=target;
  if(cap)body.captured=cap;
  var d=await api('/api/plug/adapters','POST',body);
  if(!d.success)return tip(d.error);
  var ep=d.endpoints||{};
  alert('接入点已生成\\n\\n接入点ID：'+((d.adapter&&d.adapter.id)||'')+'\\n接入密钥（只显示一次，请立即保存）：\\n'+d.plugKey+'\\n\\n下单端点：\\n'+(ep.orderUrl||'')+'\\n\\n填进对方平台的请求头：X-Plug-Key: '+d.plugKey);
  go('pluguide');
}
async function newPairCode(){
  var label=prompt('配对码备注（可留空）','')||'';
  var d=await api('/api/plug/codes','POST',{label:label});
  if(!d.success)return tip(d.error);
  var c=d.code||{};
  alert('配对码已生成\\n\\n配对码：'+c.code+'\\n有效期至：'+(c.expiresAt?String(c.expiresAt).slice(0,19).replace('T',' '):'')+'\\n\\n把「本系统地址 + 配对码」交给对方平台，在其自助接入页填入即可完成绑定。');
  go('pluguide');
}
async function plugRevokeCode(code){
  if(!confirm('确认作废该配对码？'))return;
  var d=await api('/api/plug/codes/'+encodeURIComponent(code)+'/revoke','POST',{});
  after(d.success?'已作废':d.error);
}
async function plugRotate(aid){
  if(!confirm('轮换后旧密钥立即失效，需同步更新对方平台。确认继续？'))return;
  var d=await api('/api/plug/adapters/'+aid+'/rotate','POST',{});
  if(!d.success)return tip(d.error);
  alert('新的接入密钥（只显示一次）：\\n\\n'+d.plugKey+'\\n\\n请立即更新到对方平台。');
  go('pluguide');
}
async function plugTest(aid){
  var box=q('pl_result');
  if(box)box.innerHTML='<p class="muted">正在探测目标地址…</p>';
  var d=await api('/api/plug/adapters/'+aid+'/test','POST',{});
  if(!d.success)return tip(d.error);
  var rows=(d.tests||[]).map(function(t){return {'检查项':t.name,'结果':t.ok?'通过':'未通过','详情':t.detail||''}});
  var h='<h3>连通测试 · '+E(d.name||aid)+'（'+(d.ok?'全部通过':('未通过 '+(d.failedCount||0)+' 项'))+'）</h3>'
    +'<p class="muted">'+E(d.conclusion||'')+'</p>'
    +table(['检查项','结果','详情'],rows,function(c,r){
      if(c==='结果')return '<span class="tag '+(r['结果']==='通过'?'ok':'bad')+'">'+E(r['结果'])+'</span>';
      return E(r[c]||'—');
    });
  if(box)box.innerHTML=h;
}

/* ---------------- ④ 超管：维护与对账（定时任务 + 未匹配流水人工核销） ---------------- */
var MTF={status:''};
VIEWS.maintenance=async function(){
  if(ME.role!=='super')return tip('仅超级管理员可用');
  var d=await api('/api/maintenance/status');
  if(!d.success)return tip(d.error);
  var o=d.orders||{},w=d.webhooks||{},u=d.unmatchedFlows||{},r=d.rentals||{};
  var h='<div class="grid">'
    +kpi('在途待支付订单',o.pending||0)+kpi('已过期待关闭',o.expiredWaitingSweep||0)
    +kpi('托管待收货',o.awaitingReceive||0)+kpi('到点应收货',o.autoReceiveDue||0)
    +kpi('今日已转款到户',o.settledToday||0)+kpi('待重试回调',w.pending||0)
    +kpi('到点回调',w.due||0)+kpi('未匹配流水(待人工核销)',u.open||0)
    +'</div>';
  h+='<div class="card"><div class="between"><h3>维护任务（与定时任务同源，超管可手动立即执行）</h3>'
    +'<div class="row">'+btn('立即执行一次','runMaintenanceNow()')+btn('刷新','go(\\x27maintenance\\x27)')+'</div></div>'
    +'<p class="muted">'+E(d.nextCronHint||'')+'</p>'
    +'<p class="muted">执行内容：① 超时订单自动关闭并释放金额识别码 ② 到期托管订单自动收货并转款到户 ③ 到点回调重试。三项均幂等，可安全重复执行。</p>'
    +'<div id="mt_runlog"></div></div>';

  var um=await api('/api/reconcile/unmatched?status='+encodeURIComponent(MTF.status||''));
  var rows=((um&&um.rows)||[]).map(function(x){
    return {
      rid:x.id,
      '流水号':'<span class="mono">'+E(String(x.id||'').slice(0,10))+'…</span>',
      '交易号':E(x.txnId||'—'),
      '收款账号':E(x.account||'—'),
      '金额':money(x.amount)+' MMK',
      '到账时间':E(x.time||'—'),
      '来源':E(x.source||'—'),
      '重复上报':String(x.seenCount||1)+' 次',
      '状态':mtStatusTag(x.status),
      '说明':E(x.reason||'—'),
      '操作':mtRowOps(x)
    };
  });
  var cols=['流水号','交易号','收款账号','金额','到账时间','来源','重复上报','状态','说明','操作'];
  h+='<div class="card"><div class="between"><h3>对账未匹配流水（待人工核销 '+(um&&um.count||0)+' 笔）</h3></div>'
    +'<p class="muted">银行到账但系统未自动匹配到待支付订单的流水会集中在此。核销时请把银行流水号作为交易号填入，系统会把该笔款项落到指定订单（超管专属，操作留审计）。</p>'
    +'<label>状态筛选</label><select id="mt_status">'
    +'<option value="">全部</option><option value="open">待核销</option><option value="matched">已核销</option><option value="auto-closed">已自动销账</option>'
    +'</select>'
    +'<div style="margin-top:8px">'+btn('筛选','applyMtFilter()')+'</div>'
    +table(cols,rows,function(c,rr){return c==='状态'||c==='操作'?rr[c]:rr[c]})+'</div>';
  q('view').innerHTML=h;
  var sel=q('mt_status');if(sel)sel.value=MTF.status||'';
};
function mtStatusTag(s){
  var m={open:['wait','待核销'],matched:['ok','已核销'],'auto-closed':['mute','已自动销账']}[s];
  if(!m)m=['mute',s||'—'];
  return '<span class="tag '+m[0]+'">'+E(m[1])+'</span>';
}
function mtRowOps(x){
  if(x.status!=='open')return '<span class="muted">'+(x.matchedOrderId?('已落单 '+E(x.matchedOrderId)):'—')+'</span>';
  return btn('核销','matchUnmatchedRow(\\x27'+x.id+'\\x27)');
}
function applyMtFilter(){MTF.status=q('mt_status')?q('mt_status').value:'';go('maintenance')}
async function runMaintenanceNow(){
  var box=q('mt_runlog');
  if(box)box.innerHTML='<p class="muted">正在执行维护任务…</p>';
  var d=await api('/api/maintenance/run','POST',{limit:500});
  if(!d.success){if(box)box.innerHTML='<div class="alert">'+E(d.error)+'</div>';return tip(d.error)}
  var h='<h3>本次执行结果（耗时 '+E(String(d.elapsedMs||0))+' ms · '+E(String(d.at||'').slice(0,19).replace('T',' '))+'）</h3>'
    +table(['任务','结果'],mtTaskRows(d.tasks||{}));
  if(box)box.innerHTML=h;
}
function mtTaskRows(t){
  var rows=[];
  function line(name,v){
    if(!v)return;
    if(v.error){rows.push({'任务':name,'结果':'失败：'+v.error});return}
    var parts=[];
    Object.keys(v).forEach(function(k){parts.push(k+'='+v[k])});
    rows.push({'任务':name,'结果':parts.join(' · ')});
  }
  line('超时订单自动关闭',t.expireOrders);
  line('到期自动收货转款',t.autoReceive);
  line('回调重试',t.webhooks);
  if(!rows.length)rows.push({'任务':'（无任务结果）','结果':'—'});
  return rows;
}
async function matchUnmatchedRow(id){
  var oid=prompt('要核销到哪张订单？（可留空：按金额自动匹配该金额下的待支付订单）','')||'';
  var txid=prompt('银行流水号 / 交易号（至少 5 位数字，作为核销凭据）','')||'';
  if(!txid.trim())return tip('未填写交易号，已取消核销');
  var body={txid:txid.trim()};
  if(oid.trim())body.orderId=oid.trim();
  var d=await api('/api/reconcile/'+encodeURIComponent(id)+'/match','POST',body);
  if(!d.success)return tip(d.error);
  alert('核销成功\\n未匹配流水：'+id+'\\n已落到订单：'+((d.order&&d.order.id)||'—'));
  go('maintenance');
}

/* ---------------- ⑤ 安全会话（会话可见可撤 + 审计链验真） ---------------- */
var SECU={uid:'',rows:[],chain:''};
VIEWS.security=async function(){
  var path='/api/security/sessions'+(ME.role==='super'&&SECU.uid?('?userId='+encodeURIComponent(SECU.uid)):'');
  var d=await api(path);
  if(!d.success)return tip(d.error);
  SECU.rows=d.sessions||[];
  var h='<div class="card"><div class="between"><h3>在线会话（'+SECU.rows.length+' 个）</h3>'
    +'<div class="row">'+btn('刷新','go(\\x27security\\x27)')+btn('撤销其他全部会话','revokeOtherSessions()')+'</div></div>'
    +'<p class="muted">每次登录生成一个会话令牌，活跃访问会自动续期；发现异常登录可在此立即撤销。'
    +'后台只保留来源地址的哈希，不留存明文 IP。</p>';
  if(ME.role==='super')h+='<div class="row"><input id="sec_uid" placeholder="查看指定账号的会话（填账号 ID；留空=本人）" value="'+E(SECU.uid)+'">'
    +btn('查询该账号','secLoadUser()')+'</div>';
  var rows=SECU.rows.map(function(s,i){
    return {
      '会话':E(s.tokenMasked||'—')+(s.isCurrent?' <span class="tag ok">当前</span>':''),
      '建立时间':E(String(s.createdAt||'').slice(0,19).replace('T',' ')),
      '最近活动':E(String(s.lastSeenAt||'').slice(0,19).replace('T',' ')),
      '来源':E(String(s.ua||'').slice(0,44)||'—'),
      'IP哈希':E(String(s.ipHash||'').slice(0,12)||'—'),
      '操作':s.token?btn('撤销','revokeSessionRow('+i+')'):'<span class="muted">不可撤销</span>'
    };
  });
  h+=table(['会话','建立时间','最近活动','来源','IP哈希','操作'],rows);
  if(ME.role==='super'){
    h+='<div class="card"><div class="between"><h3>审计链验真</h3>'
      +'<div class="row">'+btn('立即验真','verifyChainNow()')+'</div></div>'
      +'<p class="muted">审计记录逐条写入「序号 + 上一条哈希 + 本条哈希」，任何删除或改动都会在验真时暴露；'
      +'历史记录（升级前写入、不含哈希）会自动跳过并单独计数。</p><div id="sec_chain">'+SECU.chain+'</div></div>';
  }
  q('view').innerHTML=h;
};
function secLoadUser(){SECU.uid=q('sec_uid')?String(q('sec_uid').value).trim():'';go('security')}
async function revokeSessionRow(i){
  var s=SECU.rows[i];
  if(!s||!s.token)return tip('该会话暂不可撤销');
  if(s.isCurrent&&!confirm('这是你当前正在使用的会话，撤销后需要重新登录。确定继续？'))return;
  var d=await api('/api/security/sessions/revoke','POST',{token:s.token});
  if(!d.success)return tip(d.error);
  if(s.isCurrent){localStorage.removeItem('kbz_token');T='';return location.reload()}
  tip('会话已撤销',true);go('security');
}
async function revokeOtherSessions(){
  var list=(SECU.rows||[]).filter(function(s){return s.token&&!s.isCurrent});
  if(!list.length)return tip('除当前会话外没有其他会话');
  if(!confirm('将撤销除当前会话外的 '+list.length+' 个会话，确定继续？'))return;
  var n=0,i=0;
  for(i=0;i<list.length;i++){var d=await api('/api/security/sessions/revoke','POST',{token:list[i].token});if(d.success)n++}
  tip('已撤销 '+n+' 个会话',true);go('security');
}
async function verifyChainNow(){
  var box=q('sec_chain');
  if(box)box.innerHTML='<p class="muted">正在验真…</p>';
  var d=await api('/api/audit/verify');
  if(!d.success){if(box)box.innerHTML='<div class="alert">'+E(d.error)+'</div>';return}
  var rows=[
    {'项目':'校验结论','说明':d.ok?'<span class="tag ok">链路完整，未被篡改</span>':'<span class="tag bad">发现异常，请立即核查</span>'},
    {'项目':'已校验记录','说明':E(String(d.checked||0))+' 条'},
    {'项目':'历史记录（不计入链）','说明':E(String(d.legacySkipped||0))+' 条'},
    {'项目':'异常记录','说明':E(String(d.bad||0))+' 条'},
    {'项目':'首个异常位置','说明':d.firstBad?('seq '+E(String(d.firstBad.seq||''))+' · '+E(String(d.firstBad.reason||''))):'—'}
  ];
  SECU.chain=table(['项目','说明'],rows);
  if(box)box.innerHTML=SECU.chain;
}
`