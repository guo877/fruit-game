/* =============================================================================
 * 业务引擎（engine.js）
 * -----------------------------------------------------------------------------
 * 职责：收款引擎（金额识别码 + 自动匹配核销）/ 出款引擎（额度内自动 + 审批闸门）
 *       平台适配器与回调重试 / 设备（通知转发端·出款执行端）注册 / 资金池业务动作
 * 说明：所有入账/出账动作均写入不可变账本，金额相关状态变更只允许一次。
 * ========================================================================== */

import { toInt, safeStr, makeId, nowIso, maskAccount, maskPhone, hashInt, randomToken, kvGet, kvPut, kvDel, kvList, sha256hex, hmacHex, timingSafeEqual, withLock, getConfig, publicConfig, getUser, listUsers, publicUser, isDescendantOf, visibleOwnerIds, canAccessOwner, ledgerAppend, ledgerVerify, getStats, bumpStats, balancesOf, listChannels, createChannel, replaceChannel, resolveChannelByAccount, pickChannel, getPool, setPool, poolLedgerAppend, poolLedgerList, getDeposit, setDeposit, depositSufficient, listDeposits, addAudit, listAudit, httpError, assertSuper, encryptField, decryptField, stripSensitive, headerOf, guardReplay, pickPayAccount, normFlow } from './core.js'

/** 平台层级账户 id：超管层级的平台账户，收入来源为各代理分级账户缴纳的使用费与保证金收款归集 */
export const PLATFORM_ID = 'platform'

/* ============================== 订单（收款单） ============================== */
const SCENES = ['ecommerce', 'game', 'deposit', 'rental', 'manual']
const DELIVERY_TYPES = ['card', 'logistics', 'game', 'manual', 'none']

/** 是否进入托管（收货后才转款到户）：电商与游戏类订单 */
export function isEscrowScene(scene) {
  return scene === 'ecommerce' || scene === 'game'
}

/**
 * 解析创建订单时携带的发货要素（无文档接入：平台把自己知道的都传进来即可）
 * 支持三种写法：
 *   delivery:{type:'card', cardSecret:'...'}      卡密类（电商虚拟商品 / 游戏点卡）
 *   delivery:{type:'logistics', trackingNo:'...'} 物流类（实物电商）
 *   delivery:{type:'game', auto:true}             游戏类（凭订单里的游戏账号映射发币）
 * 兼容扁平写法：cardSecret / trackingNo / carrier / note / gameAccount / itemCode
 */
export async function buildDelivery(env, payload, scene) {
  const raw = (payload && payload.delivery && typeof payload.delivery === 'object') ? payload.delivery : {}
  let type = DELIVERY_TYPES.indexOf(raw.type) >= 0 ? raw.type : ''
  if (!type) {
    if (safeStr(payload && payload.cardSecret, 400)) type = 'card'
    else if (safeStr(payload && payload.trackingNo, 60)) type = 'logistics'
    else if (scene === 'game') type = 'game'
    else type = 'manual'
  }
  const cardSecret = safeStr(raw.cardSecret || (payload && payload.cardSecret), 400)
  const meta = {
    type: type,
    auto: raw.auto !== false,
    carrier: safeStr(raw.carrier || (payload && payload.carrier), 40),
    trackingNo: safeStr(raw.trackingNo || (payload && payload.trackingNo), 60),
    itemName: safeStr(raw.itemName || (payload && payload.subject), 80),
    note: safeStr(raw.note, 200),
    deliveryUrl: safeStr(raw.deliveryUrl, 300),
  }
  const cardCipher = cardSecret ? await encryptField(env, cardSecret) : ''
  const immediate = meta.auto && (
    (type === 'card' && !!cardCipher) ||
    (type === 'logistics' && !!meta.trackingNo) ||
    (type === 'game')
  )
  return { meta: meta, cardCipher: cardCipher, immediate: immediate }
}

/** 创建收款单：分配金额识别码与收款通道，返回可直接展示的付款信息 */
export async function createOrder(env, actor, payload) {
  const cfg = await getConfig(env)
  const scene = SCENES.indexOf(payload.scene) >= 0 ? payload.scene : 'ecommerce'

  // 保证金不足时，业务侧自动受限；但「缴纳保证金 / 缴纳租用金」本身不受限，否则无法补缴（死锁）
  const remedyScene = scene === 'deposit' || scene === 'rental'
  if (!remedyScene) {
    const dep = await depositSufficient(env, actor)
    if (!dep.ok) {
      throw httpError(403, '保证金不足，功能已受限：' + dep.reason + '（应缴 ' + dep.required + ' / 已缴 ' + dep.paid + '）',
        { code: 'DEPOSIT_INSUFFICIENT', agentId: dep.agentId, required: dep.required, paid: dep.paid })
    }
    // 租用金逾期处置（超管设为「逾期即限制业务」时生效）；缴纳类订单不受限，保证可补缴
    await assertRentalOk(env, actor)
  }

  const amount = toInt(payload.amount, 0)
  if (amount < 1) throw httpError(400, '金额必须大于 0')
  if (amount > 100000000) throw httpError(400, '单笔金额过大')

  let channel = null
  let ownerId = actor.id
  if (scene === 'deposit' || scene === 'rental') {
    const pool = await getPool(env)
    const accts = (pool.accounts || []).filter(function (a) { return a.status !== 'retired' && a.depositReceive !== false })
    if (!accts.length) throw httpError(409, '超管尚未配置保证金收款账户（资金池），请先联系管理员')
    const pick = accts[Math.floor(Math.random() * accts.length)]
    channel = { id: pick.channelId, account: pick.account, holder: pick.holder, ownerId: 'pool', status: 'active' }
    ownerId = actor.id
  } else {
    channel = await pickChannel(env, actor)
    if (!channel) throw httpError(409, '当前账号及其上级代理均未配置可用的 KBZ 收款通道，请先在后台新增 KBZ 商业账号')
  }

  const id = makeId(scene === 'deposit' ? 'dep' : 'ord')
  const token = await randomToken(16)
  const alloc = await allocTail(env, channel.id, amount, id, ownerId)
  const ttl = toInt(payload.ttlSec, cfg.orderTtlSec)
  const escrow = isEscrowScene(scene)
  const dv = await buildDelivery(env, payload, scene)
  const order = {
    id: id,
    token: token,
    scene: scene,
    ownerId: ownerId,
    rootId: actor.rootId || actor.id,
    createdBy: actor.id,
    platform: safeStr(payload.platform, 40) || 'web',
    merchantOrderId: safeStr(payload.merchantOrderId, 60),
    customer: safeStr(payload.customer, 60),
    subject: safeStr(payload.subject, 80) || (scene === 'deposit' ? '保证金缴纳' : (scene === 'rental' ? '系统租用金' : '商品/游戏充值')),
    rentalPeriod: safeStr(payload.period, 20) || '',
    amount: amount,
    payable: alloc.payable,
    tailCode: alloc.code,
    channelId: channel.id,
    channelAccount: channel.account,
    channelHolder: channel.holder,
    channelOwnerId: channel.ownerId,
    adapterId: safeStr(payload.adapterId, 40) || '',
    status: 'pending',
    paidAmount: 0,
    paidTxid: '',
    paidAt: null,
    source: '',
    // —— 履约链：pending → paid → delivered → received → settled ——
    stage: 'pending',
    escrow: escrow,
    beneficiaryId: safeStr(payload.beneficiaryId, 40) || ownerId,
    deliveryType: dv.meta.type,
    delivery: dv.meta,
    cardSecretCipher: dv.cardCipher,     // 卡密：AES-GCM 密文，明文永不落库
    deliverImmediately: dv.immediate,    // 收款到账即自动发货
    deliveryStatus: 'pending',
    deliveredAt: null,
    autoReceiveAt: null,
    receivedAt: null,
    settledAt: null,
    settleAmount: 0,
    settleFee: 0,
    settleNet: 0,
    // —— 游戏闭环：游戏账号映射与发币回执 ——
    gameAccount: safeStr(payload.gameAccount, 60),
    gameRole: safeStr(payload.gameRole, 60),
    gameZone: safeStr(payload.gameZone, 40),
    itemCode: safeStr(payload.itemCode, 60),
    quantity: toInt(payload.quantity, 1),
    grantStatus: scene === 'game' ? 'waiting' : '',
    grantTxid: '',
    grantAt: null,
    expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
  await kvPut(env, 'ord:' + ownerId + ':' + id, order)
  // 订单级回调地址：无需配置适配器即可把到账结果推给商户自己的服务器
  const notifyUrl = safeStr(payload.notifyUrl, 300)
  if (notifyUrl) {
    const notifySecret = safeStr(payload.notifySecret, 80)
    await kvPut(env, 'ordcb:' + id, {
      url: notifyUrl,
      secretCipher: notifySecret ? await encryptField(env, notifySecret) : '',  // 回调密钥加密落库，明文不落盘
    })
  }
  await kvPut(env, 'ordtok:' + token, { ownerId: ownerId, orderId: id }, { ttlSec: ttl + 3600 })
  await bumpTailCounter(env, channel.id, 1)
  await addAudit(env, actor.id, 'order.create', { orderId: id, scene: scene, amount: amount, channel: maskAccount(channel.account) })
  return await publicOrder(env, order, { keepToken: true, reveal: true })
}

/** 分配金额识别码：保证 payable 的尾码（末 N 位）在所有在途订单中唯一
 *  实现要点：
 *   1) 用「通道级分布式锁 + 确定性 key + 读校验写」降低并发撞码概率；
 *   2) 占用记录写入 tail:{channelId}:{code}，带 TTL，到期自动释放；
 *   3) KV 最终一致场景下的兜底：即使短暂重码，核销时仍以订单状态与金额二次校验。 */
export async function allocTail(env, channelId, amount, orderId, ownerId) {
  const cfg = await getConfig(env)
  const mod = Math.pow(10, toInt(cfg.tailDigits, 3))
  const base = hashInt(orderId || String(Math.random()))
  const cur = ((amount % mod) + mod) % mod
  const ttl = toInt(cfg.tailTtlSec, 1800)
  return await withLock(env, 'tailalloc:' + channelId, 15, async function () {
    for (let i = 0; i < mod; i++) {
      const code = (base + i * 97) % mod
      const key = 'tail:' + channelId + ':' + code
      const seen = await kvGet(env, key, null)
      if (seen && seen.expiresAt && Date.parse(seen.expiresAt) > Date.now()) continue
      const payable = amount + (((code - cur) % mod) + mod) % mod
      const expiresAt = new Date(Date.now() + ttl * 1000).toISOString()
      await kvPut(env, key, {
        orderId: orderId || '', ownerId: ownerId || '', code: code,
        payable: payable, channelId: channelId, expiresAt: expiresAt,
      }, { ttlSec: ttl })
      return { code: code, payable: payable, expiresAt: expiresAt }
    }
    throw httpError(409, '当前通道识别码已用尽，请增加收款通道或缩短订单有效期')
  })
}

async function bumpTailCounter(env, channelId, delta) {
  const key = 'chantail:' + channelId
  const c = await kvGet(env, key, { active: 0 })
  c.active = Math.max(0, toInt(c.active, 0) + delta)
  await kvPut(env, key, c)
}

function decorateOrder(o, cfg) {
  const expired = o.status === 'pending' && Date.parse(o.expiresAt) <= Date.now()
  return Object.assign({}, o, {
    amountText: (o.amount || 0).toLocaleString('en-US') + ' ' + cfg.currency,
    payableText: (o.payable || 0).toLocaleString('en-US') + ' ' + cfg.currency,
    expired: expired,
    payUrl: '/pay?t=' + o.token,
    statusText: o.status,
    stageText: STAGE_TEXT[o.stage || 'pending'] || o.stage,
    escrowText: o.escrow ? '托管中（收货后转款到户）' : '直接入账',
  })
}

/** 履约阶段文案（后台/收银台/回调统一口径） */
export const STAGE_TEXT = {
  pending: '待付款',
  paid: '已到账·待发货',
  delivered: '已发货·待收货',
  received: '已收货·待转款',
  settled: '已转款到户',
  refunded: '已退款',
  closed: '已关闭',
}

/** 释放订单占用的尾码 */
export async function releaseTail(env, order) {
  if (!order || !order.channelId || order.tailCode === undefined || order.tailCode === null) return
  await kvDel(env, 'tail:' + order.channelId + ':' + order.tailCode)
  await bumpTailCounter(env, order.channelId, -1)
}

export async function getOrder(env, ownerId, id) {
  return await kvGet(env, 'ord:' + ownerId + ':' + id, null)
}

export async function findOrderById(env, actor, id) {
  // 先在可见归属内查找
  const owners = await visibleOwnerIds(env, actor)
  for (const oid of owners) {
    const o = await kvGet(env, 'ord:' + oid + ':' + id, null)
    if (o) return o
  }
  return null
}

export async function getOrderByToken(env, token) {
  const idx = await kvGet(env, 'ordtok:' + token, null)
  if (!idx) return null
  return await kvGet(env, 'ord:' + idx.ownerId + ':' + idx.orderId, null)
}

export async function listOrders(env, actor, filter) {
  const owners = await visibleOwnerIds(env, actor)
  const out = []
  const f = filter || {}
  for (const oid of owners) {
    const keys = await kvList(env, 'ord:' + oid + ':')
    for (const k of keys) {
      const o = await kvGet(env, k, null)
      if (o) out.push(o)
    }
  }
  let list = out
  if (f.status) list = list.filter(function (o) { return o.status === f.status })
  if (f.scene) list = list.filter(function (o) { return o.scene === f.scene })
  if (f.stage) list = list.filter(function (o) { return (o.stage || 'pending') === f.stage })
  if (f.escrow !== undefined && f.escrow !== '') {
    const want = f.escrow === true || f.escrow === '1' || f.escrow === 'true'
    list = list.filter(function (o) { return !!o.escrow === want })
  }
  if (f.ownerId) list = list.filter(function (o) { return o.ownerId === f.ownerId })
  if (f.kw) {
    const kw = String(f.kw).toLowerCase()
    list = list.filter(function (o) {
      return (String(o.id) + String(o.merchantOrderId) + String(o.customer) + String(o.channelAccount) + String(o.paidTxid) + String(o.gameAccount) + String(o.itemCode)).toLowerCase().indexOf(kw) >= 0
    })
  }
  list.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)) })
  return list.slice(0, toInt(f.limit, 200))
}

/* ============================== 平台使用费（超管层级账户） ============================== */

/** 找到某账号向上最近的代理分级账户（商户→其上级代理；代理→自身）；无代理则返回 null */
export async function agentAncestorOf(env, ownerId) {
  let node = await getUser(env, ownerId)
  let guard = 0
  while (node && guard++ < 12) {
    if (node.role === 'agent') return node
    if (node.role === 'super' || !node.parentId) return null
    node = await getUser(env, node.parentId)
  }
  return null
}

/**
 * 平台使用费计提：按各「代理分级账户」的收款结算额计提，计入超管层级的平台账户。
 * - 计费对象：订单归属账号向上最近的代理分级账户（超管层级账户只收代理账户的使用费）；
 * - 余额不足时按可扣额计提，差额记为欠缴（代理账户余额不为负，账目始终可核）。
 * 返回 { fee, due, agentId }
 */
export async function chargePlatformFee(env, order, amount, note) {
  const cfg = await getConfig(env)
  const rate = Number(cfg.platformFeeRate || 0)
  if (!(rate > 0) || !order) return { fee: 0, due: 0, agentId: '' }
  const ag = await agentAncestorOf(env, order.ownerId)
  if (!ag) return { fee: 0, due: 0, agentId: '' }
  const want = Math.round(toInt(amount, 0) * rate)
  if (want <= 0) return { fee: 0, due: 0, agentId: ag.id }
  const st = await getStats(env, ag.id)
  const bal = toInt(st.balance, 0)
  const fee = Math.min(want, bal > 0 ? bal : 0)
  const due = want - fee
  const label = safeStr(note, 40) || '收款结算'
  if (fee > 0) {
    await ledgerAppend(env, ag.id, {
      type: 'platform_fee', direction: 'out', amount: fee, refId: order.id,
      note: '平台使用费（' + label + '，费率 ' + (rate * 100).toFixed(2) + '%）',
    })
    await bumpStats(env, ag.id, { balance: -fee, platformFee: fee })
    await ledgerAppend(env, PLATFORM_ID, {
      type: 'platform_fee_in', direction: 'in', amount: fee, refId: order.id, agentId: ag.id,
      note: '平台使用费入账（来自代理账号 ' + (ag.name || ag.username) + '）',
    })
    await bumpStats(env, PLATFORM_ID, { balance: fee, platformFeeTotal: fee, collectCount: 1 })
    await poolLedgerAppend(env, { type: 'platform_fee', agentId: ag.id, amount: fee, refId: order.id, note: '平台使用费（代理分级账户计提）' })
  }
  await addAudit(env, 'system', 'platform.fee', { agentId: ag.id, orderId: order.id, amount: want, charged: fee, due: due, rate: rate })
  return { fee: fee, due: due, agentId: ag.id }
}

/** 平台账户视图（超管专用）：使用费与保证金 / 租用金收款归集情况 */
export async function platformAccount(env) {
  const st = await getStats(env, PLATFORM_ID)
  const pool = await getPool(env)
  return {
    id: PLATFORM_ID,
    stats: st,
    balance: toInt(st.balance, 0),
    platformFeeTotal: toInt(st.platformFeeTotal, 0),
    depositTotal: toInt(pool.depositTotal, 0),
    rentalTotal: toInt(pool.rentalTotal, 0),
    poolBalance: toInt(pool.balance, 0),
    receiveAccounts: (pool.accounts || []).filter(function (a) { return a.depositReceive !== false }),
    rule: '超管层级账户只向各代理分级账户计提使用费，并归集保证金 / 租用金收款；不直接承接业务收款。',
  }
}

/** 自动核销：订单收款成功，写账本、更新通道与统计、触发回调 */
export async function settleOrder(env, order, pay) {
  const cfg = await getConfig(env)
  return await withLock(env, 'ord:' + order.id, 15, async function () {
    let fresh = await kvGet(env, 'ord:' + order.ownerId + ':' + order.id, null)
    if (!fresh) throw httpError(404, '订单不存在')
    if (fresh.status === 'paid') return { order: fresh, duplicate: true }
    if (fresh.status !== 'pending' && fresh.status !== 'partial') {
      throw httpError(409, '订单状态不允许核销：' + fresh.status)
    }
    if (Date.parse(fresh.expiresAt) <= Date.now()) {
      fresh.status = 'closed'
      fresh.updatedAt = nowIso()
      await kvPut(env, 'ord:' + fresh.ownerId + ':' + fresh.id, fresh)
      await releaseTail(env, fresh)
      return { order: fresh, expired: true }
    }
    const paidAmount = toInt(pay.amount, fresh.payable)
    if (paidAmount < fresh.amount) {
      fresh.status = 'partial'
      fresh.paidAmount = paidAmount
      fresh.updatedAt = nowIso()
      await kvPut(env, 'ord:' + fresh.ownerId + ':' + fresh.id, fresh)
      return { order: fresh, underpaid: true, shortfall: fresh.amount - paidAmount }
    }
    fresh.status = 'paid'
    fresh.paidAmount = paidAmount
    fresh.paidTxid = safeStr(pay.txid, 64)
    fresh.paidAt = pay.time || nowIso()
    fresh.source = pay.source || 'auto'
    fresh.stage = fresh.escrow ? 'paid' : 'settled'
    fresh.updatedAt = nowIso()
    await kvPut(env, 'ord:' + fresh.ownerId + ':' + fresh.id, fresh)
    await releaseTail(env, fresh)

    if (fresh.scene === 'deposit') {
      await creditDeposit(env, fresh)
    } else if (fresh.scene === 'rental') {
      await creditRental(env, fresh)
    } else if (fresh.escrow) {
      // 电商 / 游戏：到账先进托管，买家确认收货后才转款到户（可用余额）
      await ledgerAppend(env, fresh.ownerId, {
        type: 'collect', direction: 'in', amount: fresh.amount, escrow: true,
        refId: fresh.id, extId: fresh.paidTxid, channelId: fresh.channelId,
        note: '收款到账（' + fresh.scene + '，进入托管待收货）', source: fresh.source,
      })
      await bumpStats(env, fresh.ownerId, { escrow: fresh.amount, collectTotal: fresh.amount, collectCount: 1 })
    } else {
      await ledgerAppend(env, fresh.ownerId, {
        type: 'collect', direction: 'in', amount: fresh.amount,
        refId: fresh.id, extId: fresh.paidTxid, channelId: fresh.channelId,
        note: '收款到账（' + fresh.scene + '）', source: fresh.source,
      })
      await bumpStats(env, fresh.ownerId, { balance: fresh.amount, collectTotal: fresh.amount, collectCount: 1 })
      // 平台使用费：按代理分级账户计提（超管层级账户只收使用费）
      if (cfg.platformFeeOnCollect !== false) await chargePlatformFee(env, fresh, fresh.amount, '直接入账')
    }

    // 通道累计收款
    const ch = await kvGet(env, 'chan:' + fresh.channelOwnerId + ':' + fresh.channelId, null)
    if (ch) {
      ch.totalReceived = (toInt(ch.totalReceived, 0) + fresh.amount)
      ch.updatedAt = nowIso()
      await kvPut(env, 'chan:' + fresh.channelOwnerId + ':' + fresh.channelId, ch)
    }

    await addAudit(env, 'system', 'order.paid', {
      orderId: fresh.id, amount: fresh.amount, txid: fresh.paidTxid, source: fresh.source,
    })

    // 平台回调（异步投递，带重试）：到账事件
    await dispatchOrderEvent(env, fresh, 'order.paid')

    // 自动发货：商户在下单时已提供发货要素（卡密 / 物流单 / 游戏账号映射）
    if (fresh.escrow && fresh.deliverImmediately && cfg.autoDeliver !== false) {
      fresh = await applyDelivery(env, fresh, { auto: true })
    }
    return { order: fresh }
  })
}

/** 发货 / 收货 / 结算事件统一投递：优先适配器目标地址，其次订单级 notifyUrl */
async function dispatchOrderEvent(env, order, event) {
  if (order.adapterId) await enqueueWebhook(env, order, event)
  const cb = await kvGet(env, 'ordcb:' + order.id, null)
  if (cb && cb.url) {
    let secret = ''
    if (cb.secretCipher) { try { secret = await decryptField(env, cb.secretCipher) } catch (e) { secret = '' } }
    else if (cb.secret) secret = cb.secret   // 兼容历史明文记录
    await enqueueWebhook(env, order, event, { url: cb.url, secret: secret })
  }
  return true
}

/* ============================== 履约引擎（发货 · 收货 · 转款到户） ============================== */

/** 发货要素是否齐备：齐备即「到账自动发货」，平台无需任何对接文档 */
export function autoDeliverable(order) {
  if (!order || !order.escrow) return false
  const d = order.delivery || {}
  if (d.type === 'card') return !!order.cardSecretCipher
  if (d.type === 'logistics') return !!safeStr(d.trackingNo, 60)
  if (d.type === 'game') return true
  return false
}

/** 发货：写入发货记录并把订单推进到 delivered（到账自动发货 / 后台手动发货共用，幂等） */
export async function applyDelivery(env, order, opts) {
  const o = opts || {}
  if (!order) throw httpError(404, '订单不存在')
  if (order.status !== 'paid') throw httpError(409, '订单尚未到账，无法发货')
  if (order.stage === 'received' || order.stage === 'settled') throw httpError(409, '订单已收货，无需重复发货')
  if (order.stage === 'delivered' && !o.force) return order
  const cfg = await getConfig(env)
  const d = order.delivery || {}
  if (d.type === 'card' && !order.cardSecretCipher) throw httpError(400, '卡密类发货缺少卡密内容')
  if (d.type === 'logistics' && !safeStr(d.trackingNo, 60)) throw httpError(400, '物流类发货缺少物流单号')
  order.deliveryStatus = 'delivered'
  order.deliveredAt = nowIso()
  order.deliveredBy = o.by || (o.auto ? 'system' : 'manual')
  order.stage = 'delivered'
  // 发货后 N 小时无人确认收货 → 视为已收货并转款到户（0 = 关闭自动收货）
  const hours = Number(cfg.autoReceiveHours)
  order.autoReceiveAt = (hours > 0) ? new Date(Date.now() + hours * 3600 * 1000).toISOString() : null
  order.updatedAt = nowIso()
  await kvPut(env, 'ord:' + order.ownerId + ':' + order.id, order)
  await addAudit(env, order.deliveredBy, 'order.deliver', {
    orderId: order.id, auto: !!o.auto, deliveryType: d.type,
    trackingNo: d.type === 'logistics' ? d.trackingNo : '',
  })
  await dispatchOrderEvent(env, order, 'order.delivered')
  return order
}

/** 收银台 / 后台 / 回调共用的发货凭据视图（卡密默认脱敏，仅买家与归属方可取明文） */
export async function publicDelivery(env, order, reveal) {
  const d = (order && order.delivery) || {}
  let cardSecret = ''
  if (d.type === 'card' && order.cardSecretCipher) {
    try { cardSecret = await decryptField(env, order.cardSecretCipher) } catch (e) { cardSecret = '' }
    if (!reveal && cardSecret.length > 8) cardSecret = cardSecret.slice(0, 4) + '****' + cardSecret.slice(-4)
    else if (!reveal && cardSecret) cardSecret = '****'
  }
  return {
    type: d.type, itemName: d.itemName, carrier: d.carrier,
    trackingNo: d.type === 'logistics' ? d.trackingNo : '',
    deliveryUrl: d.deliveryUrl, note: d.note, cardSecret: cardSecret,
    deliveryStatus: (order && order.deliveryStatus) || 'pending',
    deliveredAt: (order && order.deliveredAt) || null,
    autoReceiveAt: (order && order.autoReceiveAt) || null,
    receivedAt: (order && order.receivedAt) || null,
    settledAt: (order && order.settledAt) || null,
  }
}

/** 订单对外视图：剔除卡密密文等敏感字段，附发货凭据 */
export async function publicOrder(env, order, opts) {
  const o = opts || {}
  const cfg = await getConfig(env)
  const base = decorateOrder(order, stripSensitive(order))
  // 收款账号默认脱敏：仅订单归属者本人 / 通道归属者本人可取明文；上级查看下级订单一律脱敏
  const acct = order.channelAccount || ''
  const ownerView = !o.viewerId || o.viewerId === order.ownerId || o.viewerId === order.channelOwnerId
  base.channelAccount = ownerView ? acct : maskAccount(acct)
  base.channelAccountMasked = maskAccount(acct)
  if (!o.keepToken) delete base.token
  base.deliveryView = await publicDelivery(env, order, !!o.reveal)
  if (o.reveal) base.cardSecretCipher = order.cardSecretCipher
  else delete base.cardSecretCipher
  return base
}

/** 确认收货 → 转款到户（带订单锁，供接口层调用） */
export async function receiveAndSettle(env, order, opts) {
  const o = opts || {}
  if (!order) throw httpError(404, '订单不存在')
  return await withLock(env, 'ord:' + order.id, 15, async function () {
    const fresh = await kvGet(env, 'ord:' + order.ownerId + ':' + order.id, null)
    if (!fresh) throw httpError(404, '订单不存在')
    return await applyReceive(env, fresh, o)
  })
}

/** 收货确认：received → settled，把托管金额释放为可用余额（可再出款到户） */
export async function applyReceive(env, order, opts) {
  const o = opts || {}
  if (!order) throw httpError(404, '订单不存在')
  if (order.stage === 'settled') return order
  if (order.status !== 'paid') throw httpError(409, '订单未到账，无法确认收货')
  if (!order.escrow) throw httpError(409, '非托管订单无需确认收货')
  if (order.stage !== 'delivered' && order.stage !== 'received' && !o.allowUndelivered) {
    throw httpError(409, '订单尚未发货，无法确认收货')
  }
  const cfg = await getConfig(env)
  order.receivedAt = order.receivedAt || nowIso()
  order.receivedBy = o.by || (o.auto ? 'system' : 'buyer')
  order.stage = 'received'
  order.updatedAt = nowIso()
  await kvPut(env, 'ord:' + order.ownerId + ':' + order.id, order)
  await addAudit(env, order.receivedBy, 'order.receive', { orderId: order.id, auto: !!o.auto })
  await dispatchOrderEvent(env, order, 'order.received')
  if (cfg.autoSettle === false && !o.forceSettle) return order
  return await settleToAccount(env, order, o)
}

/** 转款到户：从托管余额释放到受益人可用余额，按配置收取结算手续费 */
export async function settleToAccount(env, order, opts) {
  const o = opts || {}
  if (!order) throw httpError(404, '订单不存在')
  if (order.status !== 'paid') throw httpError(409, '订单未到账，无法转款到户')
  if (order.stage === 'settled') return order
  if (!order.escrow) throw httpError(409, '非托管订单无需转款到户')
  const cfg = await getConfig(env)
  const holderId = order.ownerId
  const beneficiaryId = safeStr(o.beneficiaryId, 40) || safeStr(order.beneficiaryId, 40) || holderId
  const amount = toInt(order.amount, 0)
  const st = await getStats(env, holderId)
  if (toInt(st.escrow, 0) < amount) throw httpError(409, '托管余额不足，无法转款到户')
  const fee = Math.round(amount * Number(cfg.settleFeeRate || 0))
  const net = amount - fee
  await ledgerAppend(env, holderId, {
    type: 'settle_out', direction: 'out', amount: amount, escrow: true, refId: order.id,
    note: '托管转出（收货确认，转入受益人 ' + beneficiaryId + '）',
  })
  await bumpStats(env, holderId, { escrow: -amount })
  await ledgerAppend(env, beneficiaryId, {
    type: 'settle_in', direction: 'in', amount: net, fee: fee, refId: order.id,
    note: '收货转款到户（' + order.scene + '，手续费 ' + fee + ' MMK）',
  })
  await bumpStats(env, beneficiaryId, { balance: net, settleTotal: amount, settleCount: 1 })
  // 平台使用费：按代理分级账户计提（超管层级账户只收使用费，不直接承接业务收款）
  const pf = (cfg.platformFeeOnCollect !== false) ? await chargePlatformFee(env, order, amount, '收货转款到户') : { fee: 0, due: 0 }
  order.platformFee = pf.fee
  order.platformFeeDue = pf.due
  order.stage = 'settled'
  order.settledAt = nowIso()
  order.settleAmount = amount
  order.settleFee = fee
  order.settleNet = net
  order.settledBy = o.by || (o.auto ? 'system' : 'manual')
  order.updatedAt = nowIso()
  delete order.cardSecretCipher // 转款完成即销毁发货凭据，避免卡密长期驻留
  await kvPut(env, 'ord:' + order.ownerId + ':' + order.id, order)
  await addAudit(env, order.settledBy, 'order.settle', {
    orderId: order.id, amount: amount, fee: fee, net: net, beneficiaryId: beneficiaryId,
  })
  await dispatchOrderEvent(env, order, 'order.settled')
  return order
}

/** 自动收货扫描：定时任务调用，把到期未确认的托管订单自动收货并转款到户 */
export async function autoReceiveSweep(env, limit) {
  const users = await listUsers(env)
  const now = Date.now()
  const max = toInt(limit, 100)
  let settled = 0, scanned = 0
  for (const u of users) {
    if (settled >= max) break
    const keys = await kvList(env, 'ord:' + u.id + ':')
    for (const k of keys) {
      if (settled >= max) break
      const o = await kvGet(env, k, null)
      if (!o || !o.escrow) continue
      if (o.stage !== 'delivered' || !o.autoReceiveAt) continue
      if (Date.parse(o.autoReceiveAt) > now) continue
      scanned++
      const r = await receiveAndSettle(env, o, { auto: true, by: 'system', forceSettle: true })
      if (r && r.stage === 'settled') settled++
    }
  }
  return { autoSettled: settled, scanned: scanned }
}

/**
 * 订单超时自动关闭：pending 且已过期的订单统一收口为 closed，并释放占用的金额识别码。
 * 幂等：非 pending 的订单一律跳过；识别码释放（releaseTail）可在重复执行时安全重放。
 */
export async function expireOrdersSweep(env, limit) {
  const users = await listUsers(env)
  const now = Date.now()
  const max = toInt(limit, 500)
  let closed = 0, scanned = 0
  for (const u of users) {
    if (closed >= max) break
    const keys = await kvList(env, 'ord:' + u.id + ':')
    for (const k of keys) {
      if (closed >= max) break
      const o = await kvGet(env, k, null)
      if (!o || o.status !== 'pending') continue
      if (!o.expiresAt || Date.parse(o.expiresAt) > now) continue
      scanned++
      o.status = 'closed'
      o.stage = 'closed'
      o.closeReason = '支付超时自动关闭'
      o.closedAt = nowIso()
      o.updatedAt = nowIso()
      await kvPut(env, k, o)
      await releaseTail(env, o)
      await addAudit(env, 'system', 'order.expire', { orderId: o.id, ownerId: o.ownerId, amount: o.amount })
      closed++
    }
  }
  return { expiredClosed: closed, scanned: scanned }
}

/**
 * 维护任务总入口（可被定时任务 / 超管手动触发）：
 *   ① 超时订单自动关闭 ② 到期托管订单自动收货转款 ③ 回调重试
 * 全部任务幂等，可安全重复执行；返回各任务的真实处理计数，便于后台展示与审计。
 */
export async function runMaintenance(env, opts) {
  const o = opts || {}
  const limit = toInt(o.limit, 200)
  const started = Date.now()
  const tasks = {}
  if (o.expire !== false) {
    try { tasks.expireOrders = await expireOrdersSweep(env, limit) }
    catch (e) { tasks.expireOrders = { error: (e && e.message) || '失败' } }
  }
  if (o.autoReceive !== false) {
    try { tasks.autoReceive = await autoReceiveSweep(env, limit) }
    catch (e) { tasks.autoReceive = { error: (e && e.message) || '失败' } }
  }
  if (o.webhooks !== false) {
    try { tasks.webhooks = await runWebhooks(env, limit) }
    catch (e) { tasks.webhooks = { error: (e && e.message) || '失败' } }
  }
  const out = { at: nowIso(), elapsedMs: Date.now() - started, tasks: tasks }
  await addAudit(env, o.by || 'system', 'maintenance.run', { elapsedMs: out.elapsedMs, tasks: Object.keys(tasks) })
  return out
}

/** 维护状态面板：给后台展示「有哪些待处理」，不改变任何数据 */
export async function maintenanceStatus(env, actor) {
  const cfg = await getConfig(env)
  const now = Date.now()
  const users = await listUsers(env)
  let pendingOrders = 0, expiringSoon = 0, awaitingReceive = 0, autoReceiveDue = 0, settledToday = 0
  for (const u of users) {
    const keys = await kvList(env, 'ord:' + u.id + ':')
    for (const k of keys) {
      const o = await kvGet(env, k, null)
      if (!o) continue
      if (o.status === 'pending') {
        pendingOrders++
        const exp = Date.parse(o.expiresAt || '')
        if (exp && exp <= now) expiringSoon++
      }
      if (o.escrow && o.stage === 'delivered') {
        awaitingReceive++
        const at = Date.parse(o.autoReceiveAt || '')
        if (at && at <= now) autoReceiveDue++
      }
      if (o.stage === 'settled' && o.settledAt && String(o.settledAt).slice(0, 10) === nowIso().slice(0, 10)) settledToday++
    }
  }
  const wh = await kvList(env, 'wh:')
  let webhookPending = 0, webhookDue = 0
  for (const k of wh) {
    const r = await kvGet(env, k, null)
    if (!r || r.status !== 'pending') continue
    webhookPending++
    if (Date.parse(r.nextAt || '') <= now) webhookDue++
  }
  // 只统计「待人工核销」（status=open）的笔数：已核销 / 已自动销账的台账不应再计入待办，否则面板长期虚高
  const unmatched = await listUnmatched(env, null, { limit: 500, status: 'open' })
  const rental = actor ? await rentalBoard(env, actor, {}) : { summary: {} }
  const rs = rental.summary || {}
  return {
    at: nowIso(),
    orders: { pending: pendingOrders, expiredWaitingSweep: expiringSoon, awaitingReceive: awaitingReceive, autoReceiveDue: autoReceiveDue, settledToday: settledToday },
    webhooks: { pending: webhookPending, due: webhookDue },
    unmatchedFlows: { open: unmatched.length },
    rentals: { agents: toInt(rs.agents, 0), normal: toInt(rs.normal, 0), grace: toInt(rs.grace, 0), overdue: toInt(rs.overdue, 0), unpaid: toInt(rs.periodUnpaidCount, 0) },
    nextCronHint: '定时任务（wrangler.toml [triggers] crons = */1）每分钟自动执行一次上述维护；也可用本页按钮立即执行。',
  }
}

/** 后台手动发货：可在此一步补录发货要素（下单时未提供的场景） */
export async function deliverOrder(env, actor, id, payload) {
  const p = payload || {}
  const found = await findOrderById(env, actor, id)
  if (!found) throw httpError(404, '资源不存在')
  return await withLock(env, 'ord:' + id, 15, async function () {
    let fresh = await kvGet(env, 'ord:' + found.ownerId + ':' + id, null)
    if (!fresh) throw httpError(404, '资源不存在')
    if (p.delivery || p.cardSecret || p.trackingNo) {
      const dv = await buildDelivery(env, p, fresh.scene)
      fresh.delivery = dv.meta
      fresh.deliveryType = dv.meta.type
      if (dv.cardCipher) fresh.cardSecretCipher = dv.cardCipher
      fresh.deliverImmediately = true
    }
    fresh = await applyDelivery(env, fresh, { by: actor.id })
    return await publicOrder(env, fresh, { reveal: true, viewerId: actor.id })
  })
}

/** 确认收货（后台 / 商户 / 买家自助）：确认后自动转款到户 */
export async function confirmReceive(env, actor, id, payload) {
  const p = payload || {}
  const found = await findOrderById(env, actor, id)
  if (!found) throw httpError(404, '资源不存在')
  const r = await receiveAndSettle(env, found, {
    by: actor.id, forceSettle: p.forceSettle !== false,
    beneficiaryId: safeStr(p.beneficiaryId, 40),
  })
  return await publicOrder(env, r, { viewerId: actor.id })
}

/** 买家凭订单 token 自助确认收货（收银台页面 / 平台跳转回来） */
export async function confirmReceiveByToken(env, token, payload) {
  const order = await getOrderByToken(env, safeStr(token, 80))
  if (!order) throw httpError(404, '订单不存在或已过期')
  const r = await receiveAndSettle(env, order, { by: 'buyer', forceSettle: true })
  return await publicOrder(env, r, { reveal: true })
}

/** 发货凭据查询（买家持 token 可取明文卡密；商户/后台按需取） */
export async function deliveryOfToken(env, token) {
  const order = await getOrderByToken(env, safeStr(token, 80))
  if (!order) throw httpError(404, '订单不存在或已过期')
  return { order: await publicOrder(env, order, { reveal: true }) }
}

async function creditDeposit(env, order) {
  const agentId = order.ownerId
  const amount = order.amount
  const d = await getDeposit(env, agentId)
  const paid = toInt(d.paid, 0) + amount
  await setDeposit(env, agentId, { paid: paid })
  const pool = await getPool(env)
  await setPool(env, {
    balance: toInt(pool.balance, 0) + amount,
    depositTotal: toInt(pool.depositTotal, 0) + amount,
  })
  await poolLedgerAppend(env, { type: 'deposit_in', agentId: agentId, amount: amount, refId: order.id, note: '代理保证金缴纳' })
  await ledgerAppend(env, agentId, {
    type: 'deposit', direction: 'out', amount: amount, refId: order.id,
    note: '缴纳保证金至超管资金池',
  })
  await ledgerAppend(env, 'pool', {
    type: 'deposit_in', direction: 'in', amount: amount, refId: order.id, agentId: agentId,
    note: '保证金入池',
  })
  await bumpStats(env, 'pool', { balance: amount, collectTotal: amount, collectCount: 1 })
  await addAudit(env, 'system', 'deposit.paid', { agentId: agentId, amount: amount, orderId: order.id })
  // 保证金补齐后自动解除限制
  const nd = await getDeposit(env, agentId)
  if (toInt(nd.paid, 0) >= toInt(nd.required, 0)) {
    const u = await getUser(env, agentId)
    if (u && u.status === 'restricted') {
      u.status = 'active'
      u.updatedAt = nowIso()
      await kvPut(env, 'user:' + agentId, u)
      await addAudit(env, 'system', 'deposit.release', { agentId: agentId })
    }
  }
}

async function creditRental(env, order) {
  const agentId = order.ownerId
  const amount = order.amount
  const period = order.rentalPeriod || new Date().toISOString().slice(0, 7)
  const id = makeId('rent')
  const rec = {
    id: id, agentId: agentId, amount: amount, period: period,
    status: 'paid', paidBy: 'agent-self', note: '代理自助缴纳系统租用金',
    createdAt: nowIso(),
  }
  await kvPut(env, 'rent:' + agentId + ':' + id, rec)
  const pool = await getPool(env)
  await setPool(env, {
    balance: toInt(pool.balance, 0) + amount,
    rentalTotal: toInt(pool.rentalTotal, 0) + amount,
  })
  await poolLedgerAppend(env, { type: 'rental_in', agentId: agentId, amount: amount, refId: order.id, note: '系统租用金（' + period + '）' })
  await ledgerAppend(env, agentId, { type: 'rental', direction: 'out', amount: amount, refId: order.id, note: '系统租用金 ' + period })
  await ledgerAppend(env, 'pool', { type: 'rental_in', direction: 'in', amount: amount, agentId: agentId, refId: order.id, note: '租用金入池' })
  await bumpStats(env, 'pool', { balance: amount })
  await addAudit(env, 'system', 'pool.rental', { agentId: agentId, amount: amount, period: period, orderId: order.id })
}

/* ============================== 到账匹配引擎 ============================== */
/**
 * 处理一条到账记录（来自通知转发端 / 对账文件 / 持牌通道回调）。
 * 匹配优先级：① 尾码精确匹配  ② 同金额+同通道精确匹配
 */
export async function matchIncoming(env, payload) {
  const account = safeStr(payload.receiverAccount, 32).replace(/[\s-]/g, '')
  const amount = toInt(payload.amount, 0)
  const txid = safeStr(payload.txid, 64)
  if (!amount) return { status: 'invalid', reason: '金额缺失' }

  const channel = await resolveChannelByAccount(env, account)
  if (!channel) return { status: 'unmatched', reason: '收款账号未登记：' + maskAccount(account) }

  if (txid) {
    const dup = await kvGet(env, 'txn:' + channel.id + ':' + txid, null)
    if (dup) return { status: 'duplicate', orderId: dup.orderId, reason: '该交易号已核销过' }
  }

  const cfg = await getConfig(env)
  const mod = Math.pow(10, toInt(cfg.tailDigits, 3))
  const code = ((amount % mod) + mod) % mod

  let order = null
  const tail = await kvGet(env, 'tail:' + channel.id + ':' + code, null)
  if (tail && (!tail.expiresAt || Date.parse(tail.expiresAt) > Date.now())) {
    order = await kvGet(env, 'ord:' + tail.ownerId + ':' + tail.orderId, null)
  }
  let matchedBy = 'tail'
  if (!order || order.status !== 'pending') {
    // 回退：同通道同金额的在途订单
    matchedBy = 'amount'
    order = await findPendingByAmount(env, channel, amount)
  }
  if (!order) return { status: 'unmatched', reason: '未找到匹配的待支付订单', channelId: channel.id, code: code }

  const res = await settleOrder(env, order, { amount: amount, txid: txid, time: payload.time, source: payload.source || 'notify' })
  if (txid) await kvPut(env, 'txn:' + channel.id + ':' + txid, { orderId: order.id, at: nowIso(), amount: amount })
  return {
    status: res.duplicate ? 'duplicate' : (res.expired ? 'expired' : (res.underpaid ? 'underpaid' : 'paid')),
    orderId: order.id, matchedBy: matchedBy, ownerId: order.ownerId, amount: order.amount,
  }
}

async function findPendingByAmount(env, channel, amount) {
  // 通道尾部计数器给出活动订单数，逐条扫描（活动订单量受尾码总数限制）
  const owners = []
  // 通道归属者自身的订单
  owners.push(channel.ownerId)
  if (channel.ownerId !== 'pool') {
    // 借用该通道的下级账号订单：扫描可见范围内 ownerId 前缀
    const users = await listUsers(env)
    for (const u of users) {
      if (u.id !== channel.ownerId && String(u.path || '').indexOf('/' + channel.ownerId + '/') >= 0) owners.push(u.id)
    }
  }
  for (const oid of owners) {
    const keys = await kvList(env, 'ord:' + oid + ':')
    for (const k of keys) {
      const o = await kvGet(env, k, null)
      if (!o) continue
      if (o.channelId !== channel.id) continue
      if (o.status === 'paid') continue
      const same = (o.amount === amount || o.payable === amount || o.payable === 0)
      if (same && o.status !== 'closed' && Date.parse(o.expiresAt) > Date.now()) return o
    }
  }
  return null
}

/* ============================== 对账未匹配流水（人工核销闭环） ============================== */
const UNMATCHED_TTL_SEC = 90 * 24 * 3600

/** 未匹配流水去重键：优先交易号，其次「账号+金额+时间」指纹（只存哈希，不落原始凭证明文） */
async function unmatchedKey(env, r) {
  const raw = safeStr(r.txnId || r.txid, 64) ||
    [safeStr(r.account || r.receiverAccount, 40), toInt(r.amount, 0), safeStr(r.time, 40)].join('|')
  return 'unm:' + (await sha256hex(raw)).slice(0, 24)
}

/** 落库一条未匹配流水：同一笔重复上报只累加次数，不产生新台账（供人工核销） */
async function recordUnmatched(env, r, res) {
  const key = await unmatchedKey(env, r)
  const prev = await kvGet(env, key, null)
  const rec = prev || {
    id: key.slice(4),
    txnId: safeStr(r.txnId || r.txid, 64),
    account: maskAccount(safeStr(r.account || r.receiverAccount, 40)),
    amount: toInt(r.amount, 0),
    time: safeStr(r.time, 40),
    source: safeStr(r.source, 20) || 'reconcile',
    status: 'open',
    seenCount: 0,
    firstSeenAt: nowIso(),
  }
  rec.seenCount = toInt(rec.seenCount, 0) + 1
  rec.lastSeenAt = nowIso()
  rec.reason = safeStr(res && res.reason, 140) || '未匹配到待支付订单'
  rec.channelId = safeStr(res && res.channelId, 40) || rec.channelId || ''
  await kvPut(env, key, rec, { ttlSec: UNMATCHED_TTL_SEC })
  return rec
}

/** 未匹配流水列表（超管专属；内部维护统计可传 actor=null 绕过鉴权） */
export async function listUnmatched(env, actor, filter) {
  if (actor && actor.role !== 'super') throw httpError(403, '仅超级管理员可查看对账未匹配流水')
  const f = filter || {}
  const keys = await kvList(env, 'unm:')
  const rows = []
  for (const k of keys) {
    const r = await kvGet(env, k, null)
    if (!r) continue
    if (f.status && r.status !== f.status) continue
    rows.push(r)
  }
  rows.sort(function (a, b) { return String(b.lastSeenAt || '').localeCompare(String(a.lastSeenAt || '')) })
  return rows.slice(0, toInt(f.limit, 200))
}

/** 人工核销未匹配流水：把该笔款项落到指定订单上（超管专属，不可逆动作会留审计） */
export async function matchUnmatched(env, actor, id, payload) {
  await assertSuper(actor)
  const p = payload || {}
  const key = 'unm:' + safeStr(id, 40)
  const rec = await kvGet(env, key, null)
  if (!rec) throw httpError(404, '该笔未匹配流水不存在或已清理')
  if (rec.status !== 'open') throw httpError(409, '该笔流水已核销，请勿重复处理')
  let order = null
  if (p.orderId) {
    order = await findOrderById(env, actor, safeStr(p.orderId, 60))
    if (!order) throw httpError(404, '目标订单不存在')
  } else {
    // 未指定订单时，按金额在系统内自动找一张待支付订单（超管权限，全量范围）
    const users = await listUsers(env)
    const amount = toInt(p.amount, rec.amount)
    for (const u of users) {
      const keys = await kvList(env, 'ord:' + u.id + ':')
      for (const k of keys) {
        const o = await kvGet(env, k, null)
        if (!o || o.status !== 'pending') continue
        if (o.amount !== amount && o.payable !== amount) continue
        if (Date.parse(o.expiresAt || '') <= Date.now()) continue
        order = o
        break
      }
      if (order) break
    }
    if (!order) throw httpError(404, '未找到与该金额相符的待支付订单，请显式指定 orderId')
  }
  const txid = safeStr(p.txid, 64) || rec.txnId || ''
  if (!/^\d{5,}$/.test(txid)) throw httpError(400, '核销需要至少 5 位数字的交易号（请把银行流水号作为 txid 传入）')
  const res = await settleOrder(env, order, {
    amount: toInt(p.amount, rec.amount) || order.payable, txid: txid, source: 'manual-match', time: nowIso(),
  })
  if (res.underpaid) throw httpError(400, '到账金额小于订单应付金额，请核对后再核销')
  if (res.expired) throw httpError(410, '目标订单已过期，请选择其他订单或让客户重新下单')
  rec.status = 'matched'
  rec.matchedOrderId = order.id
  rec.matchedBy = actor.id
  rec.matchedRefundAt = null
  rec.matchedAt = nowIso()
  await kvPut(env, key, rec, { ttlSec: UNMATCHED_TTL_SEC })
  await addAudit(env, actor.id, 'reconcile.match', { unmatchedId: rec.id, orderId: order.id, amount: rec.amount, txid: txid })
  return { record: rec, order: res.order }
}

/** 对账文件批量导入（路径 C）：已匹配的直接入账，未匹配的统一落库待人工核销 */
export async function ingestReconcile(env, rows) {
  const results = []
  for (const r of (rows || [])) {
    const res = await matchIncoming(env, Object.assign({ source: 'reconcile' }, r))
    if (res && (res.status === 'unmatched' || res.status === 'invalid')) {
      try { await recordUnmatched(env, r, res) } catch (e) { /* 落库失败不影响主对账结果返回 */ }
    } else if (res && (res.status === 'paid' || res.status === 'duplicate')) {
      // 曾挂为未匹配、现已被正常核销：自动销账，避免人工台账残留
      try {
        const k = await unmatchedKey(env, r)
        const old = await kvGet(env, k, null)
        if (old && old.status === 'open') {
          old.status = 'auto-closed'
          old.matchedOrderId = res.orderId || ''
          old.matchedAt = nowIso()
          await kvPut(env, k, old, { ttlSec: UNMATCHED_TTL_SEC })
        }
      } catch (e) { /* 忽略 */ }
    }
    results.push(res)
  }
  return {
    total: results.length,
    paid: results.filter(function (x) { return x.status === 'paid' }).length,
    unmatched: results.filter(function (x) { return x.status === 'unmatched' || x.status === 'invalid' }).length,
    results: results,
  }
}

/** 截图 + 交易号人工/自动核销（路径 D，兜底） */
export async function submitProof(env, token, body) {
  const order = await getOrderByToken(env, token)
  if (!order) throw httpError(404, '订单不存在或已过期')
  const txid = safeStr(body.txid, 64)
  const amount = toInt(body.amount, order.payable)
  if (!/^\d{5,}$/.test(txid)) throw httpError(400, '转账交易号需为至少 5 位数字')
  if (body.screenshot) {
    const h = await sha256hex(safeStr(body.screenshot, 400000))
    const used = await kvGet(env, 'sshash:' + h, null)
    if (used) throw httpError(409, '该截图已被使用过')
    await kvPut(env, 'sshash:' + h, { orderId: order.id, at: nowIso() })
  }
  const res = await settleOrder(env, order, { amount: amount, txid: txid, source: 'proof', time: nowIso() })
  if (res.underpaid) throw httpError(400, '到账金额小于应付金额，请补足后重试')
  if (res.expired) throw httpError(410, '订单已过期，请重新下单')
  return { ok: true, order: res.order }
}

export async function cancelOrder(env, actor, id) {
  const o = await findOrderById(env, actor, id)
  if (!o) throw httpError(404, '资源不存在')
  if (o.status === 'paid') throw httpError(409, '已到账订单不可取消，请走退款')
  o.status = 'closed'
  o.updatedAt = nowIso()
  await kvPut(env, 'ord:' + o.ownerId + ':' + id, o)
  await releaseTail(env, o)
  await addAudit(env, actor.id, 'order.close', { orderId: id })
  return o
}

export async function refundOrder(env, actor, id, reason) {
  const o = await findOrderById(env, actor, id)
  if (!o) throw httpError(404, '资源不存在')
  if (o.status !== 'paid') throw httpError(409, '只有已到账订单可退款')
  if (o.stage === 'received' || o.stage === 'settled') throw httpError(409, '订单已确认收货并转款到户，不可退款')
  // 托管中的订单从托管余额退回，已直接入账的从可用余额退回
  const fromEscrow = o.escrow === true
  const st = await getStats(env, o.ownerId)
  const avail = fromEscrow ? toInt(st.escrow, 0) : toInt(st.balance, 0)
  if (avail < o.amount) throw httpError(409, (fromEscrow ? '托管余额不足' : '可用余额不足') + '，无法退款')
  o.status = 'refunded'
  o.stage = 'refunded'
  o.refundReason = safeStr(reason, 120)
  o.refundedAt = nowIso()
  o.updatedAt = nowIso()
  delete o.cardSecretCipher // 退款即销毁发货凭据
  await kvPut(env, 'ord:' + o.ownerId + ':' + id, o)
  await ledgerAppend(env, o.ownerId, {
    type: 'refund', direction: 'out', amount: o.amount, escrow: fromEscrow,
    refId: o.id, note: o.refundReason || '订单退款',
  })
  await bumpStats(env, o.ownerId, fromEscrow
    ? { escrow: -o.amount, refundTotal: o.amount }
    : { balance: -o.amount, refundTotal: o.amount })
  await addAudit(env, actor.id, 'order.refund', { orderId: id, amount: o.amount, escrow: fromEscrow })
  return o
}

/* ============================== 出款引擎 ============================== */
export async function requestPayout(env, actor, payload) {
  const cfg = await getConfig(env)
  const amount = toInt(payload.amount, 0)
  if (amount < toInt(cfg.minWithdraw, 1000)) throw httpError(400, '单笔出款不得低于 ' + cfg.minWithdraw + ' MMK')
  let account = safeStr(payload.account, 32).replace(/[\s-]/g, '')
  // 未显式指定时，回落到该账号的「付款账户」（收付款设置里配置，支持一键替换）
  let payAccountId = ''
  if (!account) {
    const pay = await pickPayAccount(env, actor)
    if (pay) { account = pay.account; payAccountId = pay.id }
  }
  if (!/^\d{6,20}$/.test(account)) throw httpError(400, '收款 KBZ 账号需为 6-20 位数字')

  const dep = await depositSufficient(env, actor)
  if (!dep.ok) throw httpError(403, '保证金不足，出款已受限', { code: 'DEPOSIT_INSUFFICIENT' })
  // 租用金逾期处置：设为「逾期即限制业务」时，出款同样受限（资金只进不出，避免损失扩大）
  await assertRentalOk(env, actor)

  const feeRate = actor.role === 'merchant' ? Number(cfg.withdrawFeeRate) : 0
  const fee = Math.round(amount * feeRate)
  const gross = amount + fee
  const st = await getStats(env, actor.id)
  if (toInt(st.balance, 0) < gross) throw httpError(409, '可用余额不足（需含手续费 ' + fee + ' MMK）')

  const id = makeId('po')
  const auto = amount <= toInt(cfg.autoPayoutLimit, 500000)
  const payout = {
    id: id,
    ownerId: actor.id,
    rootId: actor.rootId || actor.id,
    requestedBy: actor.id,
    account: account,
    payAccountId: payAccountId,
    holder: safeStr(payload.holder, 60) || actor.name,
    amount: amount,
    fee: fee,
    gross: gross,
    status: auto ? 'queued' : 'pending',
    autoApproved: auto,
    approvedBy: auto ? 'system' : null,
    rejectReason: '',
    claimedBy: null,
    bankTxid: '',
    receiptAt: null,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
  await kvPut(env, 'po:' + actor.id + ':' + id, payout)
  // 冻结额度
  await ledgerAppend(env, actor.id, {
    type: 'payout_hold', direction: 'out', amount: gross, refId: id,
    note: auto ? '出款冻结（额度内自动出款）' : '出款冻结（待审批）',
  })
  await bumpStats(env, actor.id, { balance: -gross })
  await addAudit(env, actor.id, 'payout.request', { payoutId: id, amount: amount, auto: auto })
  return payout
}

export async function listPayouts(env, actor, filter) {
  const owners = await visibleOwnerIds(env, actor)
  const f = filter || {}
  const out = []
  for (const oid of owners) {
    const keys = await kvList(env, 'po:' + oid + ':')
    for (const k of keys) {
      const p = await kvGet(env, k, null)
      if (p) out.push(p)
    }
  }
  let list = out
  if (f.status) list = list.filter(function (p) { return p.status === f.status })
  if (f.ownerId) list = list.filter(function (p) { return p.ownerId === f.ownerId })
  list.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)) })
  return list.slice(0, toInt(f.limit, 200))
}

async function findPayout(env, actor, id) {
  const owners = await visibleOwnerIds(env, actor)
  for (const oid of owners) {
    const p = await kvGet(env, 'po:' + oid + ':' + id, null)
    if (p) return p
  }
  return null
}

export async function approvePayout(env, actor, id) {
  const p = await findPayout(env, actor, id)
  if (!p) throw httpError(404, '资源不存在')
  if (p.status !== 'pending') throw httpError(409, '该出款单当前状态不可审批：' + p.status)
  p.status = 'queued'
  p.approvedBy = actor.id
  p.updatedAt = nowIso()
  await kvPut(env, 'po:' + p.ownerId + ':' + id, p)
  await addAudit(env, actor.id, 'payout.approve', { payoutId: id, amount: p.amount })
  return p
}

export async function rejectPayout(env, actor, id, reason) {
  const p = await findPayout(env, actor, id)
  if (!p) throw httpError(404, '资源不存在')
  if (['pending', 'queued'].indexOf(p.status) < 0) throw httpError(409, '该出款单当前状态不可驳回：' + p.status)
  p.status = 'rejected'
  p.rejectReason = safeStr(reason, 120)
  p.updatedAt = nowIso()
  await kvPut(env, 'po:' + p.ownerId + ':' + id, p)
  await releaseHold(env, p, '出款驳回，额度退回')
  await addAudit(env, actor.id, 'payout.reject', { payoutId: id, reason: p.rejectReason })
  return p
}

async function releaseHold(env, p, note) {
  await ledgerAppend(env, p.ownerId, {
    type: 'payout_release', direction: 'in', amount: p.gross, refId: p.id, note: note || '出款额度退回',
  })
  await bumpStats(env, p.ownerId, { balance: p.gross })
}

/* ---------- 出款执行端（设备） ---------- */
export async function executorPull(env, device) {
  // 设备只能看到自己归属范围内的待出款任务
  const deviceUser = await getUser(env, device.ownerId)
  if (!deviceUser) throw httpError(403, '设备归属账号不存在')
  const owners = await visibleOwnerIds(env, deviceUser)
  const ownerSet = {}
  owners.forEach(function (o) { ownerSet[o] = 1 })
  const out = []
  const users = await listUsers(env)
  for (const u of users) {
    if (!ownerSet[u.id]) continue
    const keys = await kvList(env, 'po:' + u.id + ':')
    for (const k of keys) {
      const p = await kvGet(env, k, null)
      if (!p || p.status !== 'queued') continue
      p.status = 'processing'
      p.claimedBy = device.id
      p.updatedAt = nowIso()
      await kvPut(env, 'po:' + p.ownerId + ':' + p.id, p)
      out.push({
        payoutId: p.id, account: p.account, holder: p.holder,
        amount: p.amount, fee: p.fee, currency: (await getConfig(env)).currency,
      })
    }
  }
  return { tasks: out.slice(0, 20), device: device.id }
}

export async function executorReceipt(env, device, payload) {
  const payoutId = safeStr(payload.payoutId, 40)
  let p = null
  const users = await listUsers(env)
  for (const u of users) {
    const t = await kvGet(env, 'po:' + u.id + ':' + payoutId, null)
    if (t) { p = t; break }
  }
  if (!p) throw httpError(404, '出款单不存在')
  if (p.status === 'paid') return { ok: true, payout: p, duplicate: true }
  if (['queued', 'processing'].indexOf(p.status) < 0) throw httpError(409, '该出款单当前状态不可回执：' + p.status)
  const ok = !!payload.ok
  if (ok && !/^\d{5,}$/.test(safeStr(payload.bankTxid, 64))) {
    throw httpError(400, '出款成功必须提供银行/钱包流水号（至少 5 位数字）')
  }
  p.bankTxid = safeStr(payload.bankTxid, 64)
  p.receiptAt = nowIso()
  p.receiptBy = device.id
  p.updatedAt = nowIso()
  if (ok) {
    p.status = 'paid'
    await kvPut(env, 'po:' + p.ownerId + ':' + payoutId, p)
    await ledgerAppend(env, p.ownerId, {
      type: 'payout', direction: 'out', amount: p.amount, fee: p.fee, refId: p.id,
      extId: p.bankTxid, note: '出款完成',
    })
    await bumpStats(env, p.ownerId, { payoutTotal: p.amount, payoutCount: 1 })
    // 平台使用费（出款环节计提模式）：仅当配置为「仅在出款时计提」时，于出款真正完成时向代理分级账户计提
    const cfgP = await getConfig(env)
    if (cfgP.platformFeeOnCollect === false) {
      const pf = await chargePlatformFee(env, { id: p.id, ownerId: p.ownerId }, p.amount, '出款完成')
      if (pf.fee > 0 || pf.due > 0) {
        p.platformFee = pf.fee
        p.platformFeeDue = pf.due
        await kvPut(env, 'po:' + p.ownerId + ':' + payoutId, p)
      }
    }
    await addAudit(env, 'system', 'payout.paid', { payoutId: p.id, amount: p.amount, txid: p.bankTxid })
  } else {
    p.status = 'failed'
    p.rejectReason = safeStr(payload.reason, 120) || '执行端回执失败'
    await kvPut(env, 'po:' + p.ownerId + ':' + payoutId, p)
    await releaseHold(env, p, '出款失败，额度退回：' + p.rejectReason)
    await addAudit(env, 'system', 'payout.failed', { payoutId: p.id, reason: p.rejectReason })
  }
  return { ok: true, payout: p }
}

/* ============================== 设备注册 ============================== */
export async function listDevices(env, actor) {
  const owners = await visibleOwnerIds(env, actor)
  const out = []
  for (const oid of owners) {
    const keys = await kvList(env, 'dev:' + oid + ':')
    for (const k of keys) {
      const d = await kvGet(env, k, null)
      if (d) out.push({ id: d.id, ownerId: d.ownerId, type: d.type, label: d.label, phone: maskPhone(d.phone), status: d.status, keyMasked: d.keyMasked || maskAccount(d.key), createdAt: d.createdAt, lastSeenAt: d.lastSeenAt })
    }
  }
  return out
}

export async function createDevice(env, actor, payload) {
  const type = ['notify', 'payout', 'both'].indexOf(payload.type) >= 0 ? payload.type : 'both'
  const id = makeId('dev')
  const key = 'dk_' + await randomToken(20)
  const keyHash = await sha256hex('dk:' + key)
  const d = {
    id: id, ownerId: actor.id, rootId: actor.rootId || actor.id, type: type,
    label: safeStr(payload.label, 40) || ('设备 ' + id.slice(-4)),
    phone: normalizePhoneSafe(payload.phone), keyHash: keyHash, keyMasked: maskAccount(key), status: 'active',
    createdAt: nowIso(), lastSeenAt: null,
  }
  await kvPut(env, 'dev:' + actor.id + ':' + id, d)
  // 只存哈希索引：明文设备密钥仅在本次响应里回显一次
  await kvPut(env, 'devkeyhash:' + keyHash, { deviceId: id, ownerId: actor.id })
  await addAudit(env, actor.id, 'device.create', { deviceId: id, type: type })
  return Object.assign({}, stripSensitive(d), { keyPlain: key })
}

function normalizePhoneSafe(phone) {
  return safeStr(phone, 24)
}

export async function deleteDevice(env, actor, id) {
  const d = await kvGet(env, 'dev:' + actor.id + ':' + id, null)
  if (!d) throw httpError(404, '资源不存在')
  d.status = 'disabled'
  await kvPut(env, 'dev:' + actor.id + ':' + id, d)
  if (d.keyHash) await kvDel(env, 'devkeyhash:' + d.keyHash)
  if (d.key) await kvDel(env, 'devkey:' + d.key) // 兼容历史明文索引
  await addAudit(env, actor.id, 'device.disable', { deviceId: id })
  return Object.assign({}, stripSensitive(d))
}

export async function resolveDevice(env, deviceKey) {
  const globalKey = env && env.DEVICE_KEY
  if (globalKey && deviceKey && (await timingSafeEqual(deviceKey, globalKey))) {
    const superUser = await getUser(env, 'u_super')
    return { id: 'device-env', ownerId: superUser ? superUser.id : 'u_super', type: 'both', label: '环境变量设备', status: 'active' }
  }
  const k = safeStr(deviceKey, 80)
  const hash = await sha256hex('dk:' + k)
  let idx = await kvGet(env, 'devkeyhash:' + hash, null)
  if (!idx) idx = await kvGet(env, 'devkey:' + k, null) // 兼容历史明文索引
  if (!idx) return null
  const d = await kvGet(env, 'dev:' + idx.ownerId + ':' + idx.deviceId, null)
  if (!d || d.status !== 'active') return null
  d.lastSeenAt = nowIso()
  await kvPut(env, 'dev:' + idx.ownerId + ':' + idx.deviceId, d)
  const out = Object.assign({}, stripSensitive(d), { key: k })
  return out
}

/* ============================== 平台适配器（无文档跨平台接入） ============================== */
export async function listAdapters(env, actor) {
  const owners = await visibleOwnerIds(env, actor)
  const out = []
  for (const oid of owners) {
    const keys = await kvList(env, 'adp:' + oid + ':')
    for (const k of keys) {
      const a = await kvGet(env, k, null)
      if (a) out.push(publicAdapter(a))
    }
  }
  return out
}

function publicAdapter(a) {
  const base = stripSensitive(a)
  return Object.assign(base, {
    signSecretMasked: a.signSecretMasked || (a.signSecret ? maskAccount(a.signSecret) : ''),
    hasSecret: !!(a.signSecretCipher || a.signSecret),
    callbackUrl: '/api/adapter/callback/' + a.id,
    gameCallbackUrl: '/api/game/callback/' + a.id,
  })
}

/** 适配器签名密钥：优先读密文解密；兼容历史明文记录 */
export async function adapterSecret(env, a) {
  if (!a) return ''
  if (a.signSecretCipher) {
    try { return await decryptField(env, a.signSecretCipher) } catch (e) { return '' }
  }
  return a.signSecret || ''
}

export async function createAdapter(env, actor, payload) {
  const id = makeId('adp')
  const mode = ['hosted', 'sdk', 'api'].indexOf(payload.mode) >= 0 ? payload.mode : 'hosted'
  const secret = safeStr(payload.signSecret, 80) || await randomToken(16)
  const a = {
    id: id, ownerId: actor.id, rootId: actor.rootId || actor.id,
    name: safeStr(payload.name, 40) || '平台适配器',
    platform: safeStr(payload.platform, 40) || 'custom',
    mode: mode,
    targetUrl: safeStr(payload.targetUrl, 300),
    signSecretCipher: await encryptField(env, secret),   // 密钥与配置分离：明文不落库
    signSecretMasked: maskAccount(secret),
    amountField: safeStr(payload.amountField, 40) || 'amount',
    orderIdField: safeStr(payload.orderIdField, 40) || 'orderId',
    status: 'active',
    createdAt: nowIso(), updatedAt: nowIso(),
  }
  await kvPut(env, 'adp:' + actor.id + ':' + id, a)
  await kvPut(env, 'adpcb:' + id, { ownerId: actor.id, adapterId: id })
  await addAudit(env, actor.id, 'adapter.create', { adapterId: id, mode: mode })
  // 明文仅在创建响应中回显一次
  return Object.assign(publicAdapter(a), { signSecretPlain: secret })
}

export async function deleteAdapter(env, actor, id) {
  const a = await kvGet(env, 'adp:' + actor.id + ':' + id, null)
  if (!a) throw httpError(404, '资源不存在')
  a.status = 'disabled'
  a.updatedAt = nowIso()
  await kvPut(env, 'adp:' + actor.id + ':' + id, a)
  await addAudit(env, actor.id, 'adapter.disable', { adapterId: id })
  return publicAdapter(a)
}

/**
 * 回调入站统一鉴权（适配器回调 / 游戏发货回执共用）：
 *   1) 强制要求 X-Signature（HMAC-SHA256 over 原始请求体），缺失或错误一律 401；
 *   2) 若同时提供 X-Timestamp / X-Nonce，则叠加时间戳偏差 + nonce 一次性防重放；
 *   3) 签名密钥为适配器密钥（与商户 API 接入使用同一套签名串规范）。
 */
async function verifyCallbackAuth(env, a, raw, headers, scope) {
  const sig = headerOf(headers, 'X-Signature') || headerOf(headers, 'X-Sign')
  const ts = headerOf(headers, 'X-Timestamp')
  const nonce = headerOf(headers, 'X-Nonce')
  if (!sig) throw httpError(401, '缺少 X-Signature 回调签名（请按接入规范使用适配器密钥签名）')
  if (ts && nonce) await guardReplay(env, scope + ':' + a.id, headers)
  const expect = await hmacHex(await adapterSecret(env, a), raw)
  if (!(await timingSafeEqual(String(sig).toLowerCase(), String(expect).toLowerCase()))) {
    throw httpError(401, '签名校验失败')
  }
}

/** 持牌通道 / 第三方平台回调（路径 B）：验签后直接核销 */
export async function handleAdapterCallback(env, adapterId, body, headers) {
  const a = await loadAdapter(env, adapterId)
  const raw = typeof body === 'string' ? body : JSON.stringify(body)
  await verifyCallbackAuth(env, a, raw, headers, 'adpcb')
  const data = typeof body === 'string' ? safeJsonParse(body) : body
  const orderId = safeStr(data.orderId || data[a.orderIdField], 60)
  const amount = toInt(data.amount !== undefined ? data.amount : data[a.amountField], 0)
  const order = await findOrderForAdapter(env, a, orderId)
  if (!order) throw httpError(404, '未找到对应订单')
  const res = await settleOrder(env, order, {
    amount: amount || order.payable, txid: safeStr(data.txid, 64) || ('ADP' + Date.now()),
    source: 'adapter',
  })
  return { ok: true, orderId: order.id, status: res.order.status, stage: res.order.stage }
}

/** 游戏发货回执：平台发币/发货完成后回调，标记已发货并自动收货转款到户（游戏闭环） */
export async function handleGameCallback(env, adapterId, body, headers) {
  const a = await loadAdapter(env, adapterId)
  const raw = typeof body === 'string' ? body : JSON.stringify(body)
  await verifyCallbackAuth(env, a, raw, headers, 'gamecb')
  const data = typeof body === 'string' ? safeJsonParse(body) : body
  const ref = safeStr(data.orderId || data[a.orderIdField] || data.merchantOrderId, 60)
  const order = await findOrderForAdapter(env, a, ref)
  if (!order) throw httpError(404, '未找到对应订单')
  if (order.scene !== 'game') throw httpError(400, '仅游戏订单支持发货回执')
  const action = safeStr(data.action, 20) || 'grant'
  if (action !== 'grant') throw httpError(400, '不支持的回执动作：' + action)
  const r = await grantGameOrder(env, order, {
    ok: data.ok !== false, txid: safeStr(data.txid, 64), auto: true,
    quantity: toInt(data.quantity, order.quantity), itemCode: safeStr(data.itemCode, 60) || order.itemCode,
  })
  return { ok: true, orderId: order.id, stage: r.stage, grantStatus: r.grantStatus, settleNet: r.settleNet || 0 }
}

/** 游戏发货回执核心：写入发币回执，成功后立刻收货并转款到户 */
export async function grantGameOrder(env, order, payload) {
  const p = payload || {}
  if (!order) throw httpError(404, '订单不存在')
  if (order.scene !== 'game') throw httpError(400, '仅游戏订单支持发货回执')
  if (order.grantTxid) return order
  if (order.status !== 'paid') throw httpError(409, '订单尚未到账，无法回执发货')
  order.grantStatus = p.ok === false ? 'failed' : 'granted'
  order.grantTxid = safeStr(p.txid, 64)
  order.grantAt = nowIso()
  order.updatedAt = nowIso()
  await kvPut(env, 'ord:' + order.ownerId + ':' + order.id, order)
  await addAudit(env, 'system', 'game.grant', { orderId: order.id, ok: order.grantStatus === 'granted', txid: order.grantTxid })
  if (order.grantStatus !== 'granted') return order
  // 游戏发货即视为已发货，随后自动收货并转款到户
  if (order.stage === 'paid') order = await applyDelivery(env, order, { auto: true, by: 'game' })
  return await receiveAndSettle(env, order, { auto: true, by: 'game', forceSettle: true })
}

async function loadAdapter(env, adapterId) {
  const idx = await kvGet(env, 'adpcb:' + adapterId, null)
  if (!idx) throw httpError(404, '资源不存在')
  const a = await kvGet(env, 'adp:' + idx.ownerId + ':' + idx.adapterId, null)
  if (!a || a.status !== 'active') throw httpError(403, '适配器已停用')
  return a
}

/** 按订单号 / 商户订单号在适配器归属范围内定位订单 */
async function findOrderForAdapter(env, a, ref) {
  if (!ref) return null
  const owner = await getUser(env, a.ownerId)
  const owners = owner ? await visibleOwnerIds(env, owner) : [a.ownerId]
  for (const oid of owners) {
    const direct = await kvGet(env, 'ord:' + oid + ':' + ref, null)
    if (direct) return direct
    const keys = await kvList(env, 'ord:' + oid + ':')
    for (const k of keys) {
      const cand = await kvGet(env, k, null)
      if (cand && cand.merchantOrderId && cand.merchantOrderId === ref) return cand
    }
  }
  return null
}

function safeJsonParse(s) {
  try { return JSON.parse(s) } catch (e) { return {} }
}

/* ============================== 回调（Webhook）投递与重试 ============================== */
export async function enqueueWebhook(env, order, event, override) {
  const cfg = await getConfig(env)
  let url = ''
  let secret = ''
  if (override && override.url) { url = override.url; secret = override.secret || '' }
  else if (order.adapterId) {
    const owners = await visibleOwnerIds(env, await getUser(env, order.ownerId))
    for (const oid of owners) {
      const a = await kvGet(env, 'adp:' + oid + ':' + order.adapterId, null)
      if (a) { url = a.targetUrl; secret = await adapterSecret(env, a); break }
    }
    if (!url) {
      const a = await kvGet(env, 'adp:' + order.ownerId + ':' + order.adapterId, null)
      if (a) { url = a.targetUrl; secret = await adapterSecret(env, a) }
    }
  }
  if (!url) return null
  const id = makeId('wh')
  const rec = {
    id: id, url: url, secretCipher: secret ? await encryptField(env, secret) : '', event: event, orderId: order.id,
    order: stripSensitive(order, 0),
    attempts: 0, maxAttempts: toInt(cfg.webhookRetries, 5),
    nextAt: nowIso(), status: 'pending', lastError: '', createdAt: nowIso(),
  }
  await kvPut(env, 'wh:' + id, rec)
  await kvPut(env, 'whidx:' + order.id + ':' + id, { id: id })
  return rec
}

export async function runWebhooks(env, limit) {
  const keys = await kvList(env, 'wh:')
  const now = Date.now()
  const cfg = await getConfig(env)
  let delivered = 0, failed = 0, processed = 0
  for (const k of keys) {
    if (processed >= (limit || 30)) break
    const rec = await kvGet(env, k, null)
    if (!rec || rec.status !== 'pending') continue
    if (Date.parse(rec.nextAt) > now) continue
    processed++
    const o = rec.order || {}
    const dv = o.delivery || {}
    // 回调体自带完成一笔业务所需的全部字段：平台无需任何对接文档即可发货/发币
    const body = JSON.stringify({
      event: rec.event, orderId: o.id, merchantOrderId: o.merchantOrderId || '',
      scene: o.scene || '', stage: o.stage || '', status: o.status || '',
      amount: o.amount || 0, payable: o.payable || 0, txid: o.paidTxid || '',
      currency: cfg.currency, subject: o.subject || '', customer: o.customer || '',
      delivery: { type: o.deliveryType || '', itemName: dv.itemName || '', trackingNo: dv.trackingNo || '', deliveryUrl: dv.deliveryUrl || '' },
      game: { account: o.gameAccount || '', role: o.gameRole || '', zone: o.gameZone || '', itemCode: o.itemCode || '', quantity: o.quantity || 1 },
      settle: { amount: o.settleAmount || 0, fee: o.settleFee || 0, net: o.settleNet || 0 },
      ts: nowIso(),
    })
    const secret = rec.secretCipher ? await decryptField(env, rec.secretCipher) : (rec.secret || '')
    const signature = await hmacHex(secret || '', body)
    let ok = false, err = ''
    try {
      const r = await fetch(rec.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Signature': signature, 'X-Event': String(rec.event) },
        body: body,
      })
      ok = r.status >= 200 && r.status < 300
      if (!ok) err = 'HTTP ' + r.status
    } catch (e) {
      err = String(e && e.message || e)
    }
    rec.attempts = toInt(rec.attempts, 0) + 1
    rec.lastError = err
    if (ok) {
      rec.status = 'delivered'
      rec.deliveredAt = nowIso()
      delivered++
    } else if (rec.attempts >= toInt(rec.maxAttempts, 5)) {
      rec.status = 'failed'
      failed++
    } else {
      const backoff = toInt(cfg.webhookBackoffSec, 30) * Math.pow(2, rec.attempts - 1)
      rec.nextAt = new Date(Date.now() + backoff * 1000).toISOString()
    }
    await kvPut(env, 'wh:' + rec.id, rec)
  }
  return { delivered: delivered, failed: failed, processed: processed }
}

export async function listWebhooks(env, actor) {
  const owners = await visibleOwnerIds(env, actor)
  const ownerSet = {}
  owners.forEach(function (o) { ownerSet[o] = 1 })
  const keys = await kvList(env, 'wh:')
  const out = []
  for (const k of keys) {
    const r = await kvGet(env, k, null)
    if (!r) continue
    const o = r.order || {}
    if (!ownerSet[o.ownerId]) continue
    out.push({ id: r.id, orderId: r.orderId, ownerId: o.ownerId, url: r.url, status: r.status, attempts: r.attempts, lastError: r.lastError, nextAt: r.nextAt })
  }
  return out.slice(0, 200)
}

export async function retryWebhook(env, actor, id) {
  const rec = await kvGet(env, 'wh:' + id, null)
  if (!rec) throw httpError(404, '资源不存在')
  const o = rec.order || {}
  if (!(await canAccessOwner(env, actor, o.ownerId))) throw httpError(404, '资源不存在')
  rec.status = 'pending'
  rec.nextAt = nowIso()
  await kvPut(env, 'wh:' + id, rec)
  const r = await runWebhooks(env, 1)
  return { ok: true, ...r }
}

/* ============================== 资金池业务动作 ============================== */
export async function setPoolAccounts(env, actor, payload) {
  assertSuper(actor)
  const list = Array.isArray(payload.accounts) ? payload.accounts : []
  const pool = await getPool(env)
  const accounts = []
  for (const a of list) {
    const account = safeStr(a.account, 32).replace(/[\s-]/g, '')
    if (!/^\d{6,20}$/.test(account)) throw httpError(400, '资金池账号需为 6-20 位数字')
    let channelId = a.channelId
    if (!channelId) {
      const exist = await kvGet(env, 'chanacct:' + account, null)
      if (exist) channelId = exist.channelId
      else {
        channelId = makeId('chp')
        const ch = {
          id: channelId, ownerId: 'pool', rootId: 'pool', account: account,
          holder: safeStr(a.holder, 60) || '资金池', phone: '', bank: 'KBZPay',
          label: safeStr(a.label, 40) || '资金池账户', status: 'active', primary: false,
          priority: 1, dailyLimit: 0, cooldownSec: 900, totalReceived: 0,
          createdAt: nowIso(), updatedAt: nowIso(), version: 1,
        }
        await kvPut(env, 'chan:pool:' + channelId, ch)
        await kvPut(env, 'chanacct:' + account, { channelId: channelId, ownerId: 'pool', status: 'active' })
      }
    }
    accounts.push({ channelId: channelId, account: account, holder: safeStr(a.holder, 60) || '资金池', status: 'active', depositReceive: a.depositReceive !== false })
  }
  await setPool(env, { accounts: accounts })
  await addAudit(env, actor.id, 'pool.accounts', { count: accounts.length })
  const p = await getPool(env)
  return p
}

/** 超管代记保证金（线下已收） */
export async function depositTopup(env, actor, payload) {
  assertSuper(actor)
  const agentId = safeStr(payload.agentId, 40)
  const agent = await getUser(env, agentId)
  if (!agent || agent.role !== 'agent') throw httpError(400, '目标必须是代理账号')
  const amount = toInt(payload.amount, 0)
  if (amount <= 0) throw httpError(400, '金额必须大于 0')
  const d = await getDeposit(env, agentId)
  await setDeposit(env, agentId, { paid: toInt(d.paid, 0) + amount })
  const pool = await getPool(env)
  await setPool(env, {
    balance: toInt(pool.balance, 0) + amount,
    depositTotal: toInt(pool.depositTotal, 0) + amount,
  })
  await poolLedgerAppend(env, { type: 'deposit_in', agentId: agentId, amount: amount, note: safeStr(payload.note, 120) || '超管代记保证金' })
  await ledgerAppend(env, agentId, { type: 'deposit', direction: 'out', amount: amount, note: '缴纳保证金（超管代记）' })
  await ledgerAppend(env, 'pool', { type: 'deposit_in', direction: 'in', amount: amount, agentId: agentId, note: '保证金入池' })
  await bumpStats(env, 'pool', { balance: amount, collectTotal: amount, collectCount: 1 })
  await addAudit(env, actor.id, 'deposit.topup', { agentId: agentId, amount: amount })
  return await getDeposit(env, agentId)
}

/** 违规违法扣罚：从保证金中扣除，转为超管资金池已扣罚金额 */
export async function applyPenalty(env, actor, payload) {
  assertSuper(actor)
  const agentId = safeStr(payload.agentId, 40)
  const agent = await getUser(env, agentId)
  if (!agent || agent.role !== 'agent') throw httpError(400, '目标必须是代理账号')
  const amount = toInt(payload.amount, 0)
  if (amount <= 0) throw httpError(400, '扣罚金额必须大于 0')
  const d = await getDeposit(env, agentId)
  if (toInt(d.paid, 0) < amount) throw httpError(409, '保证金余额不足，无法扣罚（当前 ' + d.paid + '）')
  const id = makeId('pen')
  const reason = safeStr(payload.reason, 200) || '违反当地规定 / 违法行为'
  const rec = {
    id: id, agentId: agentId, amount: amount, reason: reason,
    evidence: safeStr(payload.evidence, 300), status: 'applied',
    operator: actor.id, createdAt: nowIso(), resolvedAt: null,
  }
  await kvPut(env, 'pen:' + agentId + ':' + id, rec)
  await setDeposit(env, agentId, {
    paid: toInt(d.paid, 0) - amount,
    penalty: toInt(d.penalty, 0) + amount,
  })
  const pool = await getPool(env)
  await setPool(env, { penaltyTotal: toInt(pool.penaltyTotal, 0) + amount })
  await poolLedgerAppend(env, { type: 'penalty', agentId: agentId, amount: amount, refId: id, note: reason })
  await ledgerAppend(env, agentId, { type: 'penalty', direction: 'out', amount: amount, refId: id, note: reason })
  await addAudit(env, actor.id, 'pool.penalty', { agentId: agentId, amount: amount, reason: reason })
  return { penalty: rec, deposit: await getDeposit(env, agentId) }
}

export async function listPenalties(env, actor, filter) {
  const owners = await visibleOwnerIds(env, actor)
  const out = []
  for (const oid of owners) {
    if (oid === 'pool') continue
    const keys = await kvList(env, 'pen:' + oid + ':')
    for (const k of keys) {
      const r = await kvGet(env, k, null)
      if (r) out.push(r)
    }
  }
  if (filter && filter.agentId) return out.filter(function (r) { return r.agentId === filter.agentId })
  return out
}

/** 扣罚申诉 → 超管复核退还 */
export async function appealPenalty(env, actor, id, note) {
  const owners = await visibleOwnerIds(env, actor)
  for (const oid of owners) {
    const r = await kvGet(env, 'pen:' + oid + ':' + id, null)
    if (r) {
      r.status = 'appealed'
      r.appealNote = safeStr(note, 200)
      r.appealedAt = nowIso()
      await kvPut(env, 'pen:' + oid + ':' + id, r)
      await addAudit(env, actor.id, 'pool.penalty.appeal', { penaltyId: id })
      return r
    }
  }
  throw httpError(404, '资源不存在')
}

export async function resolvePenalty(env, actor, id, payload) {
  assertSuper(actor)
  const agentId = safeStr(payload.agentId, 40)
  const r = await kvGet(env, 'pen:' + agentId + ':' + id, null)
  if (!r) throw httpError(404, '资源不存在')
  if (r.status !== 'appealed') throw httpError(409, '仅已申诉的扣罚可复核')
  const refund = toInt(payload.refundAmount, r.amount)
  if (refund > r.amount) throw httpError(400, '退还金额不得超过扣罚金额')
  if (refund > 0) {
    const d = await getDeposit(env, agentId)
    await setDeposit(env, agentId, {
      paid: toInt(d.paid, 0) + refund,
      penalty: Math.max(0, toInt(d.penalty, 0) - refund),
    })
    const pool = await getPool(env)
    await setPool(env, { penaltyTotal: Math.max(0, toInt(pool.penaltyTotal, 0) - refund) })
    await poolLedgerAppend(env, { type: 'penalty_refund', agentId: agentId, amount: refund, refId: id, note: '扣罚复核退还' })
    await ledgerAppend(env, agentId, { type: 'penalty_refund', direction: 'in', amount: refund, refId: id, note: '扣罚复核退还' })
  }
  r.status = 'resolved'
  r.refundAmount = refund
  r.resolvedAt = nowIso()
  r.operator = actor.id
  await kvPut(env, 'pen:' + agentId + ':' + id, r)
  await addAudit(env, actor.id, 'pool.penalty.resolve', { penaltyId: id, refund: refund })
  return r
}

/** 保证金退还（退出合作时） */
export async function refundDeposit(env, actor, payload) {
  assertSuper(actor)
  const agentId = safeStr(payload.agentId, 40)
  const agent = await getUser(env, agentId)
  if (!agent || agent.role !== 'agent') throw httpError(400, '目标必须是代理账号')
  const amount = toInt(payload.amount, 0)
  if (amount <= 0) throw httpError(400, '金额必须大于 0')
  const d = await getDeposit(env, agentId)
  const pending = (await listPenalties(env, actor, { agentId: agentId })).filter(function (r) { return r.status === 'appealed' })
  if (pending.length) throw httpError(409, '该代理存在未复核的扣罚申诉，暂不可退还保证金')
  const available = toInt(d.paid, 0)
  if (available < amount) throw httpError(409, '可退保证金不足（当前 ' + available + '）')
  const id = makeId('dref')
  await setDeposit(env, agentId, { paid: available - amount, refunded: toInt(d.refunded, 0) + amount })
  const pool = await getPool(env)
  await setPool(env, {
    balance: toInt(pool.balance, 0) - amount,
    depositTotal: Math.max(0, toInt(pool.depositTotal, 0) - amount),
    refundTotal: toInt(pool.refundTotal, 0) + amount,
  })
  await poolLedgerAppend(env, { type: 'deposit_refund', agentId: agentId, amount: amount, refId: id, note: safeStr(payload.note, 120) || '保证金退还' })
  await ledgerAppend(env, agentId, { type: 'deposit_refund', direction: 'in', amount: amount, refId: id, note: '保证金退还' })
  await ledgerAppend(env, 'pool', { type: 'deposit_refund', direction: 'out', amount: amount, agentId: agentId, refId: id, note: '保证金退还出池' })
  await bumpStats(env, 'pool', { balance: -amount })
  await addAudit(env, actor.id, 'pool.deposit.refund', { agentId: agentId, amount: amount })
  return await getDeposit(env, agentId)
}

/** 系统租用金：代理按期向超管资金池缴纳 */
export async function chargeRental(env, actor, payload) {
  assertSuper(actor)
  const agentId = safeStr(payload.agentId, 40)
  const agent = await getUser(env, agentId)
  if (!agent || agent.role !== 'agent') throw httpError(400, '目标必须是代理账号')
  const cfg = await getConfig(env)
  const amount = toInt(payload.amount, toInt(cfg.rentalFeeMonthly, 0))
  if (amount <= 0) throw httpError(400, '金额必须大于 0')
  const period = safeStr(payload.period, 20) || new Date().toISOString().slice(0, 7)
  const id = makeId('rent')
  const rec = {
    id: id, agentId: agentId, amount: amount, period: period,
    status: 'paid', paidBy: safeStr(payload.paidBy, 60) || '超管代记',
    operator: actor.id, note: safeStr(payload.note, 120), createdAt: nowIso(),
  }
  await kvPut(env, 'rent:' + agentId + ':' + id, rec)
  const pool = await getPool(env)
  await setPool(env, {
    balance: toInt(pool.balance, 0) + amount,
    rentalTotal: toInt(pool.rentalTotal, 0) + amount,
  })
  await poolLedgerAppend(env, { type: 'rental_in', agentId: agentId, amount: amount, refId: id, note: '系统租用金（' + period + '）' })
  await ledgerAppend(env, agentId, { type: 'rental', direction: 'out', amount: amount, refId: id, note: '系统租用金 ' + period })
  await ledgerAppend(env, 'pool', { type: 'rental_in', direction: 'in', amount: amount, agentId: agentId, refId: id, note: '租用金入池' })
  await bumpStats(env, 'pool', { balance: amount })
  await addAudit(env, actor.id, 'pool.rental', { agentId: agentId, amount: amount, period: period })
  return rec
}

export async function listRentals(env, actor, filter) {
  const owners = await visibleOwnerIds(env, actor)
  const out = []
  for (const oid of owners) {
    if (oid === 'pool') continue
    const keys = await kvList(env, 'rent:' + oid + ':')
    for (const k of keys) {
      const r = await kvGet(env, k, null)
      if (r) out.push(r)
    }
  }
  if (filter && filter.agentId) return out.filter(function (r) { return r.agentId === filter.agentId })
  return out
}

/* ============================== 组织树 / 总览 ============================== */
export async function buildTree(env, actor) {
  const users = await listUsers(env)
  const mine = users.filter(function (u) {
    return u.id === actor.id || (actor.role !== 'merchant' && isDescendantOf(actor.path, u))
  })
  const ids = mine.map(function (u) { return u.id })
  const nodes = []
  for (const u of mine) {
    const st = u.role === 'super' ? null : await getStats(env, u.id)
    const dep = u.role === 'agent' ? await getDeposit(env, u.id) : null
    nodes.push(Object.assign(publicUser(u), {
      childCount: mine.filter(function (x) { return x.parentId === u.id }).length,
      stats: st,
      deposit: dep,
    }))
  }
  return { nodes: nodes, count: ids.length }
}

export async function overview(env, actor) {
  const cfg = await getConfig(env)
  const users = await listUsers(env)
  const orders = await listOrders(env, actor, { limit: 1000 })
  const payouts = await listPayouts(env, actor, { limit: 1000 })
  const visible = await visibleOwnerIds(env, actor)
  const agents = users.filter(function (u) { return u.role === 'agent' && visible.indexOf(u.id) >= 0 })
  const merchants = users.filter(function (u) { return u.role === 'merchant' && visible.indexOf(u.id) >= 0 })
  const collectTotal = orders.filter(function (o) { return o.status === 'paid' }).reduce(function (s, o) { return s + (o.amount || 0) }, 0)
  const pendingCount = orders.filter(function (o) { return o.status === 'pending' }).length
  const payoutPending = payouts.filter(function (p) { return p.status === 'pending' }).length
  const payoutQueued = payouts.filter(function (p) { return p.status === 'queued' }).length
  // 履约漏斗：待发货 / 待收货（托管中）/ 已转款到户
  const toDeliver = orders.filter(function (o) { return o.status === 'paid' && o.escrow === true && (o.stage || 'paid') === 'paid' }).length
  const toReceive = orders.filter(function (o) { return o.stage === 'delivered' }).length
  const escrowOrders = orders.filter(function (o) { return o.escrow === true && o.status === 'paid' && o.stage !== 'settled' })
  const escrowTotal = escrowOrders.reduce(function (s, o) { return s + (o.amount || 0) }, 0)
  const settledOrders = orders.filter(function (o) { return o.stage === 'settled' })
  const settledTotal = settledOrders.reduce(function (s, o) { return s + toInt(o.settleAmount, 0) }, 0)
  const st = actor.role === 'super' ? null : await getStats(env, actor.id)
  const result = {
    role: actor.role,
    currency: cfg.currency,
    agents: agents.length,
    merchants: merchants.length,
    orders: orders.length,
    collectTotal: collectTotal,
    collectCount: orders.filter(function (o) { return o.status === 'paid' }).length,
    pendingOrders: pendingCount,
    payoutPending: payoutPending,
    payoutQueued: payoutQueued,
    balance: st ? st.balance : null,
    escrow: st ? toInt(st.escrow, 0) : escrowTotal,
    toDeliver: toDeliver,
    toReceive: toReceive,
    escrowTotal: escrowTotal,
    settledTotal: settledTotal,
    settledCount: settledOrders.length,
    limits: { autoPayoutLimit: cfg.autoPayoutLimit, minWithdraw: cfg.minWithdraw, withdrawFeeRate: cfg.withdrawFeeRate, settleFeeRate: cfg.settleFeeRate, autoReceiveHours: cfg.autoReceiveHours },
    deposit: actor.role === 'agent' ? await getDeposit(env, actor.id) : null,
    updatedAt: nowIso(),
  }
  if (actor.role === 'super') {
    const pool = await getPool(env)
    result.pool = pool
    result.depositAgents = (await listDeposits(env, actor)).map(function (d) {
      return { agentId: d.agentId, paid: d.paid, required: d.required, penalty: d.penalty, sufficient: d.sufficient }
    })
    result.rentalTotal = pool.rentalTotal
    result.penaltyTotal = pool.penaltyTotal
    // 超管层级账户：只收各代理分级账户的使用费 + 保证金/租用金收款归集
    result.platform = await platformAccount(env)
    result.platformFeeTotal = toInt(result.platform.platformFeeTotal, 0)
    result.platformFeeRate = Number(cfg.platformFeeRate || 0)
  }
  if (actor.role === 'agent' || actor.role === 'merchant') {
    result.platformFeeRate = Number(cfg.platformFeeRate || 0)
    result.platformFee = toInt((await getStats(env, actor.id)).platformFee, 0)
  }
  return result
}

/* ============================== 代理租用与保证金总表（超管） ============================== */
/** 某月（offset=0 本月 / 1 下月）的首日，用于「下次到期日」口径 */
function monthFirstDay(offset) {
  const d = new Date()
  d.setUTCDate(1)
  d.setUTCMonth(d.getUTCMonth() + (offset || 0))
  return d.toISOString().slice(0, 10)
}

function isoDay(d) {
  return new Date(d.getTime()).toISOString().slice(0, 10)
}

export const RENTAL_CYCLE_TEXT = { monthly: '自然月', quarterly: '自然季度', yearly: '自然年' }
export const RENTAL_OVERDUE_TEXT = { restrict: '逾期即限制业务', remind: '仅提醒不限制' }

/**
 * 计费周期与到期口径（由超管「费用与时间管理」驱动）：
 *   cycle 计费周期（monthly/quarterly/yearly）→ 本期周期标签（2026-10 / 2026-Q4 / 2026）
 *   dueDay 到期日（每期第几号截止缴费）→ dueDate；graceDays 宽限期 → graceUntil
 *   下一期到期日 nextDueDate；当前是否处于宽限期 inGrace / 是否已逾期 late。
 */
export function rentalPeriodInfo(cfg) {
  const cycle = String(cfg.rentalBillingCycle || 'monthly')
  const dueDay = Math.min(Math.max(toInt(cfg.rentalDueDay, 1), 1), 28)
  const graceDays = Math.max(0, toInt(cfg.rentalGraceDays, 3))
  const now = new Date()
  const y = now.getUTCFullYear()
  const mo = now.getUTCMonth()
  let period, periodStart, dueMonthOffset
  if (cycle === 'yearly') {
    period = String(y)
    periodStart = new Date(Date.UTC(y, 0, 1))
    dueMonthOffset = 0
  } else if (cycle === 'quarterly') {
    const q = Math.floor(mo / 3)
    period = y + '-Q' + (q + 1)
    periodStart = new Date(Date.UTC(y, q * 3, 1))
    dueMonthOffset = q * 3
  } else {
    period = y + '-' + String(mo + 1).padStart(2, '0')
    periodStart = new Date(Date.UTC(y, mo, 1))
    dueMonthOffset = mo
  }
  const dueDate = new Date(Date.UTC(y, dueMonthOffset, dueDay))
  const graceUntil = new Date(dueDate.getTime() + graceDays * 86400000)
  let nextDue
  if (cycle === 'yearly') nextDue = new Date(Date.UTC(y + 1, 0, dueDay))
  else if (cycle === 'quarterly') nextDue = new Date(Date.UTC(y, dueMonthOffset + 3, dueDay))
  else nextDue = new Date(Date.UTC(y, mo + 1, dueDay))
  return {
    cycle: cycle,
    cycleText: RENTAL_CYCLE_TEXT[cycle] || cycle,
    dueDay: dueDay,
    graceDays: graceDays,
    period: period,
    periodStart: isoDay(periodStart),
    dueDate: isoDay(dueDate),
    graceUntil: isoDay(graceUntil),
    nextDueDate: isoDay(nextDue),
    inGrace: now.getTime() > dueDate.getTime() && now.getTime() <= graceUntil.getTime(),
    late: now.getTime() > graceUntil.getTime(),
    overdueDays: now.getTime() > graceUntil.getTime() ? Math.floor((now.getTime() - graceUntil.getTime()) / 86400000) : 0,
  }
}

/**
 * 代理租用与保证金总表：逐行汇总每个代理账号的
 *   月租额 / 本期缴费状态（已缴·未缴及金额）/ 到期日·宽限期至 / 应缴保证金 / 已缴保证金 / 状态。
 * 数据源：租用金记录 rent:<agentId>:<id>（chargeRental 写入）、保证金台账 dep:<agentId>（getDeposit）、
 *        默认值 cfg.rentalFeeMonthly / cfg.depositDefaultRequired；周期/到期日/宽限期来自超管费用与时间管理配置。
 * 状态口径：受限（账号停用或保证金不足）/ 逾期（已过宽限期仍未缴本期租用金）/ 宽限期（到期后仍在宽限内未缴）/ 正常。
 * 口径说明：应缴保证金以台账 dep.required 为准：代理建号时按当时的系统默认值（cfg.depositDefaultRequired）快照写入，
 *          之后可由超管逐户调整（POST /api/accounts/:id {depositRequired}）；改系统默认值只影响此后新建的代理。
 */
export async function rentalBoard(env, actor, filter) {
  const cfg = await getConfig(env)
  const f = filter || {}
  const info = rentalPeriodInfo(cfg)
  const period = info.period
  const monthly = toInt(cfg.rentalFeeMonthly, 0)
  const depositDefault = toInt(cfg.depositDefaultRequired, 0)
  const overdueAction = cfg.rentalOverdueAction === 'remind' ? 'remind' : 'restrict'
  const users = await listUsers(env)
  const rentals = await listRentals(env, actor, {})
  const all = []
  for (const u of users) {
    if (u.role !== 'agent') continue
    const dep = await getDeposit(env, u.id)
    const mine = rentals.filter(function (r) { return r.agentId === u.id })
    const cur = mine.filter(function (r) { return r.period === period })
    const periodAmount = cur.reduce(function (s, r) { return s + toInt(r.amount, 0) }, 0)
    const periodPaid = periodAmount > 0
    const sorted = mine.slice().sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)) })
    const required = toInt(dep.required, 0)
    const depositPaid = toInt(dep.paid, 0)
    const depositSufficient = depositPaid >= required
    let status = 'normal'
    let restrictRecommended = false
    if (u.status === 'disabled') status = 'restricted'
    else if (!depositSufficient) status = 'restricted'
    else if (!periodPaid) {
      if (info.late) {
        status = 'overdue'
        restrictRecommended = overdueAction === 'restrict'
      } else {
        status = 'grace'
      }
    }
    all.push({
      agentId: u.id,
      username: u.username,
      name: u.name || u.username,
      userStatus: u.status || 'active',
      monthlyFee: periodPaid ? periodAmount : monthly,   // 本期应收月租（已缴则取实缴额）
      standardFee: monthly,
      period: period,
      periodLabel: period + '（' + info.cycleText + '）',
      cycle: info.cycle,
      cycleText: info.cycleText,
      periodPaid: periodPaid,
      periodAmount: periodAmount,
      periodRecords: cur.length,
      lastPaidPeriod: sorted.length ? (sorted[0].period || '') : '',
      lastPaidAt: sorted.length ? (sorted[0].createdAt || '') : '',
      dueDate: periodPaid ? info.nextDueDate : info.dueDate,
      currentDueDate: info.dueDate,
      graceUntil: info.graceUntil,
      nextDueDate: info.nextDueDate,
      graceDays: info.graceDays,
      overdueDays: periodPaid ? 0 : info.overdueDays,
      overdueAction: overdueAction,
      restrictRecommended: restrictRecommended,
      depositRequired: required,
      depositRequiredFromDefault: u.depositRequiredSet !== true,
      depositPaid: depositPaid,
      depositPenalty: toInt(dep.penalty, 0),
      depositSufficient: depositSufficient,
      rentTotal: mine.reduce(function (s, r) { return s + toInt(r.amount, 0) }, 0),
      rentCount: mine.length,
      status: status,
    })
  }
  let rows = all
  if (f.status) rows = rows.filter(function (r) { return r.status === f.status })
  if (f.kw) {
    const kw = String(f.kw).toLowerCase()
    rows = rows.filter(function (r) {
      return (String(r.agentId) + String(r.username) + String(r.name)).toLowerCase().indexOf(kw) >= 0
    })
  }
  rows.sort(function (a, b) { return String(a.username || '').localeCompare(String(b.username || '')) })
  const cnt = function (s) { return all.filter(function (r) { return r.status === s }).length }
  return {
    currency: cfg.currency || 'MMK',
    period: period,
    cycle: info.cycle,
    cycleText: info.cycleText,
    billingCycleText: RENTAL_CYCLE_TEXT[info.cycle] || info.cycle,
    dueDay: info.dueDay,
    graceDays: info.graceDays,
    overdueAction: overdueAction,
    overdueActionText: RENTAL_OVERDUE_TEXT[overdueAction] || overdueAction,
    currentDueDate: info.dueDate,
    graceUntil: info.graceUntil,
    nextDueDate: info.nextDueDate,
    monthlyDefault: monthly,
    depositDefaultRequired: depositDefault,
    summary: {
      agents: all.length,
      normal: cnt('normal'),
      grace: cnt('grace'),
      overdue: cnt('overdue'),
      restricted: cnt('restricted'),
      restrictRecommended: all.filter(function (r) { return r.restrictRecommended }).length,
      periodPaidCount: all.filter(function (r) { return r.periodPaid }).length,
      periodUnpaidCount: all.filter(function (r) { return !r.periodPaid }).length,
      periodPaidTotal: all.reduce(function (s, r) { return s + r.periodAmount }, 0),
      periodUnpaidTotal: all.reduce(function (s, r) { return s + (r.periodPaid ? 0 : r.standardFee) }, 0),
      depositRequiredTotal: all.reduce(function (s, r) { return s + r.depositRequired }, 0),
      depositPaidTotal: all.reduce(function (s, r) { return s + r.depositPaid }, 0),
      depositGapTotal: all.reduce(function (s, r) { return s + Math.max(0, r.depositRequired - r.depositPaid) }, 0),
    },
    filtered: rows.length,
    rows: rows.slice(0, toInt(f.limit, 500)),
  }
}

/* ============================== 代理逾期业务闸门（独立于总表展示口径） ============================== */
/**
 * 逾期业务闸门（与「代理租用与保证金」总表的展示状态相互独立，只增不减其口径）：
 *   1) 仅当超管把「逾期处置」设为 restrict（逾期即限制业务）时生效；remind 一律只提醒不限业务；
 *   2) 判定以「计费起始锚点」为准：只计该代理已经跨过的到期日——
 *      建号日不早于本期到期日的新代理，本期租用金尚不构成其义务，不会被「建号即被限制」；
 *   3) 已缴清本期租用金 → 不构成逾期；
 *   4) 沿上级链检查：下级商户 / 子代理受其归属代理的逾期状态约束（业务域一致）。
 * 豁免：保证金 / 租用金缴纳单（scene=deposit|rental）永不拦截，否则无法补缴（死锁）。
 * 返回 { restricted:boolean, action, ... }；restricted=true 时携带代理与期次信息，便于提示与审计。
 */
async function rentalPaidFor(env, agentId, period) {
  const keys = await kvList(env, 'rent:' + agentId + ':')
  for (const k of keys) {
    const r = await kvGet(env, k, null)
    if (r && r.period === period && toInt(r.amount, 0) > 0) return r
  }
  return null
}

async function agentRentalOverdue(env, agent, cfg, info) {
  if (!info.late) return null
  const createdDay = String(agent.createdAt || '').slice(0, 10)
  const anchorDay = String(agent.rentalStartAt || '').slice(0, 10) || createdDay
  // 建号日不早于本期到期日 → 本期不构成义务（首次义务自下一期到期日起算）
  if (!anchorDay || anchorDay > info.dueDate) return null
  if (await rentalPaidFor(env, agent.id, info.period)) return null
  return {
    agentId: agent.id, username: agent.username, name: agent.name || agent.username,
    period: info.period, dueDate: info.dueDate, graceUntil: info.graceUntil, overdueDays: info.overdueDays,
  }
}

export async function rentalGate(env, actor) {
  const cfg = await getConfig(env)
  const action = cfg.rentalOverdueAction === 'remind' ? 'remind' : 'restrict'
  if (!actor || action !== 'restrict') return { restricted: false, action: action }
  const info = rentalPeriodInfo(cfg)
  let node = actor
  let guard = 0
  while (node && guard++ < 12) {
    if (node.role === 'agent') {
      const hit = await agentRentalOverdue(env, node, cfg, info)
      if (hit) return Object.assign({ restricted: true, action: action }, hit)
    }
    if (node.role === 'super' || !node.parentId) break
    node = await getUser(env, node.parentId)
  }
  return { restricted: false, action: action }
}

/** 业务闸门断言：逾期且处置为 restrict 时抛 403（补救类场景请勿调用） */
export async function assertRentalOk(env, actor) {
  const r = await rentalGate(env, actor)
  if (r.restricted) {
    throw httpError(403,
      '系统租用金已逾期未缴，业务已受限：代理 ' + r.username + ' 的 ' + r.period + ' 期应于 ' + r.dueDate
      + ' 前缴清（宽限至 ' + r.graceUntil + '），已逾期 ' + r.overdueDays + ' 天；请先缴清租用金后自动恢复。',
      { code: 'RENTAL_OVERDUE', agentId: r.agentId, period: r.period, dueDate: r.dueDate, graceUntil: r.graceUntil, overdueDays: r.overdueDays })
  }
  return r
}

/* ============================== 游戏上下分指令单（玩家账号 · 闭环） ============================== */
/**
 * 业务口径（以「游戏充值ID（玩家账号）」为目标）：
 *   上分（direction=in）：玩家充值 → 平台给玩家账号加币 → 资金流入本账号（记账 +1 笔，可用余额增加）；
 *   下分（direction=out）：玩家退币/提现 → 平台从玩家账号扣币 → 资金流出本账号。
 * 闭环：创建指令（幂等）→ 执行端拉取（X-Device-Key）→ 成功 / 失败回执 → 记账与余额联动 → 失败或取消自动回滚冻结。
 * 冻结口径（与出款一致）：下分在「创建时」即冻结等额余额（ledger game_credit_hold + 余额扣减），
 *   回执成功转为实际出账（game_credit），回执失败 / 取消 / 超时释放冻结（game_credit_release + 余额回补）。
 * 归属口径：代理只能操作自己子树内的游戏ID（越权一律 404）；超管全量。
 */
export const GAME_DIRECTION_TEXT = { in: '上分（加币）', out: '下分（扣币）' }
export const GAME_STATUS_TEXT = {
  queued: '待执行', claimed: '执行中', done: '已成功', failed: '已失败',
  canceled: '已取消', rolledback: '已回滚',
}
const GAME_DIRECTIONS = ['in', 'out']

/** 游戏ID（玩家账号）归属解析：已登记的按登记归属；未登记则绑定到本次操作的归属账号
 *  越权（目标不在操作者可见范围内）一律 404，与全站「资源不存在」口径一致。 */
async function gameResolveOwner(env, actor, payload) {
  const gameId = safeStr(payload.gameId || payload.gameAccount || payload.playerId, 60)
  if (!gameId) throw httpError(400, '缺少游戏充值ID（玩家账号）gameId')
  const map = await kvGet(env, 'gidmap:' + gameId, null)
  let ownerId = safeStr(payload.ownerId, 40)
  if (map && map.ownerId) {
    // 已登记：归属不可被改写到别处；操作者必须在归属可见范围内
    if (!(await canAccessOwner(env, actor, map.ownerId))) throw httpError(404, '资源不存在')
    if (ownerId && ownerId !== map.ownerId) throw httpError(409, '该游戏充值ID已登记在其他归属账号下', { ownerId: map.ownerId })
    ownerId = map.ownerId
  }
  if (!ownerId) ownerId = actor.id
  if (!(await canAccessOwner(env, actor, ownerId))) throw httpError(404, '资源不存在')
  return { gameId: gameId, ownerId: ownerId }
}

/** 游戏ID台账：登记 / 更新（同一归属内幂等覆盖） */
export async function registerGameId(env, actor, payload) {
  const r = await gameResolveOwner(env, actor, payload)
  const key = 'gid:' + r.ownerId + ':' + r.gameId
  const prev = await kvGet(env, key, null) || {}
  const rec = {
    gameId: r.gameId, ownerId: r.ownerId,
    label: safeStr(payload.label, 60) || prev.label || r.gameId,
    gameRole: safeStr(payload.gameRole, 60) || prev.gameRole || '',
    gameZone: safeStr(payload.gameZone, 40) || prev.gameZone || '',
    platform: safeStr(payload.platform, 40) || prev.platform || '',
    credit: toInt(prev.credit, 0),               // 玩家账号在本系统的净发币额（上分 + / 下分 -）
    topupTotal: toInt(prev.topupTotal, 0),
    creditTotal: toInt(prev.creditTotal, 0),
    createdBy: prev.createdBy || actor.id,
    createdAt: prev.createdAt || nowIso(),
    updatedAt: nowIso(),
  }
  await kvPut(env, 'gidmap:' + r.gameId, { gameId: r.gameId, ownerId: r.ownerId, createdAt: nowIso() })
  await kvPut(env, key, rec)
  await addAudit(env, actor.id, 'game.id.register', { gameId: r.gameId, ownerId: r.ownerId })
  return rec
}

export async function listGameIds(env, actor) {
  const owners = await visibleOwnerIds(env, actor)
  const out = []
  for (const oid of owners) {
    if (oid === 'pool') continue
    const keys = await kvList(env, 'gid:' + oid + ':')
    for (const k of keys) {
      const g = await kvGet(env, k, null)
      if (g) out.push(g)
    }
  }
  out.sort(function (a, b) { return String(b.updatedAt).localeCompare(String(a.updatedAt)) })
  return out
}

/** 玩家账号发币台账变化（与指令单成功回执同锁内更新）
 *  kind：不传=按 delta 正负推断（正为上分、负为下分）；
 *        'topup' / 'credit' = 显式指定本次只增减对应累计口径（回滚时用，避免把「撤回」误计为新的上分/下分）。 */
async function gameCreditBump(env, ownerId, gameId, delta, kind) {
  const key = 'gid:' + ownerId + ':' + gameId
  return await withLock(env, key, 10, async function () {
    const g = await kvGet(env, key, null)
    if (!g) return null
    const d = toInt(delta, 0)
    g.credit = toInt(g.credit, 0) + d
    // 累计口径必须带符号：回滚上分传入负数需扣减 topupTotal，回滚下分传入正数需扣减 creditTotal，
    // 始终维持不变式 credit === topupTotal - creditTotal
    if (kind === 'topup') g.topupTotal = Math.max(0, toInt(g.topupTotal, 0) + d)
    else if (kind === 'credit') g.creditTotal = Math.max(0, toInt(g.creditTotal, 0) - d)
    else if (d > 0) g.topupTotal = toInt(g.topupTotal, 0) + d
    else g.creditTotal = toInt(g.creditTotal, 0) - d
    g.updatedAt = nowIso()
    await kvPut(env, key, g)
    return g
  })
}

function gamePointView(o, game) {
  const dir = o.direction || 'in'
  return {
    orderId: o.id, ownerId: o.ownerId, createdBy: o.createdBy,
    gameId: o.gameId, gameAccount: o.gameId, gameRole: o.gameRole || '', gameZone: o.gameZone || '',
    platform: o.platform || '', externalOrderNo: o.externalOrderNo || '',
    direction: dir, directionText: GAME_DIRECTION_TEXT[dir] || dir,
    amount: o.amount, currency: o.currency || 'MMK', note: o.note || '',
    status: o.status, statusText: GAME_STATUS_TEXT[o.status] || o.status,
    frozen: o.frozen === true, rolledBack: o.rolledBack === true,
    executorTxid: o.executorTxid || '', message: o.message || '',
    claimedBy: o.claimedBy || '', claimedAt: o.claimedAt || null, doneAt: o.doneAt || null,
    credit: game ? toInt(game.credit, 0) : null,
    createdAt: o.createdAt, updatedAt: o.updatedAt,
  }
}

async function gameFindOrder(env, actor, id, extraOwners) {
  const owners = (extraOwners || await visibleOwnerIds(env, actor))
  for (const oid of owners) {
    const t = await kvGet(env, 'gp:' + oid + ':' + id, null)
    if (t) return { order: t, key: 'gp:' + oid + ':' + id }
  }
  return null
}

/** 创建上分 / 下分指令单（幂等由 API 层用 X-Idempotency-Key 承担；下分创建即冻结等额余额） */
export async function createGamePointOrder(env, actor, payload) {
  const cfg = await getConfig(env)
  const direction = String(payload.direction || payload.type || '').toLowerCase()
  if (GAME_DIRECTIONS.indexOf(direction) < 0) throw httpError(400, 'direction 必须是 in（上分/加币）或 out（下分/扣币）')
  const amount = toInt(payload.amount, 0)
  if (amount <= 0) throw httpError(400, '金额必须大于 0')
  if (amount > 100000000) throw httpError(400, '单笔金额过大')
  const r = await gameResolveOwner(env, actor, payload)
  // 上分/下分同样受「保证金不足」与「租用金逾期」两类业务闸门约束（与收款下单口径一致）
  const dep = await depositSufficient(env, actor)
  if (!dep.ok) {
    throw httpError(403, '保证金不足，游戏上下分已受限：' + dep.reason, { code: 'DEPOSIT_INSUFFICIENT', agentId: dep.agentId, required: dep.required, paid: dep.paid })
  }
  await assertRentalOk(env, actor)
  const id = makeId('gpo')
  const rec = {
    id: id, ownerId: r.ownerId, rootId: actor.rootId || actor.id, createdBy: actor.id,
    gameId: r.gameId, gameRole: safeStr(payload.gameRole, 60), gameZone: safeStr(payload.gameZone, 40),
    platform: safeStr(payload.platform, 40),
    externalOrderNo: safeStr(payload.externalOrderNo || payload.merchantOrderId, 60),
    direction: direction, amount: amount, currency: cfg.currency || 'MMK',
    note: safeStr(payload.note, 200),
    status: 'queued', frozen: false, rolledBack: false,
    claimedBy: '', claimedAt: null, executorTxid: '', message: '', doneAt: null,
    createdAt: nowIso(), updatedAt: nowIso(),
  }
  // 下分：创建即冻结（余额不足直接 409），失败 / 取消 / 回滚时原路释放
  if (direction === 'out') {
    const st = await getStats(env, r.ownerId)
    if (toInt(st.balance, 0) < amount) {
      throw httpError(409, '可用余额不足，无法下分（可用 ' + toInt(st.balance, 0) + ' / 需扣 ' + amount + '）', { code: 'BALANCE_INSUFFICIENT', balance: toInt(st.balance, 0) })
    }
    await ledgerAppend(env, r.ownerId, {
      type: 'game_credit_hold', direction: 'out', amount: amount, refId: id,
      note: '游戏下分冻结（' + r.gameId + '）',
    })
    await bumpStats(env, r.ownerId, { balance: -amount, gameHold: amount })
    rec.frozen = true
  }
  await kvPut(env, 'gp:' + r.ownerId + ':' + id, rec)
  await addAudit(env, actor.id, 'game.point.create', {
    orderId: id, ownerId: r.ownerId, gameId: r.gameId, direction: direction, amount: amount,
  })
  const game = await kvGet(env, 'gid:' + r.ownerId + ':' + r.gameId, null)
  return gamePointView(rec, game)
}

export async function listGamePointOrders(env, actor, filter) {
  const f = filter || {}
  const owners = await visibleOwnerIds(env, actor)
  const out = []
  for (const oid of owners) {
    if (oid === 'pool') continue
    const keys = await kvList(env, 'gp:' + oid + ':')
    for (const k of keys) {
      const t = await kvGet(env, k, null)
      if (t) out.push(t)
    }
  }
  let list = out
  if (f.status) list = list.filter(function (o) { return o.status === f.status })
  if (f.direction) list = list.filter(function (o) { return o.direction === f.direction })
  if (f.ownerId) list = list.filter(function (o) { return o.ownerId === f.ownerId })
  if (f.kw) {
    const kw = String(f.kw).toLowerCase()
    list = list.filter(function (o) {
      return (String(o.id) + String(o.gameId) + String(o.externalOrderNo) + String(o.executorTxid) + String(o.createdBy)).toLowerCase().indexOf(kw) >= 0
    })
  }
  list.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)) })
  const sliced = list.slice(0, toInt(f.limit, 200))
  const view = []
  for (const o of sliced) view.push(gamePointView(o, null))
  return view
}

export async function getGamePointOrder(env, actor, id) {
  const hit = await gameFindOrder(env, actor, safeStr(id, 40))
  if (!hit) return null
  const game = await kvGet(env, 'gid:' + hit.order.ownerId + ':' + hit.order.gameId, null)
  return gamePointView(hit.order, game)
}

/** 执行端拉取（设备密钥）：把待执行指令置为「执行中」并返回执行要素 */
export async function gameExecutorPull(env, device) {
  const user = await getUser(env, device.ownerId)
  if (!user) return { tasks: [], device: device.id, count: 0 }
  const owners = await visibleOwnerIds(env, user)
  const tasks = []
  for (const oid of owners) {
    if (tasks.length >= 20) break
    const keys = await kvList(env, 'gp:' + oid + ':')
    for (const k of keys) {
      if (tasks.length >= 20) break
      const t = await kvGet(env, k, null)
      if (!t || t.status !== 'queued') continue
      t.status = 'claimed'
      t.claimedBy = device.id
      t.claimedAt = nowIso()
      t.updatedAt = nowIso()
      await kvPut(env, k, t)
      tasks.push({
        orderId: t.id, gameId: t.gameId, gameRole: t.gameRole || '', gameZone: t.gameZone || '',
        direction: t.direction, directionText: GAME_DIRECTION_TEXT[t.direction] || t.direction,
        amount: t.amount, currency: t.currency || 'MMK', platform: t.platform || '', note: t.note || '',
      })
    }
  }
  await addAudit(env, device.id || 'system', 'game.point.pull', { device: device.id, count: tasks.length })
  return { tasks: tasks, device: device.id, count: tasks.length }
}

/** 执行端回执：成功 → 记账 + 余额联动；失败 → 自动回滚冻结（幂等：已终态直接回原结果） */
export async function gameExecutorReceipt(env, device, payload) {
  const id = safeStr(payload.orderId || payload.id, 40)
  if (!id) throw httpError(400, '缺少指令单号 orderId')
  const user = await getUser(env, device.ownerId)
  if (!user) throw httpError(401, '设备归属账号不存在')
  const hit = await gameFindOrder(env, user, id)
  if (!hit) throw httpError(404, '指令单不存在')
  const ok = !(payload.ok === false || String(payload.ok || '').toLowerCase() === 'false')
  const txid = safeStr(payload.txid, 64)
  const message = safeStr(payload.message || payload.reason, 200)
  return await withLock(env, 'gp:' + id, 15, async function () {
    const fresh = await kvGet(env, hit.key, null)
    if (!fresh) throw httpError(404, '指令单不存在')
    if (['done', 'failed', 'canceled', 'rolledback'].indexOf(fresh.status) >= 0) {
      const g0 = await kvGet(env, 'gid:' + fresh.ownerId + ':' + fresh.gameId, null)
      return { order: gamePointView(fresh, g0), duplicate: true }
    }
    fresh.executorTxid = txid
    fresh.message = message
    fresh.claimedBy = fresh.claimedBy || device.id
    fresh.updatedAt = nowIso()
    if (ok) {
      fresh.status = 'done'
      fresh.doneAt = nowIso()
      if (fresh.direction === 'in') {
        await ledgerAppend(env, fresh.ownerId, {
          type: 'game_topup', direction: 'in', amount: fresh.amount, refId: fresh.id, extId: txid,
          note: '游戏上分（加币 ' + fresh.gameId + '）',
        })
        await bumpStats(env, fresh.ownerId, {
          balance: fresh.amount, collectTotal: fresh.amount, collectCount: 1, gameTopupTotal: fresh.amount,
        })
        await gameCreditBump(env, fresh.ownerId, fresh.gameId, fresh.amount)
      } else {
        // 下分：冻结转为实际出账（先冻结后执行，账实始终相符）
        await ledgerAppend(env, fresh.ownerId, {
          type: 'game_credit', direction: 'out', amount: fresh.amount, refId: fresh.id, extId: txid,
          note: '游戏下分（扣币 ' + fresh.gameId + '）',
        })
        await bumpStats(env, fresh.ownerId, {
          payoutTotal: fresh.amount, payoutCount: 1, gameCreditTotal: fresh.amount, gameHold: -fresh.amount,
        })
        await gameCreditBump(env, fresh.ownerId, fresh.gameId, -fresh.amount)
        fresh.frozen = false
      }
    } else {
      fresh.status = 'failed'
      if (fresh.frozen) {
        await ledgerAppend(env, fresh.ownerId, {
          type: 'game_credit_release', direction: 'in', amount: fresh.amount, refId: fresh.id,
          note: '游戏下分失败回滚（解冻 ' + fresh.gameId + '）',
        })
        await bumpStats(env, fresh.ownerId, { balance: fresh.amount, gameHold: -fresh.amount })
        fresh.frozen = false
        fresh.rolledBack = true
      }
    }
    await kvPut(env, hit.key, fresh)
    await addAudit(env, device.id || 'system', 'game.point.receipt', {
      orderId: fresh.id, ok: ok, txid: txid, direction: fresh.direction, amount: fresh.amount, device: device.id,
    })
    const g = await kvGet(env, 'gid:' + fresh.ownerId + ':' + fresh.gameId, null)
    return { order: gamePointView(fresh, g), duplicate: false }
  })
}

/** 取消指令单：仅待执行 / 执行中可取消；已冻结的余额原路释放（失败/取消回滚口径） */
export async function cancelGamePointOrder(env, actor, id, reason) {
  const hit = await gameFindOrder(env, actor, safeStr(id, 40))
  if (!hit) throw httpError(404, '资源不存在')
  return await withLock(env, 'gp:' + hit.order.id, 15, async function () {
    const fresh = await kvGet(env, hit.key, null)
    if (!fresh) throw httpError(404, '资源不存在')
    if (['canceled', 'rolledback'].indexOf(fresh.status) >= 0) return gamePointView(fresh, null)
    if (fresh.status === 'done') throw httpError(409, '指令已成功执行，不能取消；如需纠正请用「回滚」')
    if (fresh.status === 'failed') throw httpError(409, '指令已失败，无需取消')
    fresh.status = 'canceled'
    fresh.message = safeStr(reason, 200)
    fresh.updatedAt = nowIso()
    if (fresh.frozen) {
      await ledgerAppend(env, fresh.ownerId, {
        type: 'game_credit_release', direction: 'in', amount: fresh.amount, refId: fresh.id,
        note: '游戏下分取消回滚（解冻 ' + fresh.gameId + '）',
      })
      await bumpStats(env, fresh.ownerId, { balance: fresh.amount, gameHold: -fresh.amount })
      fresh.frozen = false
      fresh.rolledBack = true
    }
    await kvPut(env, hit.key, fresh)
    await addAudit(env, actor.id, 'game.point.cancel', { orderId: fresh.id, amount: fresh.amount, direction: fresh.direction })
    const g = await kvGet(env, 'gid:' + fresh.ownerId + ':' + fresh.gameId, null)
    return gamePointView(fresh, g)
  })
}

/** 回滚已成功执行的指令单：反向记账 + 反向余额变更（下分回滚需余额充足） */
export async function rollbackGamePointOrder(env, actor, id, reason) {
  const hit = await gameFindOrder(env, actor, safeStr(id, 40))
  if (!hit) throw httpError(404, '资源不存在')
  return await withLock(env, 'gp:' + hit.order.id, 15, async function () {
    const fresh = await kvGet(env, hit.key, null)
    if (!fresh) throw httpError(404, '资源不存在')
    if (fresh.status === 'rolledback') return gamePointView(fresh, null)
    if (fresh.status !== 'done') throw httpError(409, '仅已成功执行的指令可回滚（当前状态：' + (GAME_STATUS_TEXT[fresh.status] || fresh.status) + '）')
    const st = await getStats(env, fresh.ownerId)
    if (fresh.direction === 'in') {
      if (toInt(st.balance, 0) < fresh.amount) {
        throw httpError(409, '余额不足，无法回滚该笔上分（可用 ' + toInt(st.balance, 0) + ' / 需扣 ' + fresh.amount + '）')
      }
      await ledgerAppend(env, fresh.ownerId, {
        type: 'game_rollback', direction: 'out', amount: fresh.amount, refId: fresh.id,
        note: '游戏上分回滚（撤回加币 ' + fresh.gameId + '）',
      })
      await bumpStats(env, fresh.ownerId, { balance: -fresh.amount, collectTotal: -fresh.amount, collectCount: -1, gameTopupTotal: -fresh.amount })
      await gameCreditBump(env, fresh.ownerId, fresh.gameId, -fresh.amount, 'topup')
    } else {
      await ledgerAppend(env, fresh.ownerId, {
        type: 'game_rollback', direction: 'in', amount: fresh.amount, refId: fresh.id,
        note: '游戏下分回滚（退回扣币 ' + fresh.gameId + '）',
      })
      await bumpStats(env, fresh.ownerId, { balance: fresh.amount, payoutTotal: -fresh.amount, payoutCount: -1, gameCreditTotal: -fresh.amount })
      await gameCreditBump(env, fresh.ownerId, fresh.gameId, fresh.amount, 'credit')
    }
    fresh.status = 'rolledback'
    fresh.rolledBack = true
    fresh.message = safeStr(reason, 200) || fresh.message
    fresh.rolledBackAt = nowIso()
    fresh.updatedAt = nowIso()
    await kvPut(env, hit.key, fresh)
    await addAudit(env, actor.id, 'game.point.rollback', { orderId: fresh.id, direction: fresh.direction, amount: fresh.amount })
    const g = await kvGet(env, 'gid:' + fresh.ownerId + ':' + fresh.gameId, null)
    return gamePointView(fresh, g)
  })
}