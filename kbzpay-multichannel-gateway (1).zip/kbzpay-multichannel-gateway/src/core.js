/* =============================================================================
 * 核心层（core.js）
 * -----------------------------------------------------------------------------
 * 职责：配置 / 存储封装 / 加密 / 账号与组织树 / RBAC 与数据域隔离 /
 *       不可变账本 / 通道管理 / 资金池·保证金·租用金·扣罚 / 审计日志 / 并发锁
 * 说明：本层不处理 HTTP，所有函数均可被 api.js 与 engine.js 调用。
 * ========================================================================== */

/* ============================== 默认配置 ============================== */
export const DEFAULT_CONFIG = {
  gatewayName: '缅甸多平台收付款多级分管通道系统',
  currency: 'MMK',
  timezone: 'Asia/Yangon',
  // 地区锁定：默认只允许缅甸。geo=按 Cloudflare CF-IPCountry 判定
  allowCountries: ['MM'],
  allowPhonePrefixes: ['+95', '09'],
  regionMode: 'geo', // geo | phone | both | off
  // 超管账号：不预置任何密码。超管入口首次输入的口令即成为唯一超管密码。
  adminUsername: 'superadmin',
  adminPassword: '',            // 保留字段（历史兼容），实际不再使用
  adminInitialized: false,      // 是否已完成「首次设密」；false 时超管入口展示设密表单
  // 出入金规则
  minWithdraw: 1000,
  withdrawFeeRate: 0.05,
  autoPayoutLimit: 500000,   // 单笔出款 <= 该额度自动出款，超过进入人工审批
  // 收款识别码
  tailDigits: 3,             // 尾码位数（3 → 0~999 共 1000 个识别码/通道）
  tailTtlSec: 1800,          // 识别码有效期（秒）
  orderTtlSec: 1800,         // 订单有效期（秒）
  // 回调
  webhookRetries: 5,
  webhookBackoffSec: 30,
  // 保证金 / 租用金
  depositDefaultRequired: 1000000,
  commissionDefault: 0.01,
  rentalFeeMonthly: 200000,
  // 费用与时间管理（超管可配，驱动「代理表」与租用金计费联动）
  rentalBillingCycle: 'monthly',    // 计费周期：monthly=自然月 / quarterly=自然季度 / yearly=自然年
  rentalDueDay: 1,                  // 到期日：每期第几号截止缴费（1-28）
  rentalGraceDays: 3,               // 宽限期（天）：到期后 N 天内仍按「宽限期」处理，不计逾期
  rentalOverdueAction: 'restrict',  // 逾期处置：restrict=逾期即限制该代理业务 / remind=仅提醒不限制
  // 发货 / 收货 / 结算（收货转款到户）
  autoDeliver: true,          // 电商 / 游戏订单收款核销成功后是否自动发货
  autoReceiveHours: 72,       // 买家未手动确认收货时，多少小时后自动确认收货并触发转款
  autoSettle: true,           // 确认收货后是否立即自动转款到户（false = 停在「已收货·待转款」由后台放款）
  settleFeeRate: 0,           // 收货转款到户的费率（默认不加收，与提现手续费区分）
  // 平台使用费：超管层级账户只向各「代理分级账户」按收取流水计提使用费（0 = 暂不计提）
  platformFeeRate: 0,         // 平台使用费率（按代理账户的收款结算额计提，计入平台账户）
  platformFeeOnCollect: true, // true=按收款结算额计提（转款到户/直接入账时）；false=仅在出款时计提
  // 接入安全（签名 / 防重放 / 幂等 / 限流）
  requireApiSignature: false, // true=强制签名；false=宽松（带齐签名头即校验，完全不带则跳过，兼容既有接入）
  signatureSkewSec: 300,      // 请求时间戳允许偏差（秒）
  nonceTtlSec: 600,           // nonce 记忆时长（秒），用于防重放
  rateLimitPerMin: 120,       // 单接入方每分钟请求上限
  publicRateLimitPerMin: 240, // 公开接入面（免登录）按「入口 + 来源 IP」的每分钟上限；0 = 关闭该层限流
  // 账号与会话安全（登录防爆破 / 会话滑动续期 / 强制改密 / 错误脱敏）
  sessionTtlSec: 43200,       // 登录会话有效期（秒），默认 12 小时；活跃请求自动滑动续期
  loginMaxAttempts: 6,        // 同一账号连续登录失败上限，超过即锁定（账号+来源 IP 维度）
  loginLockSec: 900,          // 登录失败锁定时间（秒）
  enforcePasswordChange: false, // true=新建账号未改密前禁止调用业务接口（默认关闭，避免批量账号被整体阻断）
  exposeErrorDetail: false,   // true=5xx 错误回显内部异常信息（仅排障期临时开启）
  // 敏感信息
  allowReveal: true,          // 是否允许归属方以 ?reveal=1 读取受限明文（审计留痕）
  version: 1,
}

/* ============================== 编码 / 工具 ============================== */
export const enc = new TextEncoder()

export function jsonResponse(data, status, headers) {
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, headers || {}),
  })
}

export function textResponse(text, status, headers) {
  return new Response(text, {
    status: status || 200,
    headers: Object.assign({ 'Content-Type': 'text/plain; charset=utf-8' }, headers || {}),
  })
}

export function htmlResponse(html, status, headers) {
  return new Response(html, {
    status: status || 200,
    headers: Object.assign({ 'Content-Type': 'text/html; charset=utf-8' }, headers || {}),
  })
}

export function makeId(prefix) {
  const t = Date.now().toString(36)
  const r = Math.random().toString(36).slice(2, 8)
  const r2 = Math.floor(Math.random() * 46656).toString(36)
  return (prefix ? prefix + '_' : '') + t + r + r2
}

export function nowIso() { return new Date().toISOString() }

export function toInt(v, dflt) {
  const n = parseInt(v, 10)
  return Number.isFinite(n) ? n : (dflt || 0)
}

export function maskAccount(acct) {
  const s = String(acct || '')
  if (s.length <= 4) return s
  return s.slice(0, 4) + '****' + s.slice(-2)
}

export function hashInt(str) {
  let h = 2166136261
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return Math.abs(h)
}

export function safeStr(v, max) {
  const s = (v === undefined || v === null) ? '' : String(v)
  return max ? s.slice(0, max) : s
}

/* ============================== 存储封装 ============================== */
export function kvOf(env) {
  return env && env.KBZ_GATEWAY ? env.KBZ_GATEWAY : null
}

export async function kvGet(env, key, fallback) {
  const kv = kvOf(env)
  if (!kv) return fallback === undefined ? null : fallback
  try {
    const raw = await kv.get(key, 'text')
    if (raw === null || raw === undefined || raw === '') return fallback === undefined ? null : fallback
    try { return JSON.parse(raw) } catch (e) { return fallback === undefined ? null : fallback }
  } catch (e) {
    return fallback === undefined ? null : fallback
  }
}

export async function kvPut(env, key, value, opts) {
  const kv = kvOf(env)
  if (!kv) throw new Error('KV 未绑定（KBZ_GATEWAY）')
  const options = {}
  if (opts && opts.ttlSec) options.expirationTtl = Math.max(60, toInt(opts.ttlSec, 0))
  await kv.put(key, JSON.stringify(value), options)
  return value
}

export async function kvDel(env, key) {
  const kv = kvOf(env)
  if (!kv) return
  await kv.delete(key)
}

export async function kvList(env, prefix, limit) {
  const kv = kvOf(env)
  const out = []
  if (!kv) return out
  const cap = limit || 1000
  let cursor
  for (;;) {
    const r = await kv.list({ prefix: prefix, limit: Math.min(1000, cap - out.length) , cursor: cursor })
    const keys = (r && r.keys) || []
    for (const k of keys) out.push(k.name)
    if (!r || r.list_complete || out.length >= cap) break
    cursor = r.cursor
    if (!cursor) break
  }
  return out
}

/* ============================== 加密 ============================== */
async function subtle() {
  const c = (typeof crypto !== 'undefined' && crypto && crypto.subtle) ? crypto : null
  if (c) return c.subtle
  throw new Error('WebCrypto 不可用')
}

export async function sha256hex(input) {
  const s = await subtle()
  const data = typeof input === 'string' ? enc.encode(input) : input
  const d = await s.digest('SHA-256', data)
  return bufToHex(d)
}

export function bufToHex(buf) {
  const b = new Uint8Array(buf)
  let out = ''
  for (let i = 0; i < b.length; i++) out += b[i].toString(16).padStart(2, '0')
  return out
}

export async function hmacHex(secret, message) {
  const s = await subtle()
  const key = await s.importKey('raw', enc.encode(String(secret)), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  const sig = await s.sign('HMAC', key, enc.encode(String(message)))
  return bufToHex(sig)
}

export async function hashPassword(password, salt) {
  const s = await subtle()
  const key = await s.importKey('raw', enc.encode(String(password)), 'PBKDF2', false, ['deriveBits'])
  const bits = await s.deriveBits(
    { name: 'PBKDF2', salt: enc.encode(String(salt)), iterations: 60000, hash: 'SHA-256' },
    key, 256)
  return bufToHex(bits)
}

export async function randomToken(bytes) {
  const n = bytes || 24
  const arr = new Uint8Array(n)
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) crypto.getRandomValues(arr)
  else for (let i = 0; i < n; i++) arr[i] = Math.floor(Math.random() * 256)
  let s = ''
  for (let i = 0; i < arr.length; i++) s += arr[i].toString(16).padStart(2, '0')
  return s
}

export async function timingSafeEqual(a, b) {
  const x = String(a || ''), y = String(b || '')
  if (x.length !== y.length) return false
  let diff = 0
  for (let i = 0; i < x.length; i++) diff |= x.charCodeAt(i) ^ y.charCodeAt(i)
  return diff === 0
}

/* ============================== 并发锁（best-effort） ============================== */
export async function acquireLock(env, name, ttlSec) {
  const key = 'lock:' + name
  const existing = await kvGet(env, key, null)
  if (existing && existing.expiresAt && existing.expiresAt > Date.now()) return false
  await kvPut(env, key, { holder: makeId('l'), expiresAt: Date.now() + (ttlSec || 10) * 1000 }, { ttlSec: (ttlSec || 10) + 60 })
  return true
}

export async function releaseLock(env, name) {
  await kvDel(env, 'lock:' + name)
}

export async function withLock(env, name, ttlSec, fn, retries) {
  const max = retries === undefined ? 8 : retries
  for (let i = 0; i <= max; i++) {
    const ok = await acquireLock(env, name, ttlSec || 10)
    if (ok) {
      try { return await fn() } finally { await releaseLock(env, name) }
    }
    await sleepMs(30 + i * 40)
  }
  // 拿不到锁也放行（KV 最终一致下的兜底），由业务层做二次校验
  return await fn()
}

export function sleepMs(ms) {
  return new Promise(function (r) { setTimeout(r, ms) })
}

/* ============================== 配置 ============================== */
let _cfgCache = null

/*
 * 部署级环境变量覆盖（优先级最高，高于后台「设置」保存的值）
 * - ALLOW_COUNTRIES：允许地区白名单，逗号分隔；写 "ALL" 或 "*" 表示不限制
 * - DEFAULT_CURRENCY：默认币种
 * - GATEWAY_NAME：系统名称
 * 这样改 wrangler.toml 的 [vars] 后重新 deploy 即可立即生效（例如临时放开地区联调）。
 */
function envConfigOverrides(env) {
  const o = {}
  if (!env) return o
  const countries = env.ALLOW_COUNTRIES
  if (countries !== undefined && countries !== null && String(countries).trim() !== '') {
    const s = String(countries).trim()
    o.allowCountries = (s.toUpperCase() === 'ALL' || s === '*')
      ? []
      : s.split(',').map(function (x) { return x.trim().toUpperCase() }).filter(Boolean)
  }
  const currency = env.DEFAULT_CURRENCY
  if (currency !== undefined && currency !== null && String(currency).trim() !== '') {
    o.currency = String(currency).trim().toUpperCase()
  }
  const name = env.GATEWAY_NAME
  if (name !== undefined && name !== null && String(name).trim() !== '') {
    o.gatewayName = String(name).trim()
  }
  return o
}

export async function getConfig(env) {
  const stored = await kvGet(env, 'sys:config', null)
  // 优先级：环境变量（部署级） > KV 中已保存的后台设置 > DEFAULT_CONFIG
  const cfg = Object.assign({}, DEFAULT_CONFIG, stored || {}, envConfigOverrides(env))
  if (!stored) {
    await kvPut(env, 'sys:config', cfg)
  }
  _cfgCache = cfg
  return cfg
}

export async function setConfig(env, patch) {
  const cfg = await getConfig(env)
  const next = Object.assign({}, cfg, patch || {}, { version: (cfg.version || 1) + 1, updatedAt: nowIso() })
  await kvPut(env, 'sys:config', next)
  _cfgCache = next
  return next
}

export async function publicConfig(env) {
  const cfg = await getConfig(env)
  return {
    gatewayName: cfg.gatewayName,
    currency: cfg.currency,
    timezone: cfg.timezone,
    minWithdraw: cfg.minWithdraw,
    withdrawFeeRate: cfg.withdrawFeeRate,
    autoPayoutLimit: cfg.autoPayoutLimit,
    tailDigits: cfg.tailDigits,
    tailTtlSec: cfg.tailTtlSec,
    orderTtlSec: cfg.orderTtlSec,
    depositDefaultRequired: cfg.depositDefaultRequired,
    rentalFeeMonthly: cfg.rentalFeeMonthly,
    rentalBillingCycle: cfg.rentalBillingCycle || 'monthly',
    rentalDueDay: toInt(cfg.rentalDueDay, 1),
    rentalGraceDays: toInt(cfg.rentalGraceDays, 3),
    rentalOverdueAction: cfg.rentalOverdueAction === 'remind' ? 'remind' : 'restrict',
    autoDeliver: cfg.autoDeliver !== false,
    autoReceiveHours: toInt(cfg.autoReceiveHours, 72),
    autoSettle: cfg.autoSettle !== false,
    settleFeeRate: Number(cfg.settleFeeRate || 0),
    platformFeeRate: Number(cfg.platformFeeRate || 0),
    platformFeeOnCollect: cfg.platformFeeOnCollect !== false,
    requireApiSignature: cfg.requireApiSignature === true,
    signatureSkewSec: toInt(cfg.signatureSkewSec, 300),
    nonceTtlSec: toInt(cfg.nonceTtlSec, 600),
    rateLimitPerMin: toInt(cfg.rateLimitPerMin, 120),
    allowSubAgents: cfg.allowSubAgents === true,
    channelCooldownSec: toInt(cfg.channelCooldownSec, 900),
    allowReveal: cfg.allowReveal !== false,
    regionMode: cfg.regionMode,
    allowCountries: cfg.allowCountries,
    version: cfg.version,
  }
}

/* ============================== 种子数据 ============================== */
export async function ensureSeed(env) {
  const marker = await kvGet(env, 'sys:seeded', null)
  if (marker) return marker
  const cfg = await getConfig(env)
  const superId = 'u_super'
  const superUser = {
    id: superId,
    role: 'super',
    username: cfg.adminUsername,
    name: '超级管理员',
    phone: '',
    parentId: null,
    path: '/' + superId + '/',
    rootId: superId,
    salt: '',
    passHash: '',            // 空口令：必须由超管入口「首次设密」写入
    status: 'active',
    mustChangePassword: false,
    depositRequired: 0,
    commissionRate: 0,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
  await kvPut(env, 'user:' + superId, superUser)
  await kvPut(env, 'uname:' + cfg.adminUsername, superId)
  const pool = {
    id: 'pool',
    balance: 0,
    depositTotal: 0,
    rentalTotal: 0,
    penaltyTotal: 0,
    refundTotal: 0,
    accounts: [],
    updatedAt: nowIso(),
  }
  await kvPut(env, 'pool:main', pool)
  const seeded = { at: nowIso(), superId: superId, adminUsername: cfg.adminUsername }
  await kvPut(env, 'sys:seeded', seeded)
  return seeded
}

/* ============================== 超管入口 / 首次设密 ============================== */
// 用户名规则与 createUser 保持一致
const SUPER_USERNAME_RE = /^[a-z0-9_.-]{3,40}$/
// 禁止在「首次设密」时使用的弱口令/历史默认口令
const WEAK_ADMIN_PASSWORDS = ['admin@12345', 'aa8965', 'admin', '123456', '12345678', 'password', 'superadmin']

export async function getSuperUser(env) {
  return await getUser(env, 'u_super')
}

/** 超管是否已完成首次设密（口令已由本人写入） */
export async function superAdminInitialized(env) {
  const cfg = await getConfig(env)
  if (cfg.adminInitialized === true) return true
  if (cfg.adminInitialized === false) return false
  // 历史数据兼容：未写入标志时，以超管是否已有口令哈希判定
  const su = await getSuperUser(env)
  return !!(su && su.passHash)
}

/** 超管入口状态：供前端决定「首次设密」还是「登录」 */
export async function setupStatus(env) {
  await ensureSeed(env)
  const cfg = await getConfig(env)
  const su = await getSuperUser(env)
  return {
    initialized: await superAdminInitialized(env),
    adminUsername: (su && su.username) || cfg.adminUsername,
  }
}

/**
 * 超管入口「首次设密」：把本次输入的口令写为唯一超管密码。
 * 仅允许在未初始化时调用一次；成功后自动视为已完成初始化。
 */
export async function setupSuperAdmin(env, payload) {
  await ensureSeed(env)
  if (await superAdminInitialized(env)) throw httpError(403, '超管密码已设置，首次设密入口已关闭')

  const password = String((payload && payload.password) || '')
  if (password.length < 6) throw httpError(400, '密码至少 6 位')
  if (password.length > 64) throw httpError(400, '密码最长 64 位')
  if (WEAK_ADMIN_PASSWORDS.indexOf(password.toLowerCase()) >= 0) throw httpError(400, '该密码过于简单，请更换为唯一强密码')
  if ((payload && payload.confirm) !== undefined && String(payload.confirm) !== password) throw httpError(400, '两次输入的密码不一致')

  const cfg = await getConfig(env)
  const su = await getSuperUser(env)
  if (!su) throw httpError(500, '超管账号缺失，请重新初始化')

  let username = String((payload && payload.username) || su.username || cfg.adminUsername).toLowerCase().trim()
  if (!SUPER_USERNAME_RE.test(username)) throw httpError(400, '超管账号需为 3-40 位字母/数字/._-')
  if (username !== su.username) {
    const taken = await kvGet(env, 'uname:' + username, null)
    if (taken && taken !== su.id) throw httpError(409, '该超管账号名已被占用')
  }

  const salt = await randomToken(8)
  const next = Object.assign({}, su, {
    username: username,
    salt: salt,
    passHash: await hashPassword(password, salt),
    mustChangePassword: false,
    updatedAt: nowIso(),
  })
  await kvPut(env, 'user:' + su.id, next)
  await kvPut(env, 'uname:' + username, su.id)
  if (username !== su.username && su.username) await kvDel(env, 'uname:' + su.username)
  await setConfig(env, { adminInitialized: true, adminUsername: username })
  await addAudit(env, su.id, 'admin.setup', { username: username })
  return { profile: publicUser(next) }
}

/* ============================== 账号 / 组织树 ============================== */
export async function getUser(env, id) {
  if (!id) return null
  return await kvGet(env, 'user:' + id, null)
}

export async function getUserByUsername(env, username) {
  const id = await kvGet(env, 'uname:' + String(username || '').toLowerCase(), null)
  if (!id) return null
  return await getUser(env, id)
}

export async function listUsers(env) {
  const keys = await kvList(env, 'user:')
  const out = []
  for (const k of keys) {
    const u = await kvGet(env, k, null)
    if (u) out.push(u)
  }
  out.sort(function (a, b) { return String(a.createdAt).localeCompare(String(b.createdAt)) })
  return out
}

export function publicUser(u, opts) {
  if (!u) return null
  const full = !!(opts && opts.full)
  return {
    id: u.id, role: u.role, username: u.username, name: u.name,
    phone: full ? (u.phone || '') : maskPhone(u.phone),   // 手机号默认脱敏，本人可见全量
    phoneMasked: maskPhone(u.phone),
    parentId: u.parentId, rootId: u.rootId, status: u.status,
    depositRequired: u.depositRequired || 0,
    commissionRate: u.commissionRate || 0,
    mustChangePassword: !!u.mustChangePassword,
    createdAt: u.createdAt,
  }
}

export function isDescendantOf(ancestorPath, user) {
  if (!user || !ancestorPath) return false
  return String(user.path || '').indexOf(ancestorPath) === 0
}

/** 某账号可见的数据归属账号集合 */
export async function visibleOwnerIds(env, user) {
  if (!user) return []
  if (user.role === 'super') {
    const users = await listUsers(env)
    const ids = users.map(function (u) { return u.id })
    ids.push('pool')
    return ids
  }
  if (user.role === 'agent') {
    const users = await listUsers(env)
    const ids = users.filter(function (u) { return u.id === user.id || isDescendantOf(user.path, u) })
      .map(function (u) { return u.id })
    if (user.id === user.rootId) ids.push('pool')
    return ids
  }
  return [user.id]
}

/** 归属校验：不可见一律按“资源不存在”处理（避免越权探测） */
export async function canAccessOwner(env, user, ownerId) {
  if (!user || !ownerId) return false
  if (user.role === 'super') return true
  if (ownerId === 'pool') return false
  const target = await getUser(env, ownerId)
  if (!target) return false
  if (user.role === 'agent') {
    return target.id === user.id || isDescendantOf(user.path, target)
  }
  return target.id === user.id
}

export async function createUser(env, actor, payload) {
  const role = payload.role
  if (['agent', 'merchant'].indexOf(role) < 0) throw httpError(400, '角色只能是 agent（代理）或 merchant（商户）')
  if (!actor) throw httpError(401, '未登录')
  if (actor.role === 'merchant') throw httpError(403, '商户不可创建下级账号')
  if (actor.role === 'agent' && role !== 'merchant') {
    // 代理默认只发展商户；如需多级代理，由超管开启
    const cfg = await getConfig(env)
    if (!cfg.allowSubAgents) throw httpError(403, '当前未开启多级代理，代理只能创建商户')
  }
  // 保证金应缴额属于超管专属设定权：代理/商户不得代设
  if (actor.role !== 'super' && payload.depositRequired !== undefined) {
    throw httpError(403, '保证金应缴额仅后台超管可设定')
  }
  const username = safeStr(payload.username, 40).toLowerCase().trim()
  if (!/^[a-z0-9_.-]{3,40}$/.test(username)) throw httpError(400, '账号需为 3-40 位字母/数字/._-')
  const password = safeStr(payload.password, 64)
  if (password.length < 6) throw httpError(400, '密码至少 6 位')
  const exists = await kvGet(env, 'uname:' + username, null)
  if (exists) throw httpError(409, '该账号已存在')

  const cfg = await getConfig(env)
  const id = makeId(role === 'agent' ? 'u_ag' : 'u_mc')
  const salt = await randomToken(8)
  const parentPath = actor.path || ('/' + actor.id + '/')
  const user = {
    id: id,
    role: role,
    username: username,
    name: safeStr(payload.name, 60) || username,
    phone: normalizePhone(payload.phone, cfg),
    parentId: actor.id,
    path: parentPath + id + '/',
    rootId: actor.role === 'super' ? (role === 'agent' ? id : actor.id) : (actor.rootId || actor.id),
    salt: salt,
    passHash: await hashPassword(password, salt),
    status: 'active',
    mustChangePassword: true,
    depositRequired: actor.role === 'super'
      ? toInt(payload.depositRequired, role === 'agent' ? cfg.depositDefaultRequired : 0)
      : 0,
    // 是否由超管逐户「钉定」应缴保证金：钉定后不再随系统默认值联动；建号时留空（未显式传入）即未钉定
    depositRequiredSet: actor.role === 'super' && role === 'agent' && payload.depositRequired !== undefined,
    commissionRate: payload.commissionRate !== undefined ? Number(payload.commissionRate) : cfg.commissionDefault,
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
  await kvPut(env, 'user:' + id, user)
  await kvPut(env, 'uname:' + username, id)
  if (role === 'agent') {
    await setDeposit(env, id, { required: user.depositRequired, paid: 0 })
  }
  await addAudit(env, actor.id, 'account.create', { target: id, role: role, username: username })
  return publicUser(user)
}

export function normalizePhone(phone, cfg) {
  const p = safeStr(phone, 24).replace(/[\s-]/g, '')
  if (!p) return ''
  if (/^09\d{7,11}$/.test(p)) return '+95' + p.slice(1)
  if (/^\+?95\d{7,11}$/.test(p)) return '+' + p.replace(/^\+/, '')
  return p
}

export function isMyanmarPhone(phone, cfg) {
  const p = normalizePhone(phone, cfg)
  if (!p) return false
  return /^\+95\d{6,12}$/.test(p)
}

export async function updateUser(env, actor, id, patch) {
  const u = await getUser(env, id)
  if (!u) throw httpError(404, '资源不存在')
  if (actor.role !== 'super') {
    const ok = await canAccessOwner(env, actor, id)
    if (!ok || actor.id === id) throw httpError(403, '无权操作该账号')
    if (patch.role || patch.status === 'active') { /* 代理不可自行启用账号 */ }
  }
  if (patch.name !== undefined) u.name = safeStr(patch.name, 60)
  // 保证金应缴额属于超管专属设定权：任何非超管调用一律拒绝（不静默忽略，避免误解）
  if (actor.role !== 'super' && patch.depositRequired !== undefined) {
    throw httpError(403, '保证金应缴额仅后台超管可设定')
  }
  if (patch.phone !== undefined) u.phone = normalizePhone(patch.phone, await getConfig(env))
  if (patch.status !== undefined && ['active', 'disabled'].indexOf(patch.status) >= 0) {
    if (u.role === 'super' && patch.status === 'disabled') throw httpError(400, '不能停用超管')
    u.status = patch.status
  }
  if (actor.role === 'super') {
    if (patch.depositRequired !== undefined) {
      u.depositRequired = toInt(patch.depositRequired, 0)
      // 逐户设定即视为「钉定」：此后不再随系统默认值联动
      u.depositRequiredSet = true
      const dep = await getDeposit(env, id)
      await setDeposit(env, id, { required: u.depositRequired, paid: dep.paid, penalty: dep.penalty })
    }
    if (patch.commissionRate !== undefined) u.commissionRate = Number(patch.commissionRate)
  }
  if (patch.password) {
    if (String(patch.password).length < 6) throw httpError(400, '密码至少 6 位')
    u.salt = await randomToken(8)
    u.passHash = await hashPassword(String(patch.password), u.salt)
    u.mustChangePassword = true
  }
  u.updatedAt = nowIso()
  await kvPut(env, 'user:' + id, u)
  await addAudit(env, actor.id, 'account.update', { target: id, patch: Object.keys(patch || {}) })
  return publicUser(u)
}

/** 注销（软删除：置为 disabled 并回收会话） */
export async function disableUser(env, actor, id) {
  const u = await getUser(env, id)
  if (!u) throw httpError(404, '资源不存在')
  if (u.role === 'super') throw httpError(400, '不能停用超管')
  if (actor.role !== 'super') {
    const ok = await canAccessOwner(env, actor, id)
    if (!ok || actor.id === id) throw httpError(403, '无权操作该账号')
  }
  u.status = 'disabled'
  u.updatedAt = nowIso()
  await kvPut(env, 'user:' + id, u)
  await addAudit(env, actor.id, 'account.disable', { target: id })
  return publicUser(u)
}

/* ============================== 会话 / 登录 ============================== */
/** 来源 IP 只存哈希短串：可用于会话列表与审计比对，不落明文 IP */
export async function hashIp(ip) {
  const s = String(ip || '')
  if (!s || s === 'undefined') return ''
  return (await sha256hex('ip:' + s)).slice(0, 12)
}

/** 登录失败计数键：账号 + 来源 IP 双维度，避免单账号被全网误锁 */
async function loginFailKey(env, username, meta) {
  const iph = await hashIp(meta && meta.ip)
  return 'loginfail:' + safeStr(String(username || '').toLowerCase(), 60) + ':' + (iph || 'na')
}

/** 登录前置检查：锁定中直接拒绝（含剩余秒数），避免继续消耗口令计算 */
async function loginLockCheck(env, username, meta, cfg) {
  const rec = await kvGet(env, await loginFailKey(env, username, meta), null)
  if (!rec) return null
  const lockedUntil = Date.parse(rec.lockedUntil || '')
  if (lockedUntil && lockedUntil > Date.now()) {
    throw httpError(429, '登录失败次数过多，请 ' + Math.ceil((lockedUntil - Date.now()) / 1000) + ' 秒后再试', {
      code: 'LOGIN_LOCKED', lockedUntil: rec.lockedUntil, attempts: toInt(rec.fails, 0), max: toInt(cfg.loginMaxAttempts, 6),
    })
  }
  return rec
}

/** 记录一次登录失败：达到上限即写入锁定时间，并留审计（口令本身绝不落库） */
async function loginFailNote(env, username, meta, cfg, reason) {
  const key = await loginFailKey(env, username, meta)
  const rec = await kvGet(env, key, { fails: 0 })
  rec.fails = toInt(rec.fails, 0) + 1
  rec.lastAt = nowIso()
  rec.reason = safeStr(reason, 60)
  const max = Math.max(1, toInt(cfg.loginMaxAttempts, 6))
  const lockSec = Math.max(0, toInt(cfg.loginLockSec, 900))
  if (rec.fails >= max && lockSec > 0) {
    rec.lockedUntil = new Date(Date.now() + lockSec * 1000).toISOString()
    rec.fails = 0   // 锁定后清零，解锁后重新计数
  }
  await kvPut(env, key, rec, { ttlSec: Math.max(lockSec * 4, 3600) })
  await addAudit(env, 'system', 'auth.login.fail', { username: safeStr(String(username || '').toLowerCase(), 60), attempts: rec.fails, locked: !!rec.lockedUntil })
  return rec
}

async function loginFailClear(env, username, meta) {
  await kvDel(env, await loginFailKey(env, username, meta))
}

/** 会话登记（供「安全会话」列表 / 会话撤销使用；仅存 token 与设备线索，不存口令） */
async function sessionIndexPut(env, userId, token, s, ttlSec) {
  await kvPut(env, 'sessindex:' + userId + ':' + token, {
    token: token, createdAt: s.createdAt, ipHash: s.ipHash || '', ua: s.ua || '', lastSeenAt: s.lastSeenAt || s.createdAt,
  }, { ttlSec: ttlSec })
}

export async function login(env, username, password, meta) {
  await ensureSeed(env)
  const cfg = await getConfig(env)
  await loginLockCheck(env, username, meta, cfg)
  const u = await getUserByUsername(env, username)
  if (!u) {
    await loginFailNote(env, username, meta, cfg, '账号不存在')
    throw httpError(401, '账号或密码错误')
  }
  if (u.status === 'disabled') throw httpError(403, '账号已停用，请联系上级')
  // 超管入口未完成首次设密前，不允许用任何口令登录（避免出现默认口令被误用）
  if (u.role === 'super' && !(await superAdminInitialized(env))) {
    throw httpError(428, '超管尚未设置初始密码，请前往超管入口 /admin 完成首次设密')
  }
  const h = await hashPassword(String(password || ''), u.salt)
  if (!(await timingSafeEqual(h, u.passHash))) {
    await loginFailNote(env, username, meta, cfg, '口令错误')
    throw httpError(401, '账号或密码错误')
  }
  await loginFailClear(env, username, meta)
  const token = await randomToken(24)
  const ttl = Math.max(600, toInt(cfg.sessionTtlSec, 43200))
  const sess = {
    userId: u.id, role: u.role, createdAt: nowIso(),
    ipHash: await hashIp(meta && meta.ip), ua: safeStr(meta && meta.ua, 160),
    lastSeenAt: nowIso(),
    expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
  }
  await kvPut(env, 'sess:' + token, sess, { ttlSec: ttl })
  await sessionIndexPut(env, u.id, token, sess, ttl)
  await addAudit(env, u.id, 'auth.login', { role: u.role })
  return { token: token, expiresInSec: ttl, profile: publicUser(u, { full: true }) }
}

export async function logout(env, token) {
  if (!token) return
  const s = await kvGet(env, 'sess:' + token, null)
  await kvDel(env, 'sess:' + token)
  if (s && s.userId) await kvDel(env, 'sessindex:' + s.userId + ':' + token)
}

/** 会话滑动续期：剩余不足半个 TTL 时自动延长（长时间在后台操作不会突然掉线） */
export async function authenticate(env, token) {
  if (!token) return null
  const s = await kvGet(env, 'sess:' + token, null)
  if (!s || !s.userId) return null
  const u = await getUser(env, s.userId)
  if (!u || u.status === 'disabled') return null
  const cfg = await getConfig(env)
  const ttl = Math.max(600, toInt(cfg.sessionTtlSec, 43200))
  const exp = Date.parse(s.expiresAt || '')
  if (!exp || exp - Date.now() < ttl * 500) {
    const next = Object.assign({}, s, {
      expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
      lastSeenAt: nowIso(),
    })
    await kvPut(env, 'sess:' + token, next, { ttlSec: ttl })
    await sessionIndexPut(env, s.userId, token, next, ttl)
  }
  return u
}

/** 当前账号的有效会话列表（超管可查看任意账号） */
export async function listSessions(env, user, targetId) {
  const uid = safeStr(targetId, 40) || user.id
  if (uid !== user.id && user.role !== 'super') throw httpError(404, '资源不存在')
  const keys = await kvList(env, 'sessindex:' + uid + ':')
  const out = []
  for (const k of keys) {
    const idx = await kvGet(env, k, null)
    if (!idx) continue
    const live = await kvGet(env, 'sess:' + idx.token, null)
    if (!live) { await kvDel(env, k); continue }   // 已过期/已注销的登记项顺手清理
    out.push({
      tokenMasked: String(idx.token || '').slice(0, 6) + '…' + String(idx.token || '').slice(-4),
      // 会话标识：查看「本人」会话或超管查看任意账号时回传完整令牌（界面需要它精确撤销）；
      // 其余情况只回末 6 位，避免令牌在无关上下文里被外泄。
      token: (uid === user.id || user.role === 'super') ? idx.token : String(idx.token || '').slice(-6),
      createdAt: idx.createdAt, lastSeenAt: live.lastSeenAt || idx.lastSeenAt,
      ipHash: idx.ipHash || '', ua: idx.ua || '',
    })
  }
  out.sort(function (a, b) { return String(b.createdAt || '').localeCompare(String(a.createdAt || '')) })
  return out
}

/** 撤销指定会话（本人可撤自己的，超管可撤任意账号的） */
export async function revokeSession(env, user, token) {
  const t = safeStr(token, 120)
  if (!t) throw httpError(400, '缺少会话标识')
  const s = await kvGet(env, 'sess:' + t, null)
  const ownerId = s ? s.userId : ''
  const idxKeys = ownerId ? ['sessindex:' + ownerId + ':' + t] : await kvList(env, 'sessindex:')
  if (!s && user.role !== 'super') {
    // 无法定位归属时：按登记项反查，仅允许撤销属于自己的登记
    for (const k of idxKeys) {
      const idx = await kvGet(env, k, null)
      if (idx && idx.token === t && k.indexOf('sessindex:' + user.id + ':') === 0) {
        await kvDel(env, k)
        await addAudit(env, user.id, 'auth.session.revoke', { token: t.slice(-6) })
        return { revoked: true }
      }
    }
    throw httpError(404, '资源不存在')
  }
  if (ownerId && ownerId !== user.id && user.role !== 'super') throw httpError(404, '资源不存在')
  await kvDel(env, 'sess:' + t)
  for (const k of idxKeys) {
    const idx = await kvGet(env, k, null)
    if (idx && idx.token === t) await kvDel(env, k)
  }
  await addAudit(env, user.id, 'auth.session.revoke', { target: ownerId || '', token: t.slice(-6) })
  return { revoked: true }
}

/* ============================== 不可变账本 ============================== */
export async function ledgerAppend(env, ownerId, entry) {
  return await withLock(env, 'led:' + ownerId, 10, async function () {
    const head = await kvGet(env, 'ledhead:' + ownerId, { seq: 0, hash: 'GENESIS' })
    const seq = toInt(head.seq, 0) + 1
    const body = Object.assign({}, entry, { seq: seq, ownerId: ownerId, ts: entry.ts || nowIso(), prevHash: head.hash })
    const hash = await sha256hex(JSON.stringify(body))
    const rec = Object.assign({}, body, { hash: hash })
    await kvPut(env, 'led:' + ownerId + ':' + String(seq).padStart(10, '0'), rec)
    await kvPut(env, 'ledhead:' + ownerId, { seq: seq, hash: hash, updatedAt: nowIso() })
    return rec
  })
}

export async function ledgerList(env, ownerId, limit) {
  const keys = await kvList(env, 'led:' + ownerId + ':')
  keys.sort()
  const out = []
  const max = limit || 200
  for (let i = keys.length - 1; i >= 0 && out.length < max; i--) {
    const e = await kvGet(env, keys[i], null)
    if (e) out.push(e)
  }
  return out
}

export async function ledgerVerify(env, ownerId) {
  const keys = await kvList(env, 'led:' + ownerId + ':')
  keys.sort()
  let prev = 'GENESIS'
  let seq = 0
  const problems = []
  for (const k of keys) {
    const e = await kvGet(env, k, null)
    if (!e) { problems.push({ key: k, reason: 'missing' }); continue }
    const body = Object.assign({}, e)
    delete body.hash
    const expect = await sha256hex(JSON.stringify(body))
    if (e.prevHash !== prev) problems.push({ seq: e.seq, reason: 'prevHash 断链' })
    if (expect !== e.hash) problems.push({ seq: e.seq, reason: '内容被篡改' })
    prev = e.hash
    seq = e.seq
  }
  return { ok: problems.length === 0, entries: keys.length, lastSeq: seq, problems: problems }
}

/* ============================== 统计 ============================== */
export async function getStats(env, ownerId) {
  return await kvGet(env, 'stats:' + ownerId, {
    collectTotal: 0, collectCount: 0, payoutTotal: 0, payoutCount: 0,
    balance: 0, refundTotal: 0,
    escrow: 0,                 // 托管中：已到账但尚未确认收货/结算的金额（电商·游戏）
    settleTotal: 0, settleCount: 0,   // 已收货转款到户的累计金额与笔数
    updatedAt: null,
  })
}

/** 托管中（未结算）与可用余额（可提现）严格分离 */
export function balancesOf(statsLike) {
  const s = statsLike || {}
  return { balance: toInt(s.balance, 0), escrow: toInt(s.escrow, 0), total: toInt(s.balance, 0) + toInt(s.escrow, 0) }
}

export async function bumpStats(env, ownerId, delta) {
  const s = await getStats(env, ownerId)
  const next = Object.assign({}, s)
  Object.keys(delta || {}).forEach(function (k) {
    next[k] = (Number(next[k]) || 0) + Number(delta[k])
  })
  next.updatedAt = nowIso()
  await kvPut(env, 'stats:' + ownerId, next)
  return next
}

/* ============================== 通道（KBZ 收款账号） ============================== */
export async function listChannels(env, ownerId, flow) {
  const keys = await kvList(env, 'chan:' + ownerId + ':')
  const out = []
  for (const k of keys) {
    const c = await kvGet(env, k, null)
    if (!c) continue
    const c2 = refreshChannelStatus(c)
    if (flow && normFlow(c2) !== flow) continue
    out.push(c2)
  }
  out.sort(function (a, b) { return (b.primary ? 1 : 0) - (a.primary ? 1 : 0) })
  return out
}

/** 资金用途归一：历史通道无 flow 字段，一律视为收款账户 */
export function normFlow(c) {
  const f = c && c.flow
  return f === 'pay' ? 'pay' : 'receive'
}

export function refreshChannelStatus(c) {
  if (!c) return c
  if (c.status === 'cooldown' && c.cooldownUntil && Date.parse(c.cooldownUntil) <= Date.now()) c.status = 'retired'
  return c
}

export async function createChannel(env, actor, payload) {
  const account = safeStr(payload.account, 32).replace(/[\s-]/g, '')
  if (!/^\d{6,20}$/.test(account)) throw httpError(400, 'KBZ 账号需为 6-20 位数字')
  const cfg = await getConfig(env)
  const ownerId = actor.id
  const dupe = await kvGet(env, 'chanacct:' + account, null)
  if (dupe && dupe.status !== 'retired') throw httpError(409, '该 KBZ 账号已被占用')
  const id = makeId('ch')
  const ch = {
    id: id,
    ownerId: ownerId,
    rootId: actor.rootId || actor.id,
    account: account,
    holder: safeStr(payload.holder, 60) || actor.name,
    phone: normalizePhone(payload.phone, cfg),
    bank: safeStr(payload.bank, 20) || 'KBZPay',
    label: safeStr(payload.label, 40) || ('通道 ' + account.slice(-4)),
    status: 'active',
    /** 资金用途：receive=收款账户（用于分配收款单） / pay=付款账户（用于对外出款） */
    flow: (['receive', 'pay'].indexOf(safeStr(payload.flow, 10)) >= 0) ? safeStr(payload.flow, 10) : 'receive',
    primary: !!payload.primary,
    priority: toInt(payload.priority, 100),
    dailyLimit: toInt(payload.dailyLimit, 0),
    cooldownSec: toInt(payload.cooldownSec, cfg.channelCooldownSec || 900),
    totalReceived: 0,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    version: 1,
  }
  if (ch.primary) await clearPrimary(env, ownerId)
  await kvPut(env, 'chan:' + ownerId + ':' + id, ch)
  await kvPut(env, 'chanacct:' + account, { channelId: id, ownerId: ownerId, status: 'active' })
  await addAudit(env, actor.id, 'channel.create', { channelId: id, account: maskAccount(account) })
  return ch
}

export async function clearPrimary(env, ownerId) {
  const list = await listChannels(env, ownerId)
  for (const c of list) {
    if (c.primary) {
      c.primary = false
      c.updatedAt = nowIso()
      await kvPut(env, 'chan:' + ownerId + ':' + c.id, c)
    }
  }
}

export async function updateChannel(env, actor, id, patch) {
  const c = await kvGet(env, 'chan:' + actor.id + ':' + id, null)
  if (!c) throw httpError(404, '资源不存在')
  if (patch.label !== undefined) c.label = safeStr(patch.label, 40)
  if (patch.holder !== undefined) c.holder = safeStr(patch.holder, 60)
  if (patch.phone !== undefined) c.phone = normalizePhone(patch.phone, await getConfig(env))
  if (patch.dailyLimit !== undefined) c.dailyLimit = toInt(patch.dailyLimit, 0)
  if (patch.priority !== undefined) c.priority = toInt(patch.priority, 100)
  if (patch.status !== undefined) {
    if (['active', 'frozen', 'retired'].indexOf(patch.status) < 0) throw httpError(400, '状态不合法')
    c.status = patch.status
  }
  if (patch.primary) {
    await clearPrimary(env, actor.id)
    c.primary = true
    c.status = 'active'
  }
  c.version = toInt(c.version, 1) + 1
  c.updatedAt = nowIso()
  await kvPut(env, 'chan:' + actor.id + ':' + id, c)
  await kvPut(env, 'chanacct:' + c.account, { channelId: c.id, ownerId: c.ownerId, status: c.status })
  await addAudit(env, actor.id, 'channel.update', { channelId: id, patch: Object.keys(patch || {}) })
  return c
}

/** 一键替换：新增账号直接顶替旧通道，旧通道进入冷却期（在途订单不受影响） */
export async function replaceChannel(env, actor, id, payload) {
  const old = await kvGet(env, 'chan:' + actor.id + ':' + id, null)
  if (!old) throw httpError(404, '资源不存在')
  const account = safeStr(payload.account, 32).replace(/[\s-]/g, '')
  if (!/^\d{6,20}$/.test(account)) throw httpError(400, 'KBZ 账号需为 6-20 位数字')
  if (account === old.account) throw httpError(400, '新账号与当前账号相同')
  const cfg = await getConfig(env)
  const dupe = await kvGet(env, 'chanacct:' + account, null)
  if (dupe && dupe.status !== 'retired') throw httpError(409, '该 KBZ 账号已被占用')

  const cooling = toInt(payload.cooldownSec, old.cooldownSec || cfg.channelCooldownSec || 900)
  const cooldownUntil = new Date(Date.now() + cooling * 1000).toISOString()

  // 1) 先把旧通道标为退出中（仍在冷却期内可继续核销在途订单，但不再分配新订单）
  old.status = 'cooldown'
  old.primary = false
  old.cooldownUntil = cooldownUntil
  old.updatedAt = nowIso()
  old.version = toInt(old.version, 1) + 1
  await kvPut(env, 'chan:' + actor.id + ':' + id, old)
  await kvPut(env, 'chanacct:' + old.account, { channelId: id, ownerId: old.ownerId, status: 'cooldown' })

  // 2) 新通道接任（沿用原通道的资金用途与主通道语义）
  const newCh = await createChannel(env, actor, {
    account: account,
    holder: payload.holder || actor.name,
    phone: payload.phone,
    label: (payload.label || old.label) + ' · 新',
    primary: true,
    flow: normFlow(old),
  })
  await addAudit(env, actor.id, 'channel.replace', {
    oldChannelId: id, oldAccount: maskAccount(old.account),
    newChannelId: newCh.id, newAccount: maskAccount(account), cooldownUntil: cooldownUntil,
  })
  return { replaced: old, current: newCh, cooldownUntil: cooldownUntil }
}

export async function deleteChannel(env, actor, id) {
  const c = await kvGet(env, 'chan:' + actor.id + ':' + id, null)
  if (!c) throw httpError(404, '资源不存在')
  const pending = await kvGet(env, 'chantail:' + id, null)
  if (pending && pending.active > 0) throw httpError(409, '该通道仍有在途收款订单，请先处理或等待过期')
  c.status = 'retired'
  c.updatedAt = nowIso()
  await kvPut(env, 'chan:' + actor.id + ':' + id, c)
  await kvPut(env, 'chanacct:' + c.account, { channelId: id, ownerId: c.ownerId, status: 'retired' })
  await addAudit(env, actor.id, 'channel.retire', { channelId: id })
  return c
}

export async function resolveChannelByAccount(env, account) {
  const idx = await kvGet(env, 'chanacct:' + String(account || '').replace(/[\s-]/g, ''), null)
  if (!idx) return null
  const c = await kvGet(env, 'chan:' + idx.ownerId + ':' + idx.channelId, null)
  if (!c) return null
  return refreshChannelStatus(c)
}

/** 为某账号挑选收款通道：优先自有，其次向上级代理借用（只取「收款」用途账户） */
export async function pickChannel(env, user) {
  return await pickFlowAccount(env, user, 'receive')
}

/** 为某账号挑选付款账户：优先自有，其次向上级代理借用（只取「付款」用途账户） */
export async function pickPayAccount(env, user) {
  return await pickFlowAccount(env, user, 'pay')
}

/** 按资金用途挑选账户：own 优先，其次沿上级链向上借用 */
export async function pickFlowAccount(env, user, flow) {
  let node = user
  let guard = 0
  while (node && guard++ < 10) {
    // 超管层级账户不直接承接业务收付款：只向代理分级账户计提使用费 + 归集资金池收款
    if (node.role === 'super') break
    const list = await listChannels(env, node.id, flow)
    const active = list.filter(function (c) { return c.status === 'active' })
    if (active.length) {
      active.sort(function (a, b) {
        if ((b.primary ? 1 : 0) !== (a.primary ? 1 : 0)) return (b.primary ? 1 : 0) - (a.primary ? 1 : 0)
        if (a.priority !== b.priority) return a.priority - b.priority
        return String(a.createdAt).localeCompare(String(b.createdAt))
      })
      return active[0]
    }
    node = node.parentId ? await getUser(env, node.parentId) : null
  }
  return null
}

/* ============================== 资金池 / 保证金 / 租用金 ============================== */
export async function getPool(env) {
  return await kvGet(env, 'pool:main', {
    id: 'pool', balance: 0, depositTotal: 0, rentalTotal: 0, penaltyTotal: 0,
    refundTotal: 0, accounts: [], updatedAt: null,
  })
}

export async function setPool(env, patch) {
  const p = await getPool(env)
  const next = Object.assign({}, p, patch, { updatedAt: nowIso() })
  await kvPut(env, 'pool:main', next)
  return next
}

export async function poolLedgerAppend(env, entry) {
  return await withLock(env, 'pled', 10, async function () {
    const head = await kvGet(env, 'pledhead', { seq: 0, hash: 'GENESIS' })
    const seq = toInt(head.seq, 0) + 1
    const body = Object.assign({}, entry, { seq: seq, ts: entry.ts || nowIso(), prevHash: head.hash })
    const hash = await sha256hex(JSON.stringify(body))
    const rec = Object.assign({}, body, { hash: hash })
    await kvPut(env, 'pled:' + String(seq).padStart(10, '0'), rec)
    await kvPut(env, 'pledhead', { seq: seq, hash: hash, updatedAt: nowIso() })
    return rec
  })
}

export async function poolLedgerList(env, limit) {
  const keys = await kvList(env, 'pled:')
  keys.sort()
  const out = []
  const max = limit || 200
  for (let i = keys.length - 1; i >= 0 && out.length < max; i--) {
    const e = await kvGet(env, keys[i], null)
    if (e) out.push(e)
  }
  return out
}

export async function getDeposit(env, agentId) {
  return await kvGet(env, 'dep:' + agentId, { agentId: agentId, required: 0, paid: 0, penalty: 0, refunded: 0, updatedAt: null })
}

export async function setDeposit(env, agentId, patch) {
  const d = await getDeposit(env, agentId)
  const next = Object.assign({}, d, patch, { agentId: agentId, updatedAt: nowIso() })
  next.sufficient = (Number(next.paid) || 0) >= (Number(next.required) || 0)
  await kvPut(env, 'dep:' + agentId, next)
  return next
}

/**
 * 超管修改「默认应缴保证金」后，对尚未逐户钉定的代理同步应缴额。
 * 同步 user.depositRequired 与保证金台账 dep.required，保证代理表 / 账号视图 / 保证金闸门三处读数一致；
 * 已由超管逐户设定（depositRequiredSet === true）的代理保持原值不动。
 * 返回被联动的代理 id 列表（便于审计与前端提示）。
 */
export async function applyDepositDefault(env, newDefault) {
  const dflt = toInt(newDefault, 0)
  const users = await listUsers(env)
  const changed = []
  for (const u of users) {
    if (u.role !== 'agent' || u.depositRequiredSet === true) continue
    const dep = await getDeposit(env, u.id)
    if (toInt(u.depositRequired, 0) === dflt) {
      if (toInt(dep.required, 0) !== dflt) await setDeposit(env, u.id, { required: dflt })
      continue
    }
    u.depositRequired = dflt
    u.updatedAt = nowIso()
    await kvPut(env, 'user:' + u.id, u)
    await setDeposit(env, u.id, { required: dflt, paid: dep.paid, penalty: dep.penalty })
    changed.push(u.id)
  }
  return changed
}

/** 保证金是否满足：代理自身及上级链上各级代理的保证金都必须合规 */
export async function depositSufficient(env, user) {
  if (!user || user.role === 'super') return { ok: true }
  let node = user
  let guard = 0
  while (node && node.role !== 'super' && guard++ < 10) {
    if (node.role === 'agent') {
      const d = await getDeposit(env, node.id)
      if ((Number(d.paid) || 0) < (Number(d.required) || 0)) {
        return { ok: false, reason: '保证金不足', agentId: node.id, required: d.required, paid: d.paid }
      }
    }
    const next = node.parentId ? await getUser(env, node.parentId) : null
    if (next && next.role === 'merchant') node = next
    else node = next
  }
  return { ok: true }
}

export async function listDeposits(env, user) {
  const ids = await visibleOwnerIds(env, user)
  const out = []
  for (const id of ids) {
    if (id === 'pool') continue
    const u = await getUser(env, id)
    if (!u || u.role !== 'agent') continue
    const d = await getDeposit(env, id)
    out.push(Object.assign({}, d, { username: u.username, name: u.name, status: u.status }))
  }
  return out
}

/* ============================== 审计日志（链式防篡改，与账本同规格） ============================== */
/**
 * 审计留痕：每条记录携带 seq / prevHash / hash，形成链式结构。
 * 任何一条被改动或删除，都会导致后续链断裂，可用 GET /api/audit/verify 一键验真。
 */
export async function addAudit(env, actorId, action, detail) {
  const seqKey = 'auditseq'
  const seq = toInt(await kvGet(env, seqKey, 0), 0) + 1
  await kvPut(env, seqKey, seq)
  const head = await kvGet(env, 'audithead', { seq: 0, hash: 'GENESIS' })
  const id = makeId('aud')
  const rec = {
    id: id, seq: seq, actorId: actorId || 'system', action: action, detail: detail || {},
    ts: nowIso(), prevHash: head.hash || 'GENESIS',
  }
  rec.hash = await sha256hex(JSON.stringify(rec))
  await kvPut(env, 'audit:' + auditStamp() + ':' + id, rec)
  await kvPut(env, 'audithead', { seq: seq, hash: rec.hash, at: rec.ts })
  return rec
}

/** 审计键时间戳：14 位「时间倒序 + 严格递增」串。
 *  说明：列表按键升序即「最新在前」；同一毫秒内连续写入（高频接口 / 批量任务）时
 *  用递增补位保证键唯一，避免同毫秒覆盖导致审计丢失、链式验真出现假阳性。 */
let auditStampLast = 0
function auditStamp() {
  let t = Date.now()
  if (t <= auditStampLast) t = auditStampLast + 1
  auditStampLast = t
  return String(1e14 - t).padStart(14, '0')
}

export async function listAudit(env, user, limit) {
  const keys = await kvList(env, 'audit:')
  keys.sort()
  const owners = await visibleOwnerIds(env, user)
  const ownerSet = {}
  owners.forEach(function (o) { ownerSet[o] = 1 })
  const out = []
  for (let i = 0; i < keys.length && out.length < (limit || 200); i++) {
    const r = await kvGet(env, keys[i], null)
    if (!r) continue
    if (user.role === 'super' || ownerSet[r.actorId]) out.push(r)
  }
  return out
}

/** 审计链验真（超管专属）：逐条重算哈希并核对前后链，返回首个异常位置 */
export async function verifyAuditChain(env) {
  const keys = await kvList(env, 'audit:')
  const recs = []
  for (const k of keys) {
    const r = await kvGet(env, k, null)
    if (r) recs.push(r)
  }
  recs.sort(function (a, b) { return toInt(a.seq, 0) - toInt(b.seq, 0) })
  let prev = 'GENESIS'
  let checked = 0, skipped = 0, bad = 0
  let firstBad = null
  for (const r of recs) {
    if (!r.hash || !r.seq) { skipped++; continue }   // 历史数据（升级前写入）：不计入链，校验时跳过
    checked++
    const body = Object.assign({}, r)
    const hash = body.hash
    delete body.hash
    if (r.prevHash !== prev) {
      bad++
      if (!firstBad) firstBad = { id: r.id, seq: r.seq, reason: 'prevHash 与上一条不一致（可能被删除或替换）' }
    }
    const calc = await sha256hex(JSON.stringify(body))
    if (calc !== hash) {
      bad++
      if (!firstBad) firstBad = { id: r.id, seq: r.seq, reason: '内容与哈希不符（可能被改动）' }
    }
    prev = r.hash
  }
  return { ok: bad === 0, checked: checked, legacySkipped: skipped, bad: bad, firstBad: firstBad, total: recs.length }
}

/* ============================== 接入安全（签名 / 防重放 / 幂等 / 限流） ============================== */
/**
 * 三处一致的接入安全规范（商户服务端 API、设备通知端 / 出款执行端、适配器回调）：
 *   签名串 = `${METHOD}\n${PATH}\n${X-Timestamp}\n${X-Nonce}\n${sha256hex(rawBody)}`
 *   请求头：X-Timestamp（秒或毫秒，自动识别）/ X-Nonce（一次性随机串）/ X-Signature（HMAC-SHA256 十六进制）
 *   幂等键：X-Idempotency-Key（同一接入方内同键只受理一次，重复提交返回首次结果）
 */
export function signaturePayload(method, path, ts, nonce, bodyHash) {
  return [String(method || 'POST').toUpperCase(), String(path || ''), String(ts || ''), String(nonce || ''), String(bodyHash || '')].join('\n')
}

export function headerOf(headers, name) {
  if (!headers) return ''
  if (typeof headers.get === 'function') return String(headers.get(name) || '')
  const lc = String(name).toLowerCase()
  for (const k of Object.keys(headers)) {
    if (String(k).toLowerCase() === lc) return String(headers[k] || '')
  }
  return ''
}

/** 时间戳归一化为毫秒；无法解析返回 null */
export function parseTimestamp(raw) {
  let n = Number(String(raw === undefined || raw === null ? '' : raw).trim())
  if (!Number.isFinite(n) || n <= 0) return null
  if (n < 1e11) n = n * 1000          // 秒级 → 毫秒
  return n
}

/** 防重放第一道闸：时间戳偏差校验 + nonce 一次性记忆 */
export async function guardReplay(env, scope, headers) {
  const cfg = await getConfig(env)
  const rawTs = headerOf(headers, 'X-Timestamp')
  const ts = parseTimestamp(rawTs)
  if (!ts) throw httpError(401, '缺少或无效的 X-Timestamp 请求时间戳')
  const skew = toInt(cfg.signatureSkewSec, 300) * 1000
  if (Math.abs(Date.now() - ts) > skew) throw httpError(401, '请求时间戳超出允许偏差，已拒绝（防重放）')
  const nonce = safeStr(headerOf(headers, 'X-Nonce'), 80)
  if (!nonce) throw httpError(401, '缺少 X-Nonce 一次性随机串')
  const ttl = toInt(cfg.nonceTtlSec, 600)
  const key = 'nonce:' + scope + ':' + nonce
  const seen = await kvGet(env, key, null)
  if (seen) throw httpError(409, '该请求已被处理（nonce 重复，疑似重放）')
  await kvPut(env, key, { at: nowIso(), scope: scope }, { ttlSec: ttl })
  return { ts: ts, nonce: nonce }
}

/**
 * 校验请求签名：
 *   - 严格模式（requireApiSignature=true）：必须带齐三个签名头，否则 401；
 *   - 宽松模式（默认）：带齐签名头即强制校验；完全不带则跳过（兼容旧接入）。
 *   签名串使用「客户端实际发送的头原值」：`${METHOD}\n${PATH}\n${X-Timestamp}\n${X-Nonce}\n${sha256hex(rawBody)}`
 *   （服务端仅在防重放校验时把时间戳归一化为毫秒做偏差判断，不改变签名输入）
 * 返回 { enforced:boolean }，便于上层审计。
 */
export async function verifyApiSignature(env, opts) {
  const cfg = await getConfig(env)
  const required = cfg.requireApiSignature === true
  const sig = safeStr(headerOf(opts.headers, 'X-Signature'), 200)
  const rawTs = safeStr(headerOf(opts.headers, 'X-Timestamp'), 40)
  const rawNonce = safeStr(headerOf(opts.headers, 'X-Nonce'), 80)
  const hasTs = !!rawTs
  const hasNonce = !!rawNonce
  const present = !!sig || hasTs || hasNonce
  if (!present && !required) return { enforced: false }
  if (required && !(sig && hasTs && hasNonce)) {
    throw httpError(401, '该接入已开启强制签名校验，请提供 X-Timestamp / X-Nonce / X-Signature')
  }
  if (!sig || !hasTs || !hasNonce) throw httpError(401, '签名头不完整，需同时提供 X-Timestamp / X-Nonce / X-Signature')
  await guardReplay(env, opts.scope || 'api', opts.headers)
  const bodyHash = await sha256hex(String(opts.rawBody || ''))
  const expect = await hmacHex(opts.secret || '', signaturePayload(opts.method, opts.path, rawTs, rawNonce, bodyHash))
  if (!(await timingSafeEqual(sig.toLowerCase(), expect.toLowerCase()))) throw httpError(401, '签名校验失败')
  return { enforced: true, ts: rawTs, nonce: rawNonce }
}

/** 基础限流：同一接入方每分钟请求数上限（分钟桶计数） */
export async function rateLimitCheck(env, key, limitOverride) {
  const cfg = await getConfig(env)
  const limit = toInt(limitOverride || cfg.rateLimitPerMin, 120)
  if (!limit || limit <= 0) return { limited: false }
  const bucket = Math.floor(Date.now() / 60000)
  const redisKey = 'rl:' + safeStr(key, 120) + ':' + bucket
  const cur = toInt(await kvGet(env, redisKey, 0), 0) + 1
  await kvPut(env, redisKey, cur, { ttlSec: 120 })
  if (cur > limit) throw httpError(429, '请求过于频繁，请稍后再试（每分钟上限 ' + limit + ' 次）')
  return { limited: false, count: cur, limit: limit }
}

/** 幂等键：同一接入方 + 同一键只受理一次 */
export async function idempotentLookup(env, scope, key) {
  const k = safeStr(key, 80)
  if (!k) return { key: '', hit: null }
  return { key: k, hit: await kvGet(env, 'idem:' + scope + ':' + k, null) }
}

export async function idempotentRemember(env, scope, key, value) {
  const k = safeStr(key, 80)
  if (!k) return null
  const rec = Object.assign({ at: nowIso() }, value || {})
  await kvPut(env, 'idem:' + scope + ':' + k, rec, { ttlSec: 86400 })
  return rec
}

/* ============================== 敏感信息（脱敏 / 加密存储） ============================== */
export function maskPhone(phone) {
  const p = String(phone || '')
  if (!p) return ''
  if (p.length <= 6) return p.slice(0, 2) + '****'
  return p.slice(0, 4) + '****' + p.slice(-3)
}

/** 绝不允许出现在接口响应 / 日志 / 列表中的敏感字段名 */
export const SENSITIVE_KEYS = ['passHash', 'salt', 'merchantKey', 'merchantKeyHash', 'merchantKeyPlain',
  'key', 'keyPlain', 'keyHash', 'signSecret', 'signSecretPlain', 'signSecretHash',
  'cardSecret', 'cardSecretCipher', 'deliverySecret', 'secret', 'token', 'deviceKey']

/** 递归剥除敏感字段（用于兜底日志与二次防线） */
export function stripSensitive(obj, depth) {
  if (!obj || typeof obj !== 'object') return obj
  if (depth === undefined) depth = 0
  if (depth > 6) return obj
  if (Array.isArray(obj)) return obj.map(function (x) { return stripSensitive(x, depth + 1) })
  const out = {}
  Object.keys(obj).forEach(function (k) {
    if (SENSITIVE_KEYS.indexOf(k) >= 0) return
    out[k] = stripSensitive(obj[k], depth + 1)
  })
  return out
}

/** 收款通道展示：默认脱敏；仅归属方可 ?reveal=1 取受限明文（并记审计） */
export function publicChannel(c, reveal) {
  if (!c) return c
  const out = Object.assign({}, c)
  out.accountMasked = maskAccount(c.account)
  out.phoneMasked = maskPhone(c.phone)
  if (!reveal) { delete out.account; delete out.phone }
  return out
}

/**
 * 字段加密：卡密 / 发货凭据等必须以 AES-GCM 密文落 KV，明文不落盘。
 * 主密钥优先取环境变量 DATA_KEY（密钥与业务数据分离）；未配置时一次性随机生成并只存 sys:datakey。
 * 密文格式：enc1:{ivHex}:{cipherHex}
 */
export async function encryptField(env, plain) {
  const s = String(plain === undefined || plain === null ? '' : plain)
  if (!s) return ''
  const key = await dataKey(env)
  const iv = new Uint8Array(12)
  crypto.getRandomValues(iv)
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, enc.encode(s))
  return 'enc1:' + bufToHex(iv) + ':' + bufToHex(ct)
}

export async function decryptField(env, cipher) {
  const s = String(cipher || '')
  if (!s) return ''
  if (s.indexOf('enc1:') !== 0) return ''
  try {
    const parts = s.split(':')
    const key = await dataKey(env)
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: hexToBuf(parts[1]) }, key, hexToBuf(parts[2]))
    return new TextDecoder().decode(pt)
  } catch (e) { return '' }
}

export function hexToBuf(hex) {
  const s = String(hex || '')
  const out = new Uint8Array(Math.floor(s.length / 2))
  for (let i = 0; i < out.length; i++) out[i] = parseInt(s.substr(i * 2, 2), 16)
  return out
}

let _dataKeyCache = null
async function dataKey(env) {
  if (_dataKeyCache) return _dataKeyCache
  let material = String((env && env.DATA_KEY) || '')
  if (!material) {
    material = String(await kvGet(env, 'sys:datakey', '') || '')
    if (!material) {
      material = await randomToken(24)
      await kvPut(env, 'sys:datakey', material)
    }
  }
  const raw = await crypto.subtle.digest('SHA-256', enc.encode('kbz-data-key:' + material))
  _dataKeyCache = await crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt'])
  return _dataKeyCache
}

/* ============================== 错误 ============================== */
export function httpError(status, message, extra) {
  const e = new Error(message)
  e.status = status
  if (extra) e.extra = extra
  return e
}

/**
 * 超管专属动作断言：保证金应缴额 / 扣罚 / 没收 / 退还 / 登记入池等资金动作，
 * 只允许后台超管执行。API 层已有 requireSuper 兜底，这里再做一次纵深防御。
 */
export function assertSuper(actor) {
  if (!actor || actor.role !== 'super') throw httpError(403, '该操作仅后台超管可执行（保证金设定权归超管）')
  return actor
}

export function regionGate(request, cfg) {
  const country = (request.headers.get('CF-IPCountry') || '').toUpperCase()
  const mode = cfg.regionMode || 'geo'
  if (mode === 'off') return { allowed: true, country: country, mode: mode }
  if (!country) return { allowed: true, country: '', mode: mode, unknown: true }
  const allow = (cfg.allowCountries || []).map(function (c) { return String(c).toUpperCase() })
  const allowed = allow.length === 0 ? true : allow.indexOf(country) >= 0
  return { allowed: allowed, country: country, mode: mode }
}