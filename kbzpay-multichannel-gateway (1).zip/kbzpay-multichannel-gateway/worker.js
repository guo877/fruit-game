/* =============================================================================
 * Cloudflare Workers 入口（worker.js）
 * -----------------------------------------------------------------------------
 * - fetch：所有 HTTP 请求（页面 / API / 回调）统一交给 api.js 路由
 * - scheduled：定时任务（wrangler.toml [triggers] crons 已配置为每分钟），负责推进
 *   ① 超时订单自动关闭 ② 回调重试队列 ③ 到期托管订单自动收货并转款到户
 * 部署形态：单 Worker + KV 命名空间（wrangler.toml 已绑定 KBZ_GATEWAY）
 * ========================================================================== */
import { handleRequest } from './src/api.js'
import { ensureSeed, getConfig } from './src/core.js'
import { runMaintenance, runWebhooks } from './src/engine.js'

export default {
  async fetch(request, env, ctx) {
    const res = await handleRequest(request, env, ctx)
    // 每来一次请求，顺带把到期的回调重试推进一轮（不阻塞本次响应）
    if (ctx && typeof ctx.waitUntil === 'function') {
      ctx.waitUntil(runWebhooks(env, 10).catch(() => {}))
    }
    return res
  },

  async scheduled(event, env, ctx) {
    const work = (async () => {
      await ensureSeed(env)
      await getConfig(env)
      // 统一维护入口：超时订单自动关闭 → 回调重试 → 到期托管订单自动收货转款
      await runMaintenance(env, { by: 'cron', limit: 500 })
    })()
    if (ctx && typeof ctx.waitUntil === 'function') ctx.waitUntil(work)
    else await work
  },
}