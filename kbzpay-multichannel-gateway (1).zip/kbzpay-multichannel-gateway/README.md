# 缅甸多平台收付款多级分管通道系统（KBZPay 主通道）

> 一个**开箱即用、傻瓜操作**的收付款中台：以 **KBZPay 为主通道**，支持**多平台 / 跨平台无文档接入**、**多级代理分管**、**超管资金池与代理保证金**，并内置**电商 / 游戏两套自动闭环**（下单 → 自动收款 → 自动发货 → 收货转款到户），仅面向**缅甸地区**使用。
> 交付形态：Cloudflare Workers 单文件应用 + KV；本地可零依赖一键跑起来。

---

## 一、它能做什么（能力总览）

| 能力 | 说明 |
| --- | --- |
| 自动收款 | KBZ 到账后自动核销订单：**金额识别码**精确匹配 + 通知转发 + 对账文件 + 截图兜底，四条路径组合，命中即自动入账 |
| 自动发货 | 到账即自动发货：**卡密**（加密存储、收货后销毁）/ **物流单号** / **游戏道具**，凭据在收银台推给买家 |
| 游戏上下分 | 登记**游戏充值 ID** 台账，向指定账号**上分（加币）/ 下分（扣币）**；下分创建即**冻结等额余额**，执行端回执成功才实际出账，失败/取消自动回补 |
| 收货转款 | 买家确认收货后，托管款项**自动从平台托管余额转给商户可用余额**（可再出款）；逾期未确认则定时任务自动收货转款 |
| 自动付款 | 出款额度内**自动入队免人工**，超限**自动转上级审批**；执行端领取任务、回执必须带流水号 |
| 多级分管 | 超管 / 代理（可再分代理）/ 商户三级组织树，**代理只看自己子树，越权一律 404**，超管全量可见并拥有所有权 |
| KBZ 主通道 | 代理可自行添加 / 替换**自己名下的 KBZ 商业账号**，**一键替换**平滑切换、旧账号冷却期仍在途兜底 |
| 收付款设置 | 后台「收付款设置」页把**收款账户**与**付款账户**拆成**两个资金账户窗口**，任一账户均支持**一键替换**为自有 KBZ 商业账号，互不串号 |
| 平台使用费 | 超管层级账户**只向各代理分级账户计提使用费**（费率可配、不足记欠缴）；**保证金收款**由资金池指定账户承接，超管账户不直接承接业务收款 |
| 资金池 | 超管名下资金池：存放各代理**保证金**、**系统租用金**、违规**扣罚**、退还与申诉复核，独立不可篡改账本 |
| 代理表与费用时间管理 | 超管「代理租用与保证金」页**表格化**展示每个代理的月租、本期缴费、到期日、宽限期、逾期天数、应缴/已缴保证金与缺口；同一页集中配置月租、默认保证金、费率、计费周期、到期日、宽限期、逾期处置，保存即驱动代理表与计费联动 |
| 无文档接入 | 托管收银台链接 / 一行 SDK / 服务端 API 三种接入，**适配器表单化配置 + 回调重试**，不依赖任何平台文档 |
| 一键接入向导 | 「即插即用」向导：配对码换取凭据 → 粘贴任意格式抓包报文**一键智能解析** → **一键生成接入点** → 端点/密钥/签名说明 → **连通测试** → 密钥轮换；字段名不必统一（英/中/缅文别名自动识别） |
| 接入安全 | 服务端 API 支持 **HMAC 签名 + 时间戳 + Nonce 防重放 + 幂等键 + 限流**；回调**强制验签**（缺失/错误 401） |
| 敏感数据保护 | 密钥只存**哈希**；适配器密钥、回调密钥、卡密、投递密钥以 **AES-GCM 密文**落库；收款账号/手机号**默认脱敏**、受限明文读取留审计 |
| 账务可信 | 所有资金流水走 **prevHash 链式不可变账本**，可一键校验；全量操作审计（含审计链验真） |
| 运维与对账 | 超管「维护与对账」页集中展示待处理项（**超时订单 / 自动收货到期 / 回调积压 / 未匹配流水**）并**一键执行**；订单超时**自动关闭并释放识别码**；未匹配流水台账可**人工核销**，同一交易号二次上报**自动销账** |
| 安全会话 | 登录失败按「**账号 + 来源 IP**」锁定；会话**滑动续期**、在线会话**可查可撤**；审计链可验真；5xx 默认只回关联号（**脱敏**）；**公开接入面按「入口 + 来源 IP」限流** |
| 地区锁定 | 仅缅甸（`CF-IPCountry=MM`）可访问，非缅甸地区返回三语提示页 |

---

## 二、三分钟本地跑起来（傻瓜模式）

**要求**：Node.js ≥ 18（零第三方依赖，无需 `npm install`）。

```bash
cd kbzpay-multichannel-gateway
node dev-server.mjs          # 默认端口 8787
```

启动后打开浏览器：

| 入口 | 地址 | 用途 |
| --- | --- | --- |
| 落地页 | http://localhost:8787/ | 五步上线说明 + 三种接入方式 + 电商/游戏闭环与安全说明 |
| 后台 | http://localhost:8787/console | 超管 / 代理 / 商户统一后台（按角色显示不同标签页） |
| 超管入口 | http://localhost:8787/admin | **唯一超管入口**：首次使用在此设定唯一超管密码；设定后仅保留登录 |
| 收银台 | http://localhost:8787/pay?t=<订单token> | 终端用户付款页（到账后展示发货凭据并支持确认收货） |
| SDK | http://localhost:8787/sdk.js | 一行接入脚本（自动附带签名/防重放/幂等头） |
| 自助接入页 | http://localhost:8787/plug | 平台方自助接入：看自描述清单 / 用配对码换取凭据 / 查接入说明 |
| 即插即用脚本 | http://localhost:8787/kbz-plug.js | 页面一行引入 `KBZPlug.init(...)` 即可收发单、收通知、查状态 |
| 接入清单 | http://localhost:8787/api/plug/manifest | 机器可读的自描述清单（**免文档接入的核心**）；`/.well-known/kbz-connect.json` 同源 |
| 健康检查 | http://localhost:8787/health | 存活探测 |

**超管口令没有默认值**：系统不预置任何超管密码。第一次打开 `/admin`（超管唯一入口）时**输入的密码，就是唯一的超管密码**；系统只保存其口令哈希，无法找回（只能清空数据重设）。可用 `curl http://localhost:8787/api/setup/status` 查看是否已设密（`initialized`）。

> 本地模式用内存版 KV 模拟云端，仅用于演示与联调；数据不落盘、重启即清空。正式上线请按下一节部署。

---

## 三、部署到 Cloudflare（八步上线）

1. **建 KV 命名空间**
   ```bash
   npx wrangler kv:namespace create KBZ_GATEWAY
   ```
   把输出的 `id` 填进 `wrangler.toml` 的 `[[kv_namespaces]]`。

2. **改安全配置**（务必先做，见第四节）：在 `wrangler.toml` 的 `[vars]` 或 Cloudflare 后台环境变量里设置
   `ALLOW_COUNTRIES="MM"`、`DEFAULT_CURRENCY="MMK"`，并设置 `DEVICE_KEY` 作为**密钥**（不要写在明文 vars）；**强烈建议再设一个 `DATA_KEY`**（敏感字段加密主密钥，只存 Secret）。

   > `ALLOW_COUNTRIES` / `DEFAULT_CURRENCY` / `GATEWAY_NAME` 属于**部署级配置**，**优先级高于后台「设置」**：一旦通过环境变量给出，系统就以环境变量为准（改完重新 `wrangler deploy` 立即生效）。例如把 `ALLOW_COUNTRIES` 临时改成 `ALL`（或 `MM,TH`）即可放开地区联调，改回 `MM` 即恢复仅缅甸。地区白名单支持 `ALL` / `*`（不限制）与逗号分隔写法。

3. **部署**
   ```bash
   npx wrangler deploy
   ```
   或：`npm run build` 生成 `dist/index.js`，复制内容到 Cloudflare Workers 在线编辑器粘贴部署。

4. **设定超管密码**：访问 `https://<你的域名>/admin`（超管唯一入口），**第一次输入的密码即唯一超管密码**（≥6 位、不得使用弱口令如 `admin`/`123456`/`Admin@12345`），设定成功后自动进入后台，无需二次登录。此后该入口只保留登录功能，任何人都无法再次设定。建议顺手把超管账号名改成自己的（仍在该入口内填写）。

5. **配资金池**：后台 →「资金池」标签页，登记资金池收款账户（用于收代理保证金与租用金）。

6. **开代理**：后台 →「账号」新建代理并设定应缴保证金 → 代理登录后自建 KBZ 商业通道 → 新建商户 → 开始收款。
7. **配费用与时间**：后台 →「代理租用与保证金」→ 上半区「费用与时间管理」填月租、默认保证金、费率、计费周期、到期日、宽限期、逾期处置并保存；下半区「代理表」即按新规则展示每个代理的缴费与保证金情况（可筛选、看明细、记缴费到账、生成新代理）。
8. **接外部平台**（电商 / 游戏）：后台 →「接入向导」按「配对码 → 粘贴抓包报一键解析 → 一键生成接入点 → 连通测试」四步把任意平台接进来；游戏业务再到「游戏上下分」登记充值 ID 并发指令单。

**可选：开启自动收货定时任务**。`worker.js` 已含 `scheduled` 处理器（投递回调重试 + 自动收货转款），在 `wrangler.toml` 加：
```toml
[triggers]
crons = ["*/1 * * * *"]
```

---

## 四、上线前必改清单（安全红线）

| 项 | 默认值 | 上线要求 |
| --- | --- | --- |
| 超管密码 | **无默认值**（首次在 `/admin` 设定） | 首次上线务必在 `/admin` 设定强口令；弱口令（`admin`/`123456`/`Admin@12345` 等）会被系统拒绝 |
| `DEVICE_KEY` | 本地示例 `dev-device-key-0001` | 换成随机长串，且只存为 Cloudflare **Secret** |
| `DATA_KEY` | 未配置（本地随机兜底） | 生产务必配置为 **Secret**，用于敏感字段 AES-GCM 加密 |
| `allowCountries` | `["MM"]` | 确认仅 `MM`；**设置环境变量 `ALLOW_COUNTRIES` 时以环境变量为准**（见第三节第 2 步） |
| `requireApiSignature` | `false` | 对公网服务端接入建议开为 `true`（强制签名） |
| `autoPayoutLimit` | `500000` | 按自身风控重设（额度内出款免人工） |
| `autoReceiveHours` | `72` | 发货后自动收货小时数（`0` = 关闭自动收货） |
| `withdrawFeeRate` | `0.05` | 按业务重设 |
| `depositDefaultRequired` | `1000000` | 默认应缴保证金；**未逐户钉定的代理**会随此值联动，已逐户设定的保持不动 |
| `rentalFeeMonthly` | `200000` | 每期应收月租，按代理等级重设 |
| `rentalBillingCycle` | `monthly` | 计费周期：`monthly` 自然月 / `quarterly` 自然季度 / `yearly` 自然年 |
| `rentalDueDay` | `1` | 每期缴费截止日（1–28，超范围自动收敛） |
| `rentalGraceDays` | `3` | 宽限期天数：到期后仍不计逾期 |
| `rentalOverdueAction` | `restrict` | 逾期处置：`restrict` 逾期即限制该代理业务 / `remind` 仅提醒不限制 |
| `platformFeeRate` | `0` | 平台使用费率（`0` = 暂不计提），超管只对代理分级账户计提 |
| `platformFeeOnCollect` | `true` | 使用费计提时机：`true` 收款结算时 / `false` 出款完成时 |
| `publicRateLimitPerMin` | `240` | 公开接入面（免登录）按「**入口 + 来源 IP**」的每分钟上限；`0` = 关闭该层限流 |
| `sessionTtlSec` | `43200` | 登录会话有效期（秒，默认 12 小时），活跃请求**自动滑动续期** |
| `loginMaxAttempts` / `loginLockSec` | `6` / `900` | 登录失败上限与锁定时长（**「账号 + 来源 IP」维度**，超限返回 429） |
| `exposeErrorDetail` | `false` | 5xx 是否回显内部异常原文；仅排障期临时开启，事后**务必改回 `false`** |
| `enforcePasswordChange` | `false` | 新建账号未改密前是否禁止调用业务接口（批量账号场景默认关闭，避免整批被阻断） |

> 系统默认配置项都可通过后台「设置」或接口 `PUT /api/settings` 调整（白名单字段）；其中**「会话与错误策略」**与**公开接入面限流**等安全项，在后台「设置」页有独立卡片可直接改。

---

## 五、角色与账号体系

组织树：`超管 → 代理 → …（可多级）→ 商户`

- **超管**：拥有全部数据所有权，可看所有下级；管理资金池、设置、全量审计；**保证金应缴额、登记入池、扣罚、没收与退还仅超管可设定**；超管层级账户**只收各代理分级账户的使用费**、并归集保证金 / 租用金，**不直接承接业务收款**。
- **代理**：只能看**自己及子树**的数据，越权访问返回 **404**（不泄露存在性）；可新建下级商户；默认不可越级创建代理（由 `allowSubAgents` 控制，需超管开启）；可维护**自己的** KBZ 商业账号通道，并在「**收付款设置**」页分别维护**收款账户**与**付款账户**、各自**一键替换**；**不得设定任何保证金**（只能缴纳 / 查看自己的保证金）。
- **商户**：只能看到自己；发起收款订单、申请出款、查询账本；**不得设定任何保证金**。

初始化：系统首次访问会自动播种（`ensureSeed`）：创建超管 `u_super`（**无口令**）、资金池 `pool:main`。

### 超管唯一入口与首次设密

- **入口**：`/admin`（`/setup` 同义）。**全系统只有一个超管账号**（默认 `superadmin`，可在设密时改名）。
- **首次设密**：未设密时访问 `/admin` 展示设密表单；**第一次输入的密码即唯一超管密码**，写入口令哈希（PBKDF2 60000 轮 + 随机盐）并置 `adminInitialized=true`，随后自动签发登录态进入后台。
- **已设密后**：该入口只保留登录功能，再次提交设密返回 **403**；任何口令（含历史默认值）都无法再写入。
- **未设密时**：用超管账号走普通登录一律返回 **428** 并引导前往 `/admin`，避免“默认口令被误用”。
- 接口：`GET /api/setup/status`（查询是否已设密）、`POST /api/setup/admin`（首次设密，body：`username` / `password` / `confirm`）。
- 弱口令黑名单：`admin@12345`、`aa8965`、`admin`、`123456`、`12345678`、`password`、`superadmin`（大小写不敏感）。

### 保证金设定权（仅后台超管）

保证金相关**设定类**动作一律要求超管身份，代理与商户调用直接 **403**，界面也不对其显示这些按钮：

| 动作 | 接口 | 权限 |
| --- | --- | --- |
| 设定 / 修改应缴保证金 | `PUT /api/accounts/:id`（`depositRequired`）、`POST /api/accounts` | **仅超管** |
| 设定默认应缴保证金 | `PUT /api/settings`（`depositDefaultRequired`） | **仅超管** |
| 登记保证金入池 | `POST /api/pool/deposit` | **仅超管** |
| 违规扣罚 | `POST /api/pool/penalty` | **仅超管** |
| 扣罚复核 / 退还保证金 | `POST /api/pool/penalty/resolve`、`POST /api/pool/deposit/refund` | **仅超管** |
| 配置资金池收款账户 | `POST /api/pool/accounts` | **仅超管** |
| 代理自助缴纳保证金 / 租用金 | `POST /api/deposit/order`、`POST /api/rental/order` | 代理可自行发起（缴纳 ≠ 设定） |

> 缴纳类动作不受限，且**不受“保证金不足即受限”拦截**，否则代理无法自救补缴。

---

## 六、三种接入方式（无需平台文档）

### 方式 1：托管收银台链接（零代码，最傻瓜）
商户后台下单后拿到 `token`，把链接发给终端用户（或嵌到自己 App 的 WebView）：
```
https://<你的域名>/pay?t=<token>
```
用户在该页面看到**应付金额（含识别码尾数）**与收款账号，转账后填交易号、可选传截图 → 自动核销；到账后同页展示**发货凭据**并支持**确认收货**。

### 方式 2：一行 SDK（自动附带签名 / 防重放 / 幂等头）
```html
<script src="https://<你的域名>/sdk.js" data-key="mk_你的商户密钥"></script>
<script>
  KBZPay.init({ apiBase: 'https://<你的域名>', merchantKey: 'mk_你的商户密钥', userId: 'user001', platform: '我的平台' });
  const order = await KBZPay.createOrder({ amount: 10000, scene: 'ecommerce', cardSecret: 'CARD-XXXX', notifyUrl: 'https://你的站点/notify' });
  KBZPay.pay(10000);                       // 跳转/弹窗到托管收银台
  const status = await KBZPay.query(order.orderId);
</script>
```
> SDK 会用商户密钥对 `METHOD\nPATH\nX-Timestamp\nX-Nonce\nsha256hex(body)` 做 HMAC-SHA256 签名，并自动带 `X-Timestamp` / `X-Nonce` / `X-Signature` / `X-Idempotency-Key`。

### 方式 3：服务端 API + Webhook
在后台「商户密钥」生成 `mk_...`，服务端带 `X-Merchant-Key` 调用：

```bash
# 下单
curl -X POST https://<你的域名>/api/pay/init \
  -H "X-Merchant-Key: mk_xxx" -H "Content-Type: application/json" \
  -d '{"amount":10000,"scene":"ecommerce","cardSecret":"CARD-XXXX","notifyUrl":"https://你的站点/notify"}'

# 查询
curl https://<你的域名>/api/pay/status/<orderId> -H "X-Merchant-Key: mk_xxx"
```
到账后系统回调你的 `notifyUrl`（**HMAC-SHA256 签名**，可用商户密钥验签）。

> 三条路径本质上一致：都在系统内生成订单 → 分配识别码 → 自动核销 → 回调通知。

### 电商接入步骤（4 步）
1. 后台「商户密钥」生成 `mk_...`，调用 `POST /api/pay/init` 下单，body 带 `scene: "ecommerce"`；
2. 同时带**发货要素**：`cardSecret`（卡密/兑换码）或 `trackingNo`（物流单号）——到账即自动发货；
3. 把返回的 `payUrl` 给买家（或跳转托管收银台）；买家转账后自动核销、自动发货；
4. 买家在收银台点**确认收货** → 系统自动把款项**转款到户**（或超时自动收货转款）。

### 游戏接入步骤（4 步）
1. 后台「适配器」新增：平台名 + 回调 URL + 签名密钥，得到回调地址 `POST /api/adapter/callback/<adapterId>` 与游戏回执地址 `POST /api/game/callback/<adapterId>`；
2. 游戏平台下单：`POST /api/pay/init`，body 带 `scene: "game"` 与 `gameAccount / gameZone / gameRole / itemCode / quantity`；
3. 到账后系统自动下发（或你按规则发币），发币完成后回调游戏回执接口，body：`{"orderId":"ord_xxx","action":"grant","ok":true,"txid":"GAME-123456"}`（**必须带适配器密钥的 HMAC-SHA256 签名**）；
4. 系统收到回执即视为已发货，**自动收货 + 转款到游戏商户户**。

---

## 七、自动收款原理

1. 下单 → 系统从收款通道分配一个**金额识别码**（MMK 整数尾码，默认 3 位，唯一、带时效）。
2. 应付金额 = 订单金额 + 识别码（例如 10000 → 应付 10003，尾数 003 即识别码）。
3. 到账核销四路径：
   - **通知转发（主）**：KBZPay 商业账户的到账通知转发端调用 `POST /api/notify/forward`（带 `X-Device-Key`，支持批量 `rows`），按识别码精确匹配 → 自动核销。
   - **对账文件轮询**：`POST /api/reconcile/ingest` 批量导入对账行。
   - **截图 / 交易号兜底**：用户在收银台提交，交易号 ≥5 位、截图按 sha256 去重。
   - **人工标记**：后台「标记已付」。
4. 核销即写**不可变账本**并触发 Webhook 回调；订单状态机 `pending → paid / partial / closed`。

**幂等**：同一交易号（`txn:{通道}:{交易号}`）重复上报被识别为重复，不重复入账。

---

## 八、自动发货与收货转款（履约闭环）

订单在收款之外还有一条**履约链**：`pending → paid → delivered → received → settled`（另有 `refunded` / `closed`）。

| 阶段 | 含义 | 触发 |
| --- | --- | --- |
| `pending` | 待付款 | 下单 |
| `paid` | 已到账·待发货 | 自动核销 / 人工核销 |
| `delivered` | 已发货·待收货 | **到账自动发货**（配了发货要素）或后台手工发货 |
| `received` | 已收货·待转款 | 买家在收银台确认 / 后台确认 / 定时自动收货 |
| `settled` | 已转款到户 | 确认收货后**自动**把托管金额转入受益人可用余额 |

- **托管（escrow）**：电商 / 游戏收款先进入订单归属者的**托管余额**（`stats.escrow`），确认收货后才释放为**可用余额**（`stats.balance`，可再发起出款）；`deposit / rental / manual` 场景直接入账、不托管。
- **自动发货**：下单带 `cardSecret` / `trackingNo` / `scene=game` 时，到账即自动发货（`autoDeliver` 默认开）。
- **自动收货**：发货后计入 `autoReceiveAt = now + autoReceiveHours`（默认 72 小时，`0` = 关闭）；定时任务 `autoReceiveSweep` 到期自动收货并转款到户。也可手动触发 `POST /api/orders/auto-receive`（超管）。
- **手工发货**：`POST /api/orders/:id/deliver`（后台按钮「发货」，可补录卡密 / 物流单号 / 游戏要素）。
- **确认收货**：`POST /api/orders/:id/receive`（后台）/ `POST /api/pay/receive`（买家持 token）。
- **卡密销毁**：转款到户即 `delete order.cardSecretCipher`，卡密密文不长期驻留。

---

## 九、游戏业务逻辑闭环（无文档接入）

- 下单：`scene: "game"`，带 `gameAccount / gameZone / gameRole / itemCode / quantity`；订单创建时 `grantStatus = waiting`。
- 到账自动下发：系统把游戏要素随订单保存，供平台下发（`GET /api/pay/delivery?t=<token>` 或后台订单详情查看）。
- 发币回执：平台发币完成后调用 `POST /api/game/callback/<adapterId>`，body `{"orderId","action":"grant","ok":true,"txid"}`；**必须带适配器密钥的 HMAC-SHA256 签名**（缺失 / 错误一律 **401**）。
- 回执成功 → 写入 `grantStatus=granted` / `grantTxid` → **自动置为已发货 → 自动收货 → 转款到游戏商户户**。
- 回执失败（`ok:false`）→ `grantStatus=failed`，不转款，可人工介入。

### 游戏充值 ID 上分 / 下分（加币 / 扣币）

后台「**游戏上下分**」页（`VIEWS.gamepoints`）维护**游戏充值 ID 台账**并下达**上分 / 下分指令单**——这就是「系统调动游戏里的充值 ID，给所需账户加币 / 扣币」的能力。超管 / 代理 / 商户均可进入，可见范围按各自账号树隔离（商户只看到自己名下）。

**游戏充值 ID 台账**：`GET /api/game/ids` / `POST /api/game/ids`（body `{gameId,label?,gameRole?,gameZone?,platform?,ownerId?}`）。每行展示游戏ID、名称、区服、角色、平台、**净发币额**（`credit`）、**累计上分**（`topupTotal`）、**累计下分**（`creditTotal`）、最近更新。不变式：`credit = topupTotal − creditTotal`。

**指令单**：`GET /api/game/orders` / `POST /api/game/orders`（body `{direction:'in'|'out',gameId,amount,gameRole?,gameZone?,platform?,externalOrderNo?,note?}`，支持 `X-Idempotency-Key`）。

| 方向 | 含义 | 资金动作 |
| --- | --- | --- |
| `in` 上分（加币） | 给指定充值 ID 加币 | 指令创建不扣不冻；**执行端回执成功后**按收款口径入账（账本 `game_topup`） |
| `out` 下分（扣币） | 从指定充值 ID 扣币 | **创建即冻结等额可用余额**（余额不足直接 409）；回执成功才转实际出账（账本 `game_credit`）；**失败 / 取消 / 回滚自动解冻回补** |

**状态机**：`queued` 待执行 → `claimed` 执行中 → `done` 已成功 / `failed` 已失败 / `canceled` 已取消 / `rolledback` 已回滚。

**执行端**（真实加/扣币动作在交付包之外，由你方设备端承接）：
```
GET  /api/game/executor/pull        # 头 X-Device-Key；领取待执行指令单（queued → claimed）
POST /api/game/executor/receipt     # body {orderId, ok, txid, message?}；回执成功/失败
```
回执**幂等**：已处于终态的指令单重复回执返回首次结果（`duplicate:true`），不重复入账。

**查询 / 取消 / 回滚**：`GET /api/game/orders/:id`、`POST /api/game/orders/:id/cancel`（body `{reason}`）、`POST /api/game/orders/:id/rollback`（body `{reason}`）。回滚会**同步撤回发币台账变化**，累计口径带符号运算，始终维持 `credit = topupTotal − creditTotal` 不变式。

---

## 十、自动付款（出款）

1. 商户/代理申请出款 → 系统按金额 + 手续费**冻结额度**。
2. 金额 **≤** `autoPayoutLimit`：直接进入 `queued`（免人工，自动出款）。
3. 金额 **>** `autoPayoutLimit`：进入 `pending`，需上级审批通过后才入队；可驳回（驳回即退回额度）。
4. **出款执行端**用 `X-Device-Key` 拉取任务：
   ```
   GET  /api/payout/executor/pull      # 领取待付任务（queued → processing）
   POST /api/payout/executor/receipt   # 回执：成功必须带 ≥5 位流水号，否则拒绝
   ```
5. 只有回执校验通过才算完成，写 `payout` 账本。

> 出款不可逆：额度内自动 + 超限审批 + 回执强校验三重闸门。

---

## 十一、代理自有 KBZ 账号「一键替换」

代理在后台 →「通道」标签页：

- **新增**：填入自己的 KBZ 商业账号（账号 + 持有人），系统校验**同一 KBZ 账号不可被两个账号占用**（冲突返回 409）。
- **设为主通道 / 替换**：一键替换 `POST /api/channels/:id/replace`（后台为一键按钮）。
- **替换效果**：新账号**立即接任**主通道，后续新订单自动走新账号，**无需改代码、无需重启**；旧账号进入**冷却期**（`channelCooldownSec`），其间在途订单仍可核销到旧账号。
- 支持**冻结 / 删除**通道；`resolveChannelByAccount` 反查保证到账能落到正确通道。

> 本页面向「通道」维度。若要把**收款**与**付款**分成**两个资金账户窗口**分别维护（各自一键替换），见 **十三、收付款设置**（`/api/fundaccounts`，机制同源）。

---

## 十二、资金池、保证金、租用金与扣罚

- **资金池** `pool:main`：超管名下，登记收款账户、汇总保证金与租用金，**独立账本**。
- **保证金**：按代理分户 `dep:{agentId}`。代理保证金未缴 / 低于应缴额时，**其链路业务自动受限**（下单返回 403），补齐后恢复。**应缴额、扣罚、没收、退还仅超管可设定**；代理只能缴纳（缴纳单不受“不足即受限”拦截，避免死锁）。
- **系统租用金**：代理自助缴纳 `POST /api/rental/order`，自动入超管资金池并记台账。
- **违规扣罚**：超管从保证金扣罚 `POST /api/pool/penalty`（须有合同依据）；代理可**申诉** `POST /api/penalties/:id/appeal`，超管**复核通过**后退还、业务恢复。
- **退还**：`POST /api/pool/deposit/refund` 退还保证金，写池账本。
- 上述全部走**不可变账本**，可 `GET /api/ledger/verify` 校验哈希链。

### 代理表（超管）与费用、时间管理

超管 →「**代理租用与保证金**」页（`VIEWS.agentrentals`）把**各代理级账号的租用费与保证金情况表格化**，并把费用与时间规则集中在一处配置，保存即生效。

**代理表列**：代理账号（名称 + 账号 + 代理ID）、状态、本期月租、本期缴费、到期日、宽限期、已逾期天数、应缴保证金、已缴保证金、保证金缺口、累计租用金（含笔数）、操作。

**状态四态**：

| 状态 | 文案 | 含义 |
| --- | --- | --- |
| `normal` | 正常缴费 | 本期已缴清 **且** 保证金足额 |
| `grace` | 待缴费（未逾期） | 保证金足额，但本期未缴，尚在宽限期内 |
| `overdue` | 已逾期未缴 | 已过宽限期仍未缴本期租用金 |
| `restricted` | 受限 | 账号停用 **或** 保证金不足 |

**汇总 KPI**：代理总数、正常缴费、宽限期内、已逾期、受限、本期应收（未缴）、本期已收、应缴保证金合计、保证金缺口。

**费用与时间管理**（同一页上半区，`PUT /api/settings`，**仅超管**）：

| 配置项 | 字段 | 默认 | 作用 |
| --- | --- | --- | --- |
| 月租（每期应收） | `rentalFeeMonthly` | 200000 | 每期应向代理收取的租用金 |
| 默认应缴保证金 | `depositDefaultRequired` | 1000000 | 未逐户钉定的代理跟随此值联动 |
| 出款手续费率 | `withdrawFeeRate` | 0.05 | 出款计提费率 |
| 收货转款费率 | `settleFeeRate` | 0 | 结算转款时加收 |
| 平台使用费率 | `platformFeeRate` | 0 | 超管对代理分级账户计提费率（0 = 不计提） |
| 计费周期 | `rentalBillingCycle` | monthly | `monthly` 自然月 / `quarterly` 自然季度 / `yearly` 自然年 |
| 到期日 | `rentalDueDay` | 1 | 每期第几号截止缴费（1–28） |
| 宽限期 | `rentalGraceDays` | 3 | 到期后仍不计逾期的天数 |
| 逾期处置 | `rentalOverdueAction` | restrict | `restrict` 逾期即限制该代理业务 / `remind` 仅提醒 |

**关键接口**：

| 动作 | 接口 | 权限 |
| --- | --- | --- |
| 读代理表 | `GET /api/rental-board?status=&kw=&limit=` | **仅超管**（返回周期口径、汇总、筛选后的行与字段级状态） |
| 保存费用与时间 | `PUT /api/settings` | **仅超管** |
| 生成代理级账号 | `POST /api/accounts`（`role:"agent"`，`depositRequired` 可选） | **仅超管** |
| 记租用金到账 | `POST /api/pool/rental`（`agentId,amount,period?`） | **仅超管** |
| 记保证金到账 | `POST /api/pool/deposit`（`agentId,amount`） | **仅超管** |
| 退还保证金 | `POST /api/pool/deposit/refund`（存在未复核扣罚申诉时返回 409） | **仅超管** |

**保证金默认值的联动口径**（避免三处读数不一致）：台账 `dep.required` 是**唯一真源**。代理建号时若**留空**应缴保证金，表示**未逐户钉定**——此后超管修改「默认应缴保证金」会**自动同步**该代理的应缴额（账号视图、代理表、保证金闸门三处始终一致）；若超管在生成 / 编辑时**显式填了金额**（含 `0`），该代理即**被钉定**，不再随系统默认值浮动。

> 「代理表」页签**仅超管可见**：代理 / 商户打开该页签不会渲染任何代理表内容，并提示「仅超级管理员可用」；底层 `GET /api/rental-board` 对代理 / 商户一律 **403**。

> 「保证金收款指向哪个账户」与「超管向各代理计提多少使用费」，见 **十四、超管层级账户只收使用费（平台使用费）与保证金收款**。

---

## 十三、收付款设置：收款 / 付款两个资金账户窗口（均支持一键替换）

代理 / 商户后台新增**「收付款设置」**页面（`VIEWS.fund`），把一个账号的**收款**与**付款**拆成**两个独立的资金账户窗口**，各自维护、互不串号：

| 窗口 | 用途 | 接口 |
| --- | --- | --- |
| **收款账户** | 承接收款单：新订单按优先级分配给主收款账户 | `GET /api/fundaccounts?flow=receive` |
| **付款账户** | 对外出款：发起出款未指定收款账号时，自动回落到主付款账户 | `GET /api/fundaccounts?flow=pay` |

每个窗口的账户行都带同样一排操作，**一键替换**是其中的核心：

| 操作 | 后端 | 说明 |
| --- | --- | --- |
| **一键替换** | `POST /api/fundaccounts/:id/replace` | 输入新 KBZ 商业账号即顶替，**新账号立即接任**、旧账号进入**冷却期**（`channelCooldownSec`）；在途订单仍可核销到旧账号，**无需改代码 / 无需重启** |
| 新增 | `POST /api/fundaccounts`（`flow=receive\|pay`，`primary:true` 可顺带设主） | 同一 KBZ 账号不可被两个记录占用（冲突 409） |
| 设为主账户 | `PUT /api/fundaccounts/:id`（`primary:true`） | 同 flow 内只保留一个主账户 |
| 冻结 / 删除 | `PUT`（`status:"frozen"`）/ `DELETE` | 冻结后不再被分配新单 |

操作示例（一键替换一行命令即可，后台是一个按钮）：

```bash
# 把当前收款账户一键换成自己的新 KBZ 账号
curl -X POST https://<你的域名>/api/fundaccounts/<oldId>/replace \
  -H "Authorization: Bearer <token>" -H "Content-Type: application/json" \
  -d '{"account":"09971113333","holder":"我的新号","flow":"receive"}'
# → { "success":true, "replaced":{...旧账号(冷却中)...}, "current":{...新账号(已接管)...}, "cooldownUntil":"..." }
```

界面反馈：替换成功后弹出明确提示「已一键替换：收款账户新号 <账号> 已接管，旧账户冷却至 <时间>」，并自动刷新两个窗口。

> **数据隔离**：代理只能读自己账号的两个窗口；**超管可查看任一代理的资金账户**（`GET /api/fundaccounts?...&ownerId=<代理ID>`），但**展示一律脱敏**（`accountMasked`/`phoneMasked`），即便带 `reveal=1` 也强制脱敏——明文仅限账户归属者本人。

---

## 十四、超管层级账户只收使用费（平台使用费）与保证金收款

超管层级账户（`platform`）**不再直接承接业务收款**，它的两笔收入来源是：**各代理分级账户的使用费** 与 **资金池归集的保证金 / 租用金**。

### 平台使用费

- 计费对象：**订单归属向上最近的一级代理账户**（`agentAncestorOf`，遇到超管层级即止）。
- 费率：`platformFeeRate`（后台「平台账户」页可填，`0` = 暂不计提）；计提口径为**按代理账户的收款结算额**。
- 计提时机：`platformFeeOnCollect`
  - `true`（默认）：在**收款结算**环节计提——「收货转款到户」`settleToAccount`、「直接入账」`settleOrder`；
  - `false`：改在**出款完成**时计提（`executorReceipt` 成功回执分支）。
- 归集：命中即写代理账本 `platform_fee`（out）+ 平台账本 `platform_fee_in`（in），并计入平台账户 `platformFeeTotal`。
- **不硬扣**：代理可用余额不足时，实扣 `min(应收, 可用余额)`，差额记 `platformFeeDue`（欠缴），账目可核。
- 后台入口：`/console` → 超管 →「**平台账户**」页（`VIEWS.platform`）展示 5 个 KPI（平台使用费累计 / 平台账户余额 / 保证金归集 / 租用金归集 / 资金池余额）+ 费率与计提时机配置；接口 `PUT /api/settings {platformFeeRate, platformFeeOnCollect}`（**仅超管**），查询 `GET /api/platform`。

### 保证金 / 租用金收款

- 保证金与租用金**不走业务收款通道**，而是指向**资金池指定的收款账户**（`POST /api/pool/accounts`，**仅超管**可配置，后台「平台账户」页也提供「配置收款账户」按钮）。
- 代理生成缴纳单时，系统从资金池账户中取一个 `depositReceive !== false` 的账户作为收款目标；`getPool().accounts` 随机取用、排除 `retired`。
- 平台账户页同时列出「保证金 / 租用金收款账户（资金池）」表（账号 / 持有人 / 状态），超管可随时核对当前入账指向。

> 一句话：**代理的钱收进代理自己的收款账户；保证金 / 租用金收进资金池账户；超管只对代理分级账户计提使用费。**

---

## 十五、无文档跨平台接入（适配器）

后台 →「适配器」：**表单化**新增一个对接配置（平台名 + 回调 URL + 签名密钥），系统生成回调地址：
```
POST /api/adapter/callback/<adapterId>     # 平台到账/通知回推
POST /api/game/callback/<adapterId>        # 游戏发币回执
```
- 第三方 / 持牌通道按其原有格式回调即可，系统 **HMAC 验签**后自动核销（签名错误返回 401）。
- 订单级 `notifyUrl` 可**零配置**收到到账通知。
- **回调重试**：投递失败自动**指数退避重试**（`webhookBackoffSec * 2^(attempts-1)`），后台可查投递状态并手动重试 / 批量推进。

> 无需阅读任何平台的接口文档即可接入——用表单描述「谁来、怎么签、发到哪」即可。

### 一键接入向导（真正「即插即用」，像 U 盘一样）

后台 →「**接入向导**」页（`VIEWS.pluguide`）把上面那套适配器配置，压缩成**四步傻瓜流程**。平台方也可以完全不登录后台，直接打开自助接入页 `https://<你的域名>/plug` 自助完成。

**第 1 步 · 拿凭据（配对码）**
- 后台「生成配对码」→ 得到形如 `XXXX-XXXX` 的 8 位配对码（24 小时有效、一次性）；或平台方在 `/plug` 页自助申请。
- 平台方调 `POST /api/plug/pair`（body `{"code":"配对码","name":"平台名","targetUrl":"可选：我方接收通知地址"}`）→ 返回 `adapterId` 与一次性 `plugKey`。

**第 2 步 · 一键智能解析（无需任何文档）**
- 把从浏览器 DevTools / 服务端日志里**随便复制的一段报文**粘进「抓包报文」框，点「一键智能解析」。
- 系统按别名表自动认字段（英 / 中 / 缅文均可），并**兼容任意报文格式**：JSON、表单 / 查询串、类对象文本（如 `{out_trade_no: T…, money: "10,000 MMK", playerAccount: gamer001, serverId: s1}`，键不带引号也认）、每行一组 `key: value`。
- 返回：识别的字段映射表、`scene` 场景判定、建议动作、**识别金额**（自动去千分位 / 单位 / 缅文与全角数字）、置信度、仍需补齐字段、建议。
- 只认一条也够用：**必填字段只有 `amount`**。

**第 3 步 · 一键生成接入点**
- 点「一键生成接入点」→ 系统生成专属端点与一次性明文密钥（**只显示一次**）：请求头 `X-Plug-Key: <plugKey>`（也支持 `?k=<plugKey>`）。
- 端点（把 `{adapterId}` 换成你的）：
  ```
  POST /api/plug/{adapterId}/order      # 通用下单（任意字段名 / 任意报文格式）
  POST /api/plug/{adapterId}/notify     # 通用回执（到账 / 发货 / 收货 / 发币 / 关闭 / 退款）
  GET  /api/plug/{adapterId}/pull       # 反向查询订单状态（?orderNo=…）
  GET  /api/plug/{adapterId}/info       # 本接入点实测信息（端点 / 字段别名 / 密钥掩码）
  ```
- 备选鉴权：`X-Signature: HMAC-SHA256(plugKey, 原始请求体)`（不带密钥也能按签名鉴权）。

**第 4 步 · 连通测试 → 轮换**
- 点「连通测试」→ 逐项给出：接入点状态与端点、**字段映射完整性**、**密钥可用性**、推送回调地址连通性；四项全过时结论为「**全部通过，可直接接入**」。
- 需要换密钥时点「轮换密钥」（`POST /api/plug/adapters/:id/rotate`）→ 旧密钥**即时失效**，新密钥只回显一次。

**免文档的机器可读清单**（平台方不用问你任何问题）：
```
GET /api/plug/manifest                # 完整自描述：端点、认证方式、字段别名表、场景与动作规则、错误码
GET /.well-known/kbz-connect.json     # 同上标准发现路径
GET /kbz-plug.js                      # 页面一行引入 KBZPlug.init(...) 即可收发单 / 收通知 / 查状态
```

| 向导相关接口 | 用途 | 权限 |
| --- | --- | --- |
| `GET /api/plug/templates` | 内置模板库（电商 / 游戏 / 通用） | 登录 |
| `GET /api/plug/points` | 我可见的接入点列表（密钥**脱敏**，明文只回显一次） | 登录（按账号树隔离） |
| `POST /api/plug/codes` / `POST /api/plug/codes/:code/revoke` | 生成 / 作废配对码 | 登录 |
| `POST /api/plug/parse` | 一键智能解析（`{captured|raw, url?, contentType?}`） | 登录 |
| `POST /api/plug/adapters` | 一键生成接入点（返回端点 + 一次性密钥） | 登录 |
| `GET /api/plug/adapters/:id/profile` / `POST …/test` / `POST …/rotate` | 接入画像 / 连通测试 / 密钥轮换 | 登录（超管可作用于下属代理，作用域对称） |
| `GET /api/plug/manifest`、`POST /api/plug/pair`、`POST /api/plug/{id}/{order,notify,pull,info}` | 平台方对接面（**无需登录**，用配对码 / `X-Plug-Key` 鉴权） | 公开 |

> 关键实现约定：向导生成的接入点与自助配对路径**完全等价**（`plugKeyCipher` + `signSecretCipher` + 掩码 + `plugkeyhash:` 索引四者齐备），否则 `X-Plug-Key` 鉴权与签名验签必然失败；接入点列表**不使用 `plug` 字段过滤**（`createAdapter` 不写该字段），改用 `templateId` / `wizard` 判定。

---

## 十六、安全与敏感数据存储

### 接入安全
- **签名**：服务端 API 签名 = `HMAC-SHA256(商户密钥, METHOD\nPATH\nX-Timestamp\nX-Nonce\nsha256hex(原始请求体))`；回调签名 = `HMAC-SHA256(适配器密钥, 原始请求体)`（游戏回执同规范）。
- **防重放**：`X-Timestamp` 容忍偏差 `signatureSkewSec`（默认 300 秒）+ `X-Nonce` 一次性（TTL `nonceTtlSec`），重复 nonce 直接拒绝。
- **幂等**：下单接口支持 `X-Idempotency-Key`，同一接入方同键只受理一次（重复返回首次结果）；核销按交易号去重。
- **限流**：每接入方每分钟 `rateLimitPerMin`（默认 120）次，超限返回 429。
- **强制模式**：`requireApiSignature = true` 时，缺任一签名头直接 **401**；默认 `false` 为“带签名头即校验，完全不带则跳过”的宽松模式。
- **回调强制验签**：适配器回调与游戏回执**一律要求签名**，缺失 / 错误 401，并落 `callback.reject` 审计。

### 敏感数据存储
- **密钥只存哈希**：商户密钥 `mkeyhash:<sha256hex('mkey:'+key)>`、设备密钥 `devkeyhash:<sha256hex('dk:'+key)>` + 记录内 `keyHash`/`keyMasked`；登录口令 `passHash` + `salt`（PBKDF2 60000 轮）。
- **敏感字段加密落库**（AES-GCM，格式 `enc1:{iv}:{cipher}`）：适配器 `signSecretCipher`、订单级回调密钥 `ordcb:<id>.secretCipher`、回调投递记录 `wh:<id>.secretCipher`、卡密 `cardSecretCipher`（结算转款后 `delete`）。
- **主密钥分离**：优先读环境变量 `DATA_KEY`；未配置时随机生成并存于单独键 `sys:datakey`（仅本地兜底），**不写入配置或业务记录**。
- **展示脱敏**：收款账号 / 手机号在列表与订单中默认打码（`maskAccount` / `maskPhone`，如 `+959****567`）；只有**订单归属者本人 / 通道归属者本人**可见明文，`?reveal=1` 受限明文读取会写 `channel.reveal` 审计，**上级查看下级订单一律脱敏**。
- **响应与日志干净**：`stripSensitive` 递归剥除敏感字段；`GET /api/settings` 与 `PUT /api/settings` 都不回显任何口令字段；订单 / 账号树 / 审计日志响应中不含明文密钥、卡密。
- **不可变账本**：所有资金流水走 prevHash 链式账本；关键动作（下单 / 受限读取 / 密钥轮换 / 配置变更 / 回调拒绝）全量审计。

### 接入面与输入边界防护（防枚举 / 防灌爆）

公开接入面（**免登录**）是攻击者最容易够到的入口，系统在「地区锁定」之后、业务逻辑之前再加四道防线：

| 防线 | 触发点 | 行为 |
| --- | --- | --- |
| **公开入口限流** | `setup`（首次设密）/ `login` / `pstatus` / `payview` / `confirm` / `delivery` / `receive` / `payinit` / `pair`（配对码）/ `device`（设备与执行端密钥拉取）共 **10 个入口** | 按「**入口 + 来源 IP**」计数（`CF-Connecting-IP`→`X-Forwarded-For`→`anon`），超 `publicRateLimitPerMin`（默认 240/分钟）返回 **429**；`0` = 关闭该层限流 |
| **请求体体积上限** | 所有写接口（含回调） | `Content-Length` 或实读字节 > **2 MB** 直接 **413**，挡住超大报文体拖垮边缘节点 |
| **单次批量条数上限** | `POST /api/notify/forward`、`POST /api/reconcile/ingest` | 单次 `rows` > **200 条** 返回 **413**，要求分批上报 |
| **列表条数与 token 夹取** | 各列表接口 `limit`、凭据解析 | `limit` 一律夹到 `[1, 2000]`（空 / 非正数取默认）；会话 / Cookie / `?token=` / `Authorization` 凭据**截断至 200 字符**，避免超长串进入哈希与索引 |

> 设计意图：**限流按 IP 分桶**，可挡住「换账号喷洒」绕过账号级锁定的猜解、`payview` 的 token 枚举、`pstatus` / `device` 的密钥枚举；同时防止单个请求塞入海量流水打满边缘算力与 KV 写入。

### 会话与错误策略（后台「设置」页可配）

| 项 | 字段 | 默认 | 作用 |
| --- | --- | --- | --- |
| 会话有效期 | `sessionTtlSec` | 43200 | 登录态时长（秒）；活跃请求**滑动续期**，`GET /api/security/sessions` 可查在线会话 |
| 登录失败上限 | `loginMaxAttempts` | 6 | 同一账号连续失败达上限即锁定（**账号 + 来源 IP** 维度） |
| 登录锁定时长 | `loginLockSec` | 900 | 锁定持续秒数，解锁前登录返回 **429 `LOGIN_LOCKED`** |
| 强制改密闸门 | `enforcePasswordChange` | false | 开启后，新建账号未改密前调用业务接口返回 **428**（白名单：`/api/me/password`、`/api/auth/me`、`/api/overview`） |
| 5xx 错误脱敏 | `exposeErrorDetail` | false | 默认只回「服务器内部错误（关联号 xxxxxx）」，真实原因写审计；仅排障期可临时开启 |
| 公开接入面限流 | `publicRateLimitPerMin` | 240 | 见上一小节；`0` = 关闭 |

- **会话可查可撤**：`GET /api/security/sessions`（本人可查；超管可代查任一账号，越权返回 **404**）；`POST /api/security/sessions/revoke`（撤销后令牌**立即失效**，超管可撤他人）。
- **CORS 收紧**：公开接入面回 `*`；**携带登录态**的跨站来源**不回 `Access-Control-Allow-Origin`**，仅同源才回显；统一带 `X-Content-Type-Options: nosniff` / `X-Frame-Options: DENY` / `Strict-Transport-Security` / `Content-Security-Policy`（含 `frame-ancestors 'none'`）+ `Vary: Origin`。

### 运维建议（生产）

- 上线后**立即**在 `/admin` 设强口令，并把 `DEVICE_KEY` / `DATA_KEY` 配成 Cloudflare **Secret**（见「四、上线前必改清单」）。
- `exposeErrorDetail` 排障结束后**务必改回 `false`**；`publicRateLimitPerMin` 与 `rateLimitPerMin` 按真实流量调参（中小站点默认值足够）。
- 定期在「维护与对账」页看**未匹配流水**与**回调积压**，并 `GET /api/audit/verify` 校验审计链、`GET /api/ledger/verify` 校验资金账本。

---

## 十七、环境变量与绑定

| 名称 | 类型 | 说明 |
| --- | --- | --- |
| `KBZ_GATEWAY` | KV 绑定 | 全部业务数据存储 |
| `ALLOW_COUNTRIES` | 变量 | 允许地区白名单（逗号分隔，或 `ALL` / `*` 表示不限制），默认 `MM`（仅缅甸） |
| `DEFAULT_CURRENCY` | 变量 | 默认币种 `MMK` |
| `GATEWAY_NAME` | 变量 | 系统名称（落地页 / 后台标题） |
| `DEVICE_KEY` | **Secret** | 通知转发端 / 出款执行端的兜底设备密钥 |
| `DATA_KEY` | **Secret**（建议） | 敏感字段 AES-GCM 加密主密钥 |

> **优先级**：`ALLOW_COUNTRIES` / `DEFAULT_CURRENCY` / `GATEWAY_NAME` 由**部署环境变量**决定，**高于**后台「设置」里保存的同名字段（未设置对应环境变量时，则以后台设置为准）。因此改完 `wrangler.toml` 的 `[vars]` 需重新 `wrangler deploy` 才生效。

本地化：金额单位 MMK、时区 UTC+6:30、手机号 `+95`、KYC 支持 NRC/护照、界面中/英/缅三语。

---

## 十八、目录结构

```
kbzpay-multichannel-gateway/
├── worker.js               # Cloudflare 入口（fetch + scheduled）
├── src/
│   ├── core.js             # 配置/KV/加密/组织树/会话/账本/通道/资金池/审计/租期口径/限流
│   ├── engine.js           # 下单/识别码/核销/发货/收货转款/出款/适配器/Webhook/保证金/代理表/游戏上下分/维护任务
│   ├── plug.js             # 无文档跨平台接入层（模板库/抓包解析/通用入口/连通测试/配对码/密钥轮换）
│   ├── api.js              # 全部 HTTP 路由（页面/公开接口/设备接口/登录接口）+ 公开面限流/体积/条数闸门
│   ├── pages.js            # 落地页/后台（含「收付款设置」「平台账户」「代理租用与保证金」「游戏上下分」「接入向导」「维护与对账」「安全会话」）/收银台/SDK/自助接入页
│   └── i18n.js             # 缅/英/中多语言词条
├── lib/memory-kv.mjs       # 本地内存版 KV（仅本地联调）
├── test/                   # 端到端 + 定向验证脚本（e2e、smoke、verify-t1…t10、verify-dist 交付产物直验）
├── build.mjs               # 合成单文件 dist/index.js（把 src 各模块按 ORDER 拼接，剥离 import/export）
├── dev-server.mjs          # 本地一键启动
├── wrangler.toml           # 部署与绑定配置
├── dist/index.js           # 由 build.mjs 生成的单文件产物（= 部署到 Cloudflare 的那一份）
└── package.json
```

> 新增源码文件必须插进 `build.mjs` 的 `ORDER` 数组，否则不会进入 `dist/index.js`；改完源码务必 `node build.mjs` 重建产物。

---

## 十九、验收自测

```bash
node test/e2e-test.mjs         # 端到端（含电商/游戏闭环与安全用例）：135 项通过，失败 0 项
node test/smoke-http.mjs       # 本地 HTTP 冒烟（自启动 dev-server，真实 HTTP）：19 项通过，失败 0 项
node test/verify-t1.mjs        # 生命周期与发货/收货/结算（24 项）
node test/verify-t2.mjs        # 自动出款与审批闸门（19 项）
node test/verify-t3.mjs        # 游戏闭环与托管（19 项）
node test/verify-t4.mjs        # 签名/防重放/幂等/限流/审计（16 项）
node test/verify-t5.mjs        # 敏感信息存储加固（49 项）
node test/verify-t6.mjs        # 代理级收款/付款资金账户与数据隔离（23 项）
node test/verify-t7.mjs        # 超管平台使用费与保证金收款归集（25 项）
node test/verify-t8.mjs        # 「收付款设置」/「平台账户」页面 ↔ 后端一致性（28 项）
node test/verify-t9.mjs        # 代理表 / 费用与时间管理 / 游戏上下分 / 接入向导（120 项）
node test/verify-t10.mjs       # 业务闭环补齐 + 安全加固：维护与对账 / 安全会话 / 接入面加固（154 项）
node test/verify-dist.mjs      # 交付件本体直验：直接加载 dist/index.js 走真实请求链（52 项）
npm run check                  # 全部源文件语法检查（含 verify-dist.mjs）
npm run build                  # 生成 dist/index.js 单文件
```

> 合计 **683 项**（e2e 135 + 冒烟 19 + 定向 T1–T10 共 477 项 + 交付产物直验 52 项）。全部为本地可复跑的自动化用例，无外部依赖。

覆盖：超管唯一入口与首次设密（无默认口令、设密后关闭入口）、保证金设定权（代理/商户越权 403）、地区锁定、多级账号与数据隔离（越权 404）、KBZ 通道与一键替换、识别码自动收款核销、**电商自动发货与收货转款到户**、**游戏无文档接入与发币回执闭环**、自动付款与审批闸门、资金池/保证金/租用金/扣罚/申诉、适配器与回调重试、**签名/防重放/幂等/限流**、**敏感字段无明文落库与展示脱敏**、不可变账本校验、**代理级收款 / 付款双资金账户与一键替换（含上级查看脱敏）**、**超管平台使用费计提与保证金收款走资金池**、**超管代理表（汇总 KPI / 状态四态 / 筛选 / 明细）与费用时间配置保存生效并驱动代理表联动**、**保证金默认值钉定与联动口径**、**游戏上下分（上分入账 / 下分冻结 → 回执成功出账 / 失败取消回滚解冻 / 取消与回滚幂等 / 越权挂靠 409）**、**无文档一键接入（抓包解析 / 一键生成接入点 / 端点与密钥 / 脱敏 / 连通测试全通过 / 配对码生成作废 / 密钥轮换与作用域对称）**、**维护与对账（状态面板 / 一键执行 / 订单超时自动关闭并释放识别码 / 未匹配流水脱敏落库与人工核销 / 重复上报自动销账）**、**安全会话与错误策略（登录防爆破锁定 / 强制改密闸门 428 / 会话可查可撤 / CORS 收紧与安全响应头 / 审计链验真 / 5xx 脱敏）**、**公开接入面加固（按「入口 + 来源 IP」限流 / 请求体 2MB 上限 / 单次批量 200 条上限 / 列表 2000 夹取 / 超长 token 截断 / 凭据不外泄）**、页面与 SDK 完整性。

**交付件本体直验（`verify-dist.mjs`）另行保证**：不只看源码，而是**直接加载 `dist/index.js` 这一份单文件产物**（也就是你将部署到 Cloudflare 的那一份），在本机内存 KV 上跑真实请求链，逐条复核「地区锁定 → 超管首次设密唯一性 → 建代理 → 越权隔离 → 代理表 → 费用时间配置联动 → 保证金/租用金入池 → 收付款双窗口一键替换 → 自动收款/发货/转款 → 游戏上下分与回滚守恒 → 无文档一键接入」。

---

## 二十、常见问题

- **登录一直提示未登录？** 登录接口是 `POST /api/auth/login`，之后请求带 `Authorization: Bearer <token>`。
- **终端用户看不到付款信息？** 收银台链接需带 `?t=<token>`，token 有时效（`orderTtlSec`），过期请重新下单。
- **通知转发报 401？** 检查请求头 `X-Device-Key` 是否为有效设备密钥；若开启强制签名还需带 `X-Timestamp`/`X-Nonce`/`X-Signature`。
- **服务端下单报 401？** 开启 `requireApiSignature` 后必须带完整签名头；签名串须用**客户端实际发送的** `X-Timestamp`/`X-Nonce` 原值计算。
- **订单一直停在「已到账·待发货」？** 说明下单未带发货要素（卡密/物流单号），到后台点「发货」补录即可。
- **买家确认收不了货？** 仅**托管**订单（`ecommerce`/`game`）且已发货（`delivered`）才可确认收货；非托管订单无需确认。
- **回调没收到？** 检查第三方是否按签名验签；后台「Webhooks」可看投递记录与重试。
- **高并发识别码撞码？** 增加收款账户、缩短识别码有效期、或调大 `tailDigits` 分段扩容；生产建议将热点计数升级到 D1 / Durable Objects。
- **代理表里某代理的应缴保证金没跟着「默认值」变？** 说明该代理已被**逐户钉定**（生成 / 编辑时显式填过金额，含 `0`）。未钉定的代理才会随「默认应缴保证金」自动联动；如需重新跟随，把它的应缴额再留空保存一次即可。
- **下分提示「可用余额不足」？** 下分**创建即冻结等额余额**（不足直接 409），先确认该账号可用余额充足，或先完成上分 / 结算释放余额。
- **游戏指令单一直停在「待执行」？** 执行端尚未领取：用 `GET /api/game/executor/pull`（请求头 `X-Device-Key`）拉取任务，完成后 `POST /api/game/executor/receipt` 回执；**只有回执成功才实际入账 / 出账**，失败或取消会自动解冻回补。
- **抓包报文解析不出金额？** 必填字段只有 `amount`：尽量把含金额的那一行完整贴入（JSON / 表单串 / 类对象文本都可），或让 URL 里带上含金额的查询参数；识别金额会自动去掉千分位、单位与缅文 / 全角数字。
- **通用入口报 401？** 用生成时**只回显一次**的 `X-Plug-Key`（也支持 `?k=`），或改走 `X-Signature: HMAC-SHA256(plugKey, 原始请求体)`；密钥可随时在「接入向导」或 `POST /api/plug/adapters/:id/rotate` 轮换。
- **想改月租 / 到期日 / 逾期规则？** 超管「代理租用与保证金」页上半区改完保存**立即生效**，代理表状态与到期判定随之刷新；到期日限 1–28，超出范围自动收敛。
- **后台改了「地区 / 币种 / 系统名称」却没生效？** 这三项若在部署环境变量里给过（`ALLOW_COUNTRIES` / `DEFAULT_CURRENCY` / `GATEWAY_NAME`），**以环境变量为准**，后台设置会被覆盖。想用后台设置控制，就先把对应的环境变量删掉再重新 `wrangler deploy`。

---

## 二十一、合规提示

- 本系统是**技术中台**，不承担支付牌照责任；在缅甸提供支付相关服务的持牌要求（CBM 牌照）、持牌通道接入、博彩类高敏感业务的合规审查由运营方自行落实。
- 保证金扣罚**须有合同与当地法规依据**；请依法使用。
- 上线前务必替换所有默认口令与密钥，并配置 `DATA_KEY`。

---

许可：MIT