/**
 * 本地一键运行（无需任何云账号）
 * ---------------------------------------------------------------------------
 * 作用：把 Cloudflare Workers 的请求入口 handleRequest 挂到一个本地 HTTP 服务上，
 *       并用内存版 KV 代替云端 KV，方便在电脑/手机上先把整套系统跑起来验收。
 * 用法：
 *   node dev-server.mjs            # 默认端口 8787
 *   PORT=9000 node dev-server.mjs  # 指定端口
 * 打开：http://localhost:8787/         落地页（五步上线说明）
 *       http://localhost:8787/admin    超管唯一入口（首次进入时输入的密码即唯一超管密码）
 *       http://localhost:8787/console  后台（代理 / 商户登录；超管也可在此登录）
 * 说明：本地模式仅用于演示与联调；正式上线请用 wrangler deploy 部署到 Cloudflare Workers。
 */
import http from 'node:http'
import { createMemoryKV } from './lib/memory-kv.mjs'
import { handleRequest } from './src/api.js'

// Node 18 起内置 WebCrypto；老版本用 node:crypto 兜底
if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

const PORT = Number(process.env.PORT || 8787)
const ENV = {
  KBZ_GATEWAY: createMemoryKV(),
  ALLOW_COUNTRIES: process.env.ALLOW_COUNTRIES || 'MM',
  // 本地联调用：通知转发端/出款执行端可用该密钥直接调接口
  DEVICE_KEY: process.env.DEVICE_KEY || 'dev-device-key-0001',
  ASSETS: { fetch: async () => new Response('', { status: 404 }) },
}
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) }, passThroughOnException: () => {} }

// 本地没有 CDN 的 CF-IPCountry 头，注入 MM 让地区锁定逻辑走通
const SKIP_HEADERS = new Set(['connection', 'host', 'content-length', 'transfer-encoding', 'keep-alive', 'upgrade'])

const server = http.createServer(async (req, res) => {
  const chunks = []
  for await (const c of req) chunks.push(c)
  const raw = Buffer.concat(chunks)

  const headers = {}
  for (const [k, v] of Object.entries(req.headers)) {
    if (SKIP_HEADERS.has(k.toLowerCase())) continue
    headers[k] = Array.isArray(v) ? v.join(',') : v
  }
  if (!headers['cf-ipcountry']) headers['cf-ipcountry'] = 'MM'

  const url = 'http://' + (req.headers.host || ('localhost:' + PORT)) + req.url
  const init = { method: req.method, headers }
  if (req.method !== 'GET' && req.method !== 'HEAD' && raw.length) init.body = raw

  let response
  try {
    response = await handleRequest(new Request(url, init), ENV, CTX)
  } catch (e) {
    res.statusCode = 500
    res.setHeader('Content-Type', 'application/json; charset=utf-8')
    res.end(JSON.stringify({ success: false, error: String(e && e.message || e) }))
    return
  }

  res.statusCode = response.status
  response.headers.forEach((v, k) => res.setHeader(k, v))
  const buf = Buffer.from(await response.arrayBuffer())
  res.end(buf)
})

server.listen(PORT, () => {
  console.log('')
  console.log('  缅甸多平台收付款多级分管通道系统 —— 本地演示已启动')
  console.log('  ------------------------------------------------------------')
  console.log('  落地页：   http://localhost:' + PORT + '/')
  console.log('  超管入口： http://localhost:' + PORT + '/admin   （首次进入时输入的密码即唯一超管密码）')
  console.log('  后台：     http://localhost:' + PORT + '/console')
  console.log('  收银台：   http://localhost:' + PORT + '/pay?t=<订单token>')
  console.log('  SDK：      http://localhost:' + PORT + '/sdk.js')
  console.log('  健康检查： http://localhost:' + PORT + '/health')
  console.log('  超管账号： superadmin（无默认口令，首次在 /admin 设定）')
  console.log('  设备密钥： ' + ENV.DEVICE_KEY + '   （通知转发端 / 出款执行端使用）')
  console.log('')
})