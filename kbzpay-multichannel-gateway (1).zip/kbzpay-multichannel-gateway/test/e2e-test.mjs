/**
 * 端到端验收测试（node test/e2e-test.mjs）
 * ---------------------------------------------------------------------------
 * 直接调用 Worker 入口 handleRequest（内存 KV），并用本地 HTTP 服务扮演「第三方平台回调地址」，
 * 覆盖以下验收点：
 *   0. 超管唯一入口：第一次输入的密码即唯一超管密码（未设密引导 / 已设密只允许登录 / 无默认口令）
 *   1. 保证金设定权：应缴额、入池、扣罚、退还、系统设置仅后台超管可设定，代理/商户一律 403
 *   A. 地区锁定：非缅甸地区一律拒绝
 *   B. 多级账号：超管 → 代理 → 商户，角色/权限/数据域隔离（越权返回 404）
 *   C. KBZ 主通道：代理自建通道、通道一键替换（旧通道冷却、新通道接任）
 *   D. 自动收款：金额识别码 + 通知转发端自动核销（含交易号去重）+ 截图凭证兜底
 *   E. 自动付款：额度内自动入队 / 超限上级审批 / 执行端回执 / 额度冻结与退回
 *   F. 资金池：保证金缴纳与不足受限、违规扣罚与复核退还、系统租用金入池
 *   G. 不可变账本：哈希链校验、账实相符
 *   H. 无文档接入：适配器回调验签、回调投递与重试、商户密钥服务端下单
 * 运行：npm test
 */
import http from 'node:http'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

/* ---------------------------------------------------------------- 测试框架 */
let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' → ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' → ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

/* ---------------------------------------------------------------- 运行环境 */
const ENV = {
  KBZ_GATEWAY: createMemoryKV(),
  ALLOW_COUNTRIES: 'MM',
  DEVICE_KEY: 'test-device-key-0001',
}
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }

async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': opt.country || 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text, headers: res.headers }
}
async function login(username, password) {
  const r = await call('/api/auth/login', { method: 'POST', body: { username, password } })
  return r.json && r.json.token
}

/* ------------------------------------------------------ 第三方平台回调接收端 */
const received = []
const cbServer = http.createServer((req, res) => {
  let body = ''
  req.on('data', (c) => { body += c })
  req.on('end', () => {
    received.push({ url: req.url, body, signature: req.headers['x-signature'] })
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end('{"ok":true}')
  })
})
await new Promise((r) => cbServer.listen(0, '127.0.0.1', r))
const CB_PORT = cbServer.address().port
const CB_URL = 'http://127.0.0.1:' + CB_PORT + '/platform/callback'

async function hmacHex(secret, msg) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg))
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, '0')).join('')
}
async function sha256hex(s) {
  const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(s || '')))
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, '0')).join('')
}
// 按接入规范对服务端 API 请求签名并调用：METHOD\nPATH\nX-Timestamp\nX-Nonce\nsha256hex(rawBody)
async function apiSigned(path, body, opt = {}) {
  const raw = typeof body === 'string' ? body : JSON.stringify(body || {})
  const ts = opt.ts || String(Date.now())
  const nonce = opt.nonce || ('e2e-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8))
  const sig = opt.sig || await hmacHex(opt.key || '', ['POST', path, ts, nonce, await sha256hex(raw)].join('\n'))
  return await call(path, {
    method: 'POST',
    headers: Object.assign({
      'X-Merchant-Key': opt.key || '', 'X-Timestamp': ts, 'X-Nonce': nonce,
      'X-Signature': sig, 'X-Idempotency-Key': opt.idem || '',
    }, opt.headers || {}),
    body: raw,
  })
}

/* ===================================================================== A0 超管唯一入口 */
section('A0. 超管入口与首次设密（第一次输入的密码即唯一超管密码）')
const st0 = await call('/api/setup/status')
ok(st0.json && st0.json.success === true && st0.json.initialized === false, '全新系统：超管尚未设密（initialized=false）', st0.json)
const adminPage0 = await call('/admin')
ok(adminPage0.status === 200 && adminPage0.text.indexOf('首次设密') > 0 && adminPage0.text.indexOf('btnSetup') > 0, '未设密时 /admin 展示「首次设密」表单')
checkPage(adminPage0.text, '超管入口（首次设密）页面生成物语法与渲染正常')
ok((await call('/admin', { country: 'TH' })).status === 403, '非缅甸地区访问超管入口被拒绝（403）')
const preLogin = await call('/api/auth/login', { method: 'POST', body: { username: 'superadmin', password: 'Admin@12345' } })
ok(preLogin.status === 428 && String(preLogin.json.error).indexOf('/admin') >= 0, '设密前用任何口令登录超管一律被拒（428 并引导去 /admin）', preLogin.json)
ok((await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: '12345' } })).status === 400, '首次设密：密码短于 6 位被拒（400）')
ok((await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'Admin@12345' } })).status === 400, '首次设密：旧默认口令被拒（400）')
ok((await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'AA8965' } })).status === 400, '首次设密：历史弱口令（大小写不敏感）被拒（400）')
ok((await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'Mismatch@2026' } })).status === 400, '首次设密：两次密码不一致被拒（400）')
const setupRes = await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
ok(setupRes.json && setupRes.json.success === true && !!setupRes.json.token, '首次设密成功并直接签发登录态（免二次输入）', setupRes.json)
const tokenSuper = setupRes.json.token
ok((await call('/api/auth/me', { token: tokenSuper })).json.profile.role === 'super', '设密后立即获得超管身份')
ok((await call('/api/setup/status')).json.initialized === true, '设密后状态变为 initialized=true')
ok((await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'AnotherUnique@9' } })).status === 403, '已设密后再次设密被拒绝（403，入口永久关闭）')
const adminPage1 = await call('/admin')
ok(adminPage1.status === 200 && adminPage1.text.indexOf('首次设密') < 0 && adminPage1.text.indexOf('请使用账号密码登录') > 0, '已设密后 /admin 只保留登录（不再展示设密表单）')
ok(!!(await login('superadmin', 'MyUnique@2026')), '用自己设定的唯一密码可正常登录')
ok(!(await login('superadmin', 'Admin@12345')), '旧默认口令 Admin@12345 无法登录（系统无默认口令）')
ok(!(await login('superadmin', 'aa8965')), '历史弱口令 aa8965 无法登录')

/* ===================================================================== A 地区锁定 */
section('A. 地区锁定（仅缅甸可用）')
ok((await call('/api/config', { country: 'TH' })).status === 403, '非缅甸 IP 访问接口被拒绝（403）')
ok((await call('/', { country: 'TH' })).status === 403, '非缅甸 IP 访问后台页面被拒绝（403）')
ok((await call('/', { country: 'MM' })).status === 200, '缅甸地区可正常访问落地页')
ok((await call('/console')).status === 200, '后台页面可访问')
ok((await call('/sdk.js')).status === 200, '一行接入 SDK 可访问')
ok((await call('/health')).status === 200, '健康检查可用')

/* ===================================================================== B 多级账号 */
section('B. 多级账号与数据隔离')
ok(!!tokenSuper, '超管登录态可用（沿用首次设密签发的令牌）')
const meSuper = await call('/api/auth/me', { token: tokenSuper })
ok(meSuper.json && meSuper.json.profile.role === 'super', '超管身份识别正确')

const agentA = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const agentB = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_b', password: 'AgentB@12345', name: '代理B', depositRequired: 1000000 } })).json.account
ok(agentA && agentA.role === 'agent' && agentB && agentB.role === 'agent', '超管可创建多个代理账号')
const tokenA = await login('agent_a', 'AgentA@12345')
const tokenB = await login('agent_b', 'AgentB@12345')
ok(!!tokenA && !!tokenB, '代理账号可登录')

const merch = (await call('/api/accounts', { method: 'POST', token: tokenA, body: { role: 'merchant', username: 'shop_one', password: 'ShopOne@123', name: '一号商户' } })).json.account
ok(merch && merch.role === 'merchant' && merch.parentId === agentA.id, '代理可创建下属商户（归属正确）')
ok((await call('/api/accounts', { method: 'POST', token: tokenA, body: { role: 'agent', username: 'agent_x', password: 'AgentX@123' } })).status === 403, '代理默认不能越级创建代理（403）')
const tokenM = await login('shop_one', 'ShopOne@123')
ok(!!tokenM, '商户账号可登录')

ok((await call('/api/stats?ownerId=' + agentB.id, { token: tokenA })).status === 404, '代理读取其他代理数据被拒绝（404）')
ok((await call('/api/ledger?ownerId=' + agentB.id, { token: tokenA })).status === 404, '代理读取其他代理账本被拒绝（404）')
ok((await call('/api/channels?ownerId=' + agentB.id, { token: tokenA })).status === 404, '代理读取其他代理通道被拒绝（404）')
ok((await call('/api/accounts?ownerId=' + agentB.id, { token: tokenM })).status === 200 && (await call('/api/tree', { token: tokenM })).json.count === 1, '商户只能看到自己（组织树仅 1 个节点）')
ok((await call('/api/stats?ownerId=' + agentA.id, { token: tokenSuper })).status === 200, '超管可查看任意下级数据')

/* ===================================================================== B2 保证金设定权 */
section('B2. 保证金设定权（仅后台超管可设定）')
ok((await call('/api/accounts', { method: 'POST', token: tokenA, body: { role: 'merchant', username: 'shop_dep', password: 'ShopDep@123', depositRequired: 500000 } })).status === 403, '代理创建下级时代设保证金被拒绝（403）')
ok((await call('/api/accounts/' + merch.id, { method: 'PUT', token: tokenM, body: { depositRequired: 999999 } })).status === 403, '商户试图修改自己的应缴保证金被拒绝（403）')
ok((await call('/api/accounts/' + agentA.id, { method: 'PUT', token: tokenA, body: { depositRequired: 3000000 } })).status === 403, '代理试图修改自己的应缴保证金被拒绝（403）')
ok((await call('/api/accounts/' + merch.id, { method: 'PUT', token: tokenA, body: { depositRequired: 1 } })).status === 403, '代理试图修改下级商户的应缴保证金被拒绝（403）')
ok((await call('/api/pool', { token: tokenA })).status === 403, '代理读取超管资金池总览被拒绝（403）')
ok((await call('/api/pool/deposit', { method: 'POST', token: tokenA, body: { agentId: agentA.id, amount: 100000 } })).status === 403, '代理调用「登记保证金入池」被拒绝（403）')
ok((await call('/api/pool/penalty', { method: 'POST', token: tokenA, body: { agentId: agentB.id, amount: 100000, reason: 'x' } })).status === 403, '代理调用「违规扣罚」被拒绝（403）')
ok((await call('/api/pool/deposit/refund', { method: 'POST', token: tokenM, body: { agentId: agentA.id, amount: 100000 } })).status === 403, '商户调用「保证金退还」被拒绝（403）')
ok((await call('/api/pool/accounts', { method: 'POST', token: tokenM, body: { accounts: [] } })).status === 403, '商户配置资金池收款账户被拒绝（403）')
ok((await call('/api/settings', { method: 'PUT', token: tokenM, body: { depositDefaultRequired: 5 } })).status === 403, '商户修改系统设置（含默认应缴保证金）被拒绝（403）')
ok((await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { depositDefaultRequired: 1000000 } })).json.success === true, '超管可设定默认应缴保证金（系统设置）')
const setReqB = await call('/api/accounts/' + agentB.id, { method: 'PUT', token: tokenSuper, body: { depositRequired: 1500000 } })
ok(setReqB.json.account && setReqB.json.account.depositRequired === 1500000, '超管可设定代理应缴保证金（1500000）')
ok((await call('/api/deposit', { token: tokenB })).json.deposit.required === 1500000, '应缴保证金变更已落到该代理保证金台账')
await call('/api/accounts/' + agentB.id, { method: 'PUT', token: tokenSuper, body: { depositRequired: 1000000 } })

/* ===================================================================== F 资金池 */
section('F. 资金池 / 保证金（先补齐方可开展业务）')
ok((await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 10000 } })).status === 403, '代理保证金未缴时其商户下单被限制（403）')

const poolSet = await call('/api/pool/accounts', { method: 'POST', token: tokenSuper, body: { accounts: [{ account: '09970000111', holder: '资金池主账户' }] } })
ok(poolSet.json.success && poolSet.json.pool.accounts.length === 1, '超管可配置资金池收款账户')
// 保证金不足不得阻断「补缴」本身（否则代理无法自救）
const depSelf = await call('/api/deposit/order', { method: 'POST', token: tokenA, body: { amount: 1000000 } })
ok(depSelf.status === 200 && depSelf.json.order && depSelf.json.order.scene === 'deposit' && depSelf.json.order.channelAccount === '09970000111', '代理保证金不足时仍可自行发起缴纳单（缴纳≠设定，不越权拦截）', { status: depSelf.status, json: depSelf.json })

const topupA = await call('/api/pool/deposit', { method: 'POST', token: tokenSuper, body: { agentId: agentA.id, amount: 1000000, note: '代理A首期保证金' } })
ok(topupA.json.deposit.paid === 1000000 && topupA.json.deposit.sufficient === true, '超管登记代理A保证金 1,000,000 MMK（账实一致）')
ok((await call('/api/pool/deposit', { method: 'POST', token: tokenSuper, body: { agentId: agentB.id, amount: 1000000 } })).json.deposit.paid === 1000000, '超管登记代理B保证金 1,000,000 MMK')
const pool1 = (await call('/api/pool', { token: tokenSuper })).json.pool
ok(pool1.balance === 2000000 && pool1.depositTotal === 2000000, '资金池总额 = 各代理保证金之和')

/* ===================================================================== C 通道 */
section('C. KBZ 主通道与一键替换')
const chA = (await call('/api/channels', { method: 'POST', token: tokenA, body: { account: '09971112223', holder: '代理A(KBZ商业账户)', primary: true, label: '主力收款' } })).json.channel
ok(chA && chA.status === 'active' && chA.primary === true, '代理可自建 KBZ 商业账户通道')
ok((await call('/api/channels', { method: 'POST', token: tokenB, body: { account: '09971112223' } })).status === 409, '同一 KBZ 账号不可被两个账号占用（409）')
const chB = (await call('/api/channels', { method: 'POST', token: tokenB, body: { account: '09972223334', holder: '代理B', primary: true } })).json.channel
ok(!!chB, '代理B 建立自有通道')

/* ===================================================================== D 自动收款 */
section('D. 自动收款（金额识别码 + 通知转发自动核销）')
const ord1 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 15000, scene: 'ecommerce', subject: '游戏点卡', merchantOrderId: 'SHOP-0001', cardSecret: 'CARD-DEMO-0001' } })).json.order
ok(!!ord1 && ord1.channelAccount === '09971112223', '商户下单，自动调度到其上级代理的主通道')
ok(ord1.payable >= ord1.amount && (ord1.payable % 1000) === ord1.tailorCode, '自动分配金额识别码（尾码与应付金额一致）')
ok((await call('/api/pay/' + ord1.token)).json.order.payable === ord1.payable, '托管收银台可凭 token 取到付款信息（公开接口）')

const notify1 = await call('/api/notify/forward', {
  method: 'POST',
  headers: { 'X-Device-Key': ENV.DEVICE_KEY },
  body: { rows: [{ receiverAccount: '09971112223', amount: ord1.payable, txid: 'KBZ2601000001', source: 'notify' }] },
})
ok(notify1.json.results[0].status === 'paid' && notify1.json.results[0].matchedBy === 'tail', '通知转发自动核销成功（按识别码精确匹配）', notify1.json)
ok((await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: '09971112223', amount: ord1.payable, txid: 'KBZ2601000001' } })).json.results[0].status === 'duplicate', '同一交易号重复上报被识别为重复（幂等）')
const ord1After = (await call('/api/orders/' + ord1.orderId, { token: tokenM })).json.order
ok(ord1After.status === 'paid', '订单状态机流转到 paid')
ok(ord1After.stage === 'delivered', '电商订单到账即自动发货（stage=delivered）')
ok((await call('/api/stats', { token: tokenM })).json.stats.escrow === 15000, '电商货款先进入托管余额（待买家收货）', (await call('/api/stats', { token: tokenM })).json.stats)
const dv1 = await call('/api/pay/delivery?t=' + ord1.token)
ok(dv1.json.order.deliveryView.type === 'card' && dv1.json.order.deliveryView.cardSecret === 'CARD-DEMO-0001', '买家在收银台可取到明文卡密（受限明文）')
const recv1 = await call('/api/pay/receive', { method: 'POST', body: { token: ord1.token } })
ok(recv1.json.success && recv1.json.order.stage === 'settled', '买家确认收货 → 托管款自动转款到户（settled）')
const st1 = (await call('/api/stats', { token: tokenM })).json.stats
ok(st1.balance === 15000 && st1.escrow === 0, '收货转款后商户可用余额 +15,000 MMK 且托管清零', st1)
const recv1b = await call('/api/pay/receive', { method: 'POST', body: { token: ord1.token } })
ok(recv1b.json.success && (await call('/api/stats', { token: tokenM })).json.stats.balance === 15000, '重复确认收货幂等（不重复入账）')
ok((await call('/api/pay/delivery?t=' + ord1.token)).json.order.cardSecretCipher === undefined, '转款到户后卡密密文已销毁（不长期驻留）')

// 截图凭证兜底（路径 D）
const ord2 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 20000, scene: 'game', subject: '游戏充值' } })).json.order
const proof = await call('/api/pay/confirm', { method: 'POST', body: { token: ord2.token, amount: ord2.payable, txid: '88990011223', screenshot: 'data:image/png;base64,AAAABBBBCCCC' } })
ok(proof.json.success && proof.json.order.status === 'paid', '收银台凭证核销（截图 + 交易号兜底）成功')
ok((await call('/api/pay/confirm', { method: 'POST', body: { token: ord2.token, txid: '88990011224', screenshot: 'data:image/png;base64,AAAABBBBCCCC' } })).status === 409, '同一截图重复使用被拒绝（409）')
const ord2After = (await call('/api/orders/' + ord2.orderId, { token: tokenM })).json.order
ok(ord2After.status === 'paid' && ord2After.stage === 'delivered' && ord2After.grantStatus === 'waiting', '游戏订单到账即自动发货（stage=delivered，等待平台发币回执）')
const recv2 = await call('/api/pay/receive', { method: 'POST', body: { token: ord2.token } })
ok(recv2.json.success && recv2.json.order.stage === 'settled', '游戏订单收货 → 转款到游戏商户户（settled）')
ok((await call('/api/stats', { token: tokenM })).json.stats.balance === 35000, '游戏闭环累计到户 +20,000 MMK（15000+20000）')

// 服务端 API 接入（商户密钥）
const mk = (await call('/api/me/merchantkey', { method: 'POST', token: tokenM })).json.merchantKey
ok(/^mk_/.test(mk), '商户可生成服务端接入密钥（X-Merchant-Key）')
const ord3 = await call('/api/pay/init', { method: 'POST', headers: { 'X-Merchant-Key': mk }, body: { amount: 30000, scene: 'ecommerce', subject: '电商订单-服务端下单', customer: '09xxxxxxxxx', cardSecret: 'CARD-DEMO-0003' } })
ok(ord3.json.success && !!ord3.json.order.token, '第三方系统可用一行密钥在服务端直接下单')
ok((await call('/api/pay/init', { method: 'POST', body: { amount: 1000 } })).status === 401, '缺少商户密钥的服务端下单被拒绝（401）')

// 对账文件导入（路径 C）
const rec = await call('/api/reconcile/ingest', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { rows: [{ receiverAccount: '09971112223', amount: ord3.json.order.payable, txid: 'KBZ2601000003' }] } })
ok(rec.json.paid === 1, '对账文件批量导入自动核销成功')
const recv3 = await call('/api/pay/receive', { method: 'POST', body: { token: ord3.json.order.token } })
ok(recv3.json.success && recv3.json.order.stage === 'settled', '电商订单收货 → 转款到户（服务端 API 下单链路）')

/* ===================================================================== E 自动付款 */
section('E. 自动付款（额度内自动 / 超限审批 / 执行端回执）')
const balanceM = (await call('/api/stats', { token: tokenM })).json.stats.balance
ok(balanceM === 65000, '商户可用余额累计正确（15000+20000+30000，均已收货转款到户）', { balanceM })
const po1 = (await call('/api/payouts', { method: 'POST', token: tokenM, body: { amount: 10000, account: '09974445556', holder: '商户收款' } })).json.payout
ok(po1.status === 'queued' && po1.autoApproved === true, '额度内出款自动入队（免人工）')
ok((await call('/api/stats', { token: tokenM })).json.stats.balance === balanceM - 10000 - 500, '出款按金额+手续费冻结额度（5% 手续费）')
ok((await call('/api/payout/executor/pull')).status === 401, '执行端无设备密钥不可领取任务（401）')
const pull = await call('/api/payout/executor/pull', { headers: { 'X-Device-Key': ENV.DEVICE_KEY } })
ok(pull.json.tasks.length === 1 && pull.json.tasks[0].payoutId === po1.id, '出款执行端领取到待付款任务')
ok((await call('/api/payout/executor/receipt', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { payoutId: po1.id, ok: true } })).status === 400, '成功回执必须带流水号（400）')
const rc1 = await call('/api/payout/executor/receipt', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { payoutId: po1.id, ok: true, bankTxid: '1000100011' } })
ok(rc1.json.payout && rc1.json.payout.status === 'paid', '执行端回执后出款单完成（paid）', { status: rc1.status, json: rc1.json })

const ord4 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 700000, scene: 'ecommerce', subject: '大额订单', cardSecret: 'CARD-DEMO-0004' } })).json.order
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: '09971112223', amount: ord4.payable, txid: 'KBZ2601000004' } })
const recv4 = await call('/api/pay/receive', { method: 'POST', body: { token: ord4.token } })
ok(recv4.json.success && recv4.json.order.stage === 'settled', '大额电商订单收货 → 转款到户（700,000 MMK）')
const po2 = (await call('/api/payouts', { method: 'POST', token: tokenM, body: { amount: 600000, account: '09974445556' } })).json.payout
ok(po2.status === 'pending' && po2.autoApproved === false, '超限出款进入待审批（不自动放款）')
const apv = await call('/api/payouts/' + po2.id + '/approve', { method: 'POST', token: tokenSuper })
ok(apv.json.payout && apv.json.payout.status === 'queued', '上级（超管/代理）审批通过后进入出款队列', { status: apv.status, json: apv.json })
const po3 = (await call('/api/payouts', { method: 'POST', token: tokenM, body: { amount: 2000, account: '09974445556' } })).json.payout
const rej = await call('/api/payouts/' + po3.id + '/reject', { method: 'POST', token: tokenA, body: { reason: '资料不全' } })
ok(rej.json.payout && rej.json.payout.status === 'rejected', '上级可驳回出款申请', { status: rej.status, json: rej.json })
const before = (await call('/api/stats', { token: tokenM })).json.stats.balance
ok(before === (await call('/api/stats', { token: tokenM })).json.stats.balance, '驳回后额度退回（余额恢复）')

/* ===================================================================== 扣罚 */
section('F2. 违规扣罚 / 申诉复核 / 保证金不足自动受限')
const pen = await call('/api/pool/penalty', { method: 'POST', token: tokenSuper, body: { agentId: agentA.id, amount: 300000, reason: '违反当地规定（演示）', evidence: '工单#1024' } })
const penId = pen.json.penalty.id
ok(pen.json.deposit.paid === 700000, '扣罚从保证金中扣除（保证金预留生效）')
ok((await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 1000 } })).status === 403, '保证金低于应缴额后，该代理链路业务自动受限（403）')
await call('/api/penalties/' + penId + '/appeal', { method: 'POST', token: tokenA, body: { note: '已提交合规材料' } })
const resolved = await call('/api/pool/penalty/resolve', { method: 'POST', token: tokenSuper, body: { penaltyId: penId, agentId: agentA.id, refundAmount: 300000 } })
ok(resolved.json.penalty.status === 'resolved' && (await call('/api/deposit', { token: tokenA })).json.deposit.paid === 1000000, '申诉复核通过后保证金退还、业务恢复')

/* ===================================================================== 租用金 */
section('F3. 系统租用金入池')
const rentalOrd = (await call('/api/rental/order', { method: 'POST', token: tokenA, body: { amount: 200000, period: '2026-10' } })).json.order
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: '09970000111', amount: rentalOrd.payable, txid: 'KBZ2601000010' } })
const pool2 = (await call('/api/pool', { token: tokenSuper })).json.pool
ok(pool2.rentalTotal === 200000, '代理自助缴纳系统租用金，自动入超管资金池')
ok((await call('/api/rentals', { token: tokenA })).json.rentals.some(function (r) { return r.period === '2026-10' && r.amount === 200000 }), '租用金台账可查询（按期记录）')

/* ===================================================================== H 适配器 */
section('H. 无文档跨平台接入（适配器 + 回调重试）')
const adp = (await call('/api/adapters', { method: 'POST', token: tokenM, body: { name: '第三方电商平台', platform: 'custom', mode: 'api', targetUrl: CB_URL, signSecret: 's3cr3t-demo' } })).json.adapter
ok(!!adp.id && adp.mode === 'api', '无需任何平台文档即可配置适配器（表单化）')
const ord5 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 12000, adapterId: adp.id, subject: '适配器联调' } })).json.order
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: '09971112223', amount: ord5.payable, txid: 'KBZ2601000020' } })
await call('/api/webhooks/run', { method: 'POST', token: tokenSuper, body: { limit: 20 } })
ok(received.length >= 1, '订单到账后自动回调第三方平台')
const sigOk = received.length ? (await hmacHex('s3cr3t-demo', received[0].body)) === received[0].signature : false
ok(sigOk, '回调带 HMAC-SHA256 签名且可被平台验签')
ok((await call('/api/webhooks', { token: tokenM })).json.webhooks.some(function (w) { return w.status === 'delivered' }), '回调投递状态可查（含重试记录）')

const cbBody = JSON.stringify({ orderId: 'X', amount: 1 })
const cbOrd = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 11000, adapterId: adp.id } })).json.order
const cbPayload = JSON.stringify({ orderId: cbOrd.orderId, amount: cbOrd.amount, txid: 'ADP10001' })
ok((await call('/api/adapter/callback/' + adp.id, { method: 'POST', body: cbPayload, headers: { 'X-Signature': 'bad' } })).status === 401, '适配器回调签名错误被拒绝（401）')
const cbOk = await call('/api/adapter/callback/' + adp.id, { method: 'POST', body: cbPayload, headers: { 'X-Signature': await hmacHex('s3cr3t-demo', cbPayload) } })
ok(cbOk.json.ok === true && cbOk.json.status === 'paid', '适配器（持牌通道）回调验签通过后自动核销')
void cbBody

section('H2. 订单级回调地址（不配适配器也能收到到账通知）')
const ordCb = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 13000, notifyUrl: CB_URL, notifySecret: 'order-level-secret', subject: '订单级回调' } })).json.order
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: ordCb.channelAccount, amount: ordCb.payable, txid: 'KBZ2601000040' } })
const before2 = received.length
await call('/api/webhooks/run', { method: 'POST', token: tokenSuper, body: { limit: 20 } })
ok(received.length > before2, '订单上直接填写 notifyUrl 即可收到到账回调（零配置）')
ok((await call('/api/pay/status/' + ordCb.orderId, { headers: { 'X-Merchant-Key': mk } })).json.order.status === 'paid', '商户系统可用密钥查询订单状态（无需登录态）')
ok((await call('/api/pay/status/' + ordCb.orderId)).status === 401, '缺少商户密钥的订单查询被拒绝（401）')

/* ===================================================================== G 账本 */
section('G. 不可变账本与账实相符')
const led = await call('/api/ledger/verify?ownerId=' + merch.id, { token: tokenM })
ok(led.json.ok === true && led.json.entries > 0 && led.json.problems.length === 0, '商户账本哈希链校验通过（不可篡改）', { status: led.status, json: led.json })
const json1 = await call('/api/ledger?ownerId=' + merch.id, { token: tokenM })
ok(json1.json.entries.every(function (e, i, a) { return e.prevHash === (i === a.length - 1 ? 'GENESIS' : a[i + 1].hash) }), '账本 prevHash 逐条串联（链式结构完整）')
const poolLed = await call('/api/pool/ledger', { token: tokenSuper })
ok(poolLed.json.entries.length >= 4, '资金池独立账本记录（保证金/扣罚/退还/租用金）')
const st = (await call('/api/stats', { token: tokenM })).json.stats
const paidSum = (await call('/api/orders?status=paid', { token: tokenM })).json.orders.reduce(function (s, o) { return s + o.amount }, 0)
ok(paidSum >= 12000 && st.collectTotal >= paidSum, '收款总额与订单账实相符')
ok((await call('/api/audit', { token: tokenSuper })).json.logs.length > 10, '全量操作审计可查（超管）')

/* ===================================================================== 一键替换 */
section('C2. 代理自有 KBZ 账号一键替换')
const rep = await call('/api/channels/' + chA.id + '/replace', { method: 'POST', token: tokenA, body: { account: '09979998887', holder: '代理A(新商业账户)', label: '备用收款' } })
ok(rep.json.current.status === 'active' && rep.json.current.primary === true, '一键替换后新账号立即接任主通道')
ok(rep.json.replaced.status === 'cooldown' && !!rep.json.cooldownUntil, '旧账号进入冷却期（在途订单仍可核销）')
const ord6 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 5000 } })).json.order
ok(ord6.channelAccount === '09979998887', '替换后新订单自动走新账号（无需改代码/无需重启）')
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: '09979998887', amount: ord6.payable, txid: 'KBZ2601000030' } })
ok((await call('/api/orders/' + ord6.orderId, { token: tokenM })).json.order.status === 'paid', '新账号收款自动核销生效')

/* ===================================================================== I 页面与 SDK */
section('I. 后台/收银台/SDK 页面完整性（生成物语法与渲染检查）')
function scriptsOf(html) {
  const out = []
  const re = /<script[^>]*>([\s\S]*?)<\/script>/g
  let m
  while ((m = re.exec(html))) out.push(m[1])
  return out
}
function checkPage(html, label) {
  const bad = []
  // 1) 页内脚本逐段做语法检查（生成物不能有语法错误）
  scriptsOf(html).forEach(function (code, i2) {
    try { new Function(code) } catch (e) { bad.push('脚本#' + i2 + ' 语法错误: ' + e.message) }
  })
  // 2) 去掉脚本后再检查渲染标记（避免误报 JS 里的 typeof undefined 之类）
  const markup = html.replace(/<script[\s\S]*?<\/script>/g, '')
  if (markup.indexOf('undefined') >= 0) bad.push('渲染标记含 undefined')
  if (markup.indexOf('NaN') >= 0) bad.push('渲染标记含 NaN')
  if (/\$\{/.test(markup)) bad.push('模板未替换（残留 ${}）')
  if (scriptsOf(html).length) {
    try { void new Function(scriptsOf(html).join('\n')) } catch (e) { bad.push('脚本合并后冲突: ' + e.message) }
  }
  ok(bad.length === 0, label, bad)
  return html
}
const landing = await call('/', { country: 'MM' })
checkPage(landing.text, '落地页生成物语法与渲染正常（无占位/未替换）')
ok(landing.text.indexOf('KBZPay') > 0 && landing.text.indexOf('API') > 0, '落地页含 KBZPay 主通道与接入说明')
ok(landing.text.indexOf('超管入口') > 0 && landing.text.indexOf('/admin') > 0 && landing.text.indexOf('第一次输入的密码') > 0, '落地页指引超管唯一入口与首次设密流程')
ok(landing.text.indexOf('仅后台超管有权设定') > 0, '落地页说明保证金设定权归超管')
const consolePage = await call('/console')
checkPage(consolePage.text, '后台页面生成物语法与渲染正常')
ok(consolePage.text.indexOf('kbz_token') > 0, '后台页面内置登录态存储逻辑')
const payPage = await call('/pay?t=' + ord6.token)
checkPage(payPage.text, '托管收银台生成物语法与渲染正常')
const sdk = await call('/sdk.js')
let sdkOk = true
try { new Function(sdk.text) } catch (e) { sdkOk = false }
ok(sdkOk && sdk.text.indexOf('KBZPay') > 0, '一行接入 SDK 为合法 JS 且暴露 KBZPay 对象')
const blocked = await call('/', { country: 'TH' })
ok(blocked.text.indexOf('မြန်မာ') > 0 || blocked.text.indexOf('缅甸') > 0, '地区受限页面提供缅文/中文提示')
const i18n = await import('../src/i18n.js')
ok(typeof i18n.translate === 'function' && i18n.translate('console.title', 'my') !== 'console.title', '多语言（缅/英/中）词条可用')

/* ===================================================================== J 接入安全 + 敏感数据 */
section('J. 接入安全（签名 / 防重放 / 幂等 / 限流）与敏感数据（无明文落库 + 展示脱敏）')
ok((await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { requireApiSignature: true } })).json.success === true, '超管可开启强制签名模式')
ok((await call('/api/pay/init', { method: 'POST', headers: { 'X-Merchant-Key': mk }, body: { amount: 1000 } })).status === 401, '强制签名模式下，缺失签名头的服务端下单被拒（401）')
const jInit1 = await apiSigned('/api/pay/init', { amount: 1000, scene: 'ecommerce', cardSecret: 'CARD-DEMO-0009' }, { key: mk })
ok(jInit1.status === 200 && jInit1.json.success === true, '带完整签名（X-Timestamp/X-Nonce/X-Signature）的下单请求通过')
ok((await apiSigned('/api/pay/init', { amount: 1000, scene: 'ecommerce', cardSecret: 'CARD-DEMO-0009' }, { key: mk, sig: 'deadbeef' })).status === 401, '签名被篡改的请求被拒（401）')
const fixNonce = 'e2e-replay-' + Date.now()
const tsFix = String(Date.now())
const rp1 = await apiSigned('/api/pay/init', { amount: 1000, scene: 'ecommerce', cardSecret: 'CARD-DEMO-0010' }, { key: mk, nonce: fixNonce, ts: tsFix })
const rp2 = await apiSigned('/api/pay/init', { amount: 1000, scene: 'ecommerce', cardSecret: 'CARD-DEMO-0011' }, { key: mk, nonce: fixNonce, ts: tsFix })
ok(rp1.status === 200 && rp2.status === 409, '防重放：同一 Nonce 二次请求被拒（409）', { rp1: rp1.status, rp2: rp2.status })
const idemKey = 'e2e-idem-' + Date.now()
const id1 = await apiSigned('/api/pay/init', { amount: 2000, scene: 'ecommerce', cardSecret: 'CARD-DEMO-0012' }, { key: mk, idem: idemKey })
const id2 = await apiSigned('/api/pay/init', { amount: 2000, scene: 'ecommerce', cardSecret: 'CARD-DEMO-0012' }, { key: mk, idem: idemKey })
ok(id1.json.order && id2.json.idempotent === true && id2.json.order.orderId === id1.json.order.orderId, '幂等键：同键重复提交返回首次结果（不重复建单）')
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { rateLimitPerMin: 1 } })
const rl2 = await apiSigned('/api/pay/init', { amount: 500, scene: 'ecommerce', cardSecret: 'CARD-DEMO-0013' }, { key: mk })
ok(rl2.status === 429, '限流：超过每分钟上限的请求被拒（429）', { rl2: rl2.status })
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { rateLimitPerMin: 120, requireApiSignature: false } })

// 敏感数据：全库明文扫描（口令 / 商户密钥 / 适配器密钥 / 回调密钥 / 卡密一律不得明文落库）
const needles = ['MyUnique@2026', mk, 's3cr3t-demo', 'order-level-secret', 'CARD-DEMO-0001', 'CARD-DEMO-0003', 'CARD-DEMO-0004', 'CARD-DEMO-0009']
const dump = ENV.KBZ_GATEWAY._dump()
const leak = []
for (const [k, rec] of dump.entries()) {
  const v = String(rec && rec.value !== undefined ? rec.value : '')
  for (const n of needles) { if (n && v.indexOf(n) >= 0) leak.push(k + ' ⊃ ' + n) }
}
ok(leak.length === 0, '全库扫描：口令/商户密钥/适配器密钥/回调密钥/卡密均无明文落库', leak.slice(0, 5))
// 展示脱敏：归属者本人可见明文，超管查看下级订单为脱敏
const own1 = (await call('/api/orders/' + ord1.orderId, { token: tokenM })).json.order
ok(own1.channelAccount === '09971112223', '订单归属者本人可见收款账号明文（便于核对）')
const oList = (await call('/api/orders?delivery=1', { token: tokenSuper })).json.orders
const view1 = oList.filter(function (o) { return o.id === ord1.orderId })[0]
ok(!!view1 && view1.channelAccount === '0997****23' && view1.channelAccountMasked === '0997****23', '超管查看下级订单：收款账号脱敏展示（非明文）', view1 && { account: view1.channelAccount })

/* ------------------------------------------------------------------ 收尾 */
cbServer.close()
console.log('\n============================================================')
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
if (failures.length) {
  console.log('\n失败明细：')
  failures.forEach(function (f) { console.log(' - ' + f) })
  process.exit(1)
}
console.log('全部端到端验收通过 ✔')
process.exit(0)