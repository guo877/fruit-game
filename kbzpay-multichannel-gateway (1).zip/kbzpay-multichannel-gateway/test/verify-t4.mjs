/**
 * T4 定向验证：接入安全（签名 / 防重放 / 幂等 / 限流 / 审计）与回调一致性
 * 覆盖：HMAC 签名通过 / 篡改被拒 / 时间戳偏差被拒 / nonce 重放被拒 /
 *      Idempotency-Key 去重 / 限流 429 / 适配器与游戏回调强制验签 / 拒绝落审计。
 */
import http from 'node:http'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { hmacHex, sha256hex, randomToken } from '../src/core.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }
async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': opt.country || 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) {}
  return { status: res.status, json, text }
}
async function login(u, p) { return (await call('/api/auth/login', { method: 'POST', body: { username: u, password: p } })).json.token }
async function sign(secret, method, path, ts, nonce, raw) {
  const bodyHash = await sha256hex(raw || '')
  return await hmacHex(secret, [method, path, ts, nonce, bodyHash].join('\n'))
}
const cbServer = http.createServer((req, res) => { let b = ''; req.on('data', c => b += c); req.on('end', () => { res.writeHead(200); res.end('{"ok":true}') }) })
await new Promise(r => cbServer.listen(0, '127.0.0.1', r))

/* --------------------------- 环境 --------------------------- */
section('准备环境与接入密钥')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tSuper = await login('superadmin', 'MyUnique@2026')
const agent = (await call('/api/accounts', { method: 'POST', token: tSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tA = await login('agent_a', 'AgentA@12345')
const merch = (await call('/api/accounts', { method: 'POST', token: tA, body: { role: 'merchant', username: 'shop_one', password: 'ShopOne@123', name: '一号商户' } })).json.account
const tM = await login('shop_one', 'ShopOne@123')
await call('/api/pool/accounts', { method: 'POST', token: tSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tSuper, body: { agentId: agent.id, amount: 1000000 } })
await call('/api/channels', { method: 'POST', token: tA, body: { account: '09971112223', holder: '代理A', primary: true } })
const chAccount = (await call('/api/channels', { token: tA })).json.channels[0].account
const MKEY = (await call('/api/me/merchantkey', { method: 'POST', token: tM, body: {} })).json.merchantKey
ok(!!MKEY && MKEY.indexOf('mk_') === 0, '商户密钥已签发（明文仅回显一次）', { len: MKEY.length })

async function signedPost(path, body, opts = {}) {
  const raw = typeof body === 'string' ? body : JSON.stringify(body)
  const ts = opts.ts || String(Date.now())
  const nonce = opts.nonce || await randomToken(12)
  const sig = opts.sig || await sign(opts.secret || MKEY, 'POST', path, ts, nonce, raw)
  const headers = Object.assign({
    'X-Merchant-Key': MKEY, 'X-Timestamp': ts, 'X-Nonce': nonce, 'X-Signature': sig,
  }, opts.headers || {})
  return await call(path, { method: 'POST', body: raw, headers })
}

/* --------------------------- A. 签名正确通过 --------------------------- */
section('A. 正确签名请求通过')
const bodyA = { amount: 15000, scene: 'manual', subject: '签名用例', channelAccount: chAccount }
const rA = await signedPost('/api/pay/init', bodyA)
ok(rA.status === 200 && rA.json.success === true && rA.json.order.status === 'pending', '带齐签名头的下单请求通过', { status: rA.status, order: rA.json && rA.json.order && rA.json.order.orderId })

/* --------------------------- B. 篡改签名/请求体被拒 --------------------------- */
section('B. 篡改被拒')
const rawA = JSON.stringify(bodyA)
const tamperedRaw = JSON.stringify({ amount: 999999, scene: 'manual', subject: '签名用例', channelAccount: chAccount })
const tsB = String(Date.now()); const nonceB = await randomToken(12)
const sigForA = await sign(MKEY, 'POST', '/api/pay/init', tsB, nonceB, rawA)
const rB = await call('/api/pay/init', { method: 'POST', body: tamperedRaw, headers: { 'X-Merchant-Key': MKEY, 'X-Timestamp': tsB, 'X-Nonce': nonceB, 'X-Signature': sigForA } })
ok(rB.status === 401, '请求体被篡改（签名不匹配）→ 401', rB.status)
const rB2 = await call('/api/pay/init', { method: 'POST', body: rawA, headers: { 'X-Merchant-Key': MKEY, 'X-Timestamp': tsB, 'X-Nonce': await randomToken(12), 'X-Signature': 'deadbeef' } })
ok(rB2.status === 401, '伪造签名值 → 401', rB2.status)

/* --------------------------- C. 时间戳偏差被拒 --------------------------- */
section('C. 防重放 · 时间戳')
const staleTs = String(Date.now() - 3600 * 1000)
const rC = await signedPost('/api/pay/init', bodyA, { ts: staleTs })
ok(rC.status === 401 && /时间戳/.test(rC.json.error || ''), '过期时间戳请求被拒（401）', { status: rC.status, err: rC.json && rC.json.error })

/* --------------------------- D. nonce 重放被拒 --------------------------- */
section('D. 防重放 · nonce')
const fixedNonce = await randomToken(12)
const rD1 = await signedPost('/api/pay/init', { amount: 3000, scene: 'manual', channelAccount: chAccount }, { nonce: fixedNonce })
const rD2 = await signedPost('/api/pay/init', { amount: 3000, scene: 'manual', channelAccount: chAccount }, { nonce: fixedNonce })
ok(rD1.status === 200 && rD2.status === 409, '同一 nonce 二次请求被拒（409，疑似重放）', { first: rD1.status, second: rD2.status })

/* --------------------------- E. 幂等键去重 --------------------------- */
section('E. 幂等键 · 重复提交不重复建单')
const before = (await call('/api/orders', { token: tM })).json.orders.length
const idem = await randomToken(10)
const bodyE = { amount: 4500, scene: 'manual', subject: '幂等用例', channelAccount: chAccount }
const rE1 = await signedPost('/api/pay/init', bodyE, { headers: { 'X-Idempotency-Key': idem } })
const rE2 = await signedPost('/api/pay/init', bodyE, { headers: { 'X-Idempotency-Key': idem } })
const after = (await call('/api/orders', { token: tM })).json.orders.length
const id1 = rE1.json.order && rE1.json.order.orderId
const id2 = rE2.json.order && rE2.json.order.orderId
ok(rE1.status === 200 && rE2.status === 200 && rE2.json.idempotent === true, '重复提交命中幂等：第二次标记 idempotent', { second: rE2.json && rE2.json.idempotent })
ok(id1 === id2 && after === before + 1, '幂等去重：仅新增一张订单且返回同一订单号', { id1, id2, added: after - before })

/* --------------------------- F. 强制签名开关 --------------------------- */
section('F. 强制签名开关（requireApiSignature）')
await call('/api/settings', { method: 'PUT', token: tSuper, body: { requireApiSignature: true } })
const rF = await call('/api/pay/init', { method: 'POST', body: { amount: 1000, scene: 'manual', channelAccount: chAccount }, headers: { 'X-Merchant-Key': MKEY } })
ok(rF.status === 401, '开启强制签名后，未签名请求被拒（401）', rF.status)
const rF2 = await signedPost('/api/pay/init', { amount: 1000, scene: 'manual', channelAccount: chAccount })
ok(rF2.status === 200, '开启强制签名后，正确签名请求仍通过', rF2.status)
await call('/api/settings', { method: 'PUT', token: tSuper, body: { requireApiSignature: false } })

/* --------------------------- G. 回调强制验签 --------------------------- */
section('G. 适配器/游戏回调强制验签（与 API 同一签名规范）')
const adp = (await call('/api/adapters', { method: 'POST', token: tM, body: { name: '游戏平台', platform: 'game', mode: 'api', targetUrl: 'http://127.0.0.1:' + cbServer.address().port + '/cb' } })).json.adapter
const SECRET = adp.signSecretPlain
async function gameRaw(payload) { return JSON.stringify(payload) }
// 未签名
const gUnsigned = await call('/api/game/callback/' + adp.id, { method: 'POST', body: await gameRaw({ orderId: 'x', action: 'grant' }) })
ok(gUnsigned.status === 401, '未带签名的回调被拒（401）', gUnsigned.status)
// 错签名
const gBad = await call('/api/game/callback/' + adp.id, { method: 'POST', headers: { 'X-Signature': 'bad' }, body: await gameRaw({ orderId: 'x', action: 'grant' }) })
ok(gBad.status === 401, '错签名回调被拒（401）', gBad.status)
// 正确签名（先造一张游戏订单再到账，验证签名字段用同一 HMAC 规范）
const gOrder = (await call('/api/orders', { method: 'POST', token: tM, body: { amount: 2000, scene: 'game', adapterId: adp.id, gameAccount: 'p1', itemCode: 'x', channelAccount: chAccount } })).json.order
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: gOrder.channelAccount, amount: gOrder.payable, txid: 'TX-' + Date.now() } })
const goodPayload = await gameRaw({ orderId: gOrder.orderId, action: 'grant', ok: true, txid: 'G-1' })
const sigGood = await hmacHex(SECRET, goodPayload) // 回调规范：HMAC-SHA256(适配器密钥, 原始请求体)
const gGood = await call('/api/game/callback/' + adp.id, { method: 'POST', headers: { 'X-Signature': sigGood }, body: goodPayload })
ok(gGood.status === 200 && gGood.json.stage === 'settled', '正确签名回调通过并完成发币结算', { status: gGood.status, stage: gGood.json && gGood.json.stage })

/* --------------------------- H. 限流 --------------------------- */
section('H. 基础限流')
await call('/api/settings', { method: 'PUT', token: tSuper, body: { rateLimitPerMin: 3 } })
let got429 = false
for (let i = 0; i < 8; i++) {
  const r = await signedPost('/api/pay/init', { amount: 100, scene: 'manual', channelAccount: chAccount })
  if (r.status === 429) { got429 = true; break }
}
ok(got429, '超过每分钟上限的请求被拒（429）')
await call('/api/settings', { method: 'PUT', token: tSuper, body: { rateLimitPerMin: 120 } })

/* --------------------------- I. 审计落库 --------------------------- */
section('I. 审计落库')
const audits = (await call('/api/audit?limit=500', { token: tSuper })).json.logs || []
const hasReject = audits.some(a => a.action === 'inbound.reject') || audits.some(a => a.action === 'callback.reject')
const hasKeyRotate = audits.some(a => a.action === 'merchant.key.rotate')
const hasSettings = audits.some(a => a.action === 'settings.update')
ok(hasKeyRotate && hasSettings, '密钥轮换、配置变更已落审计', { rotate: hasKeyRotate, settings: hasSettings })
ok(hasReject, '被拒的接入请求已落审计（inbound/callback reject）', { n: audits.length })

cbServer.close()
console.log('\n============================================================')
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
if (failures.length) { console.log('\n失败明细：'); failures.forEach(f => console.log(' - ' + f)); process.exit(1) }
console.log('T4 定向验证全部通过 \u2714')
process.exit(0)