/**
 * T5 定向验证：敏感信息存储与展示
 * 覆盖：商户密钥/设备密钥只存哈希（无明文）、适配器/回调密钥与配置分离并加密落库、
 *      卡密加密落库且结算后销毁、收款账号与手机号脱敏展示 + 受限明文读取（审计留痕）、
 *      上级查看下级订单时收款账号脱敏、敏感字段不出现在列表响应与审计日志。
 */
import http from 'node:http'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { hmacHex, sha256hex, randomToken, kvGet, kvList } from '../src/core.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }
async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': opt.country || 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) {}
  return { status: res.status, json, text }
}
async function login(u, p) { return (await call('/api/auth/login', { method: 'POST', body: { username: u, password: p } })).json.token }

/* KV 底层明文扫描：直接读内存 KV 的原始存储串 */
function dumpEntries() {
  const d = ENV.KBZ_GATEWAY._dump()
  const out = []
  for (const [k, rec] of d.entries()) out.push([k, String(rec.value)])
  return out
}
function keyExists(k) { return dumpEntries().some(([kk]) => kk === k) }
function anyContains(needle) { return dumpEntries().some(([kk, vv]) => kk.indexOf(needle) >= 0 || vv.indexOf(needle) >= 0) }

const cbServer = http.createServer((req, res) => { let b = ''; req.on('data', c => b += c); req.on('end', () => { res.writeHead(200); res.end('{"ok":true}') }) })
await new Promise(r => cbServer.listen(0, '127.0.0.1', r))
const CB_URL = 'http://127.0.0.1:' + cbServer.address().port + '/cb'

/* --------------------------- 环境 --------------------------- */
section('准备环境')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tSuper = await login('superadmin', 'MyUnique@2026')
const agent = (await call('/api/accounts', { method: 'POST', token: tSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tA = await login('agent_a', 'AgentA@12345')
const merch = (await call('/api/accounts', { method: 'POST', token: tA, body: { role: 'merchant', username: 'shop_one', password: 'ShopOne@123', name: '一号商户' } })).json.account
const tM = await login('shop_one', 'ShopOne@123')
await call('/api/pool/accounts', { method: 'POST', token: tSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tSuper, body: { agentId: agent.id, amount: 1000000 } })

const CH_ACCOUNT = '09971112223'
const CH_PHONE = '+959771234567'   // normalizePhone('09771234567') → +95 前缀规整
const chAgent = (await call('/api/channels', { method: 'POST', token: tA, body: { account: CH_ACCOUNT, holder: '代理A', phone: '09771234567', primary: true } })).json.channel
ok(!!chAgent && chAgent.account === CH_ACCOUNT, '代理已新增自有 KBZ 收款通道')

/* --------------------------- A. 商户密钥只存哈希 --------------------------- */
section('A. 商户密钥：库内只存哈希，无明文')
const mkeyResp = await call('/api/me/merchantkey', { method: 'POST', token: tM, body: {} })
const MKEY = mkeyResp.json.merchantKey
ok(mkeyResp.json.merchantKeyMasked && mkeyResp.json.merchantKeyMasked.indexOf('****') >= 0, '商户密钥响应同时返回脱敏值', mkeyResp.json.merchantKeyMasked)
const mkeyHash = await sha256hex('mkey:' + MKEY)
ok(keyExists('mkeyhash:' + mkeyHash), '商户密钥以 sha256 哈希索引落库（mkeyhash:*）')
ok(!keyExists('mkey:' + MKEY), '库内不存在明文密钥索引键（mkey:<明文>）')
ok(!anyContains(MKEY), '全库扫描不含明文商户密钥', { keyPrefix: MKEY.slice(0, 6) })

/* --------------------------- B. 设备密钥只存哈希 --------------------------- */
section('B. 设备密钥：库内只存哈希，列表脱敏，功能可用')
const devResp = await call('/api/devices', { method: 'POST', token: tM, body: { type: 'both', label: '收款通知机', phone: CH_PHONE } })
const devPlain = devResp.json.device.keyPlain
const devIdRaw = devResp.json.device.id
ok(!!devPlain && devPlain.indexOf('dk_') === 0, '设备密钥明文仅创建时回显一次', { len: (devPlain || '').length })
const devHash = await sha256hex('dk:' + devPlain)
ok(keyExists('devkeyhash:' + devHash), '设备密钥以哈希索引落库（devkeyhash:*）')
ok(!keyExists('devkey:' + devPlain), '库内不存在明文设备密钥索引键（devkey:<明文>）')
ok(!anyContains(devPlain), '全库扫描不含明文设备密钥')
const devRec = await kvGet(ENV, 'dev:' + merch.id + ':' + devIdRaw, null)
ok(devRec && devRec.keyHash === devHash && !devRec.key, '设备记录只保存 keyHash 与 keyMasked', { hasKey: !!devRec.key, masked: devRec.keyMasked })
const devList = (await call('/api/devices', { token: tM })).json.devices
ok(devList.length === 1 && devList[0].keyMasked && !devList[0].keyPlain && !devList[0].keyHash, '设备列表只回显脱敏密钥，不含明文/哈希', devList[0])
ok(!/undefined/.test(JSON.stringify(devList)) && devList[0].phone !== '+959771234567' && devList[0].phone.indexOf('****') >= 0, '设备列表手机号已脱敏展示', devList[0] && devList[0].phone)
const devUse = await call('/api/payout/executor/pull', { headers: { 'X-Device-Key': devPlain } })
ok(devUse.status === 200 && devUse.json.success === true, '设备密钥可正常鉴权（哈希校验链路可用）', devUse.status)

/* --------------------------- C. 适配器密钥：加密落库 + 回调验签回环 --------------------------- */
section('C. 适配器密钥与配置分离，加密落库')
const ADP_SECRET = 'S3cret-Adapter-Key-0001'
const adp = (await call('/api/adapters', { method: 'POST', token: tM, body: { name: '游戏平台', platform: 'game', mode: 'api', targetUrl: CB_URL, signSecret: ADP_SECRET } })).json.adapter
ok(adp.signSecretPlain === ADP_SECRET, '适配器密钥明文仅创建响应回显一次')
const adpRec = await kvGet(ENV, 'adp:' + merch.id + ':' + adp.id, null)
ok(adpRec && /^enc1:/.test(adpRec.signSecretCipher || ''), '适配器密钥以 AES-GCM 密文落库（enc1:iv:ct）', { cipher: String(adpRec.signSecretCipher).slice(0, 12) })
ok(adpRec && !adpRec.signSecret, '适配器记录中不存在明文密钥字段 signSecret')
ok(!anyContains(ADP_SECRET), '全库扫描不含明文适配器密钥')
const adpList = (await call('/api/adapters', { token: tM })).json.adapters
ok(adpList.length === 1 && adpList[0].signSecretMasked && adpList[0].hasSecret === true && !adpList[0].signSecretPlain && !adpList[0].signSecret, '适配器列表只显示脱敏密钥与 hasSecret 标志')
// 回调验签回环：证明密文可正确解密用于 HMAC（密钥与配置分离但不影响可用性）
const adpOrder = (await call('/api/orders', { method: 'POST', token: tM, body: { amount: 1200, scene: 'ecommerce', adapterId: adp.id, subject: '适配器回调用例' } })).json.order
const cbRaw = JSON.stringify({ orderId: adpOrder.orderId, amount: adpOrder.payable, txid: 'ADP-1' })
const cbSig = await hmacHex(ADP_SECRET, cbRaw)
const cbRes = await call('/api/adapter/callback/' + adp.id, { method: 'POST', headers: { 'X-Signature': cbSig }, body: cbRaw })
ok(cbRes.status === 200 && cbRes.json.success === true, '用明文密钥签名 → 平台解密比对成功核销（密文可用）', { status: cbRes.status })

/* --------------------------- D. 卡密加密落库 + 结算后销毁 --------------------------- */
section('D. 发货凭据（卡密）加密落库，转款后销毁')
const CARD = 'CARD-SECRET-9988776655'
const cardOrder = (await call('/api/orders', { method: 'POST', token: tM, body: { amount: 17000, scene: 'ecommerce', subject: '卡密商品', cardSecret: CARD } })).json.order
const cardRec = await kvGet(ENV, 'ord:' + merch.id + ':' + cardOrder.orderId, null)
ok(cardRec && /^enc1:/.test(cardRec.cardSecretCipher || ''), '卡密以 AES-GCM 密文落库', { cipher: String(cardRec.cardSecretCipher).slice(0, 12) })
ok(!anyContains(CARD), '全库扫描不含明文卡密')
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: CH_ACCOUNT, amount: cardOrder.payable, txid: 'CARD-' + Date.now() } })
const ordList = await call('/api/orders', { token: tM })
ok(!/cardSecretCipher|"cardSecret"/.test(ordList.text), '订单列表响应不含卡密密文/明文字段', { hasCipher: /cardSecretCipher/.test(ordList.text) })
const settleRes = await call('/api/orders/' + cardOrder.orderId + '/receive', { method: 'POST', token: tM, body: {} })
ok(settleRes.status === 200 && settleRes.json.order.stage === 'settled', '确认收货后自动转款到户（stage=settled）', { stage: settleRes.json && settleRes.json.order && settleRes.json.order.stage })
const afterSettle = await kvGet(ENV, 'ord:' + merch.id + ':' + cardOrder.orderId, null)
ok(afterSettle && !afterSettle.cardSecretCipher, '转款完成后卡密密文已从订单记录销毁')

/* --------------------------- E. 收款账号/手机号：脱敏展示 + 受限明文 --------------------------- */
section('E. 收款账号/手机号：默认脱敏，归属方受限明文（审计留痕）')
const chOwn = await call('/api/channels', { token: tA })
const chMasked = (chOwn.json.channels || [])[0] || {}
ok(chMasked.account === undefined && chMasked.phone === undefined, '默认列表不返回收款账号/手机号明文', { account: chMasked.account, phone: chMasked.phone })
ok(!!chMasked.accountMasked && chMasked.accountMasked.indexOf('****') >= 0 && !!chMasked.phoneMasked, '默认列表返回脱敏账号与脱敏手机号', { accountMasked: chMasked.accountMasked, phoneMasked: chMasked.phoneMasked })
const chReveal = await call('/api/channels?reveal=1', { token: tA })
const chFull = (chReveal.json.channels || [])[0] || {}
ok(chFull.account === CH_ACCOUNT && chFull.phone === CH_PHONE, '归属方 ?reveal=1 可读受限明文', { account: chFull.account })
const auditsAfterReveal = (await call('/api/audit?limit=500', { token: tSuper })).json.logs || []
ok(auditsAfterReveal.some(a => a.action === 'channel.reveal'), '受限明文读取已落审计（channel.reveal）')

/* --------------------------- F. 上级查看下级订单：收款账号脱敏 --------------------------- */
section('F. 上级查看下级订单：收款账号脱敏（通道归属者本人例外）')
// 造两级：agent_a → 子代理 agent_b（自有通道）→ 商户 shop_two，订单走 agent_b 的通道
await call('/api/settings', { method: 'PUT', token: tSuper, body: { allowSubAgents: true } })
const agentB = (await call('/api/accounts', { method: 'POST', token: tA, body: { role: 'agent', username: 'agent_b', password: 'AgentB@12345', name: '代理B' } })).json.account
ok(!!agentB && agentB.role === 'agent', '子代理 agent_b 已创建（多级代理已开启）')
const tB = await login('agent_b', 'AgentB@12345')
const B_ACCOUNT = '09972223334'
await call('/api/channels', { method: 'POST', token: tB, body: { account: B_ACCOUNT, holder: '代理B', primary: true } })
const m2 = (await call('/api/accounts', { method: 'POST', token: tB, body: { role: 'merchant', username: 'shop_two', password: 'ShopTwo@123', name: '二号商户' } })).json.account
const tM2 = await login('shop_two', 'ShopTwo@123')
const subOrder = (await call('/api/orders', { method: 'POST', token: tM2, body: { amount: 18000, scene: 'ecommerce', subject: '下级订单', cardSecret: 'C-CARD-0001' } })).json.order
const m2View = (await call('/api/orders/' + subOrder.orderId, { token: tM2 })).json.order
ok(m2View.channelAccount === B_ACCOUNT, '订单归属者本人可见收款账号明文', { account: m2View.channelAccount })
ok(!!m2View.channelAccountMasked && m2View.channelAccountMasked.indexOf('****') >= 0, '订单归属者视图同时给出脱敏账号')
const bView = (await call('/api/orders/' + subOrder.orderId, { token: tB })).json.order
ok(bView.channelAccount === B_ACCOUNT, '通道归属者（子代理）可见自己账号明文')
const aView = (await call('/api/orders/' + subOrder.orderId, { token: tA })).json.order
ok(aView.channelAccount !== B_ACCOUNT && aView.channelAccount.indexOf('****') >= 0, '上级代理查看下级订单：收款账号已脱敏', { account: aView.channelAccount })
const aList = (await call('/api/orders', { token: tA })).json.orders
const aSub = aList.filter(o => o.orderId === subOrder.orderId)[0]
ok(aSub && aSub.channelAccount !== B_ACCOUNT && aSub.channelAccount.indexOf('****') >= 0, '上级代理订单列表：下级订单收款账号已脱敏', { account: aSub && aSub.channelAccount })
const aDeliv = (await call('/api/orders?delivery=1', { token: tA })).json.orders
const aSub2 = aDeliv.filter(o => o.id === subOrder.orderId)[0]
ok(aSub2 && aSub2.channelAccount !== B_ACCOUNT && aSub2.channelAccount.indexOf('****') >= 0, '上级代理 ?delivery=1 列表：收款账号同样脱敏')
const merchantChView = await call('/api/channels?ownerId=' + agent.id + '&reveal=1', { token: tM })
const mcFirst = (merchantChView.json.channels || [])[0] || {}
ok(mcFirst.account === undefined || mcFirst.account === '' || mcFirst.accountMasked, '下级查看上级通道：即便带 reveal 也一律脱敏', { account: mcFirst.account })

/* --------------------------- G. 回调密钥加密落库 --------------------------- */
section('G. 订单级回调密钥加密落库')
const NOTIFY_SECRET = 'NOTIFY-SECRET-XYZ-7788'
const nOrder = (await call('/api/orders', { method: 'POST', token: tM, body: { amount: 5000, scene: 'ecommerce', subject: '回调用例', notifyUrl: CB_URL, notifySecret: NOTIFY_SECRET, cardSecret: 'N-CARD-1' } })).json.order
const cbRec = await kvGet(ENV, 'ordcb:' + nOrder.orderId, null)
ok(cbRec && /^enc1:/.test(cbRec.secretCipher || '') && !cbRec.secret, '订单回调密钥以密文落库，无明文字段')
ok(!anyContains(NOTIFY_SECRET), '全库扫描不含明文回调密钥')
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: CH_ACCOUNT, amount: nOrder.payable, txid: 'N-' + Date.now() } })
const whKeys = await kvList(ENV, 'wh:')
ok(whKeys.length >= 1, '到账事件已生成回调投递记录（wh:*）', { n: whKeys.length })
const whRec = whKeys.length ? await kvGet(ENV, whKeys[0], null) : null
ok(whRec && /^enc1:/.test(whRec.secretCipher || '') && !whRec.secret, '回调投递记录中的密钥同样以密文落库')
const whList = (await call('/api/webhooks', { token: tM })).json.webhooks
ok((whList || []).every(w => w.secret === undefined && w.secretCipher === undefined), '回调列表不返回任何密钥字段')

/* --------------------------- H. 密钥与配置分离 --------------------------- */
section('H. 密钥与业务数据/配置分离')
const dataKey = await kvGet(ENV, 'sys:datakey', null)
ok(!!dataKey && String(dataKey).length >= 16, '主密钥单独存放于 sys:datakey（未配置 DATA_KEY 时的兜底）')
const cfgRec = await kvGet(ENV, 'sys:config', null)
ok(JSON.stringify(cfgRec || {}).indexOf(String(dataKey)) < 0, '系统配置记录中不含主密钥明文')
const ordKeys = await kvList(ENV, 'ord:')
let keyInBiz = false
for (const k of ordKeys) { const v = await kvGet(ENV, k, null); if (JSON.stringify(v || {}).indexOf(String(dataKey)) >= 0) keyInBiz = true }
ok(!keyInBiz, '业务订单记录中不含主密钥明文')

/* --------------------------- I. 列表响应与日志无敏感字段 --------------------------- */
section('I. 列表响应与审计日志不含敏感字段/明文')
const allOrders = await call('/api/orders', { token: tSuper })
const forbiddenNames = ['"cardSecretCipher"', '"cardSecret"', '"passHash"', '"salt"', '"signSecret"', '"signSecretCipher"', '"keyHash"', '"keyPlain"']
const leaked = forbiddenNames.filter(n => allOrders.text.indexOf(n) >= 0)
ok(leaked.length === 0, '订单列表响应不含任何敏感字段名', leaked)
const secreToCheck = [MKEY, devPlain, ADP_SECRET, CARD, NOTIFY_SECRET]
const leakedSecrets = secreToCheck.filter(s => allOrders.text.indexOf(s) >= 0)
ok(leakedSecrets.length === 0, '订单列表响应不含任何明文密钥/卡密/回调密钥')
const treeRes = await call('/api/accounts', { token: tSuper })
ok(treeRes.text.indexOf('"passHash"') < 0 && treeRes.text.indexOf('"salt"') < 0, '账号树响应不含口令哈希与盐')
const auditRes = await call('/api/audit?limit=800', { token: tSuper })
const auditLeaks = secreToCheck.filter(s => auditRes.text.indexOf(s) >= 0)
ok(auditLeaks.length === 0, '审计日志不含任何明文密钥/卡密', auditLeaks)
const auditActions = (auditRes.json.logs || []).map(a => a.action)
ok(auditActions.indexOf('order.create') >= 0 && auditActions.indexOf('channel.reveal') >= 0 && auditActions.indexOf('merchant.key.rotate') >= 0, '关键动作已落审计（下单/受限读取/密钥轮换）')

cbServer.close()
console.log('\n============================================================')
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
if (failures.length) { console.log('\n失败明细：'); failures.forEach(f => console.log(' - ' + f)); process.exit(1) }
console.log('T5 定向验证全部通过 \u2714')
process.exit(0)