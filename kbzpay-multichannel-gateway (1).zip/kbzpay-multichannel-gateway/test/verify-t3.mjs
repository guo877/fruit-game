/**
 * T3 定向验证：游戏业务逻辑闭环
 * 覆盖：游戏平台无文档接入下单（适配器 + 订单级回调）→ 到账自动发货 →
 *      平台发币回执（验签）→ 玩家收货 → 自动转款到游戏商户；失败回执与重试、幂等、账号映射。
 */
import http from 'node:http'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { hmacHex } from '../src/core.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }
async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': opt.country || 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) {}
  return { status: res.status, json, text }
}
async function login(u, p) { return (await call('/api/auth/login', { method: 'POST', body: { username: u, password: p } })).json.token }
const cbServer = http.createServer((req, res) => { let b = ''; req.on('data', c => b += c); req.on('end', () => { res.writeHead(200); res.end('{"ok":true}') }) })
await new Promise(r => cbServer.listen(0, '127.0.0.1', r))
const CB_URL = 'http://127.0.0.1:' + cbServer.address().port + '/game'

/* --------------------------- 环境 --------------------------- */
section('准备环境与游戏平台适配器')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tSuper = await login('superadmin', 'MyUnique@2026')
const agent = (await call('/api/accounts', { method: 'POST', token: tSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tA = await login('agent_a', 'AgentA@12345')
const merch = (await call('/api/accounts', { method: 'POST', token: tA, body: { role: 'merchant', username: 'game_shop', password: 'GameShop@123', name: '游戏商户' } })).json.account
const tM = await login('game_shop', 'GameShop@123')
await call('/api/pool/accounts', { method: 'POST', token: tSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tSuper, body: { agentId: agent.id, amount: 1000000 } })
await call('/api/channels', { method: 'POST', token: tA, body: { account: '09971112223', holder: '代理A', primary: true } })
const chAccount = (await call('/api/channels', { token: tA })).json.channels[0].account

const adpResp = (await call('/api/adapters', { method: 'POST', token: tM, body: { name: '传奇手游', platform: 'game', mode: 'api', targetUrl: CB_URL } })).json.adapter
const SECRET = adpResp.signSecretPlain
ok(!!adpResp.id && !!SECRET, '游戏适配器创建成功并回显一次接入密钥', { id: adpResp.id })
const adpList = (await call('/api/adapters', { token: tM })).json.adapters
ok(!!adpResp.gameCallbackUrl && !adpList[0].signSecretPlain, '适配器暴露游戏回执入口，且列表不回显明文密钥', { url: adpResp.gameCallbackUrl })

const statOf = async (tok) => (await call('/api/stats', { token: tok })).json.stats
async function pay(o) { return await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: o.channelAccount, amount: o.payable, txid: 'T' + Date.now() + Math.floor(Math.random() * 1000) } }) }
async function getOrder(id) { return (await call('/api/orders/' + id, { token: tM })).json.order }
async function place(body) { return (await call('/api/orders', { method: 'POST', token: tM, body: Object.assign({ channelAccount: chAccount }, body) })).json.order }

/* --------------------------- A. 无文档接入下单 --------------------------- */
section('A. 无文档接入下单：仅填适配器与游戏账号映射')
const m0 = await statOf(tM)
const g1 = await place({
  amount: 20000, scene: 'game', adapterId: adpResp.id, merchantOrderId: 'GM-ORDER-001',
  gameAccount: 'player001', gameRole: '勇者', gameZone: 'S1-电信', itemCode: 'diamond_100', quantity: 2,
  notifyUrl: CB_URL + '/notify',
})
ok(g1.scene === 'game' && g1.stage === 'pending' && g1.escrow === true, '游戏订单进入托管（escrow=true）', { scene: g1.scene, stage: g1.stage, escrow: g1.escrow })
ok(g1.gameAccount === 'player001' && g1.gameZone === 'S1-电信' && g1.itemCode === 'diamond_100' && g1.quantity === 2, '游戏账号映射完整保留（账号/区服/道具/数量）', { acct: g1.gameAccount, zone: g1.gameZone, item: g1.itemCode, qty: g1.quantity })
ok(g1.grantStatus === 'waiting' && g1.merchantOrderId === 'GM-ORDER-001', '发币状态 waiting、商户订单号已绑定', { grant: g1.grantStatus, mo: g1.merchantOrderId })

/* --------------------------- B. 到账自动发货 --------------------------- */
section('B. 到账自动发货（待平台发币）')
await pay(g1)
const g1p = await getOrder(g1.orderId)
ok(g1p.status === 'paid' && g1p.stage === 'delivered', '收款核销后自动进入已发货（待发币）', { status: g1p.status, stage: g1p.stage })
const m1 = await statOf(tM)
ok(m1.escrow === m0.escrow + 20000 && m1.balance === m0.balance, '金额进托管、未提前入余额', { escrow: m1.escrow, balance: m1.balance })

/* --------------------------- C. 发币回执（验签）→ 自动收货转款 --------------------------- */
section('C. 平台发币回执（正确签名）→ 自动收货 → 转款到游戏商户')
async function gameCb(payload, signed) {
  const raw = JSON.stringify(payload)
  const headers = {}
  if (signed) headers['X-Signature'] = await hmacHex(SECRET, raw)
  return await call('/api/game/callback/' + adpResp.id, { method: 'POST', headers, body: raw })
}
const c1 = await gameCb({ orderId: g1.orderId, action: 'grant', ok: true, txid: 'GAME-TX-0001', quantity: 2 }, true)
ok(c1.json.ok === true && c1.json.grantStatus === 'granted' && c1.json.stage === 'settled', '发币回执后：granted 且自动收货转款到户', c1.json)
const g1s = await getOrder(g1.orderId)
ok(g1s.grantTxid === 'GAME-TX-0001' && g1s.stage === 'settled' && g1s.settleAmount === 20000, '订单留存发币流水号并完成结算（结算 20000）', { txid: g1s.grantTxid, stage: g1s.stage, amt: g1s.settleAmount })
const m2 = await statOf(tM)
ok(m2.escrow === m0.escrow && m2.balance === m0.balance + 20000, '转款到户：托管清零、余额 +20000（账实相符）', { escrow: m2.escrow, balance: m2.balance })

/* --------------------------- D. 验签 --------------------------- */
section('D. 回执验签：篡改签名被拒')
const bad = await call('/api/game/callback/' + adpResp.id, { method: 'POST', headers: { 'X-Signature': '00000000' }, body: JSON.stringify({ orderId: g1.orderId, action: 'grant', ok: true }) })
ok(bad.status === 401, '错误签名回执被拒（401）', bad.status)
const rawBad = JSON.stringify({ orderId: g1.orderId, action: 'grant', ok: true, txid: 'HACK' })
const bad2 = await call('/api/game/callback/' + adpResp.id, { method: 'POST', headers: { 'X-Signature': 'deadbeef' }, body: rawBad })
ok(bad2.status === 401, '伪造签名被拒（401）', bad2.status)

/* --------------------------- E. 失败回执与重试 --------------------------- */
section('E. 发币失败回执 → 保持托管；重试成功后转款')
const g2 = await place({ amount: 9000, scene: 'game', adapterId: adpResp.id, gameAccount: 'player002', itemCode: 'vip_30d' })
await pay(g2)
const mE = await statOf(tM)
const efail = await gameCb({ orderId: g2.orderId, action: 'grant', ok: false }, true)
ok(efail.json.grantStatus === 'failed' && efail.json.stage !== 'settled', '发币失败：标记 failed 且不结算', efail.json)
const mE2 = await statOf(tM)
ok(mE2.escrow === mE.escrow, '发币失败期间资金保持托管（escrow 不变）', { before: mE.escrow, after: mE2.escrow })
const eretry = await gameCb({ orderId: g2.orderId, action: 'grant', ok: true, txid: 'GAME-TX-0002' }, true)
ok(eretry.json.grantStatus === 'granted' && eretry.json.stage === 'settled', '重试成功后回执 granted 并转款到户', eretry.json)

/* --------------------------- F. 幂等（重复回执） --------------------------- */
section('F. 重复回执幂等（不重复入账）')
const mF = await statOf(tM)
const dup = await gameCb({ orderId: g2.orderId, action: 'grant', ok: true, txid: 'GAME-TX-0002' }, true)
const mF2 = await statOf(tM)
ok(dup.json.stage === 'settled' && mF2.balance === mF.balance, '重复发币回执：返回成功但不重复转款', { before: mF.balance, after: mF2.balance })

/* --------------------------- G. 商户订单号定位 --------------------------- */
section('G. 以平台侧订单号定位并回执')
const g3 = await place({ amount: 6000, scene: 'game', adapterId: adpResp.id, merchantOrderId: 'GM-ORDER-777', gameAccount: 'player003', itemCode: 'gold_500' })
await pay(g3)
const g3c = await gameCb({ orderId: 'GM-ORDER-777', action: 'grant', ok: true, txid: 'GAME-TX-0003' }, true)
ok(g3c.json.ok === true && g3c.json.stage === 'settled', '按商户订单号定位订单并完成发币转款', g3c.json)

/* --------------------------- H. 买家自助收货 --------------------------- */
section('H. 无平台回执时，买家自助确认收货')
const g4 = await place({ amount: 4000, scene: 'game', adapterId: adpResp.id, gameAccount: 'player004', itemCode: 'skin_A' })
await pay(g4)
const h = await call('/api/pay/receive', { method: 'POST', body: { token: g4.token } })
ok(h.json.order.stage === 'settled', '游戏订单到账后买家自助收货即转款到户')

/* --------------------------- I. 非法动作 --------------------------- */
section('I. 非法回执动作被拒')
const g5 = await place({ amount: 3000, scene: 'game', adapterId: adpResp.id, gameAccount: 'player005' })
await pay(g5)
const bad3 = await gameCb({ orderId: g5.orderId, action: 'refund', ok: true }, true)
ok(bad3.status === 400, '非 grant 动作被拒（400）', bad3.status)

cbServer.close()
console.log('\n============================================================')
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
if (failures.length) { console.log('\n失败明细：'); failures.forEach(f => console.log(' - ' + f)); process.exit(1) }
console.log('T3 定向验证全部通过 \u2714')
process.exit(0)