/**
 * T6 定向验证：分级代理「收付款设置」——收款账户 / 付款账户 双向资金账户 + 一键替换
 * 覆盖：两类窗口的读取（脱敏 / 受限明文）、一键替换（旧账户冷却归档 + 接任账户沿用资金用途）、
 *       行级数据隔离（本级可见 / 越权 404 / 上级查看下级强制脱敏）、替换与明文读取落审计、
 *       出款未指定账号时回落到本账号「付款账户」。
 * 运行：node test/verify-t6.mjs   （仅本地校验，不随交付物发布）
 */
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }

async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text }
}
async function login(username, password) {
  const r = await call('/api/auth/login', { method: 'POST', body: { username, password } })
  return r.json && r.json.token
}
async function auditActions(token, limit = 400) {
  const r = await call('/api/audit?limit=' + limit, { token })
  const logs = (r.json && r.json.logs) || []
  return logs.map(function (l) { return l.action })
}

/* ------------------------------------------------------------------ 准备环境 */
section('准备：超管设密 → 代理 A → 商户 M')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tokenSuper = await login('superadmin', 'MyUnique@2026')
const agentA = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tokenA = await login('agent_a', 'AgentA@12345')
await call('/api/pool/accounts', { method: 'POST', token: tokenSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tokenSuper, body: { agentId: agentA.id, amount: 1000000 } })
ok(!!agentA && !!tokenA, '环境就绪：代理 A 可用')

/* ------------------------------------------------------------------ 收款账户窗口 */
section('收款账户窗口：新增 → 读取脱敏 → 受限明文留痕')
const recv = (await call('/api/fundaccounts', { method: 'POST', token: tokenA, body: { account: '09971112223', holder: '代理A', label: '收款主号', flow: 'receive' } })).json.account
ok(!!recv && recv.flow === 'receive', '新增收款账户：flow=receive', { flow: recv && recv.flow })
const listRecv = (await call('/api/fundaccounts?flow=receive', { token: tokenA })).json
ok(listRecv.accounts.length === 1, '收款窗口读取：仅 1 个收款账户')
ok(listRecv.accounts[0].account === undefined && !!listRecv.accounts[0].accountMasked, '默认读取脱敏（无明文账号，仅 accountMasked）', { acc: listRecv.accounts[0].account, m: listRecv.accounts[0].accountMasked })
const listRecvRev = (await call('/api/fundaccounts?flow=receive&reveal=1', { token: tokenA })).json
ok(listRecvRev.accounts[0].account === '09971112223', '归属方本人 ?reveal=1 可取明文账号')
const auditA1 = await auditActions(tokenSuper)
ok(auditA1.indexOf('fundaccount.reveal') >= 0, '受限明文读取已落审计（fundaccount.reveal）')

/* ------------------------------------------------------------------ 付款账户窗口 */
section('付款账户窗口：与收款窗口相互独立')
const pay1 = (await call('/api/fundaccounts', { method: 'POST', token: tokenA, body: { account: '09971112224', holder: '代理A', label: '付款主号', flow: 'pay' } })).json.account
ok(!!pay1 && pay1.flow === 'pay', '新增付款账户：flow=pay', { flow: pay1 && pay1.flow })
const listPay = (await call('/api/fundaccounts?flow=pay&reveal=1', { token: tokenA })).json
ok(listPay.accounts.length === 1 && listPay.accounts[0].account === '09971112224', '付款窗口仅含付款账户（与收款窗口分离）')
const listRecv2 = (await call('/api/fundaccounts?flow=receive&reveal=1', { token: tokenA })).json
ok(listRecv2.accounts.length === 1 && listRecv2.accounts[0].account === '09971112223', '收款窗口仍只含收款账户（互不串号）')

/* ------------------------------------------------------------------ 一键替换（收款） */
section('一键替换（收款账户）：旧账户冷却归档 + 新账户接任')
const rp = (await call('/api/fundaccounts/' + recv.id + '/replace', { method: 'POST', token: tokenA, body: { account: '09971113333', holder: '代理A' } })).json
ok(rp.success === true && rp.replaced && rp.replaced.status === 'cooldown', '旧收款账户进入冷却（cooldown）', { st: rp.replaced && rp.replaced.status })
ok(rp.current && rp.current.status === 'active' && rp.current.flow === 'receive', '新收款账户接任且沿用收款用途', { st: rp.current && rp.current.status, flow: rp.current && rp.current.flow })
ok(!!rp.cooldownUntil, '返回冷却到期时间（在途订单兜底窗口）', { c: rp.cooldownUntil })
const listRecv3 = (await call('/api/fundaccounts?flow=receive&reveal=1', { token: tokenA })).json
const newRecv = listRecv3.accounts.filter(function (c) { return c.account === '09971113333' })
const oldRecv = listRecv3.accounts.filter(function (c) { return c.account === '09971112223' })
ok(newRecv.length === 1 && newRecv[0].status === 'active' && newRecv[0].primary === true, '替换后：新账号 active 且为主账号')
ok(oldRecv.length === 1 && oldRecv[0].status === 'cooldown', '替换后：旧账号保留为冷却态（在途兜底，不再分配新单）')
const auditA2 = await auditActions(tokenSuper)
ok(auditA2.indexOf('channel.replace') >= 0, '一键替换已落审计（channel.replace）')

/* ------------------------------------------------------------------ 一键替换（付款）保留用途 */
section('一键替换（付款账户）：接任账户仍为付款用途')
const rpPay = (await call('/api/fundaccounts/' + pay1.id + '/replace', { method: 'POST', token: tokenA, body: { account: '09971113344', holder: '代理A' } })).json
ok(rpPay.current && rpPay.current.flow === 'pay', '付款账户替换后 flow 仍为 pay', { flow: rpPay.current && rpPay.current.flow })
const listPay2 = (await call('/api/fundaccounts?flow=pay&reveal=1', { token: tokenA })).json
ok(listPay2.accounts.filter(function (c) { return c.account === '09971113344' && c.status === 'active' }).length === 1, '付款窗口已切到新付款账号')

/* ------------------------------------------------------------------ 行级数据隔离 */
section('行级数据隔离：本级可见 / 越权 404 / 上级查看下级强制脱敏')
const agentB = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_b', password: 'AgentB@12345', name: '代理B' } })).json.account
const tokenB = await login('agent_b', 'AgentB@12345')
const bPeek = await call('/api/fundaccounts?flow=receive&ownerId=' + agentA.id, { token: tokenB })
ok(bPeek.status === 404, '非上级代理越权查看他账号资金账户被拒（404）', { status: bPeek.status })
const superPeek = (await call('/api/fundaccounts?flow=receive&ownerId=' + agentA.id + '&reveal=1', { token: tokenSuper })).json
ok(superPeek.accounts.length >= 1, '超管/上级可查看下级资金账户列表')
ok(superPeek.accounts.every(function (c) { return c.account === undefined && !!c.accountMasked }), '上级查看下级资金账户：即便带 reveal 也强制脱敏（明文仅限账户归属者本人）', { sample: superPeek.accounts[0] })

/* ------------------------------------------------------------------ 出款回落付款账户 */
section('出款引擎：未指定账号时回落到本账号「付款账户」')
const merch = (await call('/api/accounts', { method: 'POST', token: tokenA, body: { role: 'merchant', username: 'shop_one', password: 'ShopOne@123', name: '一号商户' } })).json.account
const tokenM = await login('shop_one', 'ShopOne@123')
await call('/api/fundaccounts', { method: 'POST', token: tokenM, body: { account: '09972223333', holder: '一号商户', flow: 'pay' } })
const od = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 15000, scene: 'ecommerce', subject: '点卡', delivery: { type: 'card', cardSecret: 'CARD-FUND-0001' } } })).json.order
await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: od.channelAccount, amount: od.payable, txid: 'TX' + Date.now() } })
await call('/api/pay/receive', { method: 'POST', body: { token: od.token } })
const payout = (await call('/api/payouts', { method: 'POST', token: tokenM, body: { amount: 1000 } })).json.payout
ok(!!payout && payout.account === '09972223333', '出款未传账号 → 自动使用本账号付款账户（09972223333）', { acc: payout && payout.account })
ok(!!payout && payout.payAccountId, '出款记录关联付款账户 id（可追溯）', { pid: payout && payout.payAccountId })
const tokenM2 = await login('shop_one', 'ShopOne@123')
const chOnly = await call('/api/fundaccounts', { method: 'POST', token: tokenM2, body: { account: '09972224444', holder: '过渡号', flow: 'pay' } })
const listMPay = (await call('/api/fundaccounts?flow=pay', { token: tokenM2 })).json
ok(listMPay.accounts.length === 2, '同一付款窗口可并存多账号（替换前可先查看）', { n: listMPay.accounts.length })

/* ------------------------------------------------------------------ 汇总 */
console.log('\n============================================================')
if (failures.length === 0) { console.log('T6 收付款设置（收款/付款双向账户 + 一键替换）全部通过 \u2714  （' + passed + ' 项）') }
else {
  console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项：')
  failures.forEach(function (f) { console.log('  - ' + f) })
  process.exitCode = 1
}