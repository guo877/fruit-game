/**
 * T7 定向验证：超管层级账户 = 平台使用费 + 保证金/租用金收款归集
 * 覆盖：平台使用费率可配置生效（仅超管可改）、按「代理分级账户」在收款结算环节计提并归集到平台账户、
 *       余额不足时记为欠缴（账目可核）、保证金缴纳收款走资金池指定账户、
 *       超管自身账户不直接承接业务收款、出款环节计提模式（platformFeeOnCollect=false）。
 * 运行：node test/verify-t7.mjs   （仅本地校验，不随交付物发布）
 */
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }

async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text }
}
async function login(username, password) {
  const r = await call('/api/auth/login', { method: 'POST', body: { username, password } })
  return r.json && r.json.token
}
async function pay(o) {
  return await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: o.channelAccount, amount: o.payable, txid: 'T' + Date.now() + Math.floor(Math.random() * 1000) } })
}
const POOL_ACC = '09970000111'

/* ------------------------------------------------------------------ 准备环境 */
section('准备：超管设密 → 代理 A → 商户 M → 资金池与保证金')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tokenSuper = await login('superadmin', 'MyUnique@2026')
const agentA = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tokenA = await login('agent_a', 'AgentA@12345')
await call('/api/pool/accounts', { method: 'POST', token: tokenSuper, body: { accounts: [{ account: POOL_ACC, holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tokenSuper, body: { agentId: agentA.id, amount: 1000000 } })
await call('/api/channels', { method: 'POST', token: tokenA, body: { account: '09971112223', holder: '代理A', primary: true } })
const merch = (await call('/api/accounts', { method: 'POST', token: tokenA, body: { role: 'merchant', username: 'shop_one', password: 'ShopOne@123', name: '一号商户' } })).json.account
const tokenM = await login('shop_one', 'ShopOne@123')
ok(!!agentA && !!merch && !!tokenM, '环境就绪：代理 A / 商户 M / 资金池账户')

/* ------------------------------------------------------------------ 费率可配置 */
section('平台使用费率：仅超管可配置并生效')
const setR = await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { platformFeeRate: 0.02 } })
ok(setR.status === 200 && setR.json.config.platformFeeRate === 0.02, '超管设置平台使用费率 2% 并生效', { v: setR.json && setR.json.config && setR.json.config.platformFeeRate })
const aTry = await call('/api/settings', { method: 'PUT', token: tokenA, body: { platformFeeRate: 0.9 } })
ok(aTry.status === 403, '非超管无权修改平台使用费率（403）', { status: aTry.status })
const cfgPub = (await call('/api/config')).json.config
ok(Number(cfgPub.platformFeeRate) === 0.02, '公开配置对外暴露生效费率（前端可展示）', { v: cfgPub.platformFeeRate })

async function plat() { return (await call('/api/platform', { token: tokenSuper })).json.platform }
async function agentStats() { return (await call('/api/stats', { token: tokenA })).json.stats }

/* ------------------------------------------------------------------ 收款结算环节计提（onCollect 默认 true） */
section('计提（收款结算环节）：代理余额不足时记为欠缴，账目可核')
async function mOrder(amount, card) {
  const o = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: amount, scene: 'ecommerce', subject: '商品', delivery: { type: 'card', cardSecret: card } } })).json.order
  await pay(o)
  await call('/api/pay/receive', { method: 'POST', body: { token: o.token } })
  return (await call('/api/orders/' + o.orderId, { token: tokenM })).json.order
}
const o1 = await mOrder(100000, 'CARD-T7-0001')
ok(o1.platformFee === 0 && o1.platformFeeDue === 2000, '代理余额不足：本次使用费记为欠缴 2000（未硬扣）', { fee: o1.platformFee, due: o1.platformFeeDue })
const p1 = await plat()
ok(p1.platformFeeTotal === 0 && p1.balance === 0, '欠缴未入账：平台账户使用费归集仍为 0（账目可核）', { total: p1.platformFeeTotal, bal: p1.balance })

section('计提（收款结算环节）：代理有余额时按流水扣除并归集到平台账户')
const oa = (await call('/api/orders', { method: 'POST', token: tokenA, body: { amount: 200000, scene: 'ecommerce', subject: '代理自营', delivery: { type: 'card', cardSecret: 'CARD-T7-AGENT' } } })).json.order
await pay(oa)
await call('/api/pay/receive', { method: 'POST', body: { token: oa.token } })
const aAfter1 = await agentStats()
const p2 = await plat()
ok(p2.platformFeeTotal === 4000 && p2.balance === 4000, '代理自营收款 200000 → 计提 4000 并归集到平台账户', { total: p2.platformFeeTotal, bal: p2.balance })
ok(aAfter1.platformFee === 4000 && aAfter1.balance === 196000, '代理账户被扣除使用费 4000（可用余额 196000）', { fee: aAfter1.platformFee, bal: aAfter1.balance })
const o2 = await mOrder(50000, 'CARD-T7-0002')
const p3 = await plat()
const aAfter2 = await agentStats()
ok(p3.platformFeeTotal === 5000, '下级商户收款 50000 → 向其上辖代理账户计提 1000（累计 5000）', { total: p3.platformFeeTotal })
ok(aAfter2.platformFee === 5000 && aAfter2.balance === 195000, '代理账户累计扣费 5000（可用余额 195000）', { fee: aAfter2.platformFee, bal: aAfter2.balance })
ok(String(p3.rule || '').indexOf('代理分级账户') >= 0, '平台账户视图声明计费规则（只收代理分级账户使用费）', { rule: p3.rule })
const pNoSuper = await call('/api/platform', { token: tokenA })
ok(pNoSuper.status === 403, '平台账户视图仅超管可读（403）', { status: pNoSuper.status })

/* ------------------------------------------------------------------ 保证金收款走资金池账户 */
section('保证金收款：走资金池指定收款账户')
const depOrder = (await call('/api/orders', { method: 'POST', token: tokenA, body: { amount: 1000000, scene: 'deposit' } })).json.order
ok(depOrder.channelAccount === POOL_ACC, '保证金缴纳收款账号 = 资金池指定账户', { acc: depOrder.channelAccount })
const p4 = await plat()
ok(p4.receiveAccounts.some(function (a) { return a.account === POOL_ACC }), '平台账户视图列出资金池收款账户', { accs: p4.receiveAccounts })
const before = (await call('/api/stats', { token: tokenA })).json.stats
await pay(depOrder)
const depDone = (await call('/api/orders/' + depOrder.orderId, { token: tokenA })).json.order
ok(depDone.status === 'paid' && depDone.stage === 'settled', '保证金订单缴清（非托管，直接入池）', { st: depDone.status, stage: depDone.stage })
const p5 = await plat()
ok(p5.depositTotal >= 2000000, '保证金收款归集到资金池（depositTotal 累加）', { d: p5.depositTotal })

/* ------------------------------------------------------------------ 超管自身账户不承接业务收款 */
section('超管自身账户：不直接承接业务收款')
await call('/api/channels', { method: 'POST', token: tokenSuper, body: { account: '09979990000', holder: '超管备用', primary: true } })
const agentC = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_c', password: 'AgentC@12345', name: '代理C', depositRequired: 0 } })).json.account
const tokenC = await login('agent_c', 'AgentC@12345')
const m3 = (await call('/api/accounts', { method: 'POST', token: tokenC, body: { role: 'merchant', username: 'shop_three', password: 'ShopThree@1', name: '三号商户' } })).json.account
const tokenM3 = await login('shop_three', 'ShopThree@1')
const noCh = await call('/api/orders', { method: 'POST', token: tokenM3, body: { amount: 1000, scene: 'ecommerce', subject: '测试' } })
ok(noCh.status === 409, '下级链路无自有收款账户时，不回落超管账户 → 建单被拒（409）', { status: noCh.status, err: noCh.json && noCh.json.error })

/* ------------------------------------------------------------------ 出款环节计提模式 */
section('计提（出款完成环节）：platformFeeOnCollect=false 时按出款金额计提')
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { platformFeeRate: 0.02, platformFeeOnCollect: false } })
const o3 = await mOrder(80000, 'CARD-T7-0003')
const p6 = await plat()
ok(p6.platformFeeTotal === 5000, '出款计提模式下，收款结算环节不再计提（仍为 5000）', { total: p6.platformFeeTotal })
const po = (await call('/api/payouts', { method: 'POST', token: tokenM, body: { amount: 10000, account: '09970000999', holder: '老板' } })).json.payout
ok(po.status === 'queued', '额度内出款自动入队', { st: po.status })
const pulled = (await call('/api/payout/executor/pull', { headers: { 'X-Device-Key': ENV.DEVICE_KEY } })).json
ok(pulled.tasks.length === 1 && pulled.tasks[0].payoutId === po.id, '出款执行端领取任务')
const rc = await call('/api/payout/executor/receipt', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { payoutId: po.id, ok: true, bankTxid: '1000100011' } })
ok(rc.json.payout && rc.json.payout.status === 'paid', '出款回执完成（paid）', { st: rc.json && rc.json.payout && rc.json.payout.status })
ok(rc.json.payout.platformFee === 200, '出款完成时计提使用费 200（2% × 10000）', { fee: rc.json.payout.platformFee })
const p7 = await plat()
const aAfter3 = await agentStats()
ok(p7.platformFeeTotal === 5200, '平台账户使用费归集累计 5200', { total: p7.platformFeeTotal })
ok(aAfter3.platformFee === 5200 && aAfter3.balance === 194800, '代理账户累计扣费 5200（可用余额 194800）', { fee: aAfter3.platformFee, bal: aAfter3.balance })
const rejected = await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { platformFeeRate: 0 } })
ok(rejected.status === 200 && Number(rejected.json.config.platformFeeRate) === 0, '平台使用费率可回落为 0（暂不计提）')

/* ------------------------------------------------------------------ 汇总 */
console.log('\n============================================================')
if (failures.length === 0) { console.log('T7 平台使用费与保证金收款归集全部通过 \u2714  （' + passed + ' 项）') }
else {
  console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项：')
  failures.forEach(function (f) { console.log('  - ' + f) })
  process.exitCode = 1
}