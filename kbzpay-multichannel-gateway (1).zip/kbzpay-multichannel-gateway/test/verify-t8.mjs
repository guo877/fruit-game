/**
 * T8 定向验证：后台「收付款设置」页面与超管「平台账户」入口（UI ↔ 后端一致性）
 * ---------------------------------------------------------------------------
 * 做法：把 CONSOLE_PAGE 内联脚本放进 vm 沙箱（模拟 document / localStorage / fetch / prompt），
 *       fetch 直连真实 handleRequest（内存 KV），从而「用页面自己的代码」驱动真实后端。
 * 覆盖：
 *   A. 页面结构：新增「收付款设置」「平台账户」两个导航页，含收款/付款两个资金账户窗口与一键替换按钮
 *   B. 代理上下文：登录后 boot；「收付款设置」渲染出收款 / 付款两个窗口
 *   C. UI 驱动新增：quickFund → 后端收款窗口新增 1 个
 *   D. UI 驱动一键替换：replaceFund → 旧账户冷却、新账户接任，且有明确结果反馈（toast 含「已一键替换」）
 *   E. 两个窗口互不串号：付款窗口新增不影响收款窗口
 *   F. 超管上下文：「平台账户」渲染出使用费累计 / 保证金收款账户 / 平台使用费率
 *   G. UI 驱动保存平台费率：savePlatform → /api/settings 生效
 *   H. 超管查看下级资金账户：一律脱敏
 * 运行：node test/verify-t8.mjs   （仅本地校验，不随交付物发布）
 */
import vm from 'node:vm'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { CONSOLE_PAGE } from '../src/pages.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }

async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text }
}
async function login(username, password) {
  const r = await call('/api/auth/login', { method: 'POST', body: { username, password } })
  return r.json && r.json.token
}

/* ------------------------------------------------------------------ 迷你 DOM + 沙箱 */
function makeEl() {
  return {
    _html: '', _text: '', className: '', value: '', files: [], style: {}, children: [],
    addEventListener() {}, appendChild(c) { this.children.push(c) }, remove() {}, querySelector() { return null },
    get innerHTML() { return this._html }, set innerHTML(v) { this._html = String(v) },
    get textContent() { return this._text }, set textContent(v) { this._text = String(v) },
  }
}

/** 用 CONSOLE_PAGE 的内联脚本建立 vm 沙箱，fetch 直连真实 handleRequest */
function makeUI(token) {
  const els = {}
  const body = makeEl()
  const document = {
    domain: 'gw.example.com',
    body: body,
    getElementById(id) { if (!els[id]) els[id] = makeEl(); return els[id] },
    createElement() { return makeEl() },
  }
  const store = { kbz_token: token }
  const localStorage = {
    getItem(k) { return Object.prototype.hasOwnProperty.call(store, k) ? store[k] : null },
    setItem(k, v) { store[k] = String(v) },
    removeItem(k) { delete store[k] },
  }
  const prompts = []
  const alerts = []
  const location = { origin: 'https://gw.example.com', href: '', reload() {}, search: '' }
  const sandbox = {
    document, localStorage, location, console,
    navigator: { clipboard: { writeText() {} }, userAgent: 'node' },
    setTimeout: globalThis.setTimeout.bind(globalThis), clearTimeout: globalThis.clearTimeout.bind(globalThis),
    setInterval: globalThis.setInterval.bind(globalThis), clearInterval: globalThis.clearInterval.bind(globalThis),
    prompt: () => (prompts.length ? prompts.shift() : null),
    confirm: () => true,
    alert: (m) => { alerts.push(String(m)) },
    fetch: async (path, opt) => {
      opt = opt || {}
      const headers = Object.assign({ 'cf-ipcountry': 'MM' }, opt.headers || {})
      const init = { method: opt.method || 'GET', headers }
      if (opt.body !== undefined) init.body = opt.body
      const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
      return { status: res.status, json: () => res.json(), text: () => res.text() }
    },
  }
  const ctx = vm.createContext(sandbox)
  const html = CONSOLE_PAGE({ gatewayName: 'Test' }, {})
  const code = html.match(/<script>([\s\S]*)<\/script>/)[1]
  vm.runInContext(code, ctx)
  return {
    ctx, view: () => els['view'], nav: () => els['nav'], body,
    getEl: (id) => document.getElementById(id),
    setPrompts: (arr) => { prompts.length = 0; arr.forEach((x) => prompts.push(x)) },
    toasts: () => body.children.map((c) => ({ cls: c.className, text: c.textContent })),
    alerts,
  }
}
const flush = () => new Promise((r) => setTimeout(r, 60))

/* ================================================================== 用例 */
section('准备：超管设密 → 代理 A → 资金池收款账户')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tokenSuper = await login('superadmin', 'MyUnique@2026')
const agentA = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tokenA = await login('agent_a', 'AgentA@12345')
await call('/api/pool/accounts', { method: 'POST', token: tokenSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tokenSuper, body: { agentId: agentA.id, amount: 1000000 } })
ok(!!agentA && !!tokenA, '环境就绪：代理 A 可用')

section('A. 页面结构：新增「收付款设置」与「平台账户」导航页')
const pageHtml = CONSOLE_PAGE({ gatewayName: 'Test' }, {})
ok(pageHtml.includes('收付款设置') && pageHtml.includes('平台账户'), '导航包含「收付款设置」「平台账户」')
ok(/VIEWS\.fund\s*=/.test(pageHtml) && /VIEWS\.platform\s*=/.test(pageHtml), '脚本定义了 VIEWS.fund 与 VIEWS.platform')
for (const t of [['收款账户窗口', '收款账户'], ['付款账户窗口', '付款账户'], ['一键替换', '一键替换'], ['平台使用费率', '平台使用费率'], ['保证金/租用金收款账户', '保证金 / 租用金收款账户']]) {
  ok(pageHtml.includes(t[1]), '页面含关键要素：' + t[0])
}

section('B. 代理上下文：登录后自动 boot；「收付款设置」渲染两个窗口')
const uiA = makeUI(tokenA)
await flush()
ok(!!uiA.ctx.ME && uiA.ctx.ME.role === 'agent', '代理登录后 ME.role=agent')
await uiA.ctx.VIEWS.fund()
const fundHtml = uiA.view().innerHTML
ok(fundHtml.includes('收款账户（') && fundHtml.includes('付款账户（'), '「收付款设置」同时渲染收款与付款两个资金账户窗口')
ok(fundHtml.includes('新增收款账户') && fundHtml.includes('新增付款账户'), '两个窗口各自带新增按钮')

section('C. UI 驱动新增：quickFund(receive) → 后端收款窗口新增 1 个')
uiA.setPrompts(['09971112223', '代理A', '收款主号'])
await uiA.ctx.quickFund('receive')
const recvList = (await call('/api/fundaccounts?flow=receive&reveal=1', { token: tokenA })).json
ok(recvList.accounts.length === 1 && recvList.accounts[0].account === '09971112223', '通过页面新增收款账户已落库', { n: recvList.accounts.length })
await uiA.ctx.VIEWS.fund()
ok(uiA.view().innerHTML.includes('09971112223') === false && uiA.view().innerHTML.includes('****'), '窗口展示为脱敏账号（含 ****）')

section('D. UI 驱动一键替换：replaceFund → 旧账户冷却 + 新账户接任 + 明确反馈')
const recvId = recvList.accounts[0].id
uiA.setPrompts(['09971113333', '代理A'])
await uiA.ctx.replaceFund(recvId, 'receive')
await flush()
const recv2 = (await call('/api/fundaccounts?flow=receive&reveal=1', { token: tokenA })).json
const newOne = recv2.accounts.filter((c) => c.account === '09971113333')
const oldOne = recv2.accounts.filter((c) => c.account === '09971112223')
ok(newOne.length === 1 && newOne[0].status === 'active', '一键替换后：新收款账户 active')
ok(oldOne.length === 1 && oldOne[0].status === 'cooldown', '一键替换后：旧收款账户进入 cooldown')
const t1 = uiA.toasts().map((x) => x.text).join(' | ')
ok(t1.includes('已一键替换') && t1.includes('已接管') && t1.includes('冷却'), '一键替换给出明确结果反馈（toast）', { toast: t1 })

section('E. 两个窗口互不串号：付款窗口新增不影响收款窗口')
uiA.setPrompts(['09971114444', '代理A', '付款主号'])
await uiA.ctx.quickFund('pay')
const payList = (await call('/api/fundaccounts?flow=pay&reveal=1', { token: tokenA })).json
const recv3 = (await call('/api/fundaccounts?flow=receive&reveal=1', { token: tokenA })).json
ok(payList.accounts.length === 1 && payList.accounts[0].account === '09971114444', '付款窗口只含新付款账号')
ok(recv3.accounts.filter((c) => c.status === 'active').length === 1, '收款窗口仍只含其自身账号（互不串号）')

section('F. 超管上下文：「平台账户」渲染使用费 / 保证金收款账户 / 费率入口')
const uiS = makeUI(tokenSuper)
await flush()
ok(!!uiS.ctx.ME && uiS.ctx.ME.role === 'super', '超管登录后 ME.role=super')
await uiS.ctx.VIEWS.platform()
const platHtml = uiS.view().innerHTML
ok(platHtml.includes('平台使用费累计') && platHtml.includes('平台账户余额'), '「平台账户」渲染使用费与余额 KPI')
ok(platHtml.includes('保证金 / 租用金收款账户'), '「平台账户」含保证金收款账户入口')
ok(platHtml.includes('平台使用费率') && platHtml.includes('p_fee') && platHtml.includes('p_on'), '「平台账户」含使用费率与计提时机配置项')
ok(platHtml.includes('09970000111'), '保证金收款账户展示资金池已配置账号')

section('G. UI 驱动保存平台费率：savePlatform → /api/settings 生效')
uiS.getEl('p_fee').value = '0.02'
uiS.getEl('p_on').value = 'true'
await uiS.ctx.savePlatform()
const cfgNow = (await call('/api/settings', { token: tokenSuper })).json.config
ok(cfgNow.platformFeeRate === 0.02, '平台使用费率经页面保存后生效（0.02）', { v: cfgNow.platformFeeRate })
ok(cfgNow.platformFeeOnCollect === true, '计提时机经页面保存后生效（true）')

section('H. 超管查看下级资金账户：一律脱敏')
const peek = (await call('/api/fundaccounts?flow=receive&ownerId=' + agentA.id + '&reveal=1', { token: tokenSuper })).json
ok(peek.accounts.length >= 1 && peek.accounts.every((c) => c.account === undefined && !!c.accountMasked), '超管查看下级：即便带 reveal 也强制脱敏')

section('I. 列表账号列不再空白：通道列表脱敏、资金池账户显示明文')
await uiA.ctx.VIEWS.channels()
const chHtml = uiA.view().innerHTML
ok(chHtml.includes('****') && !/09971112223|09971113333|09971114444/.test(chHtml), '「我的 KBZ 通道」账号列以脱敏展示（非空白）')
await uiS.ctx.VIEWS.pool()
const poolHtml = uiS.view().innerHTML
ok(poolHtml.includes('09970000111') && poolHtml.includes('资金池'), '「资金池收款账户」账号列显示已配置账号（非空白）')

console.log('\n============================================================')
if (failures.length === 0) { console.log('T8 收付款设置页面 / 平台账户入口 全部通过 \u2714  （' + passed + ' 项）') }
else {
  console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项：')
  failures.forEach(function (f) { console.log('  - ' + f) })
  process.exitCode = 1
}