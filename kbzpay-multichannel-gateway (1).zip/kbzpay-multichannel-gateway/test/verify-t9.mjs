/**
 * T9 定向验证：本轮新增的三大控制台能力（UI ↔ 后端一致性 + 数据隔离）
 * ---------------------------------------------------------------------------
 * 做法：把 CONSOLE_PAGE 的内联脚本放进 vm 沙箱（模拟 document / localStorage / fetch / prompt / confirm），
 *      fetch 直连真实 handleRequest（内存 KV），从而「用页面自己的代码」驱动真实后端。
 * 覆盖：
 *   A. 页面结构：新增「代理租用与保证金」「游戏上下分」「接入向导」三个导航页及其视图函数
 *   B. 超管「代理表」渲染：代理行 + 费用与时间配置项齐备
 *   C. UI 驱动保存「费用与时间管理」→ /api/settings 生效，并驱动代理表月租/到期日/宽限期联动
 *   D. 保证金闸门 → 缴保证金后状态跃迁；缴租用金后状态跃迁为「正常缴费」
 *   E. UI 驱动生成代理级账号（quickCreateAgent）
 *   F. 改「到期日 + 宽限期」→ 未缴代理由「待缴费」变「已逾期未缴」，并给出限制建议
 *   G. 代理明细视图（viewAgent）：租用金记录表 + 扣罚记录表
 *   H. 游戏上下分闭环：登记游戏ID → 上分成功 → 余额 / 净发币额联动
 *   I. 下分成功：创建即冻结 → 回执成功转实际出账
 *   J. 下分失败路径：余额不足被拒（409）；非法方向被拒；取消指令自动释放冻结
 *   K. 回滚已成功指令：反向记账 + 余额回退
 *   L. 多平台无文档一键接入：抓包解析 → 一键生成接入点 → 端点/密钥 → 接入说明 → 连通测试
 *   M. 配对码：生成 → 列表 → 作废
 *   N. 超管对下属代理接入点轮换密钥（作用域对称）
 *   O. 三级数据隔离：代理访问超管专属接口一律拒绝；代理看不到他人订单 / 他人 ID 越权 404
 * 运行：node test/verify-t9.mjs   （仅本地校验，随交付物一并发布）
 */
import vm from 'node:vm'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { CONSOLE_PAGE } from '../src/pages.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }

async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text }
}
async function login(username, password) {
  const r = await call('/api/auth/login', { method: 'POST', body: { username, password } })
  return r.json && r.json.token
}

/* ------------------------------------------------------------------ 迷你 DOM + 沙箱 */
function makeEl() {
  return {
    _html: '', _text: '', className: '', value: '', files: [], style: {}, children: [],
    addEventListener() {}, appendChild(c) { this.children.push(c) }, remove() {}, querySelector() { return null },
    get innerHTML() { return this._html }, set innerHTML(v) { this._html = String(v) },
    get textContent() { return this._text }, set textContent(v) { this._text = String(v) },
  }
}

function makeUI(token, opts = {}) {
  const els = {}
  const body = makeEl()
  const document = {
    domain: 'gw.example.com', body: body,
    getElementById(id) { if (!els[id]) els[id] = makeEl(); return els[id] },
    createElement() { return makeEl() },
  }
  const store = { kbz_token: token }
  const localStorage = {
    getItem(k) { return Object.prototype.hasOwnProperty.call(store, k) ? store[k] : null },
    setItem(k, v) { store[k] = String(v) },
    removeItem(k) { delete store[k] },
  }
  const prompts = []
  const alerts = []
  const location = { origin: 'https://gw.example.com', href: '', reload() {}, search: '' }
  const sandbox = {
    document, localStorage, location, console,
    navigator: { clipboard: { writeText() {} }, userAgent: 'node' },
    setTimeout: globalThis.setTimeout.bind(globalThis), clearTimeout: globalThis.clearTimeout.bind(globalThis),
    setInterval: globalThis.setInterval.bind(globalThis), clearInterval: globalThis.clearInterval.bind(globalThis),
    prompt: () => (prompts.length ? prompts.shift() : null),
    confirm: () => (opts.confirm === undefined ? true : opts.confirm),
    alert: (m) => { alerts.push(String(m)) },
    fetch: async (path, o) => {
      o = o || {}
      const headers = Object.assign({ 'cf-ipcountry': 'MM' }, o.headers || {})
      const init = { method: o.method || 'GET', headers }
      if (o.body !== undefined) init.body = o.body
      const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
      return { status: res.status, json: () => res.json(), text: () => res.text() }
    },
  }
  const ctx = vm.createContext(sandbox)
  const html = CONSOLE_PAGE({ gatewayName: 'Test' }, {})
  const code = html.match(/<script>([\s\S]*)<\/script>/)[1]
  vm.runInContext(code, ctx)
  return {
    ctx, view: () => els['view'], body, alerts,
    getEl: (id) => document.getElementById(id),
    setPrompts: (arr) => { prompts.length = 0; arr.forEach((x) => prompts.push(x)) },
    toasts: () => body.children.map((c) => ({ cls: c.className, text: c.textContent })),
    toastText: () => body.children.map((c) => String(c.textContent)).join(' | '),
  }
}
const flush = () => new Promise((r) => setTimeout(r, 60))
const balanceOf = (accounts, id) => {
  const u = (accounts || []).find((x) => x.id === id)
  return u && u.stats ? Number(u.stats.balance || 0) : 0
}

/* ================================================================== 用例 */
section('准备：超管设密 → 代理 A / 代理 B → 资金池账户')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tokenSuper = await login('superadmin', 'MyUnique@2026')
const agentA = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A' } })).json.account
const agentB = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_b', password: 'AgentB@12345', name: '代理B', depositRequired: 0 } })).json.account
const merchantC = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'merchant', username: 'shop_c', password: 'ShopC@123456', name: '商户C', parentId: agentA.id } })).json.account
const tokenA = await login('agent_a', 'AgentA@12345')
const tokenB = await login('agent_b', 'AgentB@12345')
const tokenC = await login('shop_c', 'ShopC@123456')
await call('/api/pool/accounts', { method: 'POST', token: tokenSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
ok(!!agentA && !!agentB && !!merchantC && !!tokenA && !!tokenB && !!tokenC, '环境就绪：代理A / 代理B / 商户C 均可用')

section('A. 页面结构：新增「代理租用与保证金」「游戏上下分」「接入向导」三页')
const pageHtml = CONSOLE_PAGE({ gatewayName: 'Test' }, {})
ok(pageHtml.includes('代理租用与保证金') && pageHtml.includes('游戏上下分') && pageHtml.includes('接入向导'), '导航包含三个新页面')
for (const k of ['agentrentals', 'gamepoints', 'pluguide']) {
  ok(new RegExp('VIEWS\\.' + k + '\\s*=').test(pageHtml), '脚本定义了 VIEWS.' + k)
}
const mustHave = [['费用与时间管理', '费用与时间管理'], ['代理表', '代理表'], ['生成代理级账号', '生成代理级账号'],
  ['状态筛选', '状态筛选'], ['一键智能解析', '一键智能解析'], ['一键生成接入点', '一键生成接入点'],
  ['配对码', '配对码'], ['游戏充值ID', '游戏充值ID'], ['新建指令单', '新建指令单'], ['kbz-plug.js', 'kbz-plug.js']]
for (const [name, needle] of mustHave) ok(pageHtml.includes(needle), '页面含关键要素：' + name)

section('B. 超管「代理表」渲染：代理行 + 费用与时间配置项齐备')
const uiS = makeUI(tokenSuper)
await flush()
ok(!!uiS.ctx.ME && uiS.ctx.ME.role === 'super', '超管登录后 ME.role=super')
await uiS.ctx.VIEWS.agentrentals()
const board0 = uiS.view().innerHTML
ok(board0.includes('代理总数') && board0.includes('本期应收'), '代理表渲染汇总 KPI')
ok(board0.includes('agent_a') && board0.includes('agent_b'), '代理表列出全部代理级账号')
for (const id of ['rb_rent', 'rb_dep', 'rb_fee', 'rb_settle', 'rb_pfee', 'rb_cycle', 'rb_due', 'rb_grace', 'rb_overdue']) {
  ok(board0.includes('id="' + id + '"'), '费用与时间管理含配置项 ' + id)
}
ok(board0.includes('saveFeeConfig()'), '费用配置带保存按钮（saveFeeConfig）')
ok(board0.includes('quickCreateAgent()'), '代理表带生成代理级账号入口')

section('C. UI 驱动保存「费用与时间管理」→ /api/settings 生效')
uiS.getEl('rb_rent').value = '300000'
uiS.getEl('rb_dep').value = '1500000'
uiS.getEl('rb_fee').value = '0.03'
uiS.getEl('rb_settle').value = '0.01'
uiS.getEl('rb_pfee').value = '0'
uiS.getEl('rb_cycle').value = 'monthly'
uiS.getEl('rb_due').value = '28'
uiS.getEl('rb_grace').value = '5'
uiS.getEl('rb_overdue').value = 'restrict'
await uiS.ctx.saveFeeConfig()
const cfgNow = (await call('/api/settings', { token: tokenSuper })).json.config
ok(cfgNow.rentalFeeMonthly === 300000, '月租保存生效（300000）', { v: cfgNow.rentalFeeMonthly })
ok(cfgNow.depositDefaultRequired === 1500000, '默认应缴保证金保存生效（1500000）', { v: cfgNow.depositDefaultRequired })
ok(cfgNow.withdrawFeeRate === 0.03 && cfgNow.settleFeeRate === 0.01, '费率保存生效（出款 0.03 / 转款 0.01）')
ok(cfgNow.rentalBillingCycle === 'monthly', '计费周期保存生效（自然月）')
ok(cfgNow.rentalDueDay === 28, '到期日保存生效（每月 28 号）', { v: cfgNow.rentalDueDay })
ok(cfgNow.rentalGraceDays === 5, '宽限期保存生效（5 天）', { v: cfgNow.rentalGraceDays })
ok(cfgNow.rentalOverdueAction === 'restrict', '逾期处置保存生效（逾期即限制）')

section('D. 代理表随配置联动 + 保证金闸门 → 缴保证金 → 缴租用金的状态跃迁')
const boardCfg = (await call('/api/rental-board', { token: tokenSuper })).json
const period = boardCfg.period
ok(/^\d{4}-\d{2}$/.test(period) && boardCfg.billingCycleText === '自然月', '代理表周期与计费周期文本跟随配置', { period })
const rowA0 = boardCfg.rows.find((r) => r.agentId === agentA.id)
ok(rowA0.monthlyFee === 300000, '代理行月租跟随配置（300000）', { v: rowA0.monthlyFee })
ok(rowA0.currentDueDate === period + '-28', '代理行到期日跟随配置（' + period + '-28）', { v: rowA0.currentDueDate })
ok(rowA0.graceDays === 5, '代理行宽限期跟随配置（5 天）')
ok(rowA0.depositRequired === 1500000, '未逐户设定时回退系统默认保证金（1500000）')
ok(rowA0.status === 'restricted' && rowA0.depositSufficient === false, '保证金不足 → 代理行状态「受限」')

await uiS.ctx.VIEWS.agentrentals()
uiS.setPrompts(['1500000'])
await uiS.ctx.quickDepositFor(agentA.id)
let boardNow = (await call('/api/rental-board', { token: tokenSuper })).json
const rowA1 = boardNow.rows.find((r) => r.agentId === agentA.id)
ok(rowA1.depositPaid === 1500000 && rowA1.depositSufficient === true, 'UI 记保证金后：已缴足、闸门打开')
ok(rowA1.status === 'grace' && rowA1.periodPaid === false, '保证金足额但本期未缴 → 状态「待缴费（未逾期）」')

await uiS.ctx.VIEWS.agentrentals()
uiS.setPrompts(['300000', period])
await uiS.ctx.quickRentalFor(agentA.id)
boardNow = (await call('/api/rental-board', { token: tokenSuper })).json
const rowA2 = boardNow.rows.find((r) => r.agentId === agentA.id)
ok(rowA2.periodPaid === true && rowA2.periodAmount === 300000, 'UI 记租用金后：本期已缴 300000')
ok(rowA2.status === 'normal', '本期缴清 + 保证金足额 → 状态「正常缴费」')

section('E. UI 驱动生成代理级账号（quickCreateAgent）')
const beforeCount = (await call('/api/accounts', { token: tokenSuper })).json.accounts.length
uiS.setPrompts(['agent_new1', '新代理一', 'NewAgent@123', '800000'])
await uiS.ctx.quickCreateAgent()
const accAfter = (await call('/api/accounts', { token: tokenSuper })).json
const created = accAfter.accounts.find((a) => a.username === 'agent_new1')
ok(accAfter.accounts.length === beforeCount + 1 && !!created, '页面生成代理级账号已落库')
ok(created.role === 'agent', '新账号角色为代理级（agent）')
ok(created.deposit && created.deposit.required === 800000, '该代理应缴保证金按页面输入生效（800000）', { v: created.deposit && created.deposit.required })
const newLogin = await call('/api/auth/login', { method: 'POST', body: { username: 'agent_new1', password: 'NewAgent@123' } })
ok(newLogin.status === 200 && !!newLogin.json.token, '新代理账号可正常登录')
const alertText = uiS.alerts.join(' | ')
ok(alertText.includes('agent_new1') && alertText.includes('800,000'), '生成后一次性回显账号要点（含账号与保证金）')

section('F. 改「到期日 + 宽限期」→ 未缴代理由「待缴费」变「已逾期未缴」')
uiS.getEl('rb_due').value = '8'
uiS.getEl('rb_grace').value = '0'
await uiS.ctx.saveFeeConfig()
boardNow = (await call('/api/rental-board', { token: tokenSuper })).json
const rowB1 = boardNow.rows.find((r) => r.agentId === agentB.id)
ok(rowB1.currentDueDate === period + '-08' && rowB1.graceDays === 0, '到期日/宽限期改动即时反映到代理行')
ok(rowB1.status === 'overdue' && rowB1.overdueDays > 0, '逾期未缴 → 状态「已逾期」，并给出逾期天数', { days: rowB1.overdueDays })
ok(rowB1.restrictRecommended === true, '逾期处置为「限制」时给出限制建议')
ok(boardNow.summary.overdue >= 1 && boardNow.summary.restrictRecommended >= 1, '汇总含逾期数与被建议限制数')
uiS.getEl('rb_overdue').value = 'remind'
await uiS.ctx.saveFeeConfig()
boardNow = (await call('/api/rental-board', { token: tokenSuper })).json
const rowB2 = boardNow.rows.find((r) => r.agentId === agentB.id)
ok(rowB2.status === 'overdue' && rowB2.restrictRecommended === false, '逾期处置改为「仅提醒」后不再建议限制')
uiS.getEl('rb_due').value = '28'
uiS.getEl('rb_grace').value = '5'
uiS.getEl('rb_overdue').value = 'restrict'
await uiS.ctx.saveFeeConfig()

section('G. 代理明细视图（viewAgent）：租用金记录表 + 扣罚记录表')
await uiS.ctx.VIEWS.agentrentals()
await uiS.ctx.viewAgent(agentA.id)
const detail = uiS.getEl('agentdetail').innerHTML
ok(detail.includes('租用金缴纳记录') && detail.includes('扣罚记录'), '明细含租用金记录与扣罚记录两张表')
ok(detail.includes('300,000') || detail.includes('300000'), '明细体现该代理已缴租用金 300000')
ok(detail.includes('已缴保证金') && detail.includes('应缴保证金'), '明细体现保证金应缴 / 已缴')
ok(detail.includes('quickRefundFor') && detail.includes('setDepositReq'), '明细带退还保证金与设定应缴保证金的入口')

section('H. 游戏上下分：登记游戏ID → 上分成功 → 余额 / 净发币额联动')
const uiA = makeUI(tokenA)
await flush()
ok(uiA.ctx.ME.role === 'agent', '代理登录后 ME.role=agent')
await uiA.ctx.VIEWS.gamepoints()
ok(uiA.view().innerHTML.includes('游戏上分 / 下分指令单'), '「游戏上下分」页面渲染出指令单表')
const balBefore = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
uiA.setPrompts(['gamer001', '玩家一号', 's1', '阿强', 'MGAME'])
await uiA.ctx.quickGameId()
let gids = (await call('/api/game/ids', { token: tokenA })).json.gameIds
ok(gids.length === 1 && gids[0].gameId === 'gamer001' && gids[0].gameZone === 's1', 'UI 登记游戏充值ID已落库', { n: gids.length })

uiA.setPrompts(['in', 'gamer001', '10000', 's1', '阿强', '', '首充'])
await uiA.ctx.quickGameOrder()
let orders = (await call('/api/game/orders', { token: tokenA })).json.orders
const inOrder = orders.find((o) => o.direction === 'in')
ok(!!inOrder && inOrder.status === 'queued' && inOrder.amount === 10000, 'UI 创建上分指令单（待执行）')
ok(uiA.alerts.join(' | ').includes(inOrder.orderId), '创建后回显指令单号')
const pull1 = (await call('/api/game/executor/pull', { headers: { 'X-Device-Key': ENV.DEVICE_KEY } })).json
ok(pull1.tasks.some((t) => t.orderId === inOrder.orderId), '执行端可拉取到该指令（X-Device-Key）')
const rc1 = await call('/api/game/executor/receipt', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { orderId: inOrder.orderId, ok: true, txid: 'tx-in-001' } })
ok(rc1.json.order.status === 'done' && rc1.json.order.executorTxid === 'tx-in-001', '上分回执成功 → 指令「已成功」')
const balAfterIn = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
ok(balAfterIn === balBefore + 10000, '上分成功后可用余额 +10000', { before: balBefore, after: balAfterIn })
gids = (await call('/api/game/ids', { token: tokenA })).json.gameIds
ok(gids[0].credit === 10000 && gids[0].topupTotal === 10000, '玩家账号净发币额 +10000', { credit: gids[0].credit })

section('I. 下分成功：创建即冻结 → 回执成功转实际出账')
uiA.setPrompts(['out', 'gamer001', '5000', 's1', '阿强', '', '退币'])
await uiA.ctx.quickGameOrder()
orders = (await call('/api/game/orders', { token: tokenA })).json.orders
const outOrder = orders.find((o) => o.direction === 'out' && o.amount === 5000)
ok(!!outOrder && outOrder.frozen === true, '下分指令创建即冻结等额余额')
const balFrozen = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
ok(balFrozen === balAfterIn - 5000, '冻结后可用余额相应扣减（先冻结后执行）', { v: balFrozen })
await call('/api/game/executor/pull', { headers: { 'X-Device-Key': ENV.DEVICE_KEY } })
const rc2 = await call('/api/game/executor/receipt', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { orderId: outOrder.orderId, ok: true, txid: 'tx-out-001' } })
ok(rc2.json.order.status === 'done' && rc2.json.order.frozen === false, '下分回执成功 → 冻结转实际出账')
const balAfterOut = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
ok(balAfterOut === balAfterIn - 5000, '下分成功后可用余额保持不变（已冻结的已出账）')
gids = (await call('/api/game/ids', { token: tokenA })).json.gameIds
ok(gids[0].credit === 5000 && gids[0].creditTotal === 5000, '玩家账号净发币额 -5000（下分计入累计下分）', { credit: gids[0].credit })

section('J. 失败路径：余额不足 / 非法方向 / 取消自动释放冻结')
const uiFail1 = makeUI(tokenA)
await flush()
uiFail1.setPrompts(['out', 'gamer001', String(balAfterOut + 1), '', '', '', ''])
await uiFail1.ctx.quickGameOrder()
ok(uiFail1.toastText().includes('可用余额不足'), '下分余额不足被拒并明确提示（可用余额不足）')
const ordersAfterFail = (await call('/api/game/orders', { token: tokenA })).json.orders
ok(ordersAfterFail.length === orders.length, '被拒的下分不产生任何指令单（无脏数据）')
const uiFail2 = makeUI(tokenA)
await flush()
uiFail2.setPrompts(['up', 'gamer001', '1000'])
await uiFail2.ctx.quickGameOrder()
ok(uiFail2.toastText().includes('方向只能是 in 或 out'), '非法方向在前端即被拦截并提示')
ok((await call('/api/game/orders', { token: tokenA })).json.orders.length === orders.length, '非法方向不产生指令单')
const badApi = await call('/api/game/orders', { token: tokenA, method: 'POST', body: { direction: 'up', gameId: 'gamer001', amount: 1000 } })
ok(badApi.status === 400, '后端同样拒绝非法方向（400，双保险）')

const uiCancel = makeUI(tokenA)
await flush()
uiCancel.setPrompts(['out', 'gamer001', '1000', '', '', '', ''])
await uiCancel.ctx.quickGameOrder()
const cancelTarget = (await call('/api/game/orders', { token: tokenA })).json.orders.find((o) => o.status === 'queued')
ok(cancelTarget && cancelTarget.frozen === true, '待取消的下分指令处于冻结态')
const balCancelBefore = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
uiCancel.setPrompts(['用户撤销'])
await uiCancel.ctx.cancelGame(cancelTarget.orderId)
const balCancelAfter = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
ok(balCancelAfter === balCancelBefore + 1000, '取消指令自动释放冻结（可用余额回补 1000）')
const canceled = (await call('/api/game/orders/' + cancelTarget.orderId, { token: tokenA })).json.order
ok(canceled.status === 'canceled' && canceled.frozen === false, '取消后状态「已取消」且冻结解除')

section('K. 回滚已成功指令：反向记账 + 余额回退')
const uiRb = makeUI(tokenA)
await flush()
uiRb.setPrompts(['纠错回滚'])
const balRbBefore = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
await uiRb.ctx.rollbackGame(outOrder.orderId)
const rbOrder = (await call('/api/game/orders/' + outOrder.orderId, { token: tokenA })).json.order
ok(rbOrder.status === 'rolledback' && rbOrder.rolledBack === true, '回滚后状态「已回滚」')
const balRbAfter = balanceOf((await call('/api/accounts', { token: tokenA })).json.accounts, agentA.id)
ok(balRbAfter === balRbBefore + 5000, '下分回滚退回已出账金额（可用余额 +5000）', { before: balRbBefore, after: balRbAfter })
gids = (await call('/api/game/ids', { token: tokenA })).json.gameIds
ok(gids[0].credit === 10000 && gids[0].creditTotal === 0, '回滚同步撤回发币变化（净发币额回到 10000）', { credit: gids[0].credit })

section('L. 多平台无文档一键接入：抓包解析 → 生成接入点 → 端点/密钥 → 接入说明 → 连通测试')
await uiA.ctx.VIEWS.pluguide()
const plugHtml0 = uiA.view().innerHTML
ok(plugHtml0.includes('多平台无文档一键接入向导') && plugHtml0.includes('一键智能解析') && plugHtml0.includes('一键生成接入点'), '接入向导渲染三步流程与两个一键按钮')
ok(plugHtml0.includes('kbz-plug.js') && plugHtml0.includes('/plug'), '向导给出开箱即用接入入口（SDK + 自助接入页）')
uiA.getEl('pl_cap').value = '{out_trade_no: T20261023001, money: "10,000 MMK", playerAccount: gamer001, serverId: s1}'
await uiA.ctx.plugParse()
const parseOut = uiA.getEl('pl_result').innerHTML
ok(parseOut.includes('解析结果') && parseOut.includes('识别金额：10000') && parseOut.includes('原始：10,000 MMK'), '抓包报文解析出金额（去千分位取数，同时如实展示原始值）')
ok(parseOut.includes('orderNo') || parseOut.includes('系统中字段') || parseOut.includes('系统字段'), '解析结果给出系统字段映射表')

uiA.setPrompts([])
uiA.getEl('pl_name').value = '测试电商平台'
uiA.getEl('pl_platform').value = 'testsite'
uiA.getEl('pl_target').value = ''
await uiA.ctx.plugCreate()
const pts = (await call('/api/plug/points', { token: tokenA })).json.points
const mine = pts.filter((p) => p.name === '测试电商平台')
ok(mine.length === 1, '一键生成接入点已落库', { n: mine.length })
ok(!!(mine[0] && mine[0].endpoints && mine[0].endpoints.orderUrl && /\/api\/plug\/.+\/order$/.test(mine[0].endpoints.orderUrl)), '接入点自带专属下单端点', { url: mine[0] && mine[0].endpoints && mine[0].endpoints.orderUrl })
ok(/^pk_/.test(mine[0].keyMasked || '') || !!mine[0].hasSecret, '接入点已具备接入密钥（脱敏展示）', { masked: mine[0].keyMasked })
ok(mine[0].templateId !== undefined, '接入点记录接入画像（templateId 字段存在）')
const createdAlert = uiA.alerts.join(' | ')
ok(/pk_/.test(createdAlert) && createdAlert.includes('只显示一次'), '生成后一次性明文回显接入密钥并提示仅显示一次')
const plainKey = (createdAlert.match(/pk_[A-Za-z0-9_-]{6,}/) || [''])[0]

await uiA.ctx.VIEWS.pluguide()
const plugHtml1 = uiA.view().innerHTML
ok(plugHtml1.includes('测试电商平台') && plainKey !== '' && !plugHtml1.includes(plainKey), '接入点列表展示该平台（明文密钥不出现在列表中）', { masked: mine[0].keyMasked })
await uiA.ctx.plugExplain(mine[0].adapterId)
const explainOut = uiA.getEl('pl_result').innerHTML
ok(explainOut.includes('接入说明') && explainOut.includes('下单端点') && explainOut.includes('签名规则'), '「接入说明」给出端点与签名规则')

await uiA.ctx.plugTest(mine[0].adapterId)
const testOut = uiA.getEl('pl_result').innerHTML
ok(testOut.includes('连通测试') && testOut.includes('密钥可用性'), '「连通测试」逐项给出检查结果')
ok(testOut.includes('全部通过'), '无回调地址时连通测试仍判定通过（通用入口无需回调）')

section('M. 配对码：生成 → 列表 → 作废')
await uiA.ctx.VIEWS.pluguide()
uiA.setPrompts(['对接电商平台'])
await uiA.ctx.newPairCode()
let codes = (await call('/api/plug/codes', { token: tokenA })).json.codes
ok(codes.length === 1 && codes[0].status === 'active', 'UI 生成配对码已落库且有效', { n: codes.length })
ok(uiA.alerts.join(' | ').includes(codes[0].code), '生成后回显配对码')
await uiA.ctx.plugRevokeCode(codes[0].code)
codes = (await call('/api/plug/codes', { token: tokenA })).json.codes
ok(codes[0].status === 'revoked', '作废后配对码状态为 revoked')

section('N. 超管对下属代理接入点轮换密钥（作用域对称）')
const rotA = await call('/api/plug/adapters/' + mine[0].adapterId + '/rotate', { method: 'POST', token: tokenA })
ok(rotA.status === 200 && /^pk_/.test(rotA.json.plugKey || ''), '代理可轮换自有接入点密钥')
const rotS = await call('/api/plug/adapters/' + mine[0].adapterId + '/rotate', { method: 'POST', token: tokenSuper })
ok(rotS.status === 200 && /^pk_/.test(rotS.json.plugKey || ''), '超管可轮换下属代理的接入点密钥（不再 404）')
ok(rotS.json.plugKey !== rotA.json.plugKey, '轮换后新旧密钥不同（旧密钥即时失效）')
const ptsAfterRot = (await call('/api/plug/points', { token: tokenA })).json.points
ok(ptsAfterRot.find((p) => p.adapterId === mine[0].adapterId).keyMasked === rotS.json.keyMasked, '轮换结果已在接入点列表反映')

section('O. 三级数据隔离：超管专属接口拒绝越权 + 订单 / ID 可见范围隔离')
const forbid = async (label, path, opt) => {
  const r = await call(path, Object.assign({ token: tokenA }, opt || {}))
  ok(r.status === 403 || r.status === 404, label + '（代理被拒 ' + r.status + '）', { status: r.status, body: r.text && r.text.slice(0, 80) })
}
await forbid('代理访问代理租用与保证金总表被拒', '/api/rental-board')
await forbid('代理修改系统设置被拒', '/api/settings', { method: 'PUT', body: { rentalFeeMonthly: 1 } })
await forbid('代理访问资金池被拒', '/api/pool')
await forbid('代理登记保证金入池被拒', '/api/pool/deposit', { method: 'POST', body: { agentId: agentB.id, amount: 1 } })
const peekSettings = await call('/api/settings', { token: tokenA })
ok(peekSettings.status === 403 || peekSettings.status === 404, '代理读取系统设置被拒')

const uiSuperOnly = makeUI(tokenA)
await flush()
const beforeHtml = uiSuperOnly.view().innerHTML
await uiSuperOnly.ctx.VIEWS.agentrentals()
const afterHtml = uiSuperOnly.view().innerHTML
ok(afterHtml === beforeHtml && !afterHtml.includes('费用与时间管理（超管）') && !afterHtml.includes('代理总数'), '代理打开「代理租用与保证金」不渲染任何内容（视图不变、无代理表要素）')
ok(uiSuperOnly.toastText().includes('仅超级管理员可用'), '并明确提示「仅超级管理员可用」')

const ordersB = (await call('/api/game/orders', { token: tokenB })).json.orders
const badCross = await call('/api/game/orders?ownerId=' + agentB.id, { token: tokenA })
ok(badCross.status === 404, '代理按他人 ownerId 查订单 → 404（资源不存在口径）', { status: badCross.status })
const ordersA = (await call('/api/game/orders', { token: tokenA })).json.orders
ok(ordersA.every((o) => o.ownerId === agentA.id), '代理订单列表仅含本人归属（' + ordersA.length + ' 条）')
ok(ordersB.length === 0, '代理B 看不到代理A 的任何订单')
const badOwner = await call('/api/game/ids', { token: tokenA, method: 'POST', body: { gameId: 'gamer001', ownerId: agentB.id } })
ok(badOwner.status === 404 || badOwner.status === 409, '把已登记游戏ID改挂到他人名下被拒（' + badOwner.status + '）')
const merchantSees = (await call('/api/game/orders', { token: tokenC })).json.orders
ok(merchantSees.length === 0, '下级商户看不到上级代理的指令单（自下而上不泄）')
await forbid('商户访问代理租用与保证金总表被拒', '/api/rental-board', { token: tokenC })

const uiMerchantOnly = makeUI(tokenC)
await flush()
const mBefore = uiMerchantOnly.view().innerHTML
await uiMerchantOnly.ctx.VIEWS.agentrentals()
const mAfter = uiMerchantOnly.view().innerHTML
ok(mAfter === mBefore && !mAfter.includes('费用与时间管理（超管）'), '商户打开「代理租用与保证金」同样不渲染代理表内容')

const superSees = (await call('/api/game/orders', { token: tokenSuper })).json.orders
ok(superSees.length >= ordersA.length + ordersB.length, '超管可见全部下级指令单（拥有全部数据）', { n: superSees.length })

/* --------------------------------------------------------------- 收尾 */
console.log('\n' + '='.repeat(60))
if (failures.length) {
  console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
  failures.forEach((f) => console.log('  \u2717 ' + f))
  console.log('T9 定向验证存在失败项 \u2717')
  process.exit(1)
} else {
  console.log('通过 ' + passed + ' 项，失败 0 项')
  console.log('T9 定向验证全部通过 \u2714')
}