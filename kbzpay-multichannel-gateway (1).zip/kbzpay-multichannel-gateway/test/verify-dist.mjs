/**
 * 交付产物直验（node test/verify-dist.mjs）
 * ---------------------------------------------------------------------------
 * 与其它脚本的区别：本脚本**直接加载交付件本体** `dist/index.js`（单文件部署版），
 * 通过它导出的 fetch 处理器走真实请求链。用途：证明「你将要粘贴到 Cloudflare Workers
 * 在线编辑器 / 或由 wrangler 部署的那一份单文件产物」本身可用，而不只是源码可用。
 *
 * 覆盖（全部为对交付件本体的断言）：
 *   A. 产物可加载 + 健康检查
 *   B. 地区锁定（仅缅甸）
 *   C. 超管唯一入口与首次设密唯一性
 *   D. 三级账号与数据隔离（越权 404）
 *   E. 超管代理表（汇总 / 行字段 / 状态四态）
 *   F. 超管费用与时间管理（保存生效 + 保证金钉定与联动口径）
 *   G. 资金池：保证金收款 + 租用金入池
 *   H. 代理自有 KBZ 通道 + 收款 / 付款两个资金账户窗口 + 一键替换
 *   I. 自动收款 → 电商自动发货 → 收货转款到户
 *   J. 游戏充值 ID 上分 / 下分 / 回执 / 回滚（账实守恒）
 *   K. 无文档一键接入（模板库 / 抓包解析 / 一键生成接入点 / 连通测试 / 密钥轮换 / 配对码）
 */
import { createMemoryKV } from '../lib/memory-kv.mjs'

// Node 18 的 ESM 上下文默认不暴露 globalThis.crypto（Cloudflare Workers 原生自带 WebCrypto）。
// 与 dev-server.mjs 一样做等价兜底，仅为本地直验服务，不属于交付件的一部分。
if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let worker
try {
  worker = (await import('../dist/index.js')).default
} catch (e) {
  console.log('无法加载 dist/index.js：' + e.message)
  console.log('请先执行：npm run build')
  process.exit(1)
}

const ENV = {
  KBZ_GATEWAY: createMemoryKV(),
  ALLOW_COUNTRIES: 'MM',
  DEVICE_KEY: 'art-check-device-key',
  ASSETS: { fetch: async () => new Response('', { status: 404 }) },
}
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) }, passThroughOnException: () => {} }

let pass = 0
const fail = []
function ok(c, l, extra) {
  if (c) { pass++; console.log('  \u2713 ' + l) }
  else { fail.push(l + (extra !== undefined ? ' → ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + l + (extra !== undefined ? ' → ' + JSON.stringify(extra) : '')) }
}

async function call(path, opt = {}) {
  const headers = Object.assign({ 'content-type': 'application/json', 'CF-IPCountry': opt.country || 'MM' }, opt.headers || {})
  const req = new Request('https://gw.example' + path, {
    method: opt.method || 'GET',
    headers,
    body: opt.body !== undefined ? (typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)) : undefined,
  })
  const res = await worker.fetch(req, ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text }
}
const auth = (t) => ({ Authorization: 'Bearer ' + t })

/* ---- A. 产物可加载 + 健康检查 ---- */
ok(typeof worker.fetch === 'function', '单文件产物可加载并导出 fetch')
ok((await call('/health')).json.ok === true, 'GET /health 可用')

/* ---- B. 地区锁定 ---- */
ok((await call('/api/config', { country: 'TH' })).status === 403, '非缅甸地区被拒（TH → 403）')
ok((await call('/api/config', { country: 'MM' })).status === 200, '缅甸地区放行（MM → 200）')

/* ---- C. 超管唯一入口与首次设密唯一性 ---- */
ok((await call('/admin')).text.includes('首次设密'), 'GET /admin 首次设密入口可访问')
ok((await call('/api/setup/status')).json.initialized === false, '初始未设密（setup/status=false）')
ok((await call('/api/setup/admin', { method: 'POST', body: { username: 'root', password: 'Root@2026x', confirm: 'Root@2026x' } })).json.token !== undefined, '首次设密成功并签发登录态')
const again = await call('/api/setup/admin', { method: 'POST', body: { username: 'root', password: 'Other@2026x', confirm: 'Other@2026x' } })
ok(again.status === 403, '再次设密被拒（唯一超管，403）', again.status)
const superT = (await call('/api/auth/login', { method: 'POST', body: { username: 'root', password: 'Root@2026x' } })).json.token
ok(!!superT, '超管登录成功')

/* ---- D. 三级账号与数据隔离 ---- */
const a1 = (await call('/api/accounts', { method: 'POST', headers: auth(superT), body: { role: 'agent', username: 'agent_alpha', password: 'Alpha@2026', name: '阿尔法代理', depositRequired: 800000 } })).json.account
const a2 = (await call('/api/accounts', { method: 'POST', headers: auth(superT), body: { role: 'agent', username: 'agent_beta', password: 'Beta@2026', name: '贝塔代理' } })).json.account
ok(a1 && a1.role === 'agent' && a2 && a2.role === 'agent', '超管生成两个代理级账号')
ok(a1 && a1.depositRequired === 800000, '超管可逐户设定代理保证金应缴额（800000）', a1 && a1.depositRequired)
const tA = (await call('/api/auth/login', { method: 'POST', body: { username: 'agent_alpha', password: 'Alpha@2026' } })).json.token
ok(!!tA, '代理登录成功')
const cross = await call('/api/accounts/' + a2.id, { headers: auth(tA) })
ok(cross.status === 404, '代理无法读取其它代理账号（越权 404）', cross.status)
const crossFund = await call('/api/fundaccounts?flow=receive&ownerId=' + a2.id, { headers: auth(tA) })
ok(crossFund.status === 404 || crossFund.status === 403, '代理无法越权读取其它代理资金账户', crossFund.status)

/* ---- E. 超管代理表 ---- */
const board = (await call('/api/rental-board', { headers: auth(superT) })).json
ok(board && Array.isArray(board.rows) && board.rows.length >= 2, '超管代理表返回行数据', board && board.rows && board.rows.length)
ok(!!board.summary && board.summary.depositRequiredTotal >= 800000, '代理表汇总含保证金应缴合计', board && board.summary && board.summary.depositRequiredTotal)
const rowA = board.rows.find((r) => r.username === 'agent_alpha')
ok(!!rowA && rowA.monthlyFee === board.monthlyDefault, '代理表行含月度租用费', rowA && rowA.monthlyFee)
ok(!!rowA && ['normal', 'grace', 'overdue', 'restricted'].includes(rowA.status), '代理表行状态为四态之一', rowA && rowA.status)
ok(!!rowA && rowA.depositRequired !== undefined, '代理表行含保证金应缴额')

/* ---- F. 超管费用与时间管理 ---- */
const setRes = await call('/api/settings', {
  method: 'PUT', headers: auth(superT),
  body: { rentalFeeMonthly: 300000, rentalBillingCycle: 'quarterly', rentalDueDay: 5, rentalGraceDays: 7, rentalOverdueAction: 'remind', platformFeeRate: 0.01, platformFeeOnCollect: true, depositDefaultRequired: 1200000 },
})
ok(setRes.json && setRes.json.success === true, '超管保存费用与时间配置')
const board2 = (await call('/api/rental-board', { headers: auth(superT) })).json
ok(board2.monthlyDefault === 300000 && board2.cycle === 'quarterly' && board2.dueDay === 5 && board2.graceDays === 7 && board2.overdueAction === 'remind', '费用/周期/到期日/宽限期/逾期处置保存后驱动代理表', board2 && { m: board2.monthlyDefault, c: board2.cycle, d: board2.dueDay, g: board2.graceDays, o: board2.overdueAction })
const rowA2 = board2.rows.find((r) => r.username === 'agent_alpha')
const rowB2 = board2.rows.find((r) => r.username === 'agent_beta')
ok(rowA2 && rowA2.depositRequired === 800000, '已被超管钉定的代理保证金不随默认值浮动（800000）', rowA2 && rowA2.depositRequired)
ok(rowB2 && rowB2.depositRequired === 1200000, '未钉定的代理随系统默认值联动（1200000）', rowB2 && rowB2.depositRequired)

/* ---- G. 资金池 ---- */
ok((await call('/api/pool/accounts', { method: 'POST', headers: auth(superT), body: { accounts: [{ account: '09970000111', holder: '资金池账户' }] } })).json.success === true, '超管配置资金池账户')
ok((await call('/api/pool/deposit', { method: 'POST', headers: auth(superT), body: { agentId: a1.id, amount: 800000 } })).json.deposit.paid === 800000, '保证金收款归集到资金池')
ok((await call('/api/pool/rental', { method: 'POST', headers: auth(superT), body: { agentId: a1.id, amount: 300000, note: '首期租用金' } })).json.success === true, '代理租用金入池')

/* ---- H. 自有 KBZ 通道 + 收款/付款两窗口 + 一键替换 ---- */
ok((await call('/api/channels', { method: 'POST', headers: auth(tA), body: { account: '09971110001', holder: '阿尔法 KBZ', primary: true } })).json.channel.status === 'active', '代理自建 KBZ 主通道')
const fa0 = await call('/api/fundaccounts', { method: 'POST', headers: auth(tA), body: { flow: 'receive', account: '09971110002', holder: '阿尔法收款号', primary: true } })
ok(fa0.json.success === true && fa0.json.account && fa0.json.account.flow === 'receive', '代理新增「收款」资金账户窗口')
const fa1 = await call('/api/fundaccounts', { method: 'POST', headers: auth(tA), body: { flow: 'pay', account: '09971110003', holder: '阿尔法付款号', primary: true } })
ok(fa1.json.success === true && fa1.json.account && fa1.json.account.flow === 'pay', '代理新增「付款」资金账户窗口')
const rep = await call('/api/fundaccounts/' + fa0.json.account.id + '/replace', { method: 'POST', headers: auth(tA), body: { account: '09971110009', holder: '阿尔法 KBZ 新号' } })
ok(rep.json.success === true && rep.json.current && rep.json.replaced && !!rep.json.cooldownUntil, '收款账户一键替换（current 新号 / replaced 旧号 / cooldownUntil）', rep.json && { c: rep.json.current && rep.json.current.account, r: rep.json.replaced && rep.json.replaced.account })
const rep2 = await call('/api/fundaccounts/' + fa1.json.account.id + '/replace', { method: 'POST', headers: auth(tA), body: { account: '09971110008', holder: '阿尔法付款新号' } })
ok(rep2.json.success === true, '付款账户一键替换')

/* ---- I. 自动收款 → 电商自动发货 → 收货转款 ---- */
const ord = (await call('/api/orders', { method: 'POST', headers: auth(tA), body: { amount: 5000, scene: 'ecommerce', subject: '直验电商单', cardSecret: 'ART-CHECK-CARD' } })).json.order
ok(ord && !!ord.payUrl, '代理下单并生成收银台链接')
const nf = await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': 'art-check-device-key' }, body: { receiverAccount: '09971110001', amount: ord.payable, txid: 'ARTCHK0001' } })
ok(nf.json.results[0].status === 'paid', '到账通知自动核销', nf.json && nf.json.results[0].status)
ok((await call('/api/pay/delivery?t=' + ord.token)).json.order.deliveryView.cardSecret === 'ART-CHECK-CARD', '买家取到明文卡密（自动发货闭环）')
ok((await call('/api/pay/receive', { method: 'POST', body: { token: ord.token } })).json.order.stage === 'settled', '确认收货 → 托管款转款到户')

/* ---- J. 游戏充值 ID 上分 / 下分 / 回执 / 回滚 ---- */
const gid = (await call('/api/game/ids', { method: 'POST', headers: auth(tA), body: { gameId: 'gamer001', label: '直验玩家', gameZone: 's1' } })).json.gameId
ok(gid && gid.gameId === 'gamer001', '登记游戏充值 ID')
const up = (await call('/api/game/orders', { method: 'POST', headers: auth(tA), body: { direction: 'in', gameId: 'gamer001', amount: 10000, gameZone: 's1' } })).json.order
ok(up && up.direction === 'in' && up.status === 'queued', '发起上分（加币）订单')
const down = (await call('/api/game/orders', { method: 'POST', headers: auth(tA), body: { direction: 'out', gameId: 'gamer001', amount: 3000, gameZone: 's1' } })).json.order
ok(down && down.direction === 'out' && down.frozen === true, '发起下分（扣币）订单（创建即冻结）')
const pull = await call('/api/game/executor/pull', { headers: { 'X-Device-Key': 'art-check-device-key' } })
ok(pull.json.success === true && Array.isArray(pull.json.tasks) && pull.json.tasks.some((o) => o.orderId === up.orderId) && pull.json.tasks.some((o) => o.orderId === down.orderId), '执行端拉取到待执行的上分/下分指令', pull.json && pull.json.tasks && pull.json.tasks.map((x) => x.orderId))
const rcUp = await call('/api/game/executor/receipt', { method: 'POST', headers: { 'X-Device-Key': 'art-check-device-key' }, body: { orderId: up.orderId, ok: true, txid: 'ARTCHK-UP-1' } })
ok(rcUp.json.success === true && rcUp.json.order.status === 'done' && rcUp.json.order.credit === 10000, '上分回执成功 → 加币入账（game credit=10000）', rcUp.json && rcUp.json.order && { s: rcUp.json.order.status, c: rcUp.json.order.credit })
const rcDown = await call('/api/game/executor/receipt', { method: 'POST', headers: { 'X-Device-Key': 'art-check-device-key' }, body: { orderId: down.orderId, ok: true, txid: 'ARTCHK-DOWN-1' } })
ok(rcDown.json.success === true && rcDown.json.order.status === 'done' && rcDown.json.order.credit === 7000, '下分回执成功 → 扣币出账（game credit=7000）', rcDown.json && rcDown.json.order && { s: rcDown.json.order.status, c: rcDown.json.order.credit })
const rollback = await call('/api/game/orders/' + down.orderId + '/rollback', { method: 'POST', headers: auth(tA), body: { reason: '直验回滚' } })
ok(rollback.json.success === true && rollback.json.order.status === 'rolledback', '已成功执行的下分可回滚（账实守恒）', rollback.json && rollback.json.order && rollback.json.order.status)
const gp = (await call('/api/game/orders/' + up.orderId, { headers: auth(tA) })).json
ok(gp && gp.order && gp.order.credit === 10000, '回滚后净发币额回到 10000（credit = 上分 - 下分，不变式成立）', gp && gp.order && gp.order.credit)
const gp2 = (await call('/api/game/ids', { headers: auth(tA) })).json
ok(gp2 && Array.isArray(gp2.gameIds) && gp2.gameIds.some((g) => g.gameId === 'gamer001'), '游戏充值 ID 列表可读', gp2 && gp2.gameIds && gp2.gameIds.length)

/* ---- K. 无文档一键接入 ---- */
ok((await call('/api/plug/templates', { headers: auth(tA) })).json.success === true, '接入模板库可读')
const parse = await call('/api/plug/parse', { method: 'POST', headers: auth(tA), body: { captured: JSON.stringify({ out_trade_no: 'T20261023001', money: '10,000 MMK', playerAccount: 'gamer001', serverId: 's1' }) } })
ok(parse.json.success === true && parse.json.amount === 10000, '抓包报文解析出金额（去千分位与单位）', parse.json && parse.json.amount)
const mk = await call('/api/plug/adapters', { method: 'POST', headers: auth(tA), body: { name: '直验平台', captured: JSON.stringify({ out_trade_no: 'T2', money: '10000', playerAccount: 'gamer001' }), platform: 'direct' } })
ok(mk.json.success === true && !!mk.json.plugKey && !!mk.json.keyMasked, '一键生成接入点并回显一次性密钥（脱敏）', mk.json && { k: !!mk.json.plugKey, m: mk.json.keyMasked })
ok(String(mk.json.keyMasked).indexOf('pk_') === -1, '脱敏回显不含明文前缀')
const aid = mk.json.adapter.id
const test = await call('/api/plug/adapters/' + aid + '/test', { method: 'POST', headers: auth(tA), body: {} })
ok(test.json.ok === true, '接入点连通测试全部通过（可直接接入）', test.json && test.json.conclusion)
ok((await call('/api/plug/manifest')).json.success !== false, '通用入口 manifest 可用')
const rot = await call('/api/plug/adapters/' + aid + '/rotate', { method: 'POST', headers: auth(tA), body: {} })
ok(rot.json.success === true && !!rot.json.plugKey, '接入密钥可一键轮换')
const pairCode = (await call('/api/plug/codes', { method: 'POST', headers: auth(superT), body: { label: '直验配对码' } })).json
ok(!!pairCode && !!(pairCode.code || pairCode.pairCode), '超管生成接入配对码', pairCode && (pairCode.code || pairCode.pairCode))

console.log('\n通过 ' + pass + ' 项，失败 ' + fail.length + ' 项')
if (fail.length) { fail.forEach((f) => console.log(' - ' + f)); process.exit(1) }
console.log('交付单文件产物（dist/index.js）直验全部通过 ✔')