/**
 * T2 定向验证：电商闭环端到端 + 额度内自动出款 / 超限审批 + 账实相符
 * 覆盖：下单 → 自动收款核销 → 自动发货（卡密/物流）→ 收货确认 → 转款到户（含指定受益人）
 *      → 额度内自动入队 / 超限人工审批 → 冻结额度与可用余额口径；超时自动收货扫描。
 */
import http from 'node:http'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { autoReceiveSweep } from '../src/engine.js'
import { kvGet, kvPut } from '../src/core.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }
async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': opt.country || 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) {}
  return { status: res.status, json, text }
}
async function login(u, p) { return (await call('/api/auth/login', { method: 'POST', body: { username: u, password: p } })).json.token }
const cbServer = http.createServer((req, res) => { let b = ''; req.on('data', c => b += c); req.on('end', () => { res.writeHead(200); res.end('{"ok":true}') }) })
await new Promise(r => cbServer.listen(0, '127.0.0.1', r))

/* --------------------------- 环境 --------------------------- */
section('准备环境')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tSuper = await login('superadmin', 'MyUnique@2026')
const agent = (await call('/api/accounts', { method: 'POST', token: tSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tA = await login('agent_a', 'AgentA@12345')
const merch = (await call('/api/accounts', { method: 'POST', token: tA, body: { role: 'merchant', username: 'shop_one', password: 'ShopOne@123', name: '一号商户' } })).json.account
const tM = await login('shop_one', 'ShopOne@123')
await call('/api/pool/accounts', { method: 'POST', token: tSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tSuper, body: { agentId: agent.id, amount: 1000000 } })
await call('/api/channels', { method: 'POST', token: tA, body: { account: '09971112223', holder: '代理A', primary: true } })
const chAccount = (await call('/api/channels', { token: tA })).json.channels[0].account
ok(true, '环境就绪')

const statOf = async (tok) => (await call('/api/stats', { token: tok })).json.stats
async function pay(o) { return await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: o.channelAccount, amount: o.payable, txid: 'T' + Date.now() + Math.floor(Math.random() * 1000) } }) }
async function getOrder(id) { return (await call('/api/orders/' + id, { token: tM })).json.order }
async function place(body) { const r = await call('/api/orders', { method: 'POST', token: tM, body: Object.assign({ channelAccount: chAccount }, body) }); return r.json.order }

/* --------------------------- A. 电商卡密全链路 --------------------------- */
section('A. 电商卡密：下单 → 收款核销 → 自动发货 → 收货 → 转款到户')
const m0 = await statOf(tM)
const a1 = await place({ amount: 50000, scene: 'ecommerce', subject: '点卡500', delivery: { type: 'card', cardSecret: 'CARD-50000-XYZ' } })
await pay(a1)
const a1p = await getOrder(a1.orderId)
ok(a1p.status === 'paid' && a1p.stage === 'delivered' && a1p.deliveryType === 'card', '到账自动发货（卡密，stage=delivered）', { status: a1p.status, stage: a1p.stage, type: a1p.deliveryType })
const m1 = await statOf(tM)
ok(m1.escrow === m0.escrow + 50000 && m1.balance === m0.balance, '收款进托管（escrow +50000）', { escrow: m1.escrow, balance: m1.balance })
const rec = await call('/api/pay/receive', { method: 'POST', body: { token: a1.token } })
ok(rec.json.order.stage === 'settled', '买家确认收货 → settled')
const m2 = await statOf(tM)
ok(m2.escrow === m0.escrow && m2.balance === m0.balance + 50000, '转款到户：托管清零、可用余额 +50000（账实相符）', { escrow: m2.escrow, balance: m2.balance })
const a1s = await getOrder(a1.orderId)
ok(a1s.cardSecret === undefined || a1s.cardSecretCipher === undefined, '结算后销毁发货凭据（卡密不驻留）', { cipher: a1s.cardSecretCipher })

/* --------------------------- B. 指定受益人转款 --------------------------- */
section('B. 指定受益人：托管在商户、转款入上级代理账户')
const a0 = await statOf(tA)
const b1 = await place({ amount: 30000, scene: 'ecommerce', subject: '代收', beneficiaryId: agent.id, delivery: { type: 'logistics', trackingNo: 'MM-777888' } })
await pay(b1)
ok((await statOf(tM)).escrow >= 30000, '托管资金仍记在商户名下')
const rb = await call('/api/pay/receive', { method: 'POST', body: { token: b1.token } })
const a1s2 = await statOf(tA)
ok(rb.json.order.stage === 'settled' && a1s2.balance === a0.balance + 30000, '收货后转款入指定受益人（代理余额 +30000）', { agentBalance: a1s2.balance })

/* --------------------------- C. 出款：额度内自动 / 超限审批 --------------------------- */
section('C. 出款：额度内自动入队、超限人工审批')
await call('/api/settings', { method: 'PUT', token: tSuper, body: { autoPayoutLimit: 10000 } })
const mC = await statOf(tM)
const po1 = (await call('/api/payouts', { method: 'POST', token: tM, body: { amount: 10000, account: '09970000999', holder: '商户老板' } })).json.payout
ok(po1.status === 'queued' && po1.autoApproved === true, '额度内出款自动入队（免人工）', { status: po1.status, auto: po1.autoApproved })
const mC1 = await statOf(tM)
ok(mC1.balance === mC.balance - (10000 + Math.round(10000 * 0.05)), '自动出款：可用余额扣减本金+手续费（冻结）', { before: mC.balance, after: mC1.balance })
const po2 = (await call('/api/payouts', { method: 'POST', token: tM, body: { amount: 20000, account: '09970000999', holder: '商户老板' } })).json.payout
ok(po2.status === 'pending' && po2.autoApproved === false, '超限出款进入待审批（pending）', { status: po2.status, auto: po2.autoApproved })
const appr = await call('/api/payouts/' + po2.id + '/approve', { method: 'POST', token: tA, body: {} })
ok(appr.json.payout.status === 'queued', '上级审批通过 → queued（进入出款队列）', appr.json.payout.status)
const rej = (await call('/api/payouts', { method: 'POST', token: tM, body: { amount: 1000, account: '09970000999' } })).json.payout
const rjr = await call('/api/payouts/' + rej.id + '/reject', { method: 'POST', token: tA, body: { reason: '信息不全' } })
ok(rjr.json.payout.status === 'rejected', '驳回出款单 → rejected')
const mD = await statOf(tM)
ok(mD.balance === mC.balance - 10500 - 21000, '驳回后额度全额退回：余额=初始−自动入队−审批中', { balance: mD.balance, expect: mC.balance - 31500 })
// 账实相符：余额 = 累计到户 - 未完成出款冻结
const list = (await call('/api/payouts', { token: tM })).json.payouts
ok(list.length >= 3 && list.some(p => p.status === 'queued') && list.some(p => p.status === 'rejected'), '出款单列表齐全且状态可查', { n: list.length })

/* --------------------------- D. 超时自动收货扫描 --------------------------- */
section('D. 超时自动收货：定时扫描把到期托管订单自动收货转款')
await call('/api/settings', { method: 'PUT', token: tSuper, body: { autoReceiveHours: 72, autoSettle: true } })
const d1 = await place({ amount: 7000, scene: 'ecommerce', subject: '自动收货用例', delivery: { type: 'card', cardSecret: 'AUTO-SETTLE' } })
await pay(d1)
const d1p = await getOrder(d1.orderId)
ok(d1p.stage === 'delivered' && !!d1p.autoReceiveAt, '发货后写入自动收货到期时间（autoReceiveAt）', { stage: d1p.stage, at: d1p.autoReceiveAt })
// 模拟时间到期：把该订单的到期时间回拨到过去
const dKey = 'ord:' + merch.id + ':' + d1.orderId
const dRaw = await kvGet(ENV, dKey, null)
dRaw.autoReceiveAt = new Date(Date.now() - 3600 * 1000).toISOString()
await kvPut(ENV, dKey, dRaw)
const mE = await statOf(tM)
const sweep = await autoReceiveSweep(ENV, 50)
const d1s = await getOrder(d1.orderId)
const mF = await statOf(tM)
ok(sweep.autoSettled >= 1 && d1s.stage === 'settled', '定时扫描将到期托管订单自动收货并结算', sweep)
ok(mF.balance === mE.balance + 7000 && mF.escrow <= 0, '自动收货后转款到户（余额 +7000、托管清零）', { balance: mF.balance, escrow: mF.escrow })
// 未到期订单不应被误结算
const d2 = await place({ amount: 3000, scene: 'ecommerce', subject: '未到期', delivery: { type: 'card', cardSecret: 'NOT-YET' } })
await pay(d2)
const sweep2 = await autoReceiveSweep(ENV, 50)
ok(sweep2.scanned === 0 && (await getOrder(d2.orderId)).stage === 'delivered', '未到期订单不被自动结算（仍处于待收货）', sweep2)

cbServer.close()
console.log('\n============================================================')
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
if (failures.length) { console.log('\n失败明细：'); failures.forEach(f => console.log(' - ' + f)); process.exit(1) }
console.log('T2 定向验证全部通过 \u2714')
process.exit(0)