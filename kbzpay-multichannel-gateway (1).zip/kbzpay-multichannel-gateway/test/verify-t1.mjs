/**
 * T1 定向验证：履约链数据模型与引擎（发货 / 收货 / 转款到户）
 * 覆盖：pending→paid→delivered→received→settled 状态迁移、托管/可用余额口径、
 *       电商（卡密/物流）、游戏（发币回执）、非托管场景、托管退款。
 * 运行：node test/verify-t1.mjs   （仅本地校验，不随交付物发布）
 */
import http from 'node:http'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { hmacHex } from '../src/core.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 'test-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }

async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': opt.country || 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text }
}
async function login(username, password) {
  const r = await call('/api/auth/login', { method: 'POST', body: { username, password } })
  return r.json && r.json.token
}

const cbServer = http.createServer((req, res) => { let b = ''; req.on('data', c => b += c); req.on('end', () => { res.writeHead(200); res.end('{"ok":true}') }) })
await new Promise(r => cbServer.listen(0, '127.0.0.1', r))
const CB_URL = 'http://127.0.0.1:' + cbServer.address().port + '/cb'

/* ------------------------------------------------------------------ 准备环境 */
section('准备：超管设密 → 代理 → 商户 → 保证金 → 通道')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tokenSuper = await login('superadmin', 'MyUnique@2026')
const agentA = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 1000000 } })).json.account
const tokenA = await login('agent_a', 'AgentA@12345')
const merch = (await call('/api/accounts', { method: 'POST', token: tokenA, body: { role: 'merchant', username: 'shop_one', password: 'ShopOne@123', name: '一号商户' } })).json.account
const tokenM = await login('shop_one', 'ShopOne@123')
await call('/api/pool/accounts', { method: 'POST', token: tokenSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
await call('/api/pool/deposit', { method: 'POST', token: tokenSuper, body: { agentId: agentA.id, amount: 1000000 } })
const ch = (await call('/api/channels', { method: 'POST', token: tokenA, body: { account: '09971112223', holder: '代理A', primary: true } })).json.channel
ok(!!ch && ch.status === 'active', '环境就绪：通道可用')

async function stats() { return (await call('/api/stats', { token: tokenM })).json.stats }
async function pay(order) {
  return await call('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { receiverAccount: order.channelAccount, amount: order.payable, txid: 'T' + Date.now() + Math.floor(Math.random() * 1000) } })
}
async function order(id) { return (await call('/api/orders/' + id, { token: tokenM })).json.order }

/* ------------------------------------------------------------------ 电商：卡密（自动发货→收货→转款到户） */
section('电商闭环 · 卡密：下单 → 收款 → 自动发货 → 收货 → 转款到户')
const s0 = await stats()
const e1 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 15000, scene: 'ecommerce', subject: '点卡', delivery: { type: 'card', cardSecret: 'CARD-AAAABBBB' } } })).json.order
ok(e1.status === 'pending' && e1.stage === 'pending' && e1.escrow === true, '下单：pending/pending，进入托管（escrow=true）', { status: e1.status, stage: e1.stage, escrow: e1.escrow })
await pay(e1)
const e1paid = await order(e1.orderId)
ok(e1paid.status === 'paid' && e1paid.stage === 'delivered', '收款核销后自动发货：paid → delivered', { status: e1paid.status, stage: e1paid.stage })
const st1 = await stats()
ok(st1.escrow === s0.escrow + 15000 && st1.balance === s0.balance, '到账金额进托管（escrow +15000），可用余额不变', { escrow: st1.escrow, balance: st1.balance })
const dv = await call('/api/pay/delivery?t=' + e1.token)
ok(dv.json.order.deliveryView.cardSecret === 'CARD-AAAABBBB', '发货后买家可取到明文卡密（凭订单 token）', dv.json.order.deliveryView)
const rec1 = await call('/api/pay/receive', { method: 'POST', body: { token: e1.token } })
ok(rec1.json.order.stage === 'settled', '买家确认收货 → settled（自动转款到户）', rec1.json.order.stage)
const st2 = await stats()
ok(st2.escrow === s0.escrow && st2.balance === s0.balance + 15000, '转款到户：托管清零、可用余额 +15000（账实相符）', { escrow: st2.escrow, balance: st2.balance })
const e1after = await order(e1.orderId)
ok(e1after.settleAmount === 15000 && e1after.settleNet === 15000, '订单记录结算金额与净额（费率为 0）', { amt: e1after.settleAmount, net: e1after.settleNet })

/* ------------------------------------------------------------------ 电商：物流 */
section('电商闭环 · 物流：自动发货（物流单号）→ 收货 → 转款')
const lg = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 8000, scene: 'ecommerce', subject: '实物', delivery: { type: 'logistics', trackingNo: 'MM123456789' } } })).json.order
await pay(lg)
const lgPaid = await order(lg.orderId)
ok(lgPaid.stage === 'delivered' && lgPaid.delivery.trackingNo === 'MM123456789', '物流订单到账即自动发货（含物流单号）', { stage: lgPaid.stage, no: lgPaid.delivery && lgPaid.delivery.trackingNo })
await call('/api/pay/receive', { method: 'POST', body: { token: lg.token } })
ok((await order(lg.orderId)).stage === 'settled', '物流订单收货后转款到户')

/* ------------------------------------------------------------------ 游戏闭环（发币回执） */
section('游戏闭环 · 平台无文档接入 → 到账 → 发币回执 → 自动收货转款')
const adp = (await call('/api/adapters', { method: 'POST', token: tokenM, body: { name: '游戏平台', platform: 'game', mode: 'api', targetUrl: CB_URL } })).json.adapter
ok(!!adp.id && !!adp.gameCallbackUrl, '游戏平台适配器创建（含游戏发货回执入口）', { id: adp.id, url: adp.gameCallbackUrl })
const ADPSECRET = adp.signSecretPlain
const g1 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 20000, scene: 'game', adapterId: adp.id, gameAccount: 'player001', gameRole: '勇者', gameZone: 's1', itemCode: 'diamond_100', quantity: 1 } })).json.order
ok(g1.scene === 'game' && g1.grantStatus === 'waiting' && g1.gameAccount === 'player001', '游戏下单：记录游戏账号映射，发币状态 waiting', { scene: g1.scene, grant: g1.grantStatus })
await pay(g1)
const g1paid = await order(g1.orderId)
ok(g1paid.status === 'paid' && g1paid.stage === 'delivered', '游戏订单到账自动发货（待平台发币）', { status: g1paid.status, stage: g1paid.stage })
const gRaw = JSON.stringify({ orderId: g1.orderId, action: 'grant', ok: true, txid: 'GAME90001' })
const gcb = await call('/api/game/callback/' + adp.id, { method: 'POST', headers: { 'X-Signature': await hmacHex(ADPSECRET, gRaw) }, body: gRaw })
ok(gcb.json.ok === true && gcb.json.grantStatus === 'granted' && gcb.json.stage === 'settled', '平台发币回执后：granted 且自动收货转款到户（settled）', gcb.json)
const g1after = await order(g1.orderId)
ok(g1after.grantTxid === 'GAME90001' && g1after.stage === 'settled', '游戏订单留存发币流水号并完成结算', { txid: g1after.grantTxid, stage: g1after.stage })

/* ------------------------------------------------------------------ 游戏：买家自助收货 */
section('游戏闭环 · 无平台回执时，买家自助确认收货')
const g2 = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 12000, scene: 'game', gameAccount: 'player002', itemCode: 'vip_30d' } })).json.order
await pay(g2)
const g2me = await call('/api/pay/receive', { method: 'POST', body: { token: g2.token } })
ok(g2me.json.order.stage === 'settled', '游戏订单到账后买家自助确认收货即转款到户')

/* ------------------------------------------------------------------ 非托管场景 */
section('非托管场景 · manual 直接入账（不进托管）')
const man = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 5000, scene: 'manual', subject: '线下收款' } })).json.order
ok(man.escrow === false, 'manual 订单不进入托管（escrow=false）', man.escrow)
const sb = await stats()
await pay(man)
const manAfter = await order(man.orderId)
ok(manAfter.status === 'paid' && manAfter.stage === 'settled', '到账即 settled（无需收货）', { status: manAfter.status, stage: manAfter.stage })
const sa = await stats()
ok(sa.balance === sb.balance + 5000 && sa.escrow === sb.escrow, '非托管订单直接进可用余额（balance +5000）', { balance: sa.balance, escrow: sa.escrow })

/* ------------------------------------------------------------------ 托管退款 */
section('托管订单退款：从托管余额原路退回')
const rf = (await call('/api/orders', { method: 'POST', token: tokenM, body: { amount: 9000, scene: 'ecommerce', subject: '退款用例', delivery: { type: 'card', cardSecret: 'CARD-REFUND' } } })).json.order
await pay(rf)
const sr = await stats()
ok(sr.escrow >= 9000, '退款前：托管中含该笔 9000', { escrow: sr.escrow })
const rfr = await call('/api/orders/' + rf.orderId + '/refund', { method: 'POST', token: tokenM, body: { reason: '用例退款' } })
ok(rfr.json.order.stage === 'refunded', '托管订单可退款至 refunded', rfr.json.order.stage)
const sr2 = await stats()
ok(sr2.escrow === sr.escrow - 9000, '退款从托管余额扣回（escrow -9000），不影响可用余额', { escrow: sr2.escrow })

/* ------------------------------------------------------------------ 越权与一致性 */
section('归属与状态一致性校验')
ok((await call('/api/orders/' + e1.orderId + '/receive', { method: 'POST', token: tokenA, body: {} })).status === 200, '上级代理可代确认下级订单收货（可见范围）')
const dupBefore = await stats()
const dupR = await call('/api/pay/receive', { method: 'POST', body: { token: e1.token } })
const dupStat = await stats()
ok(dupR.json.order.stage === 'settled' && dupStat.balance === dupBefore.balance, '重复收货幂等：返回成功但不重复入账（余额不变）', { stage: dupR.json.order.stage, before: dupBefore.balance, after: dupStat.balance })

cbServer.close()
console.log('\n============================================================')
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
if (failures.length) { console.log('\n失败明细：'); failures.forEach(f => console.log(' - ' + f)); process.exit(1) }
console.log('T1 定向验证全部通过 \u2714')
process.exit(0)