/**
 * T10 定向验证：业务闭环补齐 + 安全加固（逐项可跑通，含成功与失败路径）
 * ---------------------------------------------------------------------------
 * 覆盖：
 *   A. 页面结构：新增「维护与对账」「安全会话」两页 + 会话与错误策略配置项
 *   B. 维护与对账接口：超管可用（200）、代理一律 403；状态面板字段齐备
 *   C. 订单超时自动关闭：占用识别码 → 到期 →维护任务关闭 → 释放识别码 → 幂等
 *   D. 代理租用金逾期 → 业务闸门实际生效（下单 / 出款 / 游戏上下分 / 下级商户）
 *      且「缴纳类」场景不受限（防死锁），缴清后自动恢复
 *   E. 强制改密闸门：关闭时放行 / 开启时 428（白名单例外）/ 改密后恢复
 *   F. 对账未匹配流水：落库脱敏（明文账号不落库）→ 列表 → 人工核销 → 重复 409 /
 *      非法交易号 400 / 未知流水 404 / 同交易号二次上报自动销账
 *   G. 安全会话：本人可查 / 超管代查 / 跨账号查询 404 / 撤销后令牌立即失效 / 超管可撤他人
 *   H. CORS 收紧：公开接入面 `*`，携带登录态的跨站来源不回 ACAO，同源才回显；安全响应头齐备
 *   I. 审计链验真：代理 403、超管 200 且链路完整、被篡改后立刻暴露
 *   J. 5xx 错误脱敏：默认只回关联号（真实原因写审计），开关打开后才回原文
 *   K. 登录失败锁定：达到上限按「账号 + 来源 IP」锁定并返回 429
 *   L. 设置白名单：新增安全键可写入生效，未登记键被忽略
 *   M. 接入面加固：公开入口按「入口 + 来源 IP」限流（密钥枚举 / 登录喷洒）、
 *      请求体体积上限、单次批量条数上限、列表条数夹取、超长 token 截断、凭据不外泄
 * 运行：node test/verify-t10.mjs   （仅本地校验，随交付物一并发布）
 */
import vm from 'node:vm'
import { createMemoryKV } from '../lib/memory-kv.mjs'
import { handleRequest } from '../src/api.js'
import { CONSOLE_PAGE } from '../src/pages.js'

if (!globalThis.crypto || !globalThis.crypto.subtle) {
  const { webcrypto } = await import('node:crypto')
  globalThis.crypto = webcrypto
}

let passed = 0
const failures = []
function ok(cond, label, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + label) }
  else { failures.push(label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + label + (extra ? ' \u2192 ' + JSON.stringify(extra) : '')) }
}
function section(t) { console.log('\n== ' + t + ' ==') }

const ENV = { KBZ_GATEWAY: createMemoryKV(), ALLOW_COUNTRIES: 'MM', DEVICE_KEY: 't10-device-key-0001' }
const CTX = { waitUntil: (p) => { Promise.resolve(p).catch(() => {}) } }
const kvGet = (k) => ENV.KBZ_GATEWAY.get(k, { type: 'json' })
const kvRaw = (k) => ENV.KBZ_GATEWAY.get(k, { type: 'text' })

async function call(path, opt = {}) {
  const headers = Object.assign({ 'cf-ipcountry': 'MM', 'content-type': 'application/json' }, opt.headers || {})
  if (opt.token) headers['Authorization'] = 'Bearer ' + opt.token
  const init = { method: opt.method || 'GET', headers }
  if (opt.body !== undefined) init.body = typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)
  const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
  const text = await res.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: res.status, json, text, headers: res.headers }
}
async function login(username, password, headers) {
  const r = await call('/api/auth/login', { method: 'POST', body: { username, password }, headers: headers })
  return r.json && r.json.token
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

/* ------------------------------------------------------------------ 迷你 DOM + 沙箱（与 T9 同规格） */
function makeEl() {
  return {
    _html: '', _text: '', className: '', value: '', files: [], style: {}, children: [],
    addEventListener() {}, appendChild(c) { this.children.push(c) }, remove() {}, querySelector() { return null },
    get innerHTML() { return this._html }, set innerHTML(v) { this._html = String(v) },
    get textContent() { return this._text }, set textContent(v) { this._text = String(v) },
  }
}
function makeUI(token, opts = {}) {
  const els = {}
  const body = makeEl()
  const document = {
    domain: 'gw.example.com', body: body,
    getElementById(id) { if (!els[id]) els[id] = makeEl(); return els[id] },
    createElement() { return makeEl() },
  }
  const store = { kbz_token: token }
  const localStorage = {
    getItem(k) { return Object.prototype.hasOwnProperty.call(store, k) ? store[k] : null },
    setItem(k, v) { store[k] = String(v) },
    removeItem(k) { delete store[k] },
  }
  const prompts = []
  const alerts = []
  const location = { origin: 'https://gw.example.com', href: '', reload() {}, search: '' }
  const sandbox = {
    document, localStorage, location, console,
    navigator: { clipboard: { writeText() {} }, userAgent: 'node' },
    setTimeout: globalThis.setTimeout.bind(globalThis), clearTimeout: globalThis.clearTimeout.bind(globalThis),
    setInterval: globalThis.setInterval.bind(globalThis), clearInterval: globalThis.clearInterval.bind(globalThis),
    prompt: () => (prompts.length ? prompts.shift() : null),
    confirm: () => (opts.confirm === undefined ? true : opts.confirm),
    alert: (m) => { alerts.push(String(m)) },
    fetch: async (path, o) => {
      o = o || {}
      const headers = Object.assign({ 'cf-ipcountry': 'MM' }, o.headers || {})
      const init = { method: o.method || 'GET', headers }
      if (o.body !== undefined) init.body = o.body
      const res = await handleRequest(new Request('https://gw.example.com' + path, init), ENV, CTX)
      return { status: res.status, json: () => res.json(), text: () => res.text() }
    },
  }
  const ctx = vm.createContext(sandbox)
  const html = CONSOLE_PAGE({ gatewayName: 'Test' }, {})
  const code = html.match(/<script>([\s\S]*)<\/script>/)[1]
  vm.runInContext(code, ctx)
  return {
    ctx, view: () => els['view'], body, alerts,
    getEl: (id) => document.getElementById(id),
    setPrompts: (arr) => { prompts.length = 0; arr.forEach((x) => prompts.push(x)) },
    toastText: () => body.children.map((c) => String(c.textContent)).join(' | '),
  }
}
const flush = () => new Promise((r) => setTimeout(r, 60))

/* ================================================================== 用例 */
section('准备：超管设密 → 代理 A / 代理 D → 商户 C → 资金池 → 收款通道')
await call('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'MyUnique@2026', confirm: 'MyUnique@2026' } })
const tokenSuper = await login('superadmin', 'MyUnique@2026')
const agentA = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_a', password: 'AgentA@12345', name: '代理A', depositRequired: 0 } })).json.account
const agentD = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'agent', username: 'agent_d', password: 'AgentD@12345', name: '代理D', depositRequired: 1000000 } })).json.account
const tokenA = await login('agent_a', 'AgentA@12345')
const tokenD = await login('agent_d', 'AgentD@12345')
// 商户由「所属代理」创建：归属链 = 超管 → 代理 → 商户（三级隔离与逾期连带的真实路径）
const merchantC = (await call('/api/accounts', { method: 'POST', token: tokenA, body: { role: 'merchant', username: 'shop_c', password: 'ShopC@123456', name: '商户C' } })).json.account
const tokenC = await login('shop_c', 'ShopC@123456')
ok(!!merchantC && merchantC.parentId === agentA.id, '商户归属链正确（超管 → 代理A → 商户C）', merchantC && merchantC.parentId)
await call('/api/pool/accounts', { method: 'POST', token: tokenSuper, body: { accounts: [{ account: '09970000111', holder: '资金池' }] } })
const chA = (await call('/api/channels', { method: 'POST', token: tokenA, body: { account: '09971000101', holder: '代理A', flow: 'receive', primary: true } })).json.channel
const chC = (await call('/api/channels', { method: 'POST', token: tokenC, body: { account: '09970000888', holder: '商户C', flow: 'receive', primary: true } })).json.channel
ok(!!agentA && !!agentD && !!merchantC && !!tokenA && !!tokenD && !!tokenC && !!chA && !!chC, '环境就绪：三级账号 + 资金池 + 两条收款通道')

/* ---------------------------------------------------------- A. 页面结构 */
section('A. 页面结构：维护与对账 / 安全会话 两页 + 会话与错误策略配置项')
const pageHtml = CONSOLE_PAGE({ gatewayName: 'Test' }, {})
for (const k of ['maintenance', 'security']) {
  ok(new RegExp('VIEWS\\.' + k + '\\s*=').test(pageHtml), '脚本定义了 VIEWS.' + k)
}
const mustHave = ['维护与对账', '安全会话', 'runMaintenanceNow()', 'applyMtFilter()', 'mtStatusTag',
  'verifyChainNow()', 'revokeOtherSessions()', 'secLoadUser()', '会话与错误策略', 's_sess', 's_lockmax', 's_locksec', 's_expose']
for (const needle of mustHave) ok(pageHtml.includes(needle), '页面含关键要素：' + needle)
const uiS = makeUI(tokenSuper)
await flush()
ok(!!uiS.ctx.ME && uiS.ctx.ME.role === 'super', '超管登录后 ME.role=super')
await uiS.ctx.VIEWS.settings()
const setHtml = uiS.view().innerHTML
ok(setHtml.includes('id="s_sess"') && setHtml.includes('id="s_lockmax"') && setHtml.includes('id="s_locksec"') && setHtml.includes('id="s_expose"'),
  '系统设置页含「会话与错误策略」四个配置项')
ok(setHtml.includes('saveSettings()'), '会话策略带保存按钮')
const gv = (id) => { const m = new RegExp('id="' + id + '"[^>]*value="([^"]*)"').exec(setHtml); return m ? m[1] : '' }
ok(gv('s_sess') === '43200' && gv('s_lockmax') === '6' && gv('s_locksec') === '900',
  '配置项真实回填超管当前值（会话有效期 43200 / 登录失败上限 6 / 锁定时长 900）',
  { sess: gv('s_sess'), lockmax: gv('s_lockmax'), locksec: gv('s_locksec') })
ok(gv('s_expose') === 'false', '错误详情开关回填当前布尔态（默认 false）', { v: gv('s_expose') })

/* ---------------------------------------------------------- B. 维护与对账接口 */
section('B. 维护与对账：仅超管可用，代理一律 403；状态面板字段齐备')
ok((await call('/api/maintenance/status', { token: tokenA })).status === 403, '代理查看维护状态被拒（403）')
ok((await call('/api/maintenance/status')).status === 401, '匿名查看维护状态被拒（401）')
ok((await call('/api/maintenance/run', { method: 'POST', token: tokenA, body: {} })).status === 403, '代理触发维护任务被拒（403）')
ok((await call('/api/reconcile/unmatched', { token: tokenC })).status === 403, '商户查看未匹配流水被拒（403）')
const st0 = await call('/api/maintenance/status', { token: tokenSuper })
ok(st0.status === 200 && !!st0.json.orders && !!st0.json.webhooks && !!st0.json.unmatchedFlows && !!st0.json.rentals,
  '超管查看维护状态成功且四大板块齐备')
ok(typeof st0.json.orders.pending === 'number' && typeof st0.json.orders.expiredWaitingSweep === 'number'
  && typeof st0.json.orders.autoReceiveDue === 'number' && typeof st0.json.webhooks.pending === 'number'
  && typeof st0.json.unmatchedFlows.open === 'number' && typeof st0.json.rentals.agents === 'number',
  '状态面板计数项类型正确（待支付 / 过期待关闭 / 到点收货 / 待重试回调 / 未匹配 / 代理数）')
ok(String(st0.json.nextCronHint || '').includes('crons') && String(st0.json.nextCronHint).includes('立即执行'),
  '状态面板给出定时任务与手动执行说明')

/* ---------------------------------------------------------- C. 订单超时自动关闭 */
section('C. 订单超时自动关闭：占用识别码 → 到期 → 关闭 → 释放识别码（幂等）')
const sweep0 = st0.json.orders.expiredWaitingSweep
const ordT = (await call('/api/orders', { method: 'POST', token: tokenC, body: { scene: 'ecommerce', amount: 120000, subject: '超时测试单', ttlSec: 1 } })).json.order
ok(!!ordT && ordT.status === 'pending', '下单成功且状态为待付款')
ok(ordT.tailCode !== undefined && ordT.tailCode === ordT.tailorCode && ordT.tailCode === ordT.payable % 1000,
  '订单识别码同时以 tailorCode / tailCode 两个字段名给出（无文档接入按任一字段取用）',
  { tailorCode: ordT.tailorCode, tailCode: ordT.tailCode, payable: ordT.payable })
const tailKey = 'tail:' + chC.id + ':' + (ordT.payable % 1000)
ok((await kvGet(tailKey)) !== null, '下单后金额识别码被占用（tail:' + (ordT.payable % 1000) + '）')
await sleep(1200)
const st1 = await call('/api/maintenance/status', { token: tokenSuper })
ok(st1.json.orders.expiredWaitingSweep === sweep0 + 1, '到期后进入「已过期待关闭」统计', { before: sweep0, now: st1.json.orders.expiredWaitingSweep })
const run1 = await call('/api/maintenance/run', { method: 'POST', token: tokenSuper, body: { limit: 500 } })
ok(run1.status === 200 && !!run1.json.tasks && !!run1.json.tasks.expireOrders && !!run1.json.tasks.autoReceive && !!run1.json.tasks.webhooks,
  '维护任务返回三类子任务结果（超时关闭 / 自动收货 / 回调重试）')
ok(run1.json.tasks.expireOrders.expiredClosed >= 1, '维护任务实际关闭了超时订单', run1.json.tasks.expireOrders)
const ordT2 = await call('/api/orders/' + ordT.orderId, { token: tokenC })
ok(ordT2.json.order.status === 'closed' && ordT2.json.order.stageText === '已关闭', '超时订单持久化为「已关闭」', { s: ordT2.json.order.status, t: ordT2.json.order.stageText })
ok((await kvGet(tailKey)) === null, '关闭后金额识别码已释放（tail 键被删除）')
const st2 = await call('/api/maintenance/status', { token: tokenSuper })
ok(st2.json.orders.expiredWaitingSweep === sweep0, '已过期待关闭计数归零', { v: st2.json.orders.expiredWaitingSweep })
const run2 = await call('/api/maintenance/run', { method: 'POST', token: tokenSuper, body: { limit: 500 } })
ok(run2.json.tasks.expireOrders.expiredClosed === 0, '维护任务幂等：重复执行不再关闭订单')
const auditLogs = (await call('/api/audit?limit=200', { token: tokenSuper })).json.logs
ok(auditLogs.some((l) => l.action === 'order.expire' && l.detail && l.detail.orderId === ordT.orderId), '超时关闭写入审计（order.expire）')
ok(auditLogs.some((l) => l.action === 'maintenance.run'), '维护任务执行写入审计（maintenance.run）')

/* ---------------------------------------------------------- D. 租用金逾期闸门 */
section('D. 代理租用金逾期 → 业务闸门实际生效 + 补救类不受限 + 缴清后自动恢复')
// 预置：租用起算日远早于本期 → 本期已过到期日与宽限期未缴
for (const id of [agentA.id, agentD.id]) {
  const u = await kvGet('user:' + id)
  u.rentalStartAt = '2020-01-01T00:00:00.000Z'
  await ENV.KBZ_GATEWAY.put('user:' + id, u)
}
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { rentalDueDay: 1, rentalGraceDays: 0, rentalOverdueAction: 'restrict', rentalFeeMonthly: 200000 } })
const board = (await call('/api/rental-board', { token: tokenSuper })).json
const period = board.period
ok(/^\d{4}-\d{2}$/.test(period), '代理表给出本期周期', { period })
const rowA = board.rows.find((r) => r.agentId === agentA.id)
ok(!!rowA && rowA.status === 'overdue', '租用金逾期 → 代理表状态为「已逾期未缴」', rowA && rowA.status)
ok(rowA.periodPaid === false && rowA.graceDays === 0, '逾期行口径正确（本期未缴 + 无宽限）')
ok((await call('/api/game/ids', { method: 'POST', token: tokenA, body: { gameId: 't10_gamer_001' } })).status === 200, '登记游戏充值ID 不受逾期闸门阻挡（允许准备）')
const oOverdue = await call('/api/orders', { method: 'POST', token: tokenA, body: { scene: 'ecommerce', amount: 50000 } })
ok(oOverdue.status === 403 && oOverdue.json.detail && oOverdue.json.detail.code === 'RENTAL_OVERDUE', '逾期代理下单被拒（403 RENTAL_OVERDUE）', oOverdue.json)
const pOverdue = await call('/api/payouts', { method: 'POST', token: tokenA, body: { account: '09971000102', amount: 5000 } })
ok(pOverdue.status === 403 && pOverdue.json.detail && pOverdue.json.detail.code === 'RENTAL_OVERDUE', '逾期代理出款被拒（403 RENTAL_OVERDUE）', pOverdue.json)
const gOverdue = await call('/api/game/orders', { method: 'POST', token: tokenA, body: { direction: 'in', amount: 1000, gameId: 't10_gamer_001' } })
ok(gOverdue.status === 403 && gOverdue.json.detail && gOverdue.json.detail.code === 'RENTAL_OVERDUE', '逾期代理游戏上分被拒（403 RENTAL_OVERDUE）', gOverdue.json)
const mOverdue = await call('/api/orders', { method: 'POST', token: tokenC, body: { scene: 'ecommerce', amount: 30000 } })
ok(mOverdue.status === 403 && mOverdue.json.detail && mOverdue.json.detail.code === 'RENTAL_OVERDUE' && mOverdue.json.detail.agentId === agentA.id,
  '上级代理逾期 → 下级商户下单同步受限（403 且指向该代理）', mOverdue.json)
// 补救类场景不受限（否则无法补缴 → 死锁）
const oRemedy = await call('/api/orders', { method: 'POST', token: tokenD, body: { scene: 'deposit', amount: 300000 } })
ok(oRemedy.status === 200 && oRemedy.json.order.status === 'pending', '「缴纳保证金」类订单不受限（防死锁）', { s: oRemedy.status })
const oD = await call('/api/orders', { method: 'POST', token: tokenD, body: { scene: 'ecommerce', amount: 30000 } })
ok(oD.status === 403 && oD.json.detail && oD.json.detail.code === 'DEPOSIT_INSUFFICIENT', '保证金不足代理下单被拒（403 DEPOSIT_INSUFFICIENT，先于逾期判定）', oD.json)
// 缴清本期租用金 → 自动恢复
const payRent = await call('/api/pool/rental', { method: 'POST', token: tokenSuper, body: { agentId: agentA.id, amount: 200000, period: period } })
ok(payRent.status === 200 && payRent.json.rental.period === period, '超管代记本期租用金成功', payRent.json)
const board2 = (await call('/api/rental-board', { token: tokenSuper })).json
ok(board2.rows.find((r) => r.agentId === agentA.id).status === 'normal', '缴清后代理表状态恢复「正常缴费」')
const oRecover = await call('/api/orders', { method: 'POST', token: tokenA, body: { scene: 'ecommerce', amount: 50000 } })
ok(oRecover.status === 200, '缴清后代理下单自动恢复（200）', { s: oRecover.status })
const mRecover = await call('/api/orders', { method: 'POST', token: tokenC, body: { scene: 'ecommerce', amount: 30000 } })
ok(mRecover.status === 200, '缴清后下级商户同步恢复（200）', { s: mRecover.status })
const gRecover = await call('/api/game/orders', { method: 'POST', token: tokenA, body: { direction: 'in', amount: 1000, gameId: 't10_gamer_001' } })
ok(gRecover.status === 200, '缴清后游戏上分同步恢复（200）', { s: gRecover.status })

/* ---------------------------------------------------------- E. 强制改密闸门 */
section('E. 强制改密闸门：默认关闭 / 开启后 428（白名单例外）/ 改密后恢复')
const uiP = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'merchant', username: 'pwd_user', password: 'PwdUser@12345', name: '改密测试', parentId: agentA.id } })).json.account
const tokenP = await login('pwd_user', 'PwdUser@12345')
ok(!!tokenP, '新建账号可登录')
ok((await call('/api/orders', { token: tokenP })).status === 200, '强制改密默认关闭：未改密也能正常用接口（避免批量账号被整体阻断）')
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { enforcePasswordChange: true } })
const blocked = await call('/api/orders', { token: tokenP })
ok(blocked.status === 428 && blocked.json.detail && blocked.json.detail.code === 'PASSWORD_CHANGE_REQUIRED', '开启后未改密调用业务接口被拦（428）', blocked.json)
ok((await call('/api/auth/me', { token: tokenP })).status === 200, '白名单例外：/api/auth/me 仍可访问')
ok((await call('/api/overview', { token: tokenP })).status === 200, '白名单例外：/api/overview 仍可访问')
ok((await call('/api/me/password', { method: 'POST', token: tokenP, body: { oldPassword: 'wrong-one', password: 'NewPwd@2026' } })).status === 401, '改密时原密码错误被拒（401）')
const chPwd = await call('/api/me/password', { method: 'POST', token: tokenP, body: { oldPassword: 'PwdUser@12345', password: 'NewPwd@2026' } })
ok(chPwd.status === 200, '改密成功')
ok((await call('/api/orders', { token: tokenP })).status === 200, '改密后闸门解除（200）')
ok((await call('/api/auth/login', { method: 'POST', body: { username: 'pwd_user', password: 'PwdUser@12345' } })).status === 401, '旧密码失效（401）')
const relog = await login('pwd_user', 'NewPwd@2026')
ok(!!relog, '新密码可登录')
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { enforcePasswordChange: false } })
void uiP

/* ---------------------------------------------------------- F. 对账未匹配流水 */
section('F. 对账未匹配流水：落库脱敏 → 人工核销 → 异常路径 → 自动销账')
const ordP = (await call('/api/orders', { method: 'POST', token: tokenC, body: { scene: 'ecommerce', amount: 900000, subject: '人工核销目标单' } })).json.order
const busy = new Set([ordP.payable % 1000])
function pickAmount(base) {
  for (let d = 0; d < 1000; d++) { const amt = base + d; if (!busy.has(amt % 1000)) { busy.add(amt % 1000); return amt } }
  return base
}
const amt1 = pickAmount(950000), amt2 = pickAmount(960000), amt3 = pickAmount(970000)
async function ingest(rows) {
  return await call('/api/reconcile/ingest', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { rows: rows } })
}
const ing = await ingest([
  { receiverAccount: '09970000888', amount: amt1, time: '2026-10-23 09:10:00', source: 'reconcile', txid: 'T10RC0001' },
  { receiverAccount: '09970000888', amount: amt2, time: '2026-10-23 09:11:00', source: 'reconcile', txid: 'T10RC0002' },
  { receiverAccount: '09970000888', amount: amt3, time: '2026-10-23 09:12:00', source: 'reconcile', txid: 'T10RC0003' },
])
ok(ing.status === 200 && ing.json.unmatched === 3, '三笔到账（无对应待支付订单）全部落到未匹配台账', { u: ing.json && ing.json.unmatched })
const umList = await call('/api/reconcile/unmatched?status=open', { token: tokenSuper })
ok(umList.status === 200 && umList.json.count >= 3, '超管可查看未匹配流水列表', { c: umList.json && umList.json.count })
const r1 = umList.json.rows.find((x) => x.txnId === 'T10RC0001')
const r2 = umList.json.rows.find((x) => x.txnId === 'T10RC0002')
const r3 = umList.json.rows.find((x) => x.txnId === 'T10RC0003')
ok(!!r1 && !!r2 && !!r3 && r1.status === 'open', '三笔流水均可见且状态为「待核销」')
ok(!!r1 && !!r1.account && r1.account.includes('*') && !r1.account.includes('09970000888'), '台账只存脱敏账号，明文收款账号不落库', r1 && r1.account)
ok(!!r1 && r1.seenCount === 1, '首次落库重复上报次数为 1')
// 未指定订单时按金额自动找待支付订单
const noOrder = await call('/api/reconcile/' + encodeURIComponent(r2.id) + '/match', { method: 'POST', token: tokenSuper, body: { txid: '99990001', amount: 12345 } })
ok(noOrder.status === 404, '未指定订单且金额无匹配时给出 404 提示', { s: noOrder.status, e: noOrder.json && noOrder.json.error })
// 人工核销到显式订单
const matched = await call('/api/reconcile/' + encodeURIComponent(r1.id) + '/match', { method: 'POST', token: tokenSuper, body: { orderId: ordP.orderId, txid: '1234567890', amount: ordP.payable } })
ok(matched.status === 200 && matched.json.record.status === 'matched' && matched.json.record.matchedOrderId === ordP.orderId,
  '人工核销成功：台账置为已核销并落到指定订单', { s: matched.status, r: matched.json.record && matched.json.record.status })
ok((await call('/api/orders/' + ordP.orderId, { token: tokenC })).json.order.status === 'paid', '被核销订单实际入账（status=paid）')
const dup = await call('/api/reconcile/' + encodeURIComponent(r1.id) + '/match', { method: 'POST', token: tokenSuper, body: { orderId: ordP.orderId, txid: '1234567890', amount: ordP.payable } })
ok(dup.status === 409, '重复核销同一笔流水被拒（409）')
const badTxid = await call('/api/reconcile/' + encodeURIComponent(r2.id) + '/match', { method: 'POST', token: tokenSuper, body: { orderId: ordP.orderId, txid: 'abc' } })
ok(badTxid.status === 400 && String(badTxid.json.error).includes('交易号'), '非法交易号被拒（400，需至少 5 位数字）', badTxid.json)
const unknownId = await call('/api/reconcile/deadbeefdeadbeefdeadbeef/match', { method: 'POST', token: tokenSuper, body: { orderId: ordP.orderId, txid: '1234567' } })
ok(unknownId.status === 404, '核销不存在的流水被拒（404）')
const auditMatch = (await call('/api/audit?limit=200', { token: tokenSuper })).json.logs
ok(auditMatch.some((l) => l.action === 'reconcile.match'), '人工核销写入审计（reconcile.match）')
// 同交易号二次上报命中真实订单 → 自动销账
const ordAuto = (await call('/api/orders', { method: 'POST', token: tokenC, body: { scene: 'ecommerce', amount: amt3, subject: '自动销账目标单' } })).json.order
const ingAuto = await ingest([{ receiverAccount: '09970000888', amount: ordAuto.payable, time: '2026-10-23 09:20:00', source: 'reconcile', txid: 'T10RC0003' }])
ok(ingAuto.status === 200 && ingAuto.json.paid === 1, '补齐尾码后同交易号到账被自动匹配入账', { p: ingAuto.json && ingAuto.json.paid })
const umList2 = await call('/api/reconcile/unmatched', { token: tokenSuper })
const r3b = umList2.json.rows.find((x) => x.txnId === 'T10RC0003')
ok(!!r3b && r3b.status === 'auto-closed' && r3b.matchedOrderId === ordAuto.orderId,
  '原未匹配台账自动销账（auto-closed 且记录命中订单）', r3b && { s: r3b.status, o: r3b.matchedOrderId })
const stAfter = (await call('/api/maintenance/status', { token: tokenSuper })).json
const openRows = umList2.json.rows.filter((x) => x.status === 'open').length
ok(stAfter.unmatchedFlows.open === openRows, '维护面板「未匹配流水」计数与台账一致', { panel: stAfter.unmatchedFlows.open, list: openRows })
// 对账执行端可查询维护面板之外的动作：未匹配流水不因人工核销而丢失订单关联
ok((await call('/api/orders/' + ordAuto.orderId, { token: tokenC })).json.order.status === 'paid', '自动销账对应的订单已入账（paid）')

/* ---------------------------------------------------------- G. 安全会话 */
section('G. 安全会话：本人可查 / 超管代查 / 越权 404 / 撤销后立即失效')
const secS = await call('/api/security/sessions', { token: tokenSuper })
ok(secS.status === 200 && secS.json.sessions.length >= 1 && secS.json.sessions.some((s) => s.isCurrent), '超管可查看自己的会话且标记当前会话')
ok(secS.json.sessions.every((s) => !!s.tokenMasked), '会话列表给出去敏摘要（不以完整明文令牌作为列表标识）')
const secA = await call('/api/security/sessions', { token: tokenA })
ok(secA.status === 200 && secA.json.sessions.length >= 1, '代理可查看自己的会话')
const tokenA2 = await login('agent_a', 'AgentA@12345')
const secA2 = await call('/api/security/sessions', { token: tokenA })
ok(secA2.json.sessions.length === secA.json.sessions.length + 1, '二次登录后会话数 +1（每次登录一个会话）')
const cross = await call('/api/security/sessions?userId=' + agentD.id, { token: tokenA })
ok(cross.status === 404, '代理查询他人账号会话被拒（404，不泄露存在性）')
const superLook = await call('/api/security/sessions?userId=' + agentA.id, { token: tokenSuper })
ok(superLook.status === 200 && superLook.json.sessions.length >= 2, '超管可代查指定账号的会话')
const other = secA2.json.sessions.find((s) => !s.isCurrent)
ok(!!other && !!other.token, '本人会话列表回传可撤销的完整标识')
const rv = await call('/api/security/sessions/revoke', { method: 'POST', token: tokenA, body: { token: other.token } })
ok(rv.status === 200 && rv.json.revoked === true, '本人可撤销自己的会话')
ok((await call('/api/overview', { token: tokenA2 })).status === 401, '被撤销的会话令牌立即失效（401）')
ok((await call('/api/security/sessions/revoke', { method: 'POST', token: tokenA, body: { token: 'nope-nope-nope' } })).status === 404, '撤销不存在的会话被拒（404）')
ok((await call('/api/security/sessions/revoke', { method: 'POST', token: tokenA, body: {} })).status === 400, '缺少会话标识被拒（400）')
// 超管代撤他人会话：代理另开一个会话，超管撤掉它并验证立即失效
const tokenA3 = await login('agent_a', 'AgentA@12345')
ok(!!tokenA3, '代理重新登录成功')
const secSuper = (await call('/api/security/sessions?userId=' + agentA.id, { token: tokenSuper })).json
ok(secSuper.sessions.length >= 2, '超管可代查指定账号的全部会话')
const target = secSuper.sessions.find((s) => s.token !== tokenA3)
ok(!!target && !!target.token, '超管代查时回传完整会话标识（便于精确撤销）')
const revokeOther = await call('/api/security/sessions/revoke', { method: 'POST', token: tokenSuper, body: { token: target.token } })
ok(revokeOther.status === 200 && revokeOther.json.revoked === true, '超管可撤销他人会话')
ok((await call('/api/overview', { token: target.token })).status === 401, '被超管撤销的会话立即失效（401）')
ok((await call('/api/overview', { token: tokenA3 })).status === 200, '撤销只影响目标会话，其他有效会话不受影响（200）')
// 来源 IP 只留哈希：带真实 IP 登录后，会话记录应是哈希而非明文地址
const tokenIp = await login('agent_a', 'AgentA@12345', { 'CF-Connecting-IP': '203.0.113.7' })
const secIp = (await call('/api/security/sessions', { token: tokenIp })).json
const curIp = secIp.sessions.find((s) => s.isCurrent)
ok(!!curIp && String(curIp.ipHash).length > 0 && !String(curIp.ipHash).includes('203.0.113.7'),
  '会话记录只保存来源 IP 哈希（不落明文地址）', curIp && curIp.ipHash)
const ipR = await call('/api/security/ip', { token: tokenA3, headers: { 'CF-Connecting-IP': '203.0.113.7' } })
ok(ipR.status === 200 && ipR.json.ipHash && !String(ipR.json.ipHash).includes('203.0.113.7'), 'IP 查询只回哈希，不回原始地址', ipR.json)

/* ---------------------------------------------------------- H. CORS 收紧与安全响应头 */
section('H. CORS 收紧：公开面 `*`、携带登录态跨站不回 ACAO、同源回显；安全响应头齐备')
const pubCors = await call('/api/config', { headers: { Origin: 'https://evil.example.com' } })
ok(pubCors.headers.get('Access-Control-Allow-Origin') === '*', '公开接入面（无登录态）保持 *（任意平台可直接调用）')
const evilCors = await call('/api/overview', { token: tokenA3, headers: { Origin: 'https://evil.example.com' } })
ok(evilCors.headers.get('Access-Control-Allow-Origin') === null, '携带 Bearer 的跨站请求不回 ACAO（浏览器读不到响应体）')
ok(evilCors.headers.get('Vary') === 'Origin', '响应带 Vary: Origin（避免缓存串用）')
const sameCors = await call('/api/overview', { token: tokenA3, headers: { Origin: 'https://gw.example.com' } })
ok(sameCors.headers.get('Access-Control-Allow-Origin') === 'https://gw.example.com', '同源请求回显该来源（后台可正常调用）')
const qCors = await call('/api/overview?token=' + tokenA3, { headers: { Origin: 'https://evil.example.com' } })
ok(qCors.status === 200 && qCors.headers.get('Access-Control-Allow-Origin') === null, '登录态经由 ?token= 传递时同样按已登录面处理（不回 ACAO）')
const cookieCors = await call('/api/overview', { headers: { Origin: 'https://evil.example.com', Cookie: 'kbz_token=' + tokenA3 } })
ok(cookieCors.headers.get('Access-Control-Allow-Origin') === null, '登录态经 Cookie 传递时同样不回 ACAO')
const secHeaders = ['X-Content-Type-Options', 'X-Frame-Options', 'Referrer-Policy', 'Content-Security-Policy', 'Strict-Transport-Security']
for (const h of secHeaders) ok(sameCors.headers.get(h) !== null, '响应含安全头 ' + h)
ok(String(sameCors.headers.get('Content-Security-Policy')).includes("frame-ancestors 'none'"), 'CSP 禁止被嵌套（frame-ancestors none）')
const pageRes = await call('/console')
ok(pageRes.headers.get('X-Frame-Options') === 'DENY' && pageRes.headers.get('X-Content-Type-Options') === 'nosniff', 'HTML 页面同样带安全响应头')
const optRes = await call('/api/overview', { method: 'OPTIONS', headers: { Origin: 'https://evil.example.com', Authorization: 'Bearer x' } })
ok(optRes.status === 204 && optRes.headers.get('Access-Control-Allow-Origin') === null, '预检请求也不为跨站来源背书（204 且无 ACAO）')

/* ---------------------------------------------------------- I. 审计链验真 */
section('I. 审计链验真：代理 403 / 超管 200 链路完整 / 篡改立即暴露')
ok((await call('/api/audit/verify', { token: tokenA3 })).status === 403, '代理调用审计验真被拒（403）')
const v1 = await call('/api/audit/verify', { token: tokenSuper })
ok(v1.status === 200 && v1.json.ok === true && v1.json.bad === 0 && v1.json.checked > 0,
  '超管验真：链路完整、无异常记录', { checked: v1.json && v1.json.checked, bad: v1.json && v1.json.bad })
const auditKeys = Array.from(ENV.KBZ_GATEWAY._dump().keys()).filter((k) => k.startsWith('audit:')).sort()
ok(auditKeys.length === v1.json.total, '验真覆盖全部审计记录（无遗漏）', { keys: auditKeys.length, total: v1.json.total })
// 篡改：改一条中间记录的 detail（保留原哈希）→ 必须被验真发现
const victimKey = auditKeys[Math.floor(auditKeys.length / 2)]
const victim = await kvGet(victimKey)
victim.detail = Object.assign({}, victim.detail, { tampered: 'by-t10-test' })
await ENV.KBZ_GATEWAY.put(victimKey, victim)
const v2 = await call('/api/audit/verify', { token: tokenSuper })
ok(v2.json.ok === false && v2.json.bad >= 1 && !!v2.json.firstBad && v2.json.firstBad.seq === victim.seq,
  '被篡改的记录在下次验真时立刻暴露（ok=false + 定位首个异常）', v2.json && { bad: v2.json.bad, firstBad: v2.json.firstBad })
// 删除一条中间记录 → 同样必须暴露
const victim2 = await kvGet(auditKeys[Math.floor(auditKeys.length / 3)])
await ENV.KBZ_GATEWAY.delete(auditKeys[Math.floor(auditKeys.length / 3)])
const v3 = await call('/api/audit/verify', { token: tokenSuper })
ok(v3.json.ok === false && v3.json.bad >= 1, '记录被删除同样暴露（链断裂）', { bad: v3.json && v3.json.bad, seq: victim2 && victim2.seq })
ok(v3.json.checked === auditKeys.length - 1, '验真计数与实际记录数一致（缺一条即少一条）', { checked: v3.json.checked })

/* ---------------------------------------------------------- J. 5xx 脱敏 */
section('J. 5xx 错误脱敏：默认只回关联号并写审计，开关打开后才回原文')
const err1 = await call('/api/settings', { method: 'PUT', token: tokenSuper, body: 'null' })
ok(err1.status === 500 && String(err1.json.error).includes('服务器内部错误') && !!err1.json.errorId,
  '默认脱敏：内部异常只回统一文案 + 关联号（500）', err1.json)
ok(!String(err1.json.error).includes('Cannot read') && err1.json.detail === undefined, '默认不回内部异常原文与细节')
const errLog = (await call('/api/audit?limit=50', { token: tokenSuper })).json.logs
const errRec = errLog.find((l) => l.action === 'error.5xx' && l.detail && l.detail.errorId === err1.json.errorId)
ok(!!errRec && String(errRec.detail.real).length > 0 && errRec.detail.path === '/api/settings',
  '真实原因写入审计（含关联号 / 路径），超管可据关联号排查', errRec && errRec.detail)
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { exposeErrorDetail: true } })
const err2 = await call('/api/settings', { method: 'PUT', token: tokenSuper, body: 'null' })
ok(err2.status === 500 && String(err2.json.error).includes('Cannot read'), '排障开关打开后回传内部异常原文（便于定位）', err2.json)
const err3 = await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { exposeErrorDetail: false } })
ok(err3.status === 200, '排障开关可再关闭（避免长期外泄）')
const err4 = await call('/api/settings', { method: 'PUT', token: tokenSuper, body: 'null' })
ok(err4.status === 500 && !String(err4.json.error).includes('Cannot read'), '关闭后恢复脱敏')
void err2

/* ---------------------------------------------------------- K. 登录失败锁定 */
section('K. 登录防爆破：达到上限按「账号 + 来源 IP」锁定并返回 429')
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { loginMaxAttempts: 3, loginLockSec: 60 } })
const beforeLock = (await call('/api/auth/login', { method: 'POST', body: { username: 'agent_a', password: 'wrong-pass' } })).status
ok(beforeLock === 401, '口令错误返回 401')
await call('/api/auth/login', { method: 'POST', body: { username: 'agent_a', password: 'wrong-pass' } })
await call('/api/auth/login', { method: 'POST', body: { username: 'agent_a', password: 'wrong-pass' } })
const locked = await call('/api/auth/login', { method: 'POST', body: { username: 'agent_a', password: 'wrong-pass' } })
ok(locked.status === 429 && String(locked.json.error).includes('登录失败次数过多'), '达到上限后锁定并提示剩余秒数（429）', locked.json)
const lockedRight = await call('/api/auth/login', { method: 'POST', body: { username: 'agent_a', password: 'AgentA@12345' } })
ok(lockedRight.status === 429, '锁定期间即使口令正确也拒绝（防止在线猜解）')
const otherIp = await call('/api/auth/login', { method: 'POST', body: { username: 'agent_a', password: 'AgentA@12345' }, headers: { 'CF-Connecting-IP': '198.51.100.9' } })
ok(otherIp.status === 200, '锁定按「账号 + 来源 IP」维度，不影响其他 IP 正常登录（避免全网误锁）')
const richAcc = (await call('/api/accounts', { method: 'POST', token: tokenSuper, body: { role: 'merchant', username: 'rich_agent_check', password: 'Rich@123456', name: '审计账号' } })).json.account
ok(!!richAcc, '账户创建接口可用（锁定测试用独立账号，不污染其他用例）')
const auditFail = (await call('/api/audit?limit=200', { token: tokenSuper })).json.logs
ok(auditFail.some((l) => l.action === 'auth.login.fail'), '登录失败写入审计（auth.login.fail，口令本身绝不落库）')

/* ---------------------------------------------------------- L. 设置白名单与密钥防线 */
section('L. 设置白名单：新增安全键可写入生效、未登记键被忽略；密钥类字段不外泄')
const setW = await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { sessionTtlSec: 3600, bogusKey: 'x' } })
ok(setW.status === 200, '写入设置成功')
const cfgW = Object.assign({}, (await call('/api/settings', { token: tokenSuper })).json.raw, (await call('/api/settings', { token: tokenSuper })).json.config)
ok(cfgW.sessionTtlSec === 3600, '新增键 sessionTtlSec 生效（会话有效期可调）', { v: cfgW.sessionTtlSec })
ok(cfgW.bogusKey === undefined, '未登记键被忽略（白名单外不可写入）')
ok(cfgW.loginMaxAttempts === 3 && cfgW.loginLockSec === 60, '登录锁定策略可由后台调整')
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { sessionTtlSec: 43200, loginMaxAttempts: 6, loginLockSec: 900 } })
const setPlain = await call('/api/settings', { token: tokenA3 })
ok(setPlain.status === 403, '非超管修改系统设置被拒（403）')
const cfgPub = (await call('/api/config')).json.config
ok(cfgPub.deviceKey === undefined && cfgPub.plugSecret === undefined && cfgPub.internalSecret === undefined,
  '公开配置不泄露设备密钥 / 接入密钥等内部凭据')

/* ---------------------------------------------------------- M. 接入面加固 */
section('M. 接入面加固：公开入口按 IP 限流 / 请求体上限 / 批量条数上限 / 列表条数夹取 / 凭据不外泄')
// 把公开面上限调到 2 次/分钟，用三个互不相干的来源 IP 分别验三个公开入口，验证「按入口 + IP」独立计数、不误伤他 IP
await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { publicRateLimitPerMin: 2 } })
const ip1 = { 'CF-Connecting-IP': '198.51.100.11' }
const p1 = await call('/api/pay/status/ORDX', { headers: Object.assign({ 'X-Merchant-Key': 'mk_bogus' }, ip1) })
const p2 = await call('/api/pay/status/ORDX', { headers: Object.assign({ 'X-Merchant-Key': 'mk_bogus' }, ip1) })
const p3 = await call('/api/pay/status/ORDX', { headers: Object.assign({ 'X-Merchant-Key': 'mk_bogus' }, ip1) })
ok(p1.status === 401 && p2.status === 401, '商户密钥查询：额度内正常按业务返回（401 无效密钥）', { a: p1.status, b: p2.status })
ok(p3.status === 429, '商户密钥查询：超过公开面每分钟上限立即 429（挡住密钥枚举）', { v: p3.status })
const pOther = await call('/api/pay/status/ORDX', { headers: { 'X-Merchant-Key': 'mk_bogus', 'CF-Connecting-IP': '198.51.100.99' } })
ok(pOther.status === 401, '限流按来源 IP 独立计数：换来源 IP 立即恢复放行（不误伤正常用户）', { v: pOther.status })

const ip2 = { 'CF-Connecting-IP': '198.51.100.12' }
const d1 = await call('/api/payout/executor/pull', { headers: Object.assign({}, ip2) })
const d2 = await call('/api/payout/executor/pull', { headers: Object.assign({ 'X-Device-Key': 'dk_bogus', }, ip2) })
const d3 = await call('/api/payout/executor/pull', { headers: Object.assign({ 'X-Device-Key': 'dk_bogus' }, ip2) })
const d4 = await call('/api/payout/executor/pull', { headers: Object.assign({ 'X-Device-Key': 'dk_bogus' }, ip2) })
ok(d1.status === 401 && d2.status === 401, '设备端（含 GET 拉取）：额度内按业务返回 401（缺/错设备密钥）', { a: d1.status, b: d2.status })
ok(d3.status === 429 && d4.status === 429, '设备端 GET 拉取同样受限流保护：超限 429（挡住设备密钥枚举）', { c: d3.status, d: d4.status })

const ip3 = { 'CF-Connecting-IP': '198.51.100.13' }
{ let got = 0
  for (let i = 0; i < 4; i++) {
    const r = await call('/api/auth/login', { method: 'POST', body: { username: 'nobody_xyz', password: 'x' }, headers: ip3 })
    if (r.status === 429) { got = r.status; break }
  }
  ok(got === 429, '登录入口按来源 IP 限流：连续试探被 429（挡住换账号喷洒绕过账号级锁定）', { v: got }) }

await call('/api/settings', { method: 'PUT', token: tokenSuper, body: { publicRateLimitPerMin: 240 } })

// 请求体体积上限：Content-Length 超限在路由之前就被拒
const huge = JSON.stringify({ rows: [{ note: 'x'.repeat(3 * 1024 * 1024) }] })
const big = await call('/api/reconcile/ingest', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: huge })
ok(big.status === 413 && String(big.json.error).indexOf('请求体过大') >= 0, '超大请求体（3MB）被拒（413 请求体过大）', { s: big.status, e: big.json.error })
// 批量条数上限：单请求塞入海量流水会被拒，避免打满边缘算力 / KV 写入
const many = []
for (let i = 0; i < 250; i++) many.push({ receiverAccount: '09970000999', amount: 1000 + i, txid: 'T10BULK' + i })
const bulk = await call('/api/reconcile/ingest', { method: 'POST', headers: { 'X-Device-Key': ENV.DEVICE_KEY }, body: { rows: many } })
ok(bulk.status === 413 && String(bulk.json.error).indexOf('单次上报条数超限') >= 0, '单次上报 250 条（>上限 200）被拒（413 条数超限）', { s: bulk.status, e: bulk.json.error })

// 列表条数夹取：超大 limit 被夹到安全上限而不致读放大
const bigLimit = await call('/api/audit?limit=999999', { token: tokenSuper })
ok(bigLimit.status === 200 && Array.isArray(bigLimit.json.logs) && bigLimit.json.logs.length <= 2000,
  '超大 limit 被夹到安全上限（200 + 数组，条数 ≤ 2000，不因读放大挂掉）', { s: bigLimit.status, n: bigLimit.json && bigLimit.json.logs && bigLimit.json.logs.length })
// 超长 token 截断：异常超长串不会被当作超长 KV 键
const longTok = await call('/api/auth/me', { headers: { Authorization: 'Bearer ' + 'a'.repeat(5000) } })
ok(longTok.status === 401, '超长 token（5000 字符）被截断后按未登录处理（401，而非 5xx / 超长键）', { v: longTok.status })

const cfgPub2 = (await call('/api/config')).json.config
ok(cfgPub2.publicRateLimitPerMin === undefined, '公开配置不回显内部限流参数（仅超管可见）')

// 凭据不外泄：新建设备密钥仅在创建响应里回显一次，库里只存哈希，列表只给掩码
const devNew = (await call('/api/devices', { method: 'POST', token: tokenSuper, body: { type: 'payout', label: 'T10设备' } })).json.device
ok(!!devNew && !!devNew.keyPlain && /^dk_/.test(devNew.keyPlain), '创建设备：明文密钥仅在创建响应里回显一次（keyPlain）')
const devList = (await call('/api/devices', { token: tokenSuper })).json.devices
const row = devList.find((x) => x.id === devNew.id)
ok(!!row && row.keyMasked && row.keyPlain === undefined && row.keyHash === undefined, '设备列表只回显掩码密钥，不返回明文 / 哈希')
const dump = JSON.stringify(ENV.KBZ_GATEWAY._dump())
ok(dump.indexOf(devNew.keyPlain) === -1, '全库扫描：设备明文密钥不落库（只存哈希索引）')
const devAudit = (await call('/api/audit?limit=200', { token: tokenSuper })).json.logs.filter((l) => l.action === 'device.create')
ok(devAudit.length >= 1 && JSON.stringify(devAudit).indexOf(devNew.keyPlain) === -1, '审计日志记录设备创建但不落明文密钥')

/* ---------------------------------------------------------- 小结 */
console.log('\n====================================================')
console.log('通过 ' + passed + ' 项，失败 ' + failures.length + ' 项')
if (failures.length) {
  console.log('\n失败明细：')
  failures.forEach(function (f, i) { console.log('  ' + (i + 1) + '. ' + f) })
  process.exit(1)
}
console.log('T10 全部通过：业务闭环补齐项与安全加固项均可跑通（含失败路径）')