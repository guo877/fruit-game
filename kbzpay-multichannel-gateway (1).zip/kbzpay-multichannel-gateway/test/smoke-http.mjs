/**
 * 本地 HTTP 冒烟（node test/smoke-http.mjs）
 * ---------------------------------------------------------------------------
 * 与 e2e-test.mjs 不同：本脚本会真实启动一个 HTTP 服务进程（dev-server.mjs），
 * 通过真实网络请求走通「下单 → 自动收款核销 → 自动发货 → 买家取凭据 → 确认收货 → 转款到户」。
 * 用途：验证 Worker 入口在真实 HTTP 层可用（不依赖任何云账号）。
 */
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)))
const PORT = Number(process.env.PORT || 8899)
const BASE = 'http://127.0.0.1:' + PORT
const DEVICE_KEY = 'dev-device-key-0001'

let pass = 0
const fail = []
function ok(c, l, extra) { if (c) { pass++; console.log('  \u2713 ' + l) } else { fail.push(l + (extra ? ' → ' + JSON.stringify(extra) : '')); console.log('  \u2717 ' + l + (extra ? ' → ' + JSON.stringify(extra) : '')) } }
async function j(p, opt = {}) {
  const r = await fetch(BASE + p, {
    method: opt.method || 'GET',
    headers: Object.assign({ 'content-type': 'application/json' }, opt.headers || {}),
    body: opt.body !== undefined ? (typeof opt.body === 'string' ? opt.body : JSON.stringify(opt.body)) : undefined,
  })
  const text = await r.text()
  let json = null
  try { json = JSON.parse(text) } catch (e) { json = null }
  return { status: r.status, json, text }
}
async function waitAlive(tries = 40) {
  for (let i = 0; i < tries; i++) {
    try { const r = await fetch(BASE + '/health'); if (r.ok) return true } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 150))
  }
  return false
}

const srv = spawn(process.execPath, ['dev-server.mjs'], { cwd: ROOT, env: Object.assign({}, process.env, { PORT: String(PORT) }), stdio: 'ignore' })
let exited = false
srv.on('exit', () => { exited = true })
try {
  ok(await waitAlive(), '本地服务启动并存活（/health）')
  ok((await j('/')).text.indexOf('KBZPay') > 0, 'GET / 落地页返回')
  ok((await j('/console')).text.indexOf('kbz_token') > 0, 'GET /console 后台返回')
  ok((await j('/sdk.js')).text.indexOf('KBZPay') > 0, 'GET /sdk.js 一行接入 SDK 返回')
  ok((await j('/admin')).text.indexOf('首次设密') > 0, 'GET /admin 首次设密入口')
  ok((await j('/api/setup/status')).json.initialized === false, '初始超管尚未设密')

  const setup = await j('/api/setup/admin', { method: 'POST', body: { username: 'superadmin', password: 'Smoke@2026', confirm: 'Smoke@2026' } })
  ok(!!setup.json.token, '超管首次设密并签发登录态', setup.json)
  const tokenSuper = setup.json.token

  const agent = (await j('/api/accounts', { method: 'POST', headers: { Authorization: 'Bearer ' + tokenSuper }, body: { role: 'agent', username: 'agent_s', password: 'AgentS@123', name: '冒烟代理', depositRequired: 1000000 } })).json.account
  ok(agent && agent.role === 'agent', '超管创建代理')
  const tokenA = (await j('/api/auth/login', { method: 'POST', body: { username: 'agent_s', password: 'AgentS@123' } })).json.token
  ok(!!tokenA, '代理登录')
  ok((await j('/api/channels', { method: 'POST', headers: { Authorization: 'Bearer ' + tokenA }, body: { account: '09971110001', holder: '冒烟代理账户', primary: true } })).json.channel.status === 'active', '代理自建 KBZ 通道')
  ok((await j('/api/pool/accounts', { method: 'POST', headers: { Authorization: 'Bearer ' + tokenSuper }, body: { accounts: [{ account: '09970000222', holder: '资金池' }] } })).json.success === true, '超管配置资金池账户')
  ok((await j('/api/pool/deposit', { method: 'POST', headers: { Authorization: 'Bearer ' + tokenSuper }, body: { agentId: agent.id, amount: 1000000 } })).json.deposit.paid === 1000000, '超管登记代理保证金')

  // 电商闭环：下单（带卡密）→ 到账自动发货 → 买家取凭据 → 确认收货 → 转款到户
  const ord = (await j('/api/orders', { method: 'POST', headers: { Authorization: 'Bearer ' + tokenA }, body: { amount: 5000, scene: 'ecommerce', subject: '冒烟电商订单', cardSecret: 'SMOKE-CARD-0001' } })).json.order
  ok(ord && !!ord.payUrl, '下单并分配金额识别码（payUrl 可用）')
  const notify = await j('/api/notify/forward', { method: 'POST', headers: { 'X-Device-Key': DEVICE_KEY }, body: { receiverAccount: '09971110001', amount: ord.payable, txid: 'SMOKE0001' } })
  ok(notify.json.results[0].status === 'paid', '到账通知自动核销（paid）', notify.json)
  const afterPay = (await j('/api/orders/' + ord.orderId, { headers: { Authorization: 'Bearer ' + tokenA } })).json.order
  ok(afterPay.status === 'paid' && afterPay.stage === 'delivered', '电商订单到账即自动发货（stage=delivered）')
  ok((await j('/api/pay/delivery?t=' + ord.token)).json.order.deliveryView.cardSecret === 'SMOKE-CARD-0001', '买家在收银台取到明文卡密（受限明文）')
  ok((await j('/api/stats', { headers: { Authorization: 'Bearer ' + tokenA } })).json.stats.escrow === 5000, '货款进入托管余额（待收货）')
  const recv = await j('/api/pay/receive', { method: 'POST', body: { token: ord.token } })
  ok(recv.json.success && recv.json.order.stage === 'settled', '买家确认收货 → 托管款自动转款到户')
  ok((await j('/api/stats', { headers: { Authorization: 'Bearer ' + tokenA } })).json.stats.balance === 5000, '商户可用余额 +5,000 MMK')
} finally {
  if (!exited) srv.kill('SIGTERM')
}

console.log('\n通过 ' + pass + ' 项，失败 ' + fail.length + ' 项')
if (fail.length) { fail.forEach((f) => console.log(' - ' + f)); process.exit(1) }
console.log('本地 HTTP 冒烟全部通过 ✔')
process.exit(0)